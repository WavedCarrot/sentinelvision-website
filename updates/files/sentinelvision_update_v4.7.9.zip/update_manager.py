"""
System Update Manager
Handles code updates while preserving user data and configurations
"""
import os
import shutil
import zipfile
import json
import logging
from datetime import datetime
from pathlib import Path

logger = logging.getLogger(__name__)

# Licensing server — used to fetch the zip decryption password for encrypted packages
_RAILWAY_BASE = "https://sentinelvision-licensing-production.up.railway.app"

class UpdateManager:
    """Manages system updates without affecting user data"""
    
    PROTECTED_FILES = [
        'instance/sentinelvision_security.db',
        'instance/*.db',
        '.env',
        'config.py',
        'logs/*',
        'uploads/*',
        'detections/*',
        'temp/*'
    ]
    
    BACKUP_DIR = 'backups'
    VERSION_FILE = 'version.json'
    
    @classmethod
    def get_current_version(cls):
        """Get current system version"""
        try:
            if os.path.exists(cls.VERSION_FILE):
                with open(cls.VERSION_FILE, 'r', encoding='utf-8') as f:
                    version_data = json.load(f)
                    return version_data.get('version', '1.0.0')
            return '1.0.0'
        except Exception as e:
            logger.error(f"Error reading version: {e}")
            return '1.0.0'
    
    @classmethod
    def get_version_info(cls):
        """Get detailed version information"""
        try:
            if os.path.exists(cls.VERSION_FILE):
                with open(cls.VERSION_FILE, 'r', encoding='utf-8') as f:
                    return json.load(f)
            return {
                'version': '1.0.0',
                'updated_at': None,
                'changes': []
            }
        except Exception as e:
            logger.error(f"Error reading version info: {e}")
            return {'version': '1.0.0', 'updated_at': None, 'changes': []}
    
    MAX_BACKUPS = 3  # Keep only the last N backups to prevent disk fill on RPi

    @classmethod
    def _fetch_zip_password(cls) -> bytes:
        """
        Fetch the AES-256 zip decryption password from the licensing server.
        Returns the password as bytes, or raises RuntimeError if unavailable.
        """
        import urllib.request as _ur
        import json as _j
        try:
            from license_manager import get_device_serial
            serial = get_device_serial()
        except Exception:
            serial = "UNKNOWN"
        try:
            payload = _j.dumps({"device_serial": serial}).encode()
            req = _ur.Request(
                f"{_RAILWAY_BASE}/api/zip-password",
                data    = payload,
                headers = {"Content-Type": "application/json"},
                method  = "POST",
            )
            with _ur.urlopen(req, timeout=10) as resp:
                result = _j.loads(resp.read())
            pwd = result.get("password", "")
            if not pwd:
                raise RuntimeError("Server returned an empty password")
            return pwd.encode("utf-8")
        except Exception as e:
            raise RuntimeError(
                f"Could not retrieve update decryption key from server: {e}\n"
                "Check your internet connection and try again."
            )

    @classmethod
    def _open_zip(cls, zip_path):
        """
        Open an update package transparently — works for both plain and
        AES-256 encrypted zips (pyzipper).  Returns an open ZipFile-like
        object; use in a 'with' statement so it is closed properly.
        """
        # Try standard library first (unencrypted zips)
        zf = zipfile.ZipFile(zip_path, 'r')
        try:
            names = zf.namelist()
            if names:
                zf.open(names[0], 'r').read(1)  # quick read to detect AES encryption
            return zf  # plain zip — return as-is
        except RuntimeError:
            zf.close()  # AES-256 — standard library can't handle it

        # AES-256 encrypted — need pyzipper
        try:
            import pyzipper
        except ImportError:
            raise RuntimeError(
                "This update package is encrypted but pyzipper is not installed.\n"
                "Run: pip install pyzipper"
            )
        pwd = cls._fetch_zip_password()
        zf2 = pyzipper.AESZipFile(zip_path, 'r')
        zf2.setpassword(pwd)
        logger.info("Opened encrypted update package")
        return zf2

    @classmethod
    def create_backup(cls):
        """Create backup of current version before update"""
        try:
            timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
            backup_path = os.path.join(cls.BACKUP_DIR, f'backup_{timestamp}')
            os.makedirs(backup_path, exist_ok=True)
            
            # Backup Python files and templates
            for item in os.listdir('.'):
                if item.endswith('.py'):
                    shutil.copy2(item, backup_path)
            
            # Backup templates
            if os.path.exists('templates'):
                shutil.copytree('templates', os.path.join(backup_path, 'templates'), dirs_exist_ok=True)
            
            # Backup static files
            if os.path.exists('static'):
                shutil.copytree('static', os.path.join(backup_path, 'static'), dirs_exist_ok=True)
            
            logger.info(f"Backup created at {backup_path}")

            # Prune old backups — keep only the most recent MAX_BACKUPS
            cls._prune_old_backups()

            return backup_path
        except Exception as e:
            logger.error(f"Error creating backup: {e}")
            raise

    @classmethod
    def _prune_old_backups(cls):
        """Remove oldest backup folders so we never keep more than MAX_BACKUPS."""
        try:
            if not os.path.exists(cls.BACKUP_DIR):
                return
            backups = sorted([
                os.path.join(cls.BACKUP_DIR, d)
                for d in os.listdir(cls.BACKUP_DIR)
                if os.path.isdir(os.path.join(cls.BACKUP_DIR, d)) and d.startswith('backup_')
            ])
            while len(backups) > cls.MAX_BACKUPS:
                oldest = backups.pop(0)
                shutil.rmtree(oldest, ignore_errors=True)
                logger.info(f"Removed old backup: {oldest}")
        except Exception as e:
            logger.warning(f"Backup pruning error: {e}")
    
    @classmethod
    def validate_update_package(cls, zip_path):
        """Validate update package structure"""
        try:
            with cls._open_zip(zip_path) as zip_file:
                file_list = zip_file.namelist()
                
                # Must contain version.json
                if 'version.json' not in file_list:
                    return False, "Missing version.json in update package"
                
                # Read version info
                with zip_file.open('version.json') as f:
                    version_data = json.loads(f.read())
                    new_version = version_data.get('version')
                    
                    if not new_version:
                        return False, "Invalid version.json"
                
                # Check for protected files
                for protected in cls.PROTECTED_FILES:
                    if protected in file_list:
                        return False, f"Update package contains protected file: {protected}"
                
                return True, f"Valid update package (v{new_version})"
        except Exception as e:
            return False, f"Invalid update package: {str(e)}"
    
    @classmethod
    def apply_update(cls, zip_path):
        """Apply update from zip package"""
        try:
            # Validate package
            is_valid, message = cls.validate_update_package(zip_path)
            if not is_valid:
                raise ValueError(message)
            
            # Create backup
            backup_path = cls.create_backup()
            logger.info(f"Backup created: {backup_path}")
            
            # Extract update
            with cls._open_zip(zip_path) as zip_file:
                # Get version info first
                with zip_file.open('version.json') as f:
                    version_data = json.loads(f.read())
                
                # Extract files (excluding protected ones)
                app_root = os.path.abspath('.')
                for file_info in zip_file.filelist:
                    filename = file_info.filename
                    
                    # Skip protected files
                    if any(Path(filename).match(pattern) for pattern in cls.PROTECTED_FILES):
                        continue
                    
                    # Block path traversal — ensure target stays inside project root
                    target_path = os.path.abspath(os.path.join('.', filename))
                    if not target_path.startswith(app_root + os.sep) and target_path != app_root:
                        logger.warning(f"Blocked unsafe path in update package: {filename}")
                        continue
                    
                    # Extract file
                    zip_file.extract(filename, '.')
                    logger.info(f"Updated: {filename}")
            
            # Update version file
            version_data['updated_at'] = datetime.utcnow().isoformat()
            with open(cls.VERSION_FILE, 'w') as f:
                json.dump(version_data, f, indent=2)
            
            # Run post-install script if present
            if os.path.exists('post_install.py'):
                try:
                    import subprocess, sys
                    logger.info("Running post_install.py...")
                    subprocess.run([sys.executable, 'post_install.py'], check=False)
                    logger.info("post_install.py completed")
                except Exception as pi_err:
                    logger.warning(f"post_install.py warning: {pi_err}")
            
            logger.info(f"Update applied successfully to v{version_data['version']}")
            return True, version_data
        except Exception as e:
            logger.error(f"Error applying update: {e}")
            raise
    
    @classmethod
    def rollback_to_backup(cls, backup_path):
        """Rollback to a previous backup"""
        try:
            # Restore Python files
            for item in os.listdir(backup_path):
                src = os.path.join(backup_path, item)
                if os.path.isfile(src):
                    shutil.copy2(src, '.')
                else:
                    # Directory (templates, static)
                    if os.path.exists(item):
                        shutil.rmtree(item)
                    shutil.copytree(src, item)
            
            logger.info(f"Rollback successful from {backup_path}")
            return True
        except Exception as e:
            logger.error(f"Error during rollback: {e}")
            raise
    
    @classmethod
    def list_backups(cls):
        """List available backups"""
        try:
            if not os.path.exists(cls.BACKUP_DIR):
                return []
            
            backups = []
            for item in os.listdir(cls.BACKUP_DIR):
                backup_path = os.path.join(cls.BACKUP_DIR, item)
                if os.path.isdir(backup_path):
                    stat = os.stat(backup_path)
                    backups.append({
                        'name': item,
                        'path': backup_path,
                        'created': datetime.fromtimestamp(stat.st_ctime).isoformat(),
                        'size': sum(os.path.getsize(os.path.join(backup_path, f)) 
                                   for f in os.listdir(backup_path) if os.path.isfile(os.path.join(backup_path, f)))
                    })
            
            return sorted(backups, key=lambda x: x['created'], reverse=True)
        except Exception as e:
            logger.error(f"Error listing backups: {e}")
            return []
    
    @classmethod
    def create_update_package(cls, version, changes, output_path):
        """Create an update package (for developers)"""
        try:
            # Create version info
            version_data = {
                'version': version,
                'created_at': datetime.utcnow().isoformat(),
                'changes': changes
            }
            
            with zipfile.ZipFile(output_path, 'w', zipfile.ZIP_DEFLATED) as zip_file:
                # Add version.json first (skip the existing one in file system)
                zip_file.writestr('version.json', json.dumps(version_data, indent=2))
                
                # Add Python files (exclude protected)
                for root, dirs, files in os.walk('.'):
                    # Skip protected and unnecessary directories
                    dirs[:] = [d for d in dirs if d not in [
                        'instance', 'logs', 'uploads', 'detections', 'temp', 'backups', 
                        '__pycache__', '.git', 'venv', '.venv', 'path', 'to',
                        'sentinelvision_raspberry_pi_version', 'node_modules', '.idea', '.vscode'
                    ]]
                    
                    for file in files:
                        # Skip version.json (we already added it), zip files, and pycache
                        if file == 'version.json' or file.endswith('.zip') or file.endswith('.pyc'):
                            continue
                            
                        if file.endswith(('.py', '.html', '.css', '.js', '.json', '.txt', '.md', '.pt', '.sh', '.bat', '.service')):
                            file_path = os.path.join(root, file)
                            arcname = os.path.relpath(file_path, '.')
                            
                            # Skip protected files
                            if any(Path(arcname).match(pattern) for pattern in cls.PROTECTED_FILES):
                                continue
                            
                            zip_file.write(file_path, arcname)
                            logger.info(f"  Added: {arcname}")
            
            logger.info(f"Update package created: {output_path}")
            return True
        except Exception as e:
            logger.error(f"Error creating update package: {e}")
            raise
