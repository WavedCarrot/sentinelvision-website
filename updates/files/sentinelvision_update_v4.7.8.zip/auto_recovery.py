"""
Auto-Recovery Service for SentinelVision
Monitors and automatically restarts crashed services
"""
import os
import sys
import time
import subprocess
import logging
import threading
from datetime import datetime, timedelta

logger = logging.getLogger(__name__)


class AutoRecoveryService:
    """
    Monitor and auto-recover crashed services:
    - Detection engine threads
    - Camera connections
    - Telegram bot
    - Database connections
    """
    
    def __init__(self, app=None, detection_engine=None, telegram_service=None):
        self.app = app
        self.detection_engine = detection_engine
        self.telegram_service = telegram_service
        
        self.running = False
        self.check_interval = 30  # seconds
        self.thread = None
        
        # Failure tracking
        self.failure_counts = {
            'detection_engine': 0,
            'telegram': 0,
            'database': 0,
            'camera': {}
        }
        
        self.max_failures = 5  # Max failures before alerting
        self.last_health_report = None
    
    def start(self):
        """Start auto-recovery monitoring"""
        if self.running:
            return
        
        self.running = True
        self.thread = threading.Thread(target=self._monitor_loop, daemon=True)
        self.thread.start()
        logger.info("🔄 Auto-recovery service started")
    
    def stop(self):
        """Stop auto-recovery monitoring"""
        self.running = False
        if self.thread:
            self.thread.join(timeout=5)
        logger.info("🔄 Auto-recovery service stopped")
    
    def _monitor_loop(self):
        """Main monitoring loop"""
        while self.running:
            try:
                self._check_detection_engine()
                self._check_telegram_service()
                self._check_database()
                self._check_camera_threads()
                self._send_periodic_health_report()
            except Exception as e:
                logger.error(f"Auto-recovery check error: {e}")
            
            time.sleep(self.check_interval)
    
    def _check_detection_engine(self):
        """Check if detection engine is running"""
        if not self.detection_engine:
            return
        
        try:
            if not self.detection_engine.running:
                self.failure_counts['detection_engine'] += 1
                logger.warning(f"⚠️ Detection engine not running (failures: {self.failure_counts['detection_engine']})")
                
                if self.failure_counts['detection_engine'] >= self.max_failures:
                    self._restart_detection_engine()
            else:
                self.failure_counts['detection_engine'] = 0
        except Exception as e:
            logger.error(f"Detection engine check error: {e}")
    
    def _restart_detection_engine(self):
        """Attempt to restart detection engine"""
        try:
            logger.info("🔄 Attempting to restart detection engine...")
            
            if self.detection_engine:
                # Stop and restart
                self.detection_engine.stop()
                time.sleep(2)
                self.detection_engine.start()
                
                self.failure_counts['detection_engine'] = 0
                logger.info("✅ Detection engine restarted successfully")
                
                # Alert via Telegram
                if self.telegram_service:
                    self.telegram_service.send_message(
                        "🔄 <b>Auto-Recovery</b>\n\n"
                        "Detection engine was not responding and has been restarted."
                    )
        except Exception as e:
            logger.error(f"Failed to restart detection engine: {e}")
    
    def _check_telegram_service(self):
        """Check if Telegram service is responsive"""
        if not self.telegram_service:
            return
        
        try:
            # Simple ping check
            if hasattr(self.telegram_service, 'is_running'):
                if not self.telegram_service.is_running():
                    self.failure_counts['telegram'] += 1
                    logger.warning(f"⚠️ Telegram service not running (failures: {self.failure_counts['telegram']})")
                    
                    if self.failure_counts['telegram'] >= self.max_failures:
                        self._restart_telegram_service()
                else:
                    self.failure_counts['telegram'] = 0
        except Exception as e:
            logger.error(f"Telegram check error: {e}")
    
    def _restart_telegram_service(self):
        """Attempt to restart Telegram service"""
        try:
            logger.info("🔄 Attempting to restart Telegram service...")
            
            if self.telegram_service:
                if hasattr(self.telegram_service, 'restart'):
                    self.telegram_service.restart()
                elif hasattr(self.telegram_service, 'start_polling'):
                    self.telegram_service.start_polling()
                
                self.failure_counts['telegram'] = 0
                logger.info("✅ Telegram service restarted")
        except Exception as e:
            logger.error(f"Failed to restart Telegram: {e}")
    
    def _check_database(self):
        """Check database connectivity"""
        if not self.app:
            return
        
        try:
            with self.app.app_context():
                from models import db, SystemConfig
                # Simple query to test connection
                config = SystemConfig.query.first()
                if config:
                    self.failure_counts['database'] = 0
        except Exception as e:
            self.failure_counts['database'] += 1
            logger.error(f"Database check failed: {e}")
    
    def _check_camera_threads(self):
        """Check if camera processing threads are alive and processing frames"""
        if not self.detection_engine:
            return
        
        try:
            threads = getattr(self.detection_engine, 'threads', {})
            heartbeats = getattr(self.detection_engine, 'camera_heartbeats', {})
            
            for camera_id, thread in list(threads.items()):  # copy to avoid RuntimeError on concurrent modification
                if camera_id not in self.failure_counts['camera']:
                    self.failure_counts['camera'][camera_id] = 0

                thread_dead = not thread.is_alive()

                # A thread that is alive() but stuck in cap.read() on a stalled
                # RTSP connection never updates its heartbeat.  Treat it as dead
                # after 90 s without a frame — the OS-level thread will be
                # abandoned (daemon=True) and a fresh one started.
                heartbeat = heartbeats.get(camera_id, 0)
                thread_frozen = (
                    not thread_dead
                    and heartbeat > 0  # thread has started at least once
                    and (time.time() - heartbeat) > 90
                )

                if thread_dead or thread_frozen:
                    reason = "died" if thread_dead else f"frozen (no frame for {int(time.time() - heartbeat)}s)"
                    self.failure_counts['camera'][camera_id] += 1
                    logger.warning(f"⚠️ Camera {camera_id} thread {reason} (failures: {self.failure_counts['camera'][camera_id]})")
                    
                    if self.failure_counts['camera'][camera_id] >= 3:
                        self._restart_camera_thread(camera_id)
                else:
                    self.failure_counts['camera'][camera_id] = 0
        except Exception as e:
            logger.error(f"Camera thread check error: {e}")
    
    def _restart_camera_thread(self, camera_id):
        """Restart a specific camera processing thread"""
        try:
            logger.info(f"🔄 Restarting camera {camera_id} thread...")
            
            if self.detection_engine:
                # Get camera from database
                with self.app.app_context():
                    from models import Camera
                    camera = Camera.query.get(camera_id)
                    
                    if camera and camera.is_active:
                        # Remove dead/frozen thread entry so start_monitoring won't block
                        if camera_id in self.detection_engine.threads:
                            del self.detection_engine.threads[camera_id]

                        # Reset heartbeat so the next watchdog cycle doesn't immediately
                        # think the brand-new thread is frozen before it reads its first frame.
                        if hasattr(self.detection_engine, 'camera_heartbeats'):
                            self.detection_engine.camera_heartbeats.pop(camera_id, None)

                        time.sleep(1)

                        # start_monitoring creates a new thread and adds it to self.threads
                        self.detection_engine.start_monitoring(camera_id)

                        self.failure_counts['camera'][camera_id] = 0
                        logger.info(f"✅ Camera {camera_id} thread restarted")
        except Exception as e:
            logger.error(f"Failed to restart camera {camera_id}: {e}")
    
    def _send_periodic_health_report(self):
        """Send periodic health report (every 6 hours)"""
        now = datetime.utcnow()
        
        if self.last_health_report:
            if (now - self.last_health_report).total_seconds() < 6 * 3600:
                return
        
        if not self.telegram_service:
            return
        
        try:
            # Collect health stats
            import psutil
            
            cpu = psutil.cpu_percent()
            memory = psutil.virtual_memory().percent
            disk = psutil.disk_usage('/').percent if os.name != 'nt' else psutil.disk_usage('C:').percent
            
            # Temperature (Raspberry Pi)
            temp = "N/A"
            try:
                with open('/sys/class/thermal/thermal_zone0/temp', 'r') as f:
                    temp = f"{int(f.read()) / 1000:.1f}°C"
            except:
                pass
            
            # Camera status
            cameras_online = 0
            cameras_total = 0
            if self.detection_engine:
                threads = getattr(self.detection_engine, 'threads', {})
                cameras_total = len(threads)
                cameras_online = sum(1 for t in threads.values() if t.is_alive())
            
            report = (
                "📊 <b>System Health Report</b>\n\n"
                f"💻 CPU: {cpu:.1f}%\n"
                f"🧠 Memory: {memory:.1f}%\n"
                f"💾 Disk: {disk:.1f}%\n"
                f"🌡️ Temperature: {temp}\n"
                f"📷 Cameras: {cameras_online}/{cameras_total} online\n"
                f"⏰ {now.strftime('%Y-%m-%d %H:%M:%S')}"
            )
            
            self.telegram_service.send_message(report)
            self.last_health_report = now
            
        except Exception as e:
            logger.error(f"Health report error: {e}")
    
    def get_status(self):
        """Get current service status"""
        return {
            'running': self.running,
            'failure_counts': self.failure_counts,
            'last_health_report': self.last_health_report.isoformat() if self.last_health_report else None
        }


# Global instance
auto_recovery_service = None


def init_auto_recovery(app, detection_engine=None, telegram_service=None):
    """Initialize auto-recovery service"""
    global auto_recovery_service
    auto_recovery_service = AutoRecoveryService(app, detection_engine, telegram_service)
    auto_recovery_service.start()
    return auto_recovery_service


def get_auto_recovery_service():
    """Get auto-recovery service instance"""
    return auto_recovery_service
