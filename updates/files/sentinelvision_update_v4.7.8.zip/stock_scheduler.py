"""
Stock Control Scheduler
Automated tasks for stock management including daily/weekly reports and low stock alerts
"""
from apscheduler.schedulers.background import BackgroundScheduler
from stock_control import StockAnalytics, StockReportGenerator
from telegram_service import telegram_service
import logging
from datetime import datetime

logger = logging.getLogger(__name__)


def check_low_stock_alerts(app):
    """Check for low stock items and send alerts"""
    with app.app_context():
        try:
            logger.info("Checking for low stock alerts...")
            alerts = StockAnalytics.check_low_stock_alerts()
            
            # Send critical alerts
            for item in alerts['critical']:
                telegram_service.send_low_stock_alert(
                    camera_name=f"Camera #{item.camera_id}",
                    item_name=item.name,
                    current_count=item.current_count,
                    threshold_type='critical',
                    location=item.camera.location if item.camera else None
                )
                logger.warning(f"CRITICAL: {item.name} stock is critically low ({item.current_count})")
            
            # Send low stock warnings
            for item in alerts['low']:
                telegram_service.send_low_stock_alert(
                    camera_name=f"Camera #{item.camera_id}",
                    item_name=item.name,
                    current_count=item.current_count,
                    threshold_type='low',
                    location=item.camera.location if item.camera else None
                )
                logger.warning(f"LOW STOCK: {item.name} is running low ({item.current_count})")
            
            logger.info(f"Low stock check complete: {len(alerts['critical'])} critical, {len(alerts['low'])} low")
        except Exception as e:
            logger.error(f"Error checking low stock: {e}")


def send_daily_stock_report(app):
    """Generate and send daily stock report"""
    with app.app_context():
        try:
            logger.info("Generating daily stock report...")
            report = StockReportGenerator.generate_daily_report()
            
            # Only send if there are items in the report
            if report.get('items') and len(report['items']) > 0:
                # Send to Telegram
                telegram_service.send_daily_stock_report(report)
                logger.info("Daily stock report sent successfully")
            else:
                logger.info("No stock items to report, skipping daily report")
        except Exception as e:
            logger.error(f"Error sending daily stock report: {e}")


def send_weekly_stock_report(app):
    """Generate and send weekly stock report"""
    with app.app_context():
        try:
            logger.info("Generating weekly stock report...")
            report = StockReportGenerator.generate_weekly_report()
            
            # Only send if there are items in the report
            if report.get('items') and len(report['items']) > 0:
                # Send to Telegram
                telegram_service.send_weekly_stock_report(report)
                logger.info("Weekly stock report sent successfully")
            else:
                logger.info("No stock items to report, skipping weekly report")
        except Exception as e:
            logger.error(f"Error sending weekly stock report: {e}")


def update_all_stock_analytics(app):
    """Update analytics for all stock items"""
    with app.app_context():
        try:
            from models import StockItem
            
            logger.info("Updating stock analytics...")
            items = StockItem.query.all()
            
            for item in items:
                StockAnalytics.update_stock_item_analytics(item.id)
            
            logger.info(f"Updated analytics for {len(items)} stock items")
        except Exception as e:
            logger.error(f"Error updating stock analytics: {e}")


def start_stock_scheduler(app):
    """Start the stock control scheduler"""
    scheduler = BackgroundScheduler()
    
    # Check for low stock every hour
    scheduler.add_job(
        func=lambda: check_low_stock_alerts(app),
        trigger='interval',
        hours=1,
        id='low_stock_check',
        name='Check for low stock items'
    )
    
    # Send daily report at 6 PM
    scheduler.add_job(
        func=lambda: send_daily_stock_report(app),
        trigger='cron',
        hour=18,
        minute=0,
        id='daily_stock_report',
        name='Daily stock report'
    )
    
    # Send weekly report on Sunday at 7 PM
    scheduler.add_job(
        func=lambda: send_weekly_stock_report(app),
        trigger='cron',
        day_of_week='sun',
        hour=19,
        minute=0,
        id='weekly_stock_report',
        name='Weekly stock report'
    )
    
    # Update analytics every 6 hours
    scheduler.add_job(
        func=lambda: update_all_stock_analytics(app),
        trigger='interval',
        hours=6,
        id='update_analytics',
        name='Update stock analytics'
    )
    
    scheduler.start()
    logger.info("Stock control scheduler started successfully")
    logger.info("Schedule:")
    logger.info("  - Low stock check: Every 1 hour")
    logger.info("  - Daily report: Every day at 6:00 PM")
    logger.info("  - Weekly report: Every Sunday at 7:00 PM")
    logger.info("  - Analytics update: Every 6 hours")
    
    return scheduler
