"""
Stock Control Analytics Module
Provides inventory analytics, predictive alerts, and stock management
"""
from datetime import datetime, timedelta, date
from sqlalchemy import func, and_
from models import db, StockItem, StockDelivery, StockWaste, StockUsageHistory, DetectionEvent
import logging

logger = logging.getLogger(__name__)


class StockAnalytics:
    """Stock control analytics and predictions"""
    
    @staticmethod
    def calculate_average_daily_usage(stock_item_id, days=7):
        """Calculate average daily usage over specified days"""
        end_date = date.today()
        start_date = end_date - timedelta(days=days)
        
        usage_records = StockUsageHistory.query.filter(
            and_(
                StockUsageHistory.stock_item_id == stock_item_id,
                StockUsageHistory.date >= start_date,
                StockUsageHistory.date <= end_date
            )
        ).all()
        
        if not usage_records:
            return 0.0
        
        total_used = sum(record.items_used for record in usage_records)
        return round(total_used / len(usage_records), 2)
    
    @staticmethod
    def predict_days_until_empty(stock_item):
        """Predict how many days until stock runs out"""
        if stock_item.average_daily_usage == 0:
            return 999  # Infinite (no usage)
        
        days = stock_item.current_count / stock_item.average_daily_usage
        return int(days)
    
    @staticmethod
    def calculate_reorder_point(stock_item, lead_time_days=3, safety_stock_days=2):
        """Calculate optimal reorder point"""
        daily_usage = stock_item.average_daily_usage
        if daily_usage == 0:
            return stock_item.min_threshold
        
        # Reorder point = (Lead time × Daily usage) + Safety stock
        reorder_point = (lead_time_days * daily_usage) + (safety_stock_days * daily_usage)
        return int(reorder_point)
    
    @staticmethod
    def update_stock_item_analytics(stock_item_id):
        """Update all analytics for a stock item"""
        stock_item = StockItem.query.get(stock_item_id)
        if not stock_item:
            return False
        
        # Calculate average daily usage
        stock_item.average_daily_usage = StockAnalytics.calculate_average_daily_usage(stock_item_id)
        
        # Predict days until empty
        stock_item.days_until_empty = StockAnalytics.predict_days_until_empty(stock_item)
        
        # Calculate reorder point
        stock_item.reorder_point = StockAnalytics.calculate_reorder_point(stock_item)
        
        db.session.commit()
        return True
    
    @staticmethod
    def get_peak_hours(stock_item_id, days=7):
        """Get peak usage hours"""
        end_date = date.today()
        start_date = end_date - timedelta(days=days)
        
        # Get hourly usage from detection events
        hourly_usage = db.session.query(
            func.extract('hour', DetectionEvent.created_at).label('hour'),
            func.count(DetectionEvent.id).label('count')
        ).join(
            StockItem, StockItem.camera_id == DetectionEvent.camera_id
        ).filter(
            and_(
                StockItem.id == stock_item_id,
                DetectionEvent.created_at >= start_date,
                DetectionEvent.item_name == StockItem.name
            )
        ).group_by('hour').order_by(func.count(DetectionEvent.id).desc()).all()
        
        return [{'hour': int(row.hour), 'count': row.count} for row in hourly_usage]
    
    @staticmethod
    def get_waste_percentage(stock_item_id, days=30):
        """Calculate waste percentage over period"""
        end_date = date.today()
        start_date = end_date - timedelta(days=days)
        
        usage_data = StockUsageHistory.query.filter(
            and_(
                StockUsageHistory.stock_item_id == stock_item_id,
                StockUsageHistory.date >= start_date
            )
        ).all()
        
        total_used = sum(r.items_used for r in usage_data)
        total_wasted = sum(r.items_wasted for r in usage_data)
        
        if total_used + total_wasted == 0:
            return 0.0
        
        return round((total_wasted / (total_used + total_wasted)) * 100, 2)
    
    @staticmethod
    def create_daily_usage_record(stock_item_id, items_used=0, items_added=0, items_wasted=0):
        """Create or update daily usage record"""
        today = date.today()
        
        # Check if record exists
        record = StockUsageHistory.query.filter(
            and_(
                StockUsageHistory.stock_item_id == stock_item_id,
                StockUsageHistory.date == today
            )
        ).first()
        
        stock_item = StockItem.query.get(stock_item_id)
        
        if record:
            # Update existing record
            record.items_used += items_used
            record.items_added += items_added
            record.items_wasted += items_wasted
            record.ending_count = stock_item.current_count
        else:
            # Create new record
            record = StockUsageHistory(
                stock_item_id=stock_item_id,
                date=today,
                items_used=items_used,
                items_added=items_added,
                items_wasted=items_wasted,
                starting_count=stock_item.current_count + items_used - items_added + items_wasted,
                ending_count=stock_item.current_count
            )
            db.session.add(record)
        
        # Update peak hour
        peak_hours = StockAnalytics.get_peak_hours(stock_item_id, days=1)
        if peak_hours:
            record.peak_hour = peak_hours[0]['hour']
            record.peak_hour_count = peak_hours[0]['count']
        
        db.session.commit()
        return record
    
    @staticmethod
    def add_stock_delivery(stock_item_id, quantity, supplier=None, notes=None):
        """Record stock delivery and update inventory"""
        stock_item = StockItem.query.get(stock_item_id)
        if not stock_item:
            return None
        
        # Create delivery record
        delivery = StockDelivery(
            stock_item_id=stock_item_id,
            quantity=quantity,
            supplier=supplier,
            notes=notes
        )
        db.session.add(delivery)
        
        # Update stock count
        stock_item.current_count += quantity
        stock_item.last_restocked_at = datetime.utcnow()
        
        # Update daily usage history
        StockAnalytics.create_daily_usage_record(stock_item_id, items_added=quantity)
        
        # Update analytics
        StockAnalytics.update_stock_item_analytics(stock_item_id)
        
        db.session.commit()
        logger.info(f"Added {quantity} {stock_item.name} to inventory. New total: {stock_item.current_count}")
        return delivery
    
    @staticmethod
    def log_stock_waste(stock_item_id, quantity, reason=None, notes=None):
        """Log wasted/damaged stock"""
        stock_item = StockItem.query.get(stock_item_id)
        if not stock_item:
            return None
        
        # Create waste record
        waste = StockWaste(
            stock_item_id=stock_item_id,
            quantity=quantity,
            reason=reason,
            notes=notes
        )
        db.session.add(waste)
        
        # Update stock count
        stock_item.current_count = max(0, stock_item.current_count - quantity)
        
        # Update daily usage history
        StockAnalytics.create_daily_usage_record(stock_item_id, items_wasted=quantity)
        
        db.session.commit()
        logger.info(f"Logged {quantity} {stock_item.name} as waste. Reason: {reason}")
        return waste
    
    @staticmethod
    def increment_stock_usage(stock_item_id, quantity=1):
        """Increment stock usage (called when item is detected)"""
        stock_item = StockItem.query.get(stock_item_id)
        if not stock_item:
            return False
        
        # Decrement current count
        stock_item.current_count = max(0, stock_item.current_count - quantity)
        
        # Update daily usage
        StockAnalytics.create_daily_usage_record(stock_item_id, items_used=quantity)
        
        db.session.commit()
        return True
    
    @staticmethod
    def get_stock_summary(camera_id=None):
        """Get comprehensive stock summary"""
        query = StockItem.query
        if camera_id:
            query = query.filter(StockItem.camera_id == camera_id)
        
        items = query.all()
        
        summary = {
            'total_items': len(items),
            'critical_items': sum(1 for item in items if item.get_status() == 'critical'),
            'low_items': sum(1 for item in items if item.get_status() == 'low'),
            'items': []
        }
        
        for item in items:
            item_data = item.to_dict()
            item_data['waste_percentage'] = StockAnalytics.get_waste_percentage(item.id)
            item_data['peak_hours'] = StockAnalytics.get_peak_hours(item.id, days=7)
            summary['items'].append(item_data)
        
        return summary
    
    @staticmethod
    def get_usage_trend(stock_item_id, days=30):
        """Get usage trend over time"""
        end_date = date.today()
        start_date = end_date - timedelta(days=days)
        
        usage_records = StockUsageHistory.query.filter(
            and_(
                StockUsageHistory.stock_item_id == stock_item_id,
                StockUsageHistory.date >= start_date
            )
        ).order_by(StockUsageHistory.date).all()
        
        return [record.to_dict() for record in usage_records]
    
    @staticmethod
    def check_low_stock_alerts(camera_id=None):
        """Check for low stock and return items needing alerts"""
        query = StockItem.query
        if camera_id:
            query = query.filter(StockItem.camera_id == camera_id)
        
        items = query.all()
        alerts = {
            'critical': [],
            'low': [],
            'reorder': []
        }
        
        now = datetime.utcnow()
        
        for item in items:
            # Prevent spam - only alert once per hour
            if item.last_low_stock_alert:
                if (now - item.last_low_stock_alert).seconds < 3600:
                    continue
            
            if item.current_count <= item.critical_threshold:
                alerts['critical'].append(item)
                item.last_low_stock_alert = now
            elif item.current_count <= item.min_threshold:
                alerts['low'].append(item)
                item.last_low_stock_alert = now
            elif item.current_count <= item.reorder_point:
                alerts['reorder'].append(item)
        
        db.session.commit()
        return alerts


class StockReportGenerator:
    """Generate stock control reports"""
    
    @staticmethod
    def generate_daily_report(camera_id=None):
        """Generate end-of-day stock report"""
        today = date.today()
        
        query = StockUsageHistory.query.filter(StockUsageHistory.date == today)
        if camera_id:
            query = query.join(StockItem).filter(StockItem.camera_id == camera_id)
        
        usage_records = query.all()
        
        report = {
            'date': today.isoformat(),
            'total_items_used': sum(r.items_used for r in usage_records),
            'total_items_added': sum(r.items_added for r in usage_records),
            'total_items_wasted': sum(r.items_wasted for r in usage_records),
            'items': [r.to_dict() for r in usage_records]
        }
        
        return report
    
    @staticmethod
    def generate_weekly_report(camera_id=None):
        """Generate weekly stock report"""
        end_date = date.today()
        start_date = end_date - timedelta(days=7)
        
        query = StockUsageHistory.query.filter(
            and_(
                StockUsageHistory.date >= start_date,
                StockUsageHistory.date <= end_date
            )
        )
        if camera_id:
            query = query.join(StockItem).filter(StockItem.camera_id == camera_id)
        
        usage_records = query.all()
        
        # Group by stock item
        items_summary = {}
        for record in usage_records:
            item_name = record.stock_item.name
            if item_name not in items_summary:
                items_summary[item_name] = {
                    'name': item_name,
                    'total_used': 0,
                    'total_added': 0,
                    'total_wasted': 0,
                    'current_count': record.stock_item.current_count,
                    'status': record.stock_item.get_status()
                }
            
            items_summary[item_name]['total_used'] += record.items_used
            items_summary[item_name]['total_added'] += record.items_added
            items_summary[item_name]['total_wasted'] += record.items_wasted
        
        report = {
            'period': f"{start_date.isoformat()} to {end_date.isoformat()}",
            'items': list(items_summary.values())
        }
        
        return report
