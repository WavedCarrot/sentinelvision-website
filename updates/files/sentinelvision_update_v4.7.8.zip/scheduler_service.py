"""
Auto-schedule service for SentinelVision
Handles automatic arming and disarming based on configured times
"""
import logging
from datetime import datetime, time
from apscheduler.schedulers.background import BackgroundScheduler
from apscheduler.triggers.cron import CronTrigger
from models import db, SystemConfig, Camera
from telegram_service import telegram_service

logger = logging.getLogger(__name__)


class SchedulerService:
    """Service for handling automatic arm/disarm scheduling"""
    
    def __init__(self, app):
        self.app = app
        self.scheduler = BackgroundScheduler()
        self.scheduler.start()
        logger.info("Scheduler service initialized")
    
    def start(self):
        """Start the scheduler and set up initial jobs"""
        with self.app.app_context():
            self.update_schedule()
        logger.info("Scheduler service started")
    
    def stop(self):
        """Stop the scheduler"""
        if self.scheduler.running:
            self.scheduler.shutdown()
        logger.info("Scheduler service stopped")
    
    def update_schedule(self):
        """Update scheduler jobs based on current configuration"""
        try:
            with self.app.app_context():
                config = SystemConfig.query.first()
                if not config:
                    logger.warning("No system config found")
                    return
                
                # Remove existing schedule jobs
                for job in self.scheduler.get_jobs():
                    if job.id in ['auto_arm', 'auto_disarm']:
                        self.scheduler.remove_job(job.id)
                
                if not config.enable_auto_schedule:
                    logger.info("Auto-schedule disabled")
                    return
                
                # Parse times
                try:
                    arm_hour, arm_minute = map(int, config.arm_time.split(':'))
                    disarm_hour, disarm_minute = map(int, config.disarm_time.split(':'))
                except ValueError:
                    logger.error(f"Invalid time format: arm={config.arm_time}, disarm={config.disarm_time}")
                    return
                
                # Get schedule days
                schedule_days = config.get_schedule_days_list()
                
                # APScheduler CronTrigger uses ISO weekday numbering (0=Monday),
                # same as Python's weekday() — no conversion needed.
                cron_days = ','.join(str(d) for d in schedule_days)
                
                # Add arm job
                arm_trigger = CronTrigger(
                    hour=arm_hour,
                    minute=arm_minute,
                    day_of_week=cron_days,
                    timezone=config.timezone or 'UTC'
                )
                
                self.scheduler.add_job(
                    func=self.auto_arm_system,
                    trigger=arm_trigger,
                    id='auto_arm',
                    name='Auto Arm System',
                    replace_existing=True
                )
                
                # Add disarm job
                disarm_trigger = CronTrigger(
                    hour=disarm_hour,
                    minute=disarm_minute,
                    day_of_week=cron_days,
                    timezone=config.timezone or 'UTC'
                )
                
                self.scheduler.add_job(
                    func=self.auto_disarm_system,
                    trigger=disarm_trigger,
                    id='auto_disarm',
                    name='Auto Disarm System',
                    replace_existing=True
                )
                
                logger.info(f"Auto-schedule updated: Arm at {config.arm_time}, Disarm at {config.disarm_time}")
                
        except Exception as e:
            logger.error(f"Error updating schedule: {e}")
    
    def auto_arm_system(self):
        """Automatically arm the system"""
        try:
            with self.app.app_context():
                config = SystemConfig.query.first()
                if config:
                    config.is_armed = True
                
                # Arm all active cameras
                Camera.query.filter_by(is_active=True).update({Camera.is_armed: True})
                db.session.commit()
                
                # Send notification
                current_time = datetime.now().strftime('%H:%M')
                telegram_service.send_system_alert(
                    'success',
                    f'🛡️ System automatically armed at {current_time}\\n\\n⚡ Scheduled activation triggered\\n🎯 All cameras are now monitoring'
                )
                
                logger.info("System automatically armed by scheduler")
                
        except Exception as e:
            logger.error(f"Error in auto arm: {e}")
            try:
                db.session.rollback()
            except Exception:
                pass
    
    def auto_disarm_system(self):
        """Automatically disarm the system"""
        try:
            with self.app.app_context():
                config = SystemConfig.query.first()
                if config:
                    config.is_armed = False
                
                # Disarm all cameras
                Camera.query.update({Camera.is_armed: False})
                db.session.commit()
                
                # Send notification
                current_time = datetime.now().strftime('%H:%M')
                telegram_service.send_system_alert(
                    'info',
                    f'🔓 System automatically disarmed at {current_time}\\n\\n⚡ Scheduled deactivation triggered\\n😴 Detection alerts paused'
                )
                
                logger.info("System automatically disarmed by scheduler")
                
        except Exception as e:
            logger.error(f"Error in auto disarm: {e}")
            try:
                db.session.rollback()
            except Exception:
                pass
    
    def get_next_schedule_times(self):
        """Get next scheduled arm/disarm times"""
        next_times = {'arm': None, 'disarm': None}
        
        try:
            for job in self.scheduler.get_jobs():
                if job.id == 'auto_arm':
                    next_times['arm'] = job.next_run_time
                elif job.id == 'auto_disarm':
                    next_times['disarm'] = job.next_run_time
            
        except Exception as e:
            logger.error(f"Error getting next schedule times: {e}")
        
        return next_times
    
    def test_schedule(self, test_type='arm'):
        """Test the schedule by running arm/disarm immediately"""
        try:
            if test_type == 'arm':
                self.auto_arm_system()
            else:
                self.auto_disarm_system()
            return True
        except Exception as e:
            logger.error(f"Error testing schedule: {e}")
            return False


# Global scheduler instance
scheduler_service = None


def init_scheduler_service(app):
    """Initialize the global scheduler service"""
    global scheduler_service
    scheduler_service = SchedulerService(app)
    return scheduler_service


def get_scheduler_service():
    """Get the global scheduler service"""
    return scheduler_service