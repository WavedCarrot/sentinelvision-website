"""
WSGI entry-point for gunicorn on Linux / Raspberry Pi.

By pointing gunicorn at this module (wsgi:app) instead of app:app,
the detection engine and all background services are initialised
INSIDE the gunicorn worker process after fork — so they share memory
with the Flask request handlers and /api/stats returns live counts.

Previously they were started in the parent run.py process, which is
a completely separate OS process from gunicorn's worker.  That meant
detection_engine was always None inside Flask, so people_now, camera
status, and all live-data endpoints always returned 0 / empty.
"""
import logging
import sys

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('sentinelvision.log'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

from app import app, set_detection_engine  # noqa: E402

with app.app_context():
    try:
        from detection_engine import init_detection_engine
        from telegram_service import telegram_service
        from telegram_bot_commands import init_bot_commands
        from stock_scheduler import start_stock_scheduler
        from auto_recovery import init_auto_recovery
        from models import SystemConfig

        engine = init_detection_engine(app, telegram_service)
        set_detection_engine(engine)

        config = SystemConfig.query.first()

        if config and config.telegram_chat_id:
            system_name = getattr(config, 'system_name', None) or 'SentinelVision'
            telegram_service.set_credentials(config.telegram_chat_id)

            bot = init_bot_commands(app, telegram_service)
            bot.update_credentials(config.telegram_chat_id)
            if bot.set_bot_commands():
                logger.info('Telegram bot commands registered')
            bot.start_polling()

            start_stock_scheduler(app)

            armed_status = '🔒 ARMED' if config.is_armed else '🔓 DISARMED'
            telegram_service.send_message(
                f'🚀 <b>{system_name} Started</b>\n\n'
                f'System Status: {armed_status}\n'
                f'Use /start to open the control menu'
            )

            if engine.start():
                logger.info('Detection engine started in WSGI worker')
                init_auto_recovery(app, engine, telegram_service)
                logger.info('Auto-recovery service started')
            else:
                logger.warning('Detection engine failed to start')
        else:
            logger.warning('System not configured — complete setup via web interface')
            # Still start engine so monitoring begins as soon as user configures cameras
            engine.start()

    except Exception as exc:
        logger.error(f'Failed to initialise services in WSGI worker: {exc}', exc_info=True)
