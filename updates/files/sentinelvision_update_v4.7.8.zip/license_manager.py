"""
SentinelVision License Manager
Offline license key validation with expiry for premium features.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
KEY FORMAT:   SVP-{FC}{DC}-{8HEX}-{4HEX}
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
  FC  = Feature Code  (single letter)
          Z → Zone Detection  (includes tripwire / line crossing)
          P → People Counting
          V → Vehicle Detection
          O → Object Detection
          W → Weapon Detection
          S → Stock Control
          A → ALL features (bundle)

  NOTE: L (Line Crossing) is no longer a separate feature.
        Existing L keys are treated as Zone Detection for backward compatibility.

  DC  = Duration Code (single character)
          1 → 1 month  (31 days)
          3 → 3 months (92 days)
          Y → 12 months (365 days)

  8HEX = 8 random uppercase hex characters
  4HEX = 4-char HMAC checksum (signs FC+DC+8HEX)

Examples:
  SVP-Z1-A3F9C201-4D2E  →  Zone Detection, 1 month
  SVP-S3-B7E2D401-9C1F  →  Stock Control, 3 months
  SVP-AY-C1F4A802-3B7E  →  ALL features, 12 months
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
"""

import hmac as _hmac
import hashlib
import secrets
import logging
from datetime import datetime, timedelta

logger = logging.getLogger(__name__)

# ─── Signing secret ────────────────────────────────────────────────────────────────── #
# Do NOT change this after issuing any keys — it will invalidate them all.
_LICENSE_SECRET = "SVP2026-c9f3a1b2-sentinel-license-secret"

# ─── Feature definitions ───────────────────────────────────────────────────────────── #
FEATURES = {
    "zone_detection": {
        "name": "Zone Detection",
        "description": "Draw detection zones on cameras. Get instant alerts when people enter or exit restricted areas.",
        "icon": "fas fa-draw-polygon",
        "is_experimental": False,
        "code": "Z",
    },
    "stock_control": {
        "name": "Stock Control",
        "description": "AI-powered shelf monitoring — track stock levels and receive low-stock alerts automatically.",
        "icon": "fas fa-boxes",
        "is_experimental": True,
        "code": "S",
    },
    "people_counting": {
        "name": "People Counting",
        "description": "Automatically count people moving through entrances, exits or defined zones.",
        "icon": "fas fa-users",
        "is_experimental": False,
        "code": "P",
    },
    "weapon_detection": {
        "name": "Weapon Detection",
        "description": "AI detection of potential weapons in live camera feeds for high-security environments.",
        "icon": "fas fa-shield-alt",
        "is_experimental": True,
        "code": "W",
    },
    "vehicle_detection": {
        "name": "Vehicle Detection",
        "description": "Detect and alert on vehicles (cars, trucks, buses, motorcycles, bicycles) in camera feeds.",
        "icon": "fas fa-car",
        "is_experimental": False,
        "code": "V",
    },
    "object_detection": {
        "name": "Object Detection",
        "description": "Detect and alert on everyday objects (bags, bottles, furniture, electronics and more) in camera feeds.",
        "icon": "fas fa-cube",
        "is_experimental": False,
        "code": "O",
    },
}

# Reverse map: single-letter code → feature_id
_CODE_TO_FEATURE = {v["code"]: k for k, v in FEATURES.items()}
ALL_FEATURE_IDS = list(FEATURES.keys())

# ─── Duration definitions ──────────────────────────────────────────────────── #
DURATIONS = {
    "1": {"label": "1 Month",   "months": 1,  "days": 31},
    "3": {"label": "3 Months",  "months": 3,  "days": 92},
    "Y": {"label": "12 Months", "months": 12, "days": 365},
}


# ─── Device serial ─────────────────────────────────────────────────────────── #
def get_device_serial() -> str:
    """
    Return the hardware serial for this device.

    Priority:
      1. SV_DEVICE_SERIAL environment variable (dev/testing override)
      2. /proc/cpuinfo Serial line (Raspberry Pi)
      3. /etc/machine-id (other Linux)
      4. Windows registry MachineGuid
      5. 'UNKNOWN' as last resort
    """
    import os
    override = os.environ.get("SV_DEVICE_SERIAL", "").strip().upper()
    if override:
        return override
    try:
        with open("/proc/cpuinfo", "r") as f:
            for line in f:
                if line.lower().startswith("serial"):
                    serial = line.split(":")[-1].strip().upper()
                    if serial and serial != "0000000000000000":
                        return serial
    except OSError:
        pass
    try:
        with open("/etc/machine-id", "r") as f:
            mid = f.read().strip().upper()
            if mid:
                return mid[:16]  # first 16 chars is plenty
    except OSError:
        pass
    try:
        import winreg
        key = winreg.OpenKey(
            winreg.HKEY_LOCAL_MACHINE,
            r"SOFTWARE\Microsoft\Cryptography"
        )
        guid = winreg.QueryValueEx(key, "MachineGuid")[0]
        winreg.CloseKey(key)
        # Strip hyphens and take first 16 chars to keep it compact
        return guid.replace("-", "").upper()[:16]
    except Exception:
        pass
    return "UNKNOWN"


# ─── Internal HMAC helper ──────────────────────────────────────────────────── #
def _sign(fc: str, dc: str, base8: str, serial: str) -> str:
    """Return 4-char uppercase HMAC checksum — serial is baked in."""
    msg = f"{fc.upper()}{dc.upper()}:{base8.upper()}:{serial.upper()}"
    digest = _hmac.new(_LICENSE_SECRET.encode(), msg.encode(), hashlib.sha256).hexdigest()
    return digest[:4].upper()


# ─── Key generation ────────────────────────────────────────────────────────── #
def generate_license_key(feature_id_or_all: str, duration_code: str, device_serial: str) -> str:
    """
    Generate a signed license key bound to a specific device serial.

    Args:
        feature_id_or_all: a key from FEATURES (e.g. 'zone_detection') OR 'all'
        duration_code: '1' (1 month), '3' (3 months), or 'Y' (12 months)
        device_serial: the customer's Pi serial (from /proc/cpuinfo or get_device_serial())

    Returns:
        Key string, e.g. 'SVP-Z1-A3F9C201-4D2E'  (same format, serial baked into checksum)
    """
    duration_code = duration_code.upper()
    if duration_code not in DURATIONS:
        raise ValueError(f"Invalid duration_code {duration_code!r}. Use '1', '3', or 'Y'.")

    if not device_serial or not device_serial.strip():
        raise ValueError("device_serial is required — get it from the customer's Pi.")

    if feature_id_or_all == "all":
        fc = "A"
    elif feature_id_or_all in FEATURES:
        fc = FEATURES[feature_id_or_all]["code"]
    else:
        raise ValueError(f"Unknown feature {feature_id_or_all!r}.")

    base8 = secrets.token_hex(4).upper()
    check  = _sign(fc, duration_code, base8, device_serial.strip().upper())
    return f"SVP-{fc}{duration_code}-{base8}-{check}"


# ─── Key parsing & verification ────────────────────────────────────────────── #
def parse_license_key(key: str) -> dict | None:
    """
    Parse and verify a key string. Returns None if invalid/tampered.

    Returns dict on success:
        {
            "fc": "Z",
            "dc": "1",
            "feature_ids": ["zone_detection"],
            "covers_all": False,
            "duration_months": 1,
            "duration_days": 31,
            "duration_label": "1 Month",
        }
    """
    try:
        parts = key.strip().upper().split("-")
        if len(parts) != 4 or parts[0] != "SVP":
            return None

        fc_dc, base8, check = parts[1], parts[2], parts[3]

        if len(fc_dc) != 2 or len(base8) != 8 or len(check) != 4:
            return None

        fc, dc = fc_dc[0], fc_dc[1]

        if dc not in DURATIONS:
            return None

        # Verify HMAC — must match this device's serial
        serial = get_device_serial()
        expected = _sign(fc, dc, base8, serial)
        if not _hmac.compare_digest(check, expected):
            return None

        # Resolve feature(s)
        if fc == "A":
            feature_ids = list(ALL_FEATURE_IDS)
            covers_all  = True
        elif fc in _CODE_TO_FEATURE:
            feature_ids = [_CODE_TO_FEATURE[fc]]
            covers_all  = False
        else:
            return None

        dur = DURATIONS[dc]
        return {
            "fc":              fc,
            "dc":              dc,
            "feature_ids":     feature_ids,
            "covers_all":      covers_all,
            "duration_months": dur["months"],
            "duration_days":   dur["days"],
            "duration_label":  dur["label"],
        }
    except Exception:
        return None


def verify_license_key(key: str) -> bool:
    """Quick check: True if the key signature is valid (ignores expiry)."""
    return parse_license_key(key) is not None


# ─── DB-level helpers ──────────────────────────────────────────────────────── #
def expire_old_licenses():
    """Mark past-expiry active keys as inactive."""
    try:
        from models import LicenseKey, db
        now = datetime.utcnow()
        expired = LicenseKey.query.filter(
            LicenseKey.is_active == True,
            LicenseKey.expires_at != None,
            LicenseKey.expires_at < now
        ).all()
        for k in expired:
            k.is_active = False
            logger.info(f"License expired: {k.key} ({k.feature_id})")
        if expired:
            db.session.commit()
    except Exception as e:
        logger.error(f"expire_old_licenses error: {e}")


# line_crossing merged into zone_detection — treat them as the same feature
_FEATURE_ALIASES = {
    "line_crossing": "zone_detection",
}

def is_feature_unlocked(feature_id: str) -> bool:
    """
    Return True if the feature has an active, non-expired license in the DB.
    Accepts both specific-feature keys and all-features bundle keys.
    line_crossing is aliased to zone_detection.
    """
    # Resolve alias
    feature_id = _FEATURE_ALIASES.get(feature_id, feature_id)
    try:
        from models import LicenseKey
        expire_old_licenses()
        now = datetime.utcnow()
        keys = LicenseKey.query.filter(
            LicenseKey.is_active == True,
        ).all()
        for k in keys:
            # Skip expired (belt-and-suspenders)
            if k.expires_at and k.expires_at <= now:
                continue
            # Also accept old 'L' (line_crossing) keys as zone_detection
            resolved_fid = _FEATURE_ALIASES.get(k.feature_id, k.feature_id)
            if k.covers_all or resolved_fid == feature_id:
                return True
        return False
    except Exception as e:
        logger.error(f"License check failed for {feature_id!r}: {e}")
        return False


def get_feature_status() -> dict:
    """
    Return a dict mapping feature_id → status info (used by license.html).
    """
    try:
        from models import LicenseKey
        expire_old_licenses()
        now = datetime.utcnow()
        active_keys = LicenseKey.query.filter(
            LicenseKey.is_active == True,
        ).all()
    except Exception:
        active_keys = []

    # Build per-feature lookup including "all" bundle keys
    unlocked = {}  # feature_id → LicenseKey row
    now = datetime.utcnow()
    for row in active_keys:
        if row.expires_at and row.expires_at <= now:
            continue
        if row.covers_all:
            for fid in ALL_FEATURE_IDS:
                if fid not in unlocked:
                    unlocked[fid] = row
        elif row.feature_id in FEATURES and row.feature_id not in unlocked:
            unlocked[row.feature_id] = row

    result = {}
    for fid, fdata in FEATURES.items():
        row = unlocked.get(fid)
        days_rem = None
        if row and row.expires_at:
            days_rem = max(0, (row.expires_at - now).days)

        is_expired = bool(row and row.expires_at and row.expires_at <= now)

        result[fid] = {
            **{k: v for k, v in fdata.items()},
            "is_unlocked":    row is not None and not is_expired,
            "is_expired":     is_expired,
            "license_key":    row.key if row else None,
            "expires_at":     row.expires_at.strftime("%d %b %Y") if (row and row.expires_at) else None,
            "duration_label": row.duration_label if row else None,
            "days_remaining": days_rem,
            "covers_all":     (row.covers_all if row else False),
        }
    return result


def get_expiry_warnings() -> list:
    """
    Return a sorted list of dicts for licenses that are expired or expiring within 30 days.
    Each dict:  { feature, feature_id, days_remaining, expired, expires_at }
    Used by the global banner in base.html and by Telegram notifications.
    """
    try:
        from models import LicenseKey
        now = datetime.utcnow()
        active_keys = LicenseKey.query.filter(LicenseKey.is_active == True).all()

        # Also pick up keys that WERE active but have now expired (expire_old_licenses may not have run yet)
        recently_expired = LicenseKey.query.filter(
            LicenseKey.is_active == False,
            LicenseKey.expires_at != None,
            LicenseKey.expires_at >= (now - timedelta(days=1)),  # expired in last 24h
            LicenseKey.expires_at < now,
        ).all()

        seen_features = set()
        warnings = []

        for k in list(active_keys) + list(recently_expired):
            if not k.expires_at:
                continue
            days_rem = (k.expires_at - now).days
            if days_rem > 30:
                continue  # not near expiry

            # Determine display name
            if k.covers_all:
                feature_display = "All Features"
                fid = "all"
            else:
                fid = k.feature_id
                feature_display = FEATURES.get(fid, {}).get("name", fid)

            if fid in seen_features:
                continue
            seen_features.add(fid)

            warnings.append({
                "feature":        feature_display,
                "feature_id":     fid,
                "days_remaining": max(0, days_rem),
                "expired":        k.expires_at <= now,
                "expires_at":     k.expires_at.strftime("%d %b %Y"),
            })

        return sorted(warnings, key=lambda x: x["days_remaining"])
    except Exception as e:
        logger.error(f"get_expiry_warnings error: {e}")
        return []
