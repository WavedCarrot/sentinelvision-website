"""
Telegram Bot Commands Handler for SentinelVision Security Platform
Handles all incoming bot commands and provides interactive menu
Uses shared SentinelVision bot - users only configure their Chat ID
"""
import logging
import requests
from io import BytesIO
import cv2
from datetime import datetime, timedelta
from models import db, SystemConfig, Camera, DetectionEvent

logger = logging.getLogger(__name__)

# Shared SentinelVision Bot Token
SENTINELVISION_BOT_TOKEN = "8092135145:AAH1uKh9MQV8THbSiO8UuKgAl7hTkd-9DHc"


class TelegramBotCommands:
    def __init__(self, app, telegram_service):
        self.app = app
        self.telegram_service = telegram_service
        self.bot_token = SENTINELVISION_BOT_TOKEN
        self.chat_id = None
        self.last_update_id = 0
        self.running = False
        
        # Debouncing: prevent duplicate message sends
        self.last_message_times = {}  # message_key: timestamp
        self.message_cooldown = 3  # seconds between same messages
        
        # Track processed callback queries to prevent double-processing
        self.processed_callbacks = {}  # callback_id: timestamp
        self.callback_expiry = 60  # seconds to remember callbacks
    
    def update_credentials(self, chat_id):
        """Update chat ID (bot token is fixed)"""
        self.chat_id = chat_id
        self.telegram_service.set_credentials(chat_id)
    
    def should_send_message(self, message_key):
        """Check if we should send a message (debounce duplicate sends)"""
        current_time = datetime.utcnow()
        last_time = self.last_message_times.get(message_key)
        
        if last_time and (current_time - last_time).total_seconds() < self.message_cooldown:
            logger.debug(f"Debouncing message: {message_key}")
            return False
        
        self.last_message_times[message_key] = current_time
        
        # Clean up old entries
        cutoff = current_time - timedelta(seconds=30)
        self.last_message_times = {k: v for k, v in self.last_message_times.items() if v > cutoff}
        
        return True
    
    def is_callback_processed(self, callback_id):
        """Check if a callback was already processed (prevent double-processing)"""
        current_time = datetime.utcnow()
        
        # Clean up old entries
        cutoff = current_time - timedelta(seconds=self.callback_expiry)
        self.processed_callbacks = {k: v for k, v in self.processed_callbacks.items() if v > cutoff}
        
        if callback_id in self.processed_callbacks:
            logger.debug(f"Callback already processed: {callback_id}")
            return True
        
        self.processed_callbacks[callback_id] = current_time
        return False
    
    def send_message_to_user(self, user_chat_id, text):
        """Send message to a specific user"""
        try:
            url = f"https://api.telegram.org/bot{self.bot_token}/sendMessage"
            payload = {
                'chat_id': user_chat_id,
                'text': text,
                'parse_mode': 'HTML'
            }
            response = requests.post(url, json=payload, timeout=10)
            return response.status_code == 200
        except Exception as e:
            logger.error(f"Failed to send message to {user_chat_id}: {e}")
            return False
    
    def set_bot_commands(self):
        """Set bot commands menu"""
        if not self.bot_token:
            return False
        
        commands = [
            {"command": "start", "description": "🏠 Show main menu"},
            {"command": "status", "description": "📊 System status"},
            {"command": "arm", "description": "🔒 Arm the system"},
            {"command": "disarm", "description": "🔓 Disarm the system"},
            {"command": "snooze", "description": "🔇 Snooze alerts (30 min)"},
            {"command": "unsnooze", "description": "🔔 Resume all alerts"},
            {"command": "schedule", "description": "⏰ Schedule settings"},
            {"command": "setarm", "description": "🕘 Set auto-arm time (HH:MM)"},
            {"command": "setdisarm", "description": "🕛 Set auto-disarm time (HH:MM)"},
            {"command": "setdays", "description": "📅 Set schedule days (1,2,3...)"},
            {"command": "enableschedule", "description": "✅ Enable/disable schedule"},
            {"command": "snapshot", "description": "📸 Get camera snapshot"},
            {"command": "cameras", "description": "📷 List all cameras"},
            {"command": "events", "description": "🚨 Recent events (last 10)"},
            {"command": "stats", "description": "📈 System statistics"},
            {"command": "sensitivity", "description": "🎛️ Adjust detection sensitivity"},
            {"command": "help", "description": "❓ Help and commands"}
        ]
        
        try:
            url = f"https://api.telegram.org/bot{self.bot_token}/setMyCommands"
            response = requests.post(url, json={"commands": commands}, timeout=10)
            return response.status_code == 200
        except Exception as e:
            logger.error(f"Failed to set bot commands: {e}")
            return False
    
    def send_keyboard(self, text, keyboard_buttons):
        """Send message with inline keyboard"""
        if not self.bot_token or not self.chat_id:
            return False
        
        try:
            url = f"https://api.telegram.org/bot{self.bot_token}/sendMessage"
            payload = {
                'chat_id': self.chat_id,
                'text': text,
                'parse_mode': 'HTML',
                'reply_markup': {
                    'inline_keyboard': keyboard_buttons
                }
            }
            response = requests.post(url, json=payload, timeout=10)
            return response.status_code == 200
        except Exception as e:
            logger.error(f"Failed to send keyboard: {e}")
            return False
    
    def capture_snapshot(self, camera):
        """Capture snapshot from camera - Enhanced for Provision/Hikvision/Dahua"""
        import os
        import re
        import numpy as np
        
        def is_gray_frame(img):
            """Check if frame is mostly gray/blank"""
            if img is None:
                return True
            try:
                gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
                variance = np.var(gray)
                if variance < 100:
                    return True
                return False
            except:
                return False
        
        def try_capture(url, max_frames=30):
            """Try to capture a good frame from URL"""
            try:
                # Set FFMPEG options for better compatibility
                os.environ['OPENCV_FFMPEG_CAPTURE_OPTIONS'] = 'rtsp_transport;tcp|analyzeduration;5000000|fflags;nobuffer|stimeout;10000000'
                cap = cv2.VideoCapture(url, cv2.CAP_FFMPEG)
                cap.set(cv2.CAP_PROP_BUFFERSIZE, 3)
                cap.set(cv2.CAP_PROP_OPEN_TIMEOUT_MSEC, 15000)
                cap.set(cv2.CAP_PROP_READ_TIMEOUT_MSEC, 10000)
                
                if not cap.isOpened():
                    return None
                
                frame = None
                for _ in range(max_frames):
                    ret, temp_frame = cap.read()
                    if ret and temp_frame is not None:
                        if not is_gray_frame(temp_frame):
                            frame = temp_frame
                            break
                        frame = temp_frame  # Keep as fallback
                cap.release()
                return frame
            except Exception as e:
                logger.debug(f"Snapshot attempt failed for {url}: {e}")
                return None
        
        try:
            rtsp_url = camera.rtsp_url
            # Use working URL from detection engine if available
            working_rtsp_url = getattr(camera, 'working_rtsp_url', None)
            
            # Build list of URLs to try - working URL first
            urls_to_try = []
            if working_rtsp_url:
                urls_to_try.append(working_rtsp_url)
                logger.info(f"Using working RTSP URL for snapshot: {working_rtsp_url}")
            urls_to_try.append(rtsp_url)
            
            # Parse URL and generate alternates for Provision/Hikvision/Dahua
            match = re.match(r'rtsp://([^:]+):([^@]+)@([^:/]+)(?::(\d+))?(/.*)?', rtsp_url)
            if match:
                user, passwd, host, port, path = match.groups()
                port = port or '554'
                auth = f"{user}:{passwd}@{host}:{port}"
                
                # Add comprehensive stream path formats for Provision/Hikvision/Dahua
                urls_to_try.extend([
                    # Provision standalone camera formats
                    f"rtsp://{auth}/stream1",
                    f"rtsp://{auth}/stream2",
                    f"rtsp://{auth}/live/ch00_0",
                    f"rtsp://{auth}/live/ch00_1",
                    f"rtsp://{auth}/live/main",
                    f"rtsp://{auth}/live/sub",
                    f"rtsp://{auth}/media/video1",
                    f"rtsp://{auth}/media/video2",
                    f"rtsp://{auth}/profile1",
                    f"rtsp://{auth}/profile2",
                    f"rtsp://{auth}/video",
                    f"rtsp://{auth}/videoinput_1/h264_1",
                    f"rtsp://{auth}/videoMain",
                    f"rtsp://{auth}/videoSub",
                    # Provision/Dahua NVR formats
                    f"rtsp://{auth}/cam/realmonitor?channel=1&subtype=0",
                    f"rtsp://{auth}/cam/realmonitor?channel=1&subtype=1",
                    f"rtsp://{auth}/live",
                    # Hikvision formats
                    f"rtsp://{auth}/Streaming/Channels/101",
                    f"rtsp://{auth}/Streaming/Channels/102",
                    f"rtsp://{auth}/h264/ch1/main/av_stream",
                    f"rtsp://{auth}/h264/ch1/sub/av_stream",
                    # ONVIF standard
                    f"rtsp://{auth}/onvif1",
                    f"rtsp://{auth}/onvif2",
                    # Generic
                    f"rtsp://{auth}/",
                ])
                
                # Also try HTTP snapshot for Hikvision/Dahua
                http_urls = [
                    f"http://{user}:{passwd}@{host}/ISAPI/Streaming/channels/101/picture",
                    f"http://{user}:{passwd}@{host}/cgi-bin/snapshot.cgi?channel=1",
                ]
                
                # Try HTTP snapshots first (faster)
                for http_url in http_urls:
                    try:
                        import requests
                        resp = requests.get(http_url, timeout=5, stream=True)
                        if resp.status_code == 200 and 'image' in resp.headers.get('Content-Type', ''):
                            return BytesIO(resp.content)
                    except:
                        pass
            
            # Try RTSP URLs
            for url in urls_to_try:
                frame = try_capture(url)
                if frame is not None:
                    # Fix color space if needed
                    if len(frame.shape) == 2:
                        frame = cv2.cvtColor(frame, cv2.COLOR_GRAY2BGR)
                    elif frame.shape[2] == 4:
                        frame = cv2.cvtColor(frame, cv2.COLOR_BGRA2BGR)
                    
                    # Encode as JPEG
                    ret, buffer = cv2.imencode('.jpg', frame, [cv2.IMWRITE_JPEG_QUALITY, 85])
                    if ret:
                        logger.info(f"Snapshot captured from {camera.name} using {url}")
                        return BytesIO(buffer.tobytes())
            
            logger.warning(f"All snapshot attempts failed for camera {camera.name}")
            return None
        except Exception as e:
            logger.error(f"Failed to capture snapshot from camera {camera.name}: {e}")
            return None
    
    def get_site_id(self):
        """Get the site_id for this Pi"""
        with self.app.app_context():
            config = SystemConfig.query.first()
            if config and config.site_id:
                return config.site_id
            # Generate and save a unique site_id if not set
            import uuid
            site_id = str(uuid.uuid4())[:8]
            if config:
                config.site_id = site_id
                db.session.commit()
            return site_id
    
    def get_site_name(self):
        """Get the site name for this Pi"""
        with self.app.app_context():
            config = SystemConfig.query.first()
            return config.site_name if config and config.site_name else 'Main Site'
    
    def handle_start(self):
        """Handle /start command - Shows site selection so user can pick ONE site at a time"""
        with self.app.app_context():
            config = SystemConfig.query.first()
            if not config:
                return
            
            site_id = self.get_site_id()
            site_name = config.site_name if config.site_name else 'Main Site'
            armed_status = "🔒 ARMED" if config.is_armed else "🔓 DISARMED"
            
            # This Pi shows a site selection button - ONLY show this site as an option
            # Each Pi sends ONE button for its site, user picks which one they want
            text = f"""
🛡️ <b>SentinelVision Pro</b>

<b>Select a site to control:</b>

Tap the site you want to manage. Only that site's menu will open.
"""
            
            # Each Pi sends ONE site button - user picks which site they want
            keyboard = [
                [
                    {"text": f"🏢 {site_name} ({armed_status})", "callback_data": f"open_site:{site_id}"}
                ]
            ]
            
            self.send_keyboard(text, keyboard)
    
    def handle_open_site(self):
        """Show the full menu for THIS specific site when user selects it"""
        with self.app.app_context():
            config = SystemConfig.query.first()
            if not config:
                return
            
            site_id = self.get_site_id()
            site_name = config.site_name if config.site_name else 'Main Site'
            armed_status = "🔒 ARMED" if config.is_armed else "🔓 DISARMED"
            
            # Check if any cameras are snoozed
            cameras = Camera.query.filter_by(is_active=True).all()
            snoozed_count = sum(1 for c in cameras if hasattr(c, 'is_snoozed') and c.is_snoozed())
            snooze_status = f" (🔕 {snoozed_count} snoozed)" if snoozed_count > 0 else ""
            
            text = f"""
🛡️ <b>SentinelVision Pro Control Panel</b>

🏢 <b>Site:</b> {site_name}
🆔 <b>ID:</b> {site_id}
📊 <b>Status:</b> {armed_status}{snooze_status}

Use the menu below to control this site:
"""
            
            # Dynamically show snooze or unsnooze button
            if snoozed_count > 0:
                snooze_btn = {"text": "🔔 Unsnooze Alerts", "callback_data": f"unsnooze:{site_id}"}
            else:
                snooze_btn = {"text": "🔕 Snooze Alerts", "callback_data": f"snooze:{site_id}"}
            
            # Include site_id in ALL callback_data to ensure only THIS Pi responds
            keyboard = [
                [
                    {"text": "🔒 Arm System", "callback_data": f"arm:{site_id}"},
                    {"text": "🔓 Disarm System", "callback_data": f"disarm:{site_id}"}
                ],
                [
                    {"text": "⏰ Schedule", "callback_data": f"schedule_menu:{site_id}"},
                    snooze_btn
                ],
                [
                    {"text": "📊 System Status", "callback_data": f"status:{site_id}"},
                    {"text": "📸 Take Snapshot", "callback_data": f"snapshot_menu:{site_id}"}
                ],
                [
                    {"text": "📷 List Cameras", "callback_data": f"cameras:{site_id}"},
                    {"text": "🚨 Recent Events", "callback_data": f"events:{site_id}"}
                ],
                [
                    {"text": "📈 Statistics", "callback_data": f"stats:{site_id}"},
                    {"text": "🎛️ Sensitivity", "callback_data": f"sens_menu:{site_id}"}
                ],
                [
                    {"text": "❓ Help", "callback_data": f"help:{site_id}"},
                    {"text": "🔄 Switch Site", "callback_data": f"switch_site:{site_id}"}
                ]
            ]
            
            self.send_keyboard(text, keyboard)
    
    def handle_switch_site(self):
        """Go back to site selection - same as /start"""
        self.handle_start()
    
    def handle_status(self):
        """Handle /status command"""
        with self.app.app_context():
            config = SystemConfig.query.first()
            cameras = Camera.query.all()
            active_cameras = Camera.query.filter_by(is_active=True).count()
            
            armed_status = "🔒 ARMED" if config and config.is_armed else "🔓 DISARMED"
            
            # Get system stats
            import psutil
            cpu = psutil.cpu_percent(interval=1)
            memory = psutil.virtual_memory()
            
            # Get temperature
            temp = "N/A"
            try:
                with open('/sys/class/thermal/thermal_zone0/temp', 'r') as f:
                    temp = f"{float(f.read()) / 1000.0:.1f}°C"
            except:
                pass
            
            site_name = getattr(config, 'site_name', None) or 'Main Site' if config else 'Main Site'
            
            text = f"""
📊 <b>System Status</b>

🏢 <b>Site:</b> {site_name}
🔐 <b>Security:</b> {armed_status}
📷 <b>Total Cameras:</b> {len(cameras)}
✅ <b>Active Cameras:</b> {active_cameras}
💻 <b>CPU Usage:</b> {cpu:.1f}%
🧠 <b>Memory Usage:</b> {memory.percent:.1f}%
🌡️ <b>Temperature:</b> {temp}

<i>System running normally</i>
"""
            site_id = self.get_site_id()
            keyboard = [
                [
                    {"text": "🔄 Refresh", "callback_data": f"status:{site_id}"},
                    {"text": "🔙 Back to Menu", "callback_data": f"start:{site_id}"}
                ]
            ]
            
            self.send_keyboard(text, keyboard)
    
    def handle_arm(self):
        """Handle /arm command - show site selection if site name is set"""
        with self.app.app_context():
            config = SystemConfig.query.first()
            if config:
                site_name = config.site_name or 'Main Site'
                site_id = self.get_site_id()
                
                # Show confirmation with site name
                keyboard = [
                    [{"text": f"🔒 Arm {site_name}", "callback_data": f"arm_confirm:{site_id}"}],
                    [{"text": "🔙 Cancel", "callback_data": f"start:{site_id}"}]
                ]
                
                self.send_keyboard(
                    f"🔒 <b>Arm System</b>\n\n"
                    f"🏢 <b>Site:</b> {site_name}\n\n"
                    f"This will enable detection alerts for all cameras at this site.\n\n"
                    f"Confirm arm?",
                    keyboard
                )
            else:
                self.telegram_service.send_message("❌ Configuration error. Please check system settings.")
    
    def handle_arm_confirm(self, site_id=None):
        """Confirm and arm the system"""
        with self.app.app_context():
            config = SystemConfig.query.first()
            if config:
                config.is_armed = True
                config.updated_at = datetime.utcnow()
                db.session.commit()
                
                site_name = getattr(config, 'site_name', None) or 'Main Site'
                
                self.telegram_service.send_message(
                    f"🔒 <b>System ARMED</b>\n\n"
                    f"🏢 <b>Site:</b> {site_name}\n\n"
                    f"All cameras are now actively monitoring and will send alerts when objects are detected."
                )
            else:
                self.telegram_service.send_message("❌ Configuration error. Please check system settings.")
    
    def handle_disarm(self):
        """Handle /disarm command - show site selection if site name is set"""
        with self.app.app_context():
            config = SystemConfig.query.first()
            if config:
                site_name = config.site_name or 'Main Site'
                site_id = self.get_site_id()
                
                # Show confirmation with site name
                keyboard = [
                    [{"text": f"🔓 Disarm {site_name}", "callback_data": f"disarm_confirm:{site_id}"}],
                    [{"text": "🔙 Cancel", "callback_data": f"start:{site_id}"}]
                ]
                
                self.send_keyboard(
                    f"🔓 <b>Disarm System</b>\n\n"
                    f"🏢 <b>Site:</b> {site_name}\n\n"
                    f"This will disable detection alerts. Cameras will still record but won't send notifications.\n\n"
                    f"Confirm disarm?",
                    keyboard
                )
            else:
                self.telegram_service.send_message("❌ Configuration error. Please check system settings.")
    
    def handle_disarm_confirm(self, site_id=None):
        """Confirm and disarm the system"""
        with self.app.app_context():
            config = SystemConfig.query.first()
            if config:
                config.is_armed = False
                config.updated_at = datetime.utcnow()
                db.session.commit()
                
                site_name = config.site_name or 'Main Site'
                
                self.telegram_service.send_message(
                    f"🔓 <b>System DISARMED</b>\n\n"
                    f"🏢 <b>Site:</b> {site_name}\n\n"
                    f"Detection alerts are disabled. Cameras are still recording but won't send notifications."
                )
            else:
                self.telegram_service.send_message("❌ Configuration error. Please check system settings.")
    
    def handle_snooze(self, duration_minutes=None):
        """Handle /snooze command - temporarily mute alerts for all cameras"""
        with self.app.app_context():
            site_id = self.get_site_id()
            
            if duration_minutes is None:
                # Show snooze duration options
                keyboard = [
                    [
                        {"text": "15 min", "callback_data": f"snooze_15:{site_id}"},
                        {"text": "30 min", "callback_data": f"snooze_30:{site_id}"},
                        {"text": "1 hour", "callback_data": f"snooze_60:{site_id}"}
                    ],
                    [
                        {"text": "2 hours", "callback_data": f"snooze_120:{site_id}"},
                        {"text": "4 hours", "callback_data": f"snooze_240:{site_id}"},
                        {"text": "8 hours", "callback_data": f"snooze_480:{site_id}"}
                    ],
                    [{"text": "🔙 Cancel", "callback_data": f"start:{site_id}"}]
                ]
                
                self.send_keyboard(
                    "🔕 <b>Snooze Alerts</b>\n\n"
                    "Select how long to mute alerts:\n"
                    "<i>Cameras will continue monitoring but won't send notifications.</i>",
                    keyboard
                )
            else:
                # Apply snooze to all cameras
                cameras = Camera.query.filter_by(is_active=True).all()
                snooze_count = 0
                
                for camera in cameras:
                    if hasattr(camera, 'snooze_alerts'):
                        camera.snooze_alerts(duration_minutes)
                        snooze_count += 1
                
                db.session.commit()
                
                # Calculate end time
                end_time = datetime.utcnow() + timedelta(minutes=duration_minutes)
                end_time_str = end_time.strftime("%H:%M")
                
                if duration_minutes >= 60:
                    duration_str = f"{duration_minutes // 60} hour{'s' if duration_minutes >= 120 else ''}"
                else:
                    duration_str = f"{duration_minutes} minutes"
                
                self.telegram_service.send_message(
                    f"🔕 <b>Alerts Snoozed</b>\n\n"
                    f"⏱️ <b>Duration:</b> {duration_str}\n"
                    f"⏰ <b>Alerts resume at:</b> {end_time_str}\n"
                    f"📷 <b>Cameras affected:</b> {snooze_count}\n\n"
                    f"<i>Use /unsnooze to cancel snooze early.</i>"
                )
    
    def handle_unsnooze(self):
        """Handle /unsnooze command - resume alerts immediately"""
        with self.app.app_context():
            cameras = Camera.query.filter_by(is_active=True).all()
            unsnooze_count = 0
            
            for camera in cameras:
                if hasattr(camera, 'unsnooze_alerts') and camera.is_snoozed():
                    camera.unsnooze_alerts()
                    unsnooze_count += 1
            
            db.session.commit()
            
            if unsnooze_count > 0:
                self.telegram_service.send_message(
                    f"🔔 <b>Alerts Resumed</b>\n\n"
                    f"📷 <b>Cameras:</b> {unsnooze_count}\n\n"
                    f"<i>All cameras are now sending alerts normally.</i>"
                )
            else:
                self.telegram_service.send_message(
                    "ℹ️ <b>No Snoozed Cameras</b>\n\n"
                    "<i>All cameras are already sending alerts normally.</i>"
                )
    
    def handle_snapshot_menu(self):
        """Show snapshot camera selection menu"""
        with self.app.app_context():
            cameras = Camera.query.filter_by(is_active=True).all()
            site_id = self.get_site_id()
            
            if not cameras:
                self.telegram_service.send_message("❌ No active cameras available.")
                return
            
            keyboard = []
            
            # Add "All Cameras" button
            keyboard.append([{"text": "📸 All Cameras", "callback_data": f"snapshot_all:{site_id}"}])
            
            # Add individual camera buttons
            for camera in cameras:
                keyboard.append([
                    {"text": f"📷 {camera.name}", "callback_data": f"snapshot_{camera.id}:{site_id}"}
                ])
            
            keyboard.append([{"text": "🔙 Back to Menu", "callback_data": f"start:{site_id}"}])
            
            config = SystemConfig.query.first()
            site_name = config.site_name or 'Main Site' if config else 'Main Site'
            
            self.send_keyboard(f"📸 <b>Select Camera for Snapshot</b>\n\n🏢 <b>Site:</b> {site_name}", keyboard)
    
    def handle_snapshot(self, camera_id=None):
        """Handle snapshot request"""
        with self.app.app_context():
            if camera_id == "all":
                # Capture from all active cameras
                cameras = Camera.query.filter_by(is_active=True).all()
                
                if not cameras:
                    self.telegram_service.send_message("❌ No active cameras available.")
                    return
                
                self.telegram_service.send_message(f"📸 Capturing snapshots from {len(cameras)} camera(s)...")
                
                for camera in cameras:
                    snapshot = self.capture_snapshot(camera)
                    if snapshot:
                        caption = f"📷 <b>{camera.name}</b>\n📍 {camera.location or 'No location'}\n⏰ {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}"
                        
                        # Send snapshot
                        try:
                            url = f"https://api.telegram.org/bot{self.bot_token}/sendPhoto"
                            files = {'photo': snapshot}
                            data = {
                                'chat_id': self.chat_id,
                                'caption': caption,
                                'parse_mode': 'HTML'
                            }
                            requests.post(url, files=files, data=data, timeout=30)
                        except Exception as e:
                            logger.error(f"Failed to send snapshot: {e}")
                    else:
                        self.telegram_service.send_message(f"❌ Failed to capture from {camera.name}")
            
            else:
                # Capture from specific camera
                camera = Camera.query.get(camera_id)
                
                if not camera:
                    self.telegram_service.send_message("❌ Camera not found.")
                    return
                
                if not camera.is_active:
                    self.telegram_service.send_message(f"❌ Camera '{camera.name}' is not active.")
                    return
                
                self.telegram_service.send_message(f"📸 Capturing snapshot from {camera.name}...")
                
                snapshot = self.capture_snapshot(camera)
                
                if snapshot:
                    caption = f"📷 <b>{camera.name}</b>\n📍 {camera.location or 'No location'}\n⏰ {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}"
                    
                    # Send snapshot
                    try:
                        url = f"https://api.telegram.org/bot{self.bot_token}/sendPhoto"
                        files = {'photo': snapshot}
                        data = {
                            'chat_id': self.chat_id,
                            'caption': caption,
                            'parse_mode': 'HTML'
                        }
                        response = requests.post(url, files=files, data=data, timeout=30)
                        
                        if response.status_code != 200:
                            self.telegram_service.send_message(f"❌ Failed to send snapshot from {camera.name}")
                    except Exception as e:
                        logger.error(f"Failed to send snapshot: {e}")
                        self.telegram_service.send_message(f"❌ Error sending snapshot: {str(e)}")
                else:
                    self.telegram_service.send_message(f"❌ Failed to capture from {camera.name}. Check camera connection.")
    
    def handle_cameras(self):
        """Handle /cameras command"""
        with self.app.app_context():
            cameras = Camera.query.all()
            config = SystemConfig.query.first()
            site_id = self.get_site_id()
            site_name = config.site_name or 'Main Site' if config else 'Main Site'
            
            if not cameras:
                keyboard = [
                    [{"text": "🔙 Back to Menu", "callback_data": f"start:{site_id}"}]
                ]
                self.send_keyboard(f"📷 <b>Camera List</b>\n\n🏢 <b>Site:</b> {site_name}\n\n❌ No cameras configured yet.", keyboard)
                return
            
            text = f"📷 <b>Camera List</b>\n\n🏢 <b>Site:</b> {site_name}\n\n"
            
            for camera in cameras:
                status = "✅ Active" if camera.is_active else "❌ Inactive"
                armed = "🔒 Armed" if camera.is_armed else "🔓 Disarmed"
                location = camera.location or "No location"
                
                detections = []
                if camera.enable_person_detection:
                    detections.append("👤 Person")
                if camera.enable_vehicle_detection:
                    detections.append("🚗 Vehicle")
                if camera.enable_animal_detection:
                    detections.append("🐕 Animal")
                if camera.enable_object_detection:
                    detections.append("📦 All Objects")
                
                detection_str = ", ".join(detections) if detections else "None"
                
                text += f"<b>{camera.name}</b>\n"
                text += f"  Status: {status} | {armed}\n"
                text += f"  📍 {location}\n"
                text += f"  🎯 {detection_str}\n\n"
            
            keyboard = [
                [{"text": "🔙 Back to Menu", "callback_data": f"start:{site_id}"}]
            ]
            
            self.send_keyboard(text, keyboard)
    
    def handle_events(self):
        """Handle /events command"""
        with self.app.app_context():
            events = DetectionEvent.query.order_by(
                DetectionEvent.created_at.desc()
            ).limit(10).all()
            
            config = SystemConfig.query.first()
            site_id = self.get_site_id()
            site_name = config.site_name or 'Main Site' if config else 'Main Site'
            
            if not events:
                keyboard = [
                    [{"text": "🔄 Refresh", "callback_data": f"events:{site_id}"}],
                    [{"text": "🔙 Back to Menu", "callback_data": f"start:{site_id}"}]
                ]
                self.send_keyboard(f"🚨 <b>Recent Detection Events</b>\n\n🏢 <b>Site:</b> {site_name}\n\n❌ No detection events yet.", keyboard)
                return
            
            text = f"🚨 <b>Recent Detection Events</b>\n\n🏢 <b>Site:</b> {site_name}\n\n"
            
            for event in events:
                camera_name = event.camera.name if event.camera else "Unknown"
                detected = event.detected_class.title()
                confidence = event.confidence * 100
                time = event.created_at.strftime('%Y-%m-%d %H:%M:%S')
                
                text += f"• <b>{detected}</b> ({confidence:.1f}%)\n"
                text += f"  📷 {camera_name}\n"
                text += f"  ⏰ {time}\n\n"
            
            keyboard = [
                [{"text": "🔄 Refresh", "callback_data": f"events:{site_id}"}],
                [{"text": "🔙 Back to Menu", "callback_data": f"start:{site_id}"}]
            ]
            
            self.send_keyboard(text, keyboard)
    
    def handle_stats(self):
        """Handle /stats command"""
        with self.app.app_context():
            config = SystemConfig.query.first()
            site_name = config.site_name or 'Main Site' if config else 'Main Site'
            
            # Today's stats
            today = datetime.utcnow().date()
            detections_today = DetectionEvent.query.filter(
                DetectionEvent.created_at >= today
            ).count()
            
            # This week's stats
            week_ago = datetime.utcnow() - timedelta(days=7)
            detections_week = DetectionEvent.query.filter(
                DetectionEvent.created_at >= week_ago
            ).count()
            
            # Detections by class (today)
            from sqlalchemy import func
            detections_by_class = db.session.query(
                DetectionEvent.detected_class,
                func.count(DetectionEvent.id)
            ).filter(
                DetectionEvent.created_at >= today
            ).group_by(DetectionEvent.detected_class).all()
            
            text = f"📈 <b>Detection Statistics</b>\n\n🏢 <b>Site:</b> {site_name}\n\n"
            text += f"<b>Today:</b> {detections_today} detections\n"
            text += f"<b>This Week:</b> {detections_week} detections\n\n"
            
            if detections_by_class:
                text += "<b>Today by Type:</b>\n"
                for cls, count in detections_by_class:
                    text += f"  • {cls.title()}: {count}\n"
            
            site_id = self.get_site_id()
            keyboard = [
                [{"text": "🔄 Refresh", "callback_data": f"stats:{site_id}"}],
                [{"text": "🔙 Back to Menu", "callback_data": f"start:{site_id}"}]
            ]
            
            self.send_keyboard(text, keyboard)
    
    def handle_help(self):
        """Handle /help command"""
        site_id = self.get_site_id()
        text = """
❓ <b>SentinelVision Help</b>

<b>Available Commands:</b>

/start - Show main menu
/status - System status
/arm - Arm the system (enable alerts)
/disarm - Disarm the system (disable alerts)
/snooze - Temporarily mute alerts
/unsnooze - Resume alerts early

<b>Schedule Commands:</b>
/schedule - Schedule settings menu
/setarm HH:MM - Set auto-arm time (e.g., /setarm 22:00)
/setdisarm HH:MM - Set auto-disarm time (e.g., /setdisarm 07:00)
/setdays 1,2,3,4,5 - Set active days (1=Mon, 7=Sun)
/enableschedule on - Enable auto-schedule
/enableschedule off - Disable auto-schedule

<b>Other Commands:</b>
/snapshot - Get camera snapshot
/cameras - List all cameras
/events - Recent detection events
/stats - Detection statistics
/sensitivity - Adjust detection sensitivity
/help - Show this help

<b>Schedule Examples:</b>
• /setarm 22:00 - Auto-arm at 10 PM
• /setdisarm 07:00 - Auto-disarm at 7 AM
• /setdays 1,2,3,4,5 - Weekdays only
• /setdays 1,2,3,4,5,6,7 - All days

<b>How It Works:</b>

When the system is <b>ARMED</b>, it monitors all active cameras and sends you alerts when objects are detected.

When <b>DISARMED</b>, cameras continue monitoring but won't send alerts.

<b>Snooze Feature:</b>
Use /snooze to temporarily mute alerts for 15 min to 8 hours. System continues monitoring but won't notify you. Use /unsnooze to resume early.

<b>Need More Help?</b>
Access the web interface for detailed configuration and event history.
"""
        keyboard = [
            [{"text": "🔙 Back to Menu", "callback_data": f"start:{site_id}"}]
        ]
        
        self.send_keyboard(text, keyboard)
    
    def handle_schedule_menu(self):
        """Handle schedule menu"""
        with self.app.app_context():
            config = SystemConfig.query.first()
            
            if not config:
                self.telegram_service.send_message("❌ System not configured")
                return
            
            schedule_status = "✅ ENABLED" if config.enable_auto_schedule else "❌ DISABLED"
            
            text = f"""
⏰ <b>Schedule Configuration</b>

Status: {schedule_status}
Arm Time: {config.arm_time or 'Not set'}
Disarm Time: {config.disarm_time or 'Not set'}
Days: {', '.join(['Mon','Tue','Wed','Thu','Fri','Sat','Sun'][i-1] for i in config.get_schedule_days_list()) if config.get_schedule_days_list() else 'Not set'}
Timezone: {config.timezone or 'UTC'}

Use the buttons below to manage the schedule:
"""
            site_id = self.get_site_id()
            keyboard = [
                [
                    {"text": "📋 View Schedule", "callback_data": f"view_schedule:{site_id}"}
                ],
                [
                    {"text": "✅ Enable Schedule" if not config.enable_auto_schedule else "❌ Disable Schedule", 
                     "callback_data": f"enable_schedule:{site_id}" if not config.enable_auto_schedule else f"disable_schedule:{site_id}"}
                ],
                [
                    {"text": "🧪 Test Arm", "callback_data": f"test_arm:{site_id}"},
                    {"text": "🧪 Test Disarm", "callback_data": f"test_disarm:{site_id}"}
                ],
                [
                    {"text": "🔙 Back to Menu", "callback_data": f"start:{site_id}"}
                ]
            ]
            
            self.send_keyboard(text, keyboard)
    
    def handle_view_schedule(self):
        """Show current schedule configuration"""
        with self.app.app_context():
            config = SystemConfig.query.first()
            site_id = self.get_site_id()
            
            if not config:
                self.telegram_service.send_message("❌ System not configured")
                return
            
            status = "✅ ENABLED" if config.enable_auto_schedule else "❌ DISABLED"
            arm_time = config.arm_time or "Not set"
            disarm_time = config.disarm_time or "Not set"
            timezone = config.timezone or "UTC"
            
            # Format schedule days
            days_list = config.get_schedule_days_list() if config.get_schedule_days_list() else []
            day_names = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday']
            active_days = [day_names[i-1] for i in days_list] if days_list else ['None']
            
            text = f"""
⏰ <b>Current Schedule Configuration</b>

📊 <b>Status:</b> {status}
🕘 <b>Auto-Arm Time:</b> {arm_time}
🕛 <b>Auto-Disarm Time:</b> {disarm_time}
📅 <b>Active Days:</b> {', '.join(active_days)}
🌍 <b>Timezone:</b> {timezone}

<b>💡 How to Update:</b>
• Use the web interface at your server IP
• Or send direct commands:
  - /setarm 22:00
  - /setdisarm 07:00
  - /setdays 1,2,3,4,5
  - /enableschedule on

📝 <b>Note:</b> Changes via text commands will update automatically.
"""
            
            keyboard = [
                [
                    {"text": "🔙 Back to Schedule", "callback_data": f"schedule_menu:{site_id}"}
                ]
            ]
            
            self.send_keyboard(text, keyboard)
    
    def handle_enable_schedule(self):
        """Enable auto-schedule"""
        with self.app.app_context():
            config = SystemConfig.query.first()
            
            if not config:
                self.telegram_service.send_message("❌ System not configured")
                return
            
            config.enable_auto_schedule = True
            self.app.config['SQLALCHEMY_DATABASE_URI']
            from app import db
            db.session.commit()
            
            # Update scheduler
            try:
                from scheduler_service import get_scheduler_service
                scheduler = get_scheduler_service()
                if scheduler:
                    scheduler.update_schedule(config)
            except Exception as e:
                logger.error(f"Error updating scheduler: {e}")
            
            self.telegram_service.send_message("✅ Auto-schedule ENABLED")
            self.handle_schedule_menu()
    
    def handle_disable_schedule(self):
        """Disable auto-schedule"""
        with self.app.app_context():
            config = SystemConfig.query.first()
            
            if not config:
                self.telegram_service.send_message("❌ System not configured")
                return
            
            config.enable_auto_schedule = False
            from app import db
            db.session.commit()
            
            # Update scheduler
            try:
                from scheduler_service import get_scheduler_service
                scheduler = get_scheduler_service()
                if scheduler:
                    scheduler.update_schedule(config)
            except Exception as e:
                logger.error(f"Error updating scheduler: {e}")
            
            self.telegram_service.send_message("❌ Auto-schedule DISABLED")
            self.handle_schedule_menu()
    
    def handle_test_schedule(self, action):
        """Test schedule actions"""
        with self.app.app_context():
            config = SystemConfig.query.first()
            
            if not config:
                self.telegram_service.send_message("❌ System not configured")
                return
            
            from models import Camera
            from app import db
            
            if action == "arm":
                config.is_armed = True
                Camera.query.update({Camera.is_armed: True})
                message = "🧪 <b>Test ARM</b> - System armed successfully!"
            else:
                config.is_armed = False
                Camera.query.update({Camera.is_armed: False})
                message = "🧪 <b>Test DISARM</b> - System disarmed successfully!"
            
            db.session.commit()
            self.telegram_service.send_message(message)
    
    def handle_setarm_command(self, text):
        """Handle /setarm HH:MM command"""
        try:
            parts = text.strip().split()
            if len(parts) != 2:
                self.telegram_service.send_message("❌ <b>Invalid format</b>\n\nUse: /setarm HH:MM\nExample: /setarm 22:00")
                return
            
            time_str = parts[1]
            
            # Validate time format - more flexible validation
            import re
            time_pattern = r'^([0-1]?[0-9]|2[0-3]):([0-5][0-9])$'
            match = re.match(time_pattern, time_str)
            
            if not match:
                self.telegram_service.send_message("❌ <b>Invalid time format</b>\n\nUse HH:MM format (24-hour)\nExamples:\n• 07:00 for 7 AM\n• 22:00 for 10 PM\n• 13:30 for 1:30 PM")
                return
            
            hour = int(match.group(1))
            minute = int(match.group(2))
            formatted_time = f"{hour:02d}:{minute:02d}"
            
            # Update database
            with self.app.app_context():
                config = SystemConfig.query.first()
                if not config:
                    self.telegram_service.send_message("❌ System not configured")
                    return
                
                old_time = config.arm_time
                config.arm_time = formatted_time
                
                from app import db
                db.session.commit()
                
                # Update scheduler
                try:
                    from scheduler_service import get_scheduler_service
                    scheduler = get_scheduler_service()
                    if scheduler:
                        scheduler.update_schedule(config)
                except Exception as e:
                    logger.error(f"Error updating scheduler: {e}")
                
                self.telegram_service.send_message(f"✅ <b>Arm time updated</b>\n\n🕘 <b>Old time:</b> {old_time or 'Not set'}\n🕘 <b>New time:</b> {formatted_time}\n\n⏰ Auto-arm will occur daily at {formatted_time} on selected days.")
                
        except Exception as e:
            self.telegram_service.send_message(f"❌ Error updating arm time: {str(e)}")
    
    def handle_setdisarm_command(self, text):
        """Handle /setdisarm HH:MM command"""
        try:
            parts = text.strip().split()
            if len(parts) != 2:
                self.telegram_service.send_message("❌ <b>Invalid format</b>\n\nUse: /setdisarm HH:MM\nExample: /setdisarm 07:00")
                return
            
            time_str = parts[1]
            
            # Validate time format - more flexible validation
            import re
            time_pattern = r'^([0-1]?[0-9]|2[0-3]):([0-5][0-9])$'
            match = re.match(time_pattern, time_str)
            
            if not match:
                self.telegram_service.send_message("❌ <b>Invalid time format</b>\n\nUse HH:MM format (24-hour)\nExamples:\n• 07:00 for 7 AM\n• 22:00 for 10 PM\n• 13:30 for 1:30 PM")
                return
            
            hour = int(match.group(1))
            minute = int(match.group(2))
            formatted_time = f"{hour:02d}:{minute:02d}"
            
            # Update database
            with self.app.app_context():
                config = SystemConfig.query.first()
                if not config:
                    self.telegram_service.send_message("❌ System not configured")
                    return
                
                old_time = config.disarm_time
                config.disarm_time = formatted_time
                
                from app import db
                db.session.commit()
                
                # Update scheduler
                try:
                    from scheduler_service import get_scheduler_service
                    scheduler = get_scheduler_service()
                    if scheduler:
                        scheduler.update_schedule(config)
                except Exception as e:
                    logger.error(f"Error updating scheduler: {e}")
                
                self.telegram_service.send_message(f"✅ <b>Disarm time updated</b>\n\n🕛 <b>Old time:</b> {old_time or 'Not set'}\n🕛 <b>New time:</b> {formatted_time}\n\n⏰ Auto-disarm will occur daily at {formatted_time} on selected days.")
                
        except Exception as e:
            self.telegram_service.send_message(f"❌ Error updating disarm time: {str(e)}")
    
    def handle_setdays_command(self, text):
        """Handle /setdays 1,2,3,4,5 command"""
        try:
            parts = text.strip().split()
            if len(parts) != 2:
                self.telegram_service.send_message("❌ <b>Invalid format</b>\n\nUse: /setdays 1,2,3,4,5\n\nDays: 1=Mon, 2=Tue, 3=Wed, 4=Thu, 5=Fri, 6=Sat, 7=Sun\nExample: /setdays 1,2,3,4,5 (weekdays)")
                return
            
            days_str = parts[1]
            
            # Validate days format
            try:
                day_numbers = []
                for day in days_str.split(','):
                    day_num = int(day.strip())
                    if day_num < 1 or day_num > 7:
                        raise ValueError
                    day_numbers.append(day_num)
                
                if not day_numbers:
                    raise ValueError
                    
                # Remove duplicates and sort
                day_numbers = sorted(list(set(day_numbers)))
                
            except ValueError:
                self.telegram_service.send_message("❌ <b>Invalid days format</b>\n\nUse comma-separated numbers 1-7\nDays: 1=Mon, 2=Tue, 3=Wed, 4=Thu, 5=Fri, 6=Sat, 7=Sun\nExample: 1,2,3,4,5")
                return
            
            # Update database
            with self.app.app_context():
                config = SystemConfig.query.first()
                if not config:
                    self.telegram_service.send_message("❌ System not configured")
                    return
                
                old_days = config.get_schedule_days_list() or []
                config.set_schedule_days(day_numbers)
                
                from app import db
                db.session.commit()
                
                # Update scheduler
                try:
                    from scheduler_service import get_scheduler_service
                    scheduler = get_scheduler_service()
                    if scheduler:
                        scheduler.update_schedule(config)
                except Exception as e:
                    logger.error(f"Error updating scheduler: {e}")
                
                # Format day names
                day_names = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun']
                old_day_names = [day_names[i-1] for i in old_days] if old_days else ['None']
                new_day_names = [day_names[i-1] for i in day_numbers]
                
                self.telegram_service.send_message(f"✅ <b>Schedule days updated</b>\n\n📅 <b>Old days:</b> {', '.join(old_day_names)}\n📅 <b>New days:</b> {', '.join(new_day_names)}\n\n⏰ Auto-schedule will only run on selected days.")
                
        except Exception as e:
            self.telegram_service.send_message(f"❌ Error updating schedule days: {str(e)}")
    
    def handle_enableschedule_command(self, text):
        """Handle /enableschedule on/off command"""
        try:
            parts = text.strip().split()
            if len(parts) != 2:
                self.telegram_service.send_message("❌ <b>Invalid format</b>\n\nUse: /enableschedule on  OR  /enableschedule off")
                return
            
            action = parts[1].lower()
            
            if action not in ['on', 'off', 'enable', 'disable', 'true', 'false']:
                self.telegram_service.send_message("❌ <b>Invalid option</b>\n\nUse: on/off, enable/disable, or true/false")
                return
            
            enable = action in ['on', 'enable', 'true']
            
            # Update database
            with self.app.app_context():
                config = SystemConfig.query.first()
                if not config:
                    self.telegram_service.send_message("❌ System not configured")
                    return
                
                old_status = config.enable_auto_schedule
                config.enable_auto_schedule = enable
                
                from app import db
                db.session.commit()
                
                # Update scheduler
                try:
                    from scheduler_service import get_scheduler_service
                    scheduler = get_scheduler_service()
                    if scheduler:
                        scheduler.update_schedule(config)
                except Exception as e:
                    logger.error(f"Error updating scheduler: {e}")
                
                status_text = "✅ ENABLED" if enable else "❌ DISABLED"
                old_status_text = "✅ ENABLED" if old_status else "❌ DISABLED"
                
                if enable and (not config.arm_time or not config.disarm_time):
                    warning = "\n\n⚠️ <b>Warning:</b> Please set arm and disarm times:\n• /setarm HH:MM\n• /setdisarm HH:MM"
                else:
                    warning = ""
                
                self.telegram_service.send_message(f"✅ <b>Auto-schedule updated</b>\n\n📊 <b>Old status:</b> {old_status_text}\n📊 <b>New status:</b> {status_text}{warning}")
                
        except Exception as e:
            self.telegram_service.send_message(f"❌ Error updating schedule status: {str(e)}")
    
    def handle_reactivate_lock(self):
        """Handle re-activate lock command - enables feature password protection"""
        with self.app.app_context():
            config = SystemConfig.query.first()
            
            if not config:
                self.telegram_service.send_message("❌ System not configured")
                return
            
            # Enable feature password
            config.feature_password_enabled = True
            from app import db
            db.session.commit()
            
            keyboard = [
                [{"text": "🔙 Back to Menu", "callback_data": "start"}]
            ]
            
            self.send_keyboard(
                "🔐 <b>Feature Lock Re-activated</b>\n\n"
                "✅ The feature password protection has been re-enabled.\n\n"
                "🔒 Protected features:\n"
                "• Detection Zones\n"
                "• Stock Control\n"
                "• Advanced Settings\n\n"
                "📝 To access these features, you will need to enter the feature password through the web interface.",
                keyboard
            )
    
    def handle_sensitivity_menu(self):
        """Handle /sensitivity command — show animal/person detection sensitivity options"""
        with self.app.app_context():
            cameras = Camera.query.all()
            site_id = self.get_site_id()

            if not cameras:
                self.telegram_service.send_message("❌ No cameras configured.")
                return

            animal_vals = [c.animal_sensitivity for c in cameras if c.animal_sensitivity]
            person_vals = [c.person_sensitivity for c in cameras if c.person_sensitivity]
            animal_avg = sum(animal_vals) / len(animal_vals) if animal_vals else 0.65
            person_avg = sum(person_vals) / len(person_vals) if person_vals else 0.75
            cam_word = 'camera' if len(cameras) == 1 else 'cameras'

            text = (
                f"🎛️ <b>Detection Sensitivity</b>\n\n"
                f"🐾 <b>Animal:</b> {animal_avg:.0%} (across {len(cameras)} {cam_word})\n"
                f"👤 <b>Person:</b> {person_avg:.0%} (across {len(cameras)} {cam_word})\n\n"
                f"<i>Lower % = more sensitive (more alerts)\n"
                f"Higher % = less sensitive (fewer false alerts)</i>"
            )
            keyboard = [
                [
                    {"text": "🐾 Animal Detection", "callback_data": f"sens_animal:{site_id}"},
                    {"text": "👤 Person Detection", "callback_data": f"sens_person:{site_id}"}
                ],
                [{"text": "🔙 Back to Menu", "callback_data": f"start:{site_id}"}]
            ]
            self.send_keyboard(text, keyboard)

    def handle_sensitivity_animal_menu(self):
        """Show animal detection sensitivity percentage options"""
        with self.app.app_context():
            cameras = Camera.query.all()
            site_id = self.get_site_id()
            animal_vals = [c.animal_sensitivity for c in cameras if c.animal_sensitivity]
            current = sum(animal_vals) / len(animal_vals) if animal_vals else 0.65
            current_pct = int(round(current * 100))

            text = (
                f"🐾 <b>Animal Detection Sensitivity</b>\n\n"
                f"📊 <b>Current:</b> {current_pct}%\n\n"
                f"Select a new threshold:\n"
                f"<i>(Lower = more alerts, Higher = fewer false alerts)</i>"
            )
            options = [50, 55, 60, 65, 68, 70, 75, 80]
            buttons = []
            row = []
            for pct in options:
                label = f"✅ {pct}%" if pct == current_pct else f"{pct}%"
                row.append({"text": label, "callback_data": f"sens_set_animal_{pct}:{site_id}"})
                if len(row) == 3:
                    buttons.append(row)
                    row = []
            if row:
                buttons.append(row)
            buttons.append([
                {"text": "🔙 Back", "callback_data": f"sens_menu:{site_id}"},
                {"text": "🏠 Main Menu", "callback_data": f"start:{site_id}"}
            ])
            self.send_keyboard(text, buttons)

    def handle_sensitivity_person_menu(self):
        """Show person detection sensitivity percentage options"""
        with self.app.app_context():
            cameras = Camera.query.all()
            site_id = self.get_site_id()
            person_vals = [c.person_sensitivity for c in cameras if c.person_sensitivity]
            current = sum(person_vals) / len(person_vals) if person_vals else 0.75
            current_pct = int(round(current * 100))

            text = (
                f"👤 <b>Person Detection Sensitivity</b>\n\n"
                f"📊 <b>Current:</b> {current_pct}%\n\n"
                f"Select a new threshold:\n"
                f"<i>(Lower = more alerts, Higher = fewer false alerts)</i>"
            )
            options = [50, 55, 60, 65, 68, 70, 75, 80]
            buttons = []
            row = []
            for pct in options:
                label = f"✅ {pct}%" if pct == current_pct else f"{pct}%"
                row.append({"text": label, "callback_data": f"sens_set_person_{pct}:{site_id}"})
                if len(row) == 3:
                    buttons.append(row)
                    row = []
            if row:
                buttons.append(row)
            buttons.append([
                {"text": "🔙 Back", "callback_data": f"sens_menu:{site_id}"},
                {"text": "🏠 Main Menu", "callback_data": f"start:{site_id}"}
            ])
            self.send_keyboard(text, buttons)

    def handle_set_sensitivity(self, det_type, value_pct):
        """Apply a sensitivity change to all cameras"""
        with self.app.app_context():
            from app import db
            cameras = Camera.query.all()
            site_id = self.get_site_id()

            if not cameras:
                self.telegram_service.send_message("❌ No cameras configured.")
                return

            value = value_pct / 100.0
            if det_type == 'animal':
                for cam in cameras:
                    cam.animal_sensitivity = value
                field_label = "Animal Detection"
                emoji = "🐾"
            else:
                for cam in cameras:
                    cam.person_sensitivity = value
                field_label = "Person Detection"
                emoji = "👤"

            db.session.commit()
            cam_word = 'camera' if len(cameras) == 1 else 'cameras'
            text = (
                f"✅ <b>Sensitivity Updated</b>\n\n"
                f"{emoji} <b>{field_label}:</b> {value_pct}%\n"
                f"📷 Applied to {len(cameras)} {cam_word}\n\n"
                f"<i>Change takes effect on the next detection.</i>"
            )
            keyboard = [
                [
                    {"text": "🎛️ Back to Sensitivity", "callback_data": f"sens_menu:{site_id}"},
                    {"text": "🏠 Main Menu", "callback_data": f"start:{site_id}"}
                ]
            ]
            self.send_keyboard(text, keyboard)

    def handle_callback_query(self, callback_data):
        """Handle inline keyboard button clicks - checks site_id to ensure only correct Pi responds"""
        # Parse site_id from callback_data (format: "action:site_id" or "action_param:site_id")
        my_site_id = self.get_site_id()
        
        # Check if callback has site_id and if it matches this Pi
        if ':' in callback_data:
            parts = callback_data.rsplit(':', 1)
            action = parts[0]
            callback_site_id = parts[1]
            
            # Only respond if site_id matches THIS Pi
            if callback_site_id != my_site_id:
                logger.debug(f"Ignoring callback for different site: {callback_site_id} (this is {my_site_id})")
                return
        else:
            # Legacy callback without site_id - process normally for backwards compatibility
            action = callback_data
        
        # Process the action
        if action == "start":
            self.handle_start()
        elif action == "open_site":
            self.handle_open_site()
        elif action == "switch_site":
            self.handle_switch_site()
        elif action == "status":
            self.handle_status()
        elif action == "arm":
            self.handle_arm()
        elif action == "disarm":
            self.handle_disarm()
        elif action.startswith("arm_confirm"):
            self.handle_arm_confirm()
        elif action.startswith("disarm_confirm"):
            self.handle_disarm_confirm()
        elif action == "schedule_menu":
            self.handle_schedule_menu()
        elif action == "view_schedule":
            self.handle_view_schedule()
        elif action == "enable_schedule":
            self.handle_enable_schedule()
        elif action == "disable_schedule":
            self.handle_disable_schedule()
        elif action == "test_arm":
            self.handle_test_schedule("arm")
        elif action == "test_disarm":
            self.handle_test_schedule("disarm")
        elif action == "snapshot_menu":
            self.handle_snapshot_menu()
        elif action == "snapshot_all":
            self.handle_snapshot("all")
        elif action.startswith("snapshot_"):
            camera_id = int(action.replace("snapshot_", ""))
            self.handle_snapshot(camera_id)
        elif action == "cameras":
            self.handle_cameras()
        elif action == "events":
            self.handle_events()
        elif action == "stats":
            self.handle_stats()
        elif action == "help":
            self.handle_help()
        elif action == "reactivate_lock":
            self.handle_reactivate_lock()
        elif action == "snooze":
            self.handle_snooze()
        elif action.startswith("snooze_"):
            duration = int(action.replace("snooze_", ""))
            self.handle_snooze(duration)
        elif action == "unsnooze":
            self.handle_unsnooze()
        elif action == "sens_menu":
            self.handle_sensitivity_menu()
        elif action == "sens_animal":
            self.handle_sensitivity_animal_menu()
        elif action == "sens_person":
            self.handle_sensitivity_person_menu()
        elif action.startswith("sens_set_animal_"):
            pct = int(action.replace("sens_set_animal_", ""))
            self.handle_set_sensitivity("animal", pct)
        elif action.startswith("sens_set_person_"):
            pct = int(action.replace("sens_set_person_", ""))
            self.handle_set_sensitivity("person", pct)
        elif action == "alert_ok":
            # User confirmed the alert was real — no action needed
            self.send_message_to_user(self.chat_id, "✅ Alert confirmed as real.")
        elif action.startswith("fp_cam_"):
            # User reported a false positive — record it to train confidence auto-tuner
            try:
                cam_id = int(action.replace("fp_cam_", ""))
                from detection_engine import detection_engine as _de
                if _de:
                    _de.record_false_positive(cam_id)
                with self.app.app_context():
                    from models import Camera
                    cam = Camera.query.get(cam_id)
                    cam_name = cam.name if cam else f"Camera {cam_id}"
                new_thresh = None
                if _de:
                    new_thresh = _de.camera_conf_thresholds.get(cam_id)
                msg = (
                    f"❌ <b>False alert recorded</b>\n\n"
                    f"📷 Camera: <b>{cam_name}</b>\n"
                    f"🎯 The AI confidence threshold for this camera will automatically tighten to reduce future false alerts."
                )
                if new_thresh:
                    msg += f"\n📈 Current threshold: <b>{new_thresh:.2f}</b>"
                self.send_message_to_user(self.chat_id, msg)
                logger.info(f"False positive reported via Telegram for camera {cam_id}")
            except Exception as e:
                logger.error(f"Error handling fp callback: {e}")
                self.send_message_to_user(self.chat_id, "❌ False alert recorded.")
    
    def process_updates(self):
        """Process incoming Telegram updates - Only responds to users configured on THIS site"""
        if not self.bot_token:
            return
        
        try:
            url = f"https://api.telegram.org/bot{self.bot_token}/getUpdates"
            params = {
                'offset': self.last_update_id + 1,
                'timeout': 30
            }
            
            response = requests.get(url, params=params, timeout=35)
            
            if response.status_code != 200:
                return
            
            data = response.json()
            
            if not data.get('ok'):
                return
            
            updates = data.get('result', [])
            
            for update in updates:
                self.last_update_id = update['update_id']
                
                # Handle text commands
                if 'message' in update:
                    message = update['message']
                    chat_id = str(message.get('chat', {}).get('id'))
                    
                    # Check if user is authorized ON THIS SITE
                    # Each Pi only responds to users configured in its own database
                    with self.app.app_context():
                        config = SystemConfig.query.first()
                        if not config:
                            continue
                        
                        # Get list of chat IDs configured on THIS site
                        authorized_chat_ids = config.get_chat_ids()
                        
                        # Only process if this user is registered on THIS site
                        if chat_id not in authorized_chat_ids:
                            # User not registered on this Pi - skip (another Pi will handle it)
                            continue
                        
                        is_admin = config.is_admin(chat_id)
                    
                    # IMPORTANT: Set chat_id so responses go to THIS user
                    original_chat_id = self.chat_id
                    self.chat_id = chat_id
                    
                    text = message.get('text', '')
                    
                    try:
                        if text.startswith('/'):
                            command = text.split()[0].replace('/', '').split('@')[0]
                            
                            # Commands available to all users
                            if command == 'start':
                                self.handle_start()
                            elif command == 'status':
                                self.handle_status()
                            elif command == 'cameras':
                                self.handle_cameras()
                            elif command == 'events':
                                self.handle_events()
                            elif command == 'stats':
                                self.handle_stats()
                            elif command == 'help':
                                self.handle_help()
                            # Admin-only commands
                            elif command == 'arm':
                                if is_admin:
                                    self.handle_arm()
                                else:
                                    self.send_message_to_user(chat_id, "🔒 <b>Access Denied</b>\n\nOnly administrators can arm/disarm the system.")
                            elif command == 'disarm':
                                if is_admin:
                                    self.handle_disarm()
                                else:
                                    self.send_message_to_user(chat_id, "🔒 <b>Access Denied</b>\n\nOnly administrators can arm/disarm the system.")
                            elif command == 'snapshot':
                                if is_admin:
                                    self.handle_snapshot_menu()
                                else:
                                    self.send_message_to_user(chat_id, "🔒 <b>Access Denied</b>\n\nOnly administrators can take snapshots.")
                            elif command == 'setarm':
                                if is_admin:
                                    self.handle_setarm_command(text)
                                else:
                                    self.send_message_to_user(chat_id, "🔒 <b>Access Denied</b>\n\nOnly administrators can modify schedule settings.")
                            elif command == 'setdisarm':
                                if is_admin:
                                    self.handle_setdisarm_command(text)
                                else:
                                    self.send_message_to_user(chat_id, "🔒 <b>Access Denied</b>\n\nOnly administrators can modify schedule settings.")
                            elif command == 'setdays':
                                if is_admin:
                                    self.handle_setdays_command(text)
                                else:
                                    self.send_message_to_user(chat_id, "🔒 <b>Access Denied</b>\n\nOnly administrators can modify schedule settings.")
                            elif command == 'enableschedule':
                                if is_admin:
                                    self.handle_enableschedule_command(text)
                                else:
                                    self.send_message_to_user(chat_id, "🔒 <b>Access Denied</b>\n\nOnly administrators can modify schedule settings.")
                            elif command == 'schedule':
                                self.handle_schedule_menu()
                            elif command == 'snooze':
                                if is_admin:
                                    self.handle_snooze()
                                else:
                                    self.send_message_to_user(chat_id, "🔒 <b>Access Denied</b>\n\nOnly administrators can snooze alerts.")
                            elif command == 'unsnooze':
                                if is_admin:
                                    self.handle_unsnooze()
                                else:
                                    self.send_message_to_user(chat_id, "🔒 <b>Access Denied</b>\n\nOnly administrators can unsnooze alerts.")
                            elif command == 'sensitivity':
                                if is_admin:
                                    self.handle_sensitivity_menu()
                                else:
                                    self.send_message_to_user(chat_id, "🔒 <b>Access Denied</b>\n\nOnly administrators can adjust detection sensitivity.")
                    finally:
                        # Restore original chat_id
                        self.chat_id = original_chat_id
                
                # Handle callback queries (button clicks)
                elif 'callback_query' in update:
                    callback = update['callback_query']
                    callback_chat_id = str(callback.get('message', {}).get('chat', {}).get('id'))
                    
                    # Check if user is authorized ON THIS SITE (same isolation logic)
                    with self.app.app_context():
                        config = SystemConfig.query.first()
                        if not config:
                            continue
                        
                        # Only process if this user is registered on THIS site
                        authorized_chat_ids = config.get_chat_ids()
                        if callback_chat_id not in authorized_chat_ids:
                            # User not registered on this Pi - skip
                            continue
                        
                        is_callback_admin = config.is_admin(callback_chat_id)
                    
                    # Check if this callback was already processed (prevent double-processing)
                    callback_id = callback.get('id')
                    if self.is_callback_processed(callback_id):
                        logger.debug(f"Skipping already-processed callback: {callback_id}")
                        continue
                    
                    # Store current chat_id to respond to the correct user
                    original_chat_id = self.chat_id
                    self.chat_id = callback_chat_id
                    
                    # Non-admins can only use read-only buttons
                    read_only_actions = ['start', 'status', 'cameras', 'events', 'stats', 'help']
                    
                    if not is_callback_admin and callback.get('data') not in read_only_actions:
                        # Send access denied message to the user
                        try:
                            url = f"https://api.telegram.org/bot{self.bot_token}/sendMessage"
                            payload = {
                                'chat_id': callback_chat_id,
                                'text': "🔒 <b>Access Denied</b>\n\nOnly administrators can use this function.\n\nContact your system admin to upgrade your role.",
                                'parse_mode': 'HTML'
                            }
                            requests.post(url, json=payload, timeout=10)
                        except:
                            pass
                        self.chat_id = original_chat_id
                        continue
                    
                    callback_data = callback.get('data')
                    
                    # Answer callback query to remove loading state
                    try:
                        answer_url = f"https://api.telegram.org/bot{self.bot_token}/answerCallbackQuery"
                        requests.post(answer_url, json={'callback_query_id': callback_id}, timeout=5)
                    except:
                        pass
                    
                    self.handle_callback_query(callback_data)
                    
                    # Restore original chat_id if needed
                    self.chat_id = original_chat_id
        
        except Exception as e:
            logger.error(f"Error processing Telegram updates: {e}")
    
    def start_polling(self):
        """Start polling for updates"""
        import threading
        import time
        
        self.running = True
        
        def poll():
            while self.running:
                try:
                    self.process_updates()
                except Exception as e:
                    logger.error(f"Polling error: {e}")
                    time.sleep(5)
        
        thread = threading.Thread(target=poll, daemon=True)
        thread.start()
        logger.info("Telegram bot command polling started")
    
    def stop_polling(self):
        """Stop polling for updates"""
        self.running = False
        logger.info("Telegram bot command polling stopped")


# Global instance
bot_commands = None


def init_bot_commands(app, telegram_service):
    """Initialize bot commands handler"""
    global bot_commands
    bot_commands = TelegramBotCommands(app, telegram_service)
    return bot_commands
