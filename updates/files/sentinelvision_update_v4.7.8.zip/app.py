"""
SentinelVision Security Platform
Professional security camera system with AI detection and Telegram notifications
"""
from flask import Flask, render_template, request, jsonify, redirect, url_for, flash, send_from_directory, session, Response
from flask_cors import CORS
from models import db, SystemConfig, Camera, DetectionEvent, SystemStats, StockItem, StockDelivery, StockWaste, StockUsageHistory, DetectionZone
from flask import send_file
from telegram_service import telegram_service
from network_scanner import NetworkScanner
from scheduler_service import init_scheduler_service, get_scheduler_service
import os
import json
from datetime import datetime, timedelta
import logging
from pathlib import Path
import psutil
import socket
import threading
from functools import wraps
import time
import cv2
import numpy as np

# Import detection engine (may not be running)
detection_engine = None
try:
    from detection_engine import detection_engine as _detection_engine
    detection_engine = _detection_engine
except ImportError:
    pass


def set_detection_engine(engine):
    """Called by run.py after the detection engine is initialised so that
    all API endpoints see the live instance, not the None placeholder."""
    global detection_engine
    detection_engine = engine

# Simple in-memory login rate limiter
# {ip: [(timestamp, failed), ...]}
_login_attempts: dict = {}
_LOGIN_MAX_FAILURES = 5     # max failed attempts
_LOGIN_WINDOW_SECONDS = 60  # within this window
_LOGIN_LOCKOUT_SECONDS = 300  # lockout duration after exceeding limit

def _check_login_rate_limit(ip: str) -> tuple:
    """Return (allowed: bool, seconds_remaining: int)"""
    now = time.time()
    attempts = _login_attempts.get(ip, [])
    # Remove old entries outside the window
    attempts = [t for t in attempts if now - t < _LOGIN_LOCKOUT_SECONDS]
    _login_attempts[ip] = attempts
    recent_failures = [t for t in attempts if now - t < _LOGIN_WINDOW_SECONDS]
    if len(recent_failures) >= _LOGIN_MAX_FAILURES:
        oldest = min(recent_failures)
        remaining = int(_LOGIN_LOCKOUT_SECONDS - (now - oldest))
        return False, max(remaining, 1)
    return True, 0

def _record_login_failure(ip: str):
    now = time.time()
    _login_attempts.setdefault(ip, []).append(now)

def log_audit(action, username=None, target_type=None, target_id=None, details=None):
    """Record a security audit log entry (call from request context only)"""
    try:
        from models import AuditLog
        if username is None:
            username = session.get('logged_in_username') or ('admin' if session.get('admin_logged_in') else 'viewer')
        entry = AuditLog(
            username=username,
            action=action,
            target_type=target_type,
            target_id=target_id,
            details=json.dumps(details) if details else None,
            ip_address=(request.remote_addr or '?')[:45],
            user_agent=(request.headers.get('User-Agent', '') or '')[:500]
        )
        db.session.add(entry)
        db.session.commit()
    except Exception:
        pass  # Audit log must never break normal flow

# Setup logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)


def get_local_ip():
    """Get the local IP address of the machine"""
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("8.8.8.8", 80))
        ip = s.getsockname()[0]
        s.close()
        return ip
    except:
        return "127.0.0.1"

# ── Disk alert state ──────────────────────────────────────────────────
_disk_alert_sent = False

def check_disk_and_alert():
    """Send Telegram warning if disk usage crosses 85%; resets when it drops below 80%"""
    global _disk_alert_sent
    try:
        import psutil as _pu
        disk = _pu.disk_usage('/')
        pct = disk.percent
        if pct >= 85 and not _disk_alert_sent:
            free_gb  = disk.free  / (1024 ** 3)
            total_gb = disk.total / (1024 ** 3)
            msg = (
                f"\U0001f4be <b>Disk Almost Full \u2014 {pct:.1f}% used</b>\n\n"
                f"\U0001f4ca <b>Free:</b> {free_gb:.1f} GB of {total_gb:.1f} GB remaining\n\n"
                f"\u26a0\ufe0f Detection images may stop saving when disk is full.\n"
                f"\U0001f5d1\ufe0f <b>Action:</b> Go to Settings \u2192 Delete All Events to free up space."
            )
            telegram_service.send_system_alert('warning', msg)
            _disk_alert_sent = True
            logger.warning(f"Disk usage at {pct:.1f}% \u2014 Telegram alert sent")
        elif pct < 80 and _disk_alert_sent:
            _disk_alert_sent = False  # Reset so it can alert again next time
    except Exception as e:
        logger.error(f"Disk alert check failed: {e}")

def cleanup_old_events():
    """Delete detection events older than 7 days (auto-cleanup)"""
    try:
        with app.app_context():
            days = 7
            cutoff_date = datetime.utcnow() - timedelta(days=days)
            # Load only file-path columns — avoids pulling full ORM objects into RAM
            rows = (DetectionEvent.query
                    .filter(DetectionEvent.created_at < cutoff_date)
                    .with_entities(DetectionEvent.id, DetectionEvent.image_path,
                                   DetectionEvent.thumbnail_path, DetectionEvent.clip_path)
                    .all())
            
            if rows:
                count = len(rows)
                event_ids = [r.id for r in rows]
                
                # Delete associated files
                for row in rows:
                    if row.image_path and os.path.exists(row.image_path):
                        try:
                            os.remove(row.image_path)
                        except:
                            pass
                    # Delete thumbnail
                    if row.thumbnail_path and os.path.exists(row.thumbnail_path):
                        try:
                            os.remove(row.thumbnail_path)
                        except:
                            pass
                    # Delete video clip
                    if row.clip_path:
                        full_clip = os.path.join(os.path.dirname(__file__), row.clip_path)
                        if os.path.exists(full_clip):
                            try:
                                os.remove(full_clip)
                            except:
                                pass
                
                # Delete related analytics records tied to these events / time range
                try:
                    from models import ZoneTransition, ZoneHeatmapData, ZoneDailyStats, LoiteringEvent, OccupancyLog
                    # Bulk delete analytics data older than cutoff (not tied to specific events)
                    ZoneTransition.query.filter(ZoneTransition.timestamp < cutoff_date).delete(synchronize_session=False)
                    OccupancyLog.query.filter(OccupancyLog.timestamp < cutoff_date).delete(synchronize_session=False)
                    LoiteringEvent.query.filter(LoiteringEvent.created_at < cutoff_date).delete(synchronize_session=False)
                except Exception as ana_err:
                    logger.warning(f"Analytics cleanup error: {ana_err}")

                # Delete the events themselves — single bulk query, not N individual deletes
                DetectionEvent.query.filter(DetectionEvent.id.in_(event_ids)).delete(synchronize_session=False)
                
                db.session.commit()
                logger.info(f"Cleaned up {count} events older than {days} days")
                return count
            return 0
    except Exception as e:
        logger.error(f"Failed to cleanup old events: {e}")
        return 0

def schedule_cleanup():
    """Schedule automatic cleanup every 24 hours; check disk every hour"""
    def _cleanup_loop():
        hours = 0
        while True:
            time.sleep(3600)  # wake every hour
            hours += 1
            try:
                check_disk_and_alert()
            except Exception as e:
                logger.error(f"Disk check error: {e}")
            if hours >= 24:
                hours = 0
                try:
                    cleanup_old_events()
                except Exception as e:
                    logger.error(f"Scheduled cleanup error: {e}")
    
    t = threading.Thread(target=_cleanup_loop, daemon=True, name='cleanup-scheduler')
    t.start()


def _get_or_create_secret_key():
    """Return a persistent random secret key, generating one on first run."""
    import secrets as _secrets
    key_file = Path(__file__).parent / '.sentinelvision_secret'
    try:
        if key_file.exists():
            return key_file.read_text().strip()
        key = _secrets.token_hex(32)
        key_file.write_text(key)
        try:
            key_file.chmod(0o600)
        except Exception:
            pass  # Windows — chmod is a no-op
        return key
    except Exception:
        # Final fallback: random key valid only for this process lifetime
        return _secrets.token_hex(32)


# Initialize Flask app
app = Flask(__name__)
app.config['SECRET_KEY'] = os.environ.get('SECRET_KEY') or _get_or_create_secret_key()
app.config['SQLALCHEMY_DATABASE_URI'] = os.environ.get('DATABASE_URL', 'sqlite:///sentinelvision.db')
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
app.config['MAX_CONTENT_LENGTH'] = 16 * 1024 * 1024  # 16MB max file size

# SQLite tuning for multi-camera concurrent writes
# WAL mode allows multiple readers + 1 writer simultaneously (critical for 5+ cameras)
# busy_timeout: wait up to 5s instead of immediately failing on a locked DB
app.config['SQLALCHEMY_ENGINE_OPTIONS'] = {
    'connect_args': {'check_same_thread': False, 'timeout': 5},
    'pool_size': 1,          # SQLite works best with 1 connection per process
    'pool_timeout': 10,
    'pool_recycle': 300,
}

# Session security
app.config['SESSION_COOKIE_HTTPONLY'] = True    # JS cannot read the session cookie
app.config['SESSION_COOKIE_SAMESITE'] = 'Lax'   # CSRF mitigation for normal browsing
app.config['PERMANENT_SESSION_LIFETIME'] = timedelta(hours=12)  # Auto-logout after 12h idle
# Secure cookie: auto-enabled when running behind HTTPS (reverse proxy sets this env var)
# or when FORCE_HTTPS env var is explicitly set. Safe to leave unset on local HTTP.
app.config['SESSION_COOKIE_SECURE'] = os.environ.get('FORCE_HTTPS', '').lower() in ('1', 'true', 'yes')

# Upload folders
UPLOAD_FOLDER = Path(__file__).parent / 'uploads'
UPLOAD_FOLDER.mkdir(exist_ok=True)
app.config['UPLOAD_FOLDER'] = str(UPLOAD_FOLDER)

CLIPS_FOLDER = Path(__file__).parent / 'uploads' / 'clips'
CLIPS_FOLDER.mkdir(parents=True, exist_ok=True)
app.config['CLIPS_FOLDER'] = str(CLIPS_FOLDER)

# Initialize extensions
db.init_app(app)
# Restrict CORS to API paths only — no wildcard on HTML pages, no credential leak
CORS(app, resources={r'/api/*': {'origins': '*'}}, supports_credentials=False)

# Route to serve uploaded files
@app.route('/uploads/<path:filename>')
def uploaded_file(filename):
    """Serve uploaded detection images"""
    return send_from_directory(app.config['UPLOAD_FOLDER'], filename)

@app.route('/clips/<path:filename>')
def serve_clip(filename):
    """Serve video clips"""
    return send_from_directory(app.config['CLIPS_FOLDER'], filename)

# Create database tables
with app.app_context():
    db.create_all()
    # Enable WAL mode for SQLite — allows concurrent reads while a camera thread writes
    try:
        from sqlalchemy import text
        with db.engine.connect() as _conn:
            _conn.execute(text('PRAGMA journal_mode=WAL'))
            _conn.execute(text('PRAGMA synchronous=NORMAL'))  # Safe + fast for WAL
            _conn.execute(text('PRAGMA cache_size=-32000'))    # 32 MB page cache
            _conn.execute(text('PRAGMA busy_timeout=5000'))    # 5s wait on lock
            _conn.commit()
        logger.info("SQLite WAL mode enabled")
    except Exception as _wal_err:
        logger.debug(f"WAL setup: {_wal_err}")
    logger.info("Database initialized")
    
    # Run migration to add telegram_users column if needed
    try:
        from sqlalchemy import text, inspect
        inspector = inspect(db.engine)
        columns = [col['name'] for col in inspector.get_columns('system_config')]
        if 'telegram_users' not in columns:
            with db.engine.connect() as conn:
                conn.execute(text('ALTER TABLE system_config ADD COLUMN telegram_users TEXT'))
                conn.commit()
            logger.info("Added telegram_users column via migration")
    except Exception as e:
        logger.debug(f"Migration check: {e}")
    
    # Run migration to add stock control columns
    try:
        from sqlalchemy import text, inspect
        inspector = inspect(db.engine)
        
        # Add stock control columns to cameras table
        camera_columns = [col['name'] for col in inspector.get_columns('cameras')]
        if 'enable_stock_control' not in camera_columns:
            with db.engine.connect() as conn:
                conn.execute(text('ALTER TABLE cameras ADD COLUMN enable_stock_control BOOLEAN DEFAULT 0'))
                conn.commit()
            logger.info("Added enable_stock_control column to cameras")
        
        if 'stock_items' not in camera_columns:
            with db.engine.connect() as conn:
                conn.execute(text('ALTER TABLE cameras ADD COLUMN stock_items TEXT'))
                conn.commit()
            logger.info("Added stock_items column to cameras")
        
        if 'stock_low_threshold' not in camera_columns:
            with db.engine.connect() as conn:
                conn.execute(text('ALTER TABLE cameras ADD COLUMN stock_low_threshold INTEGER DEFAULT 50'))
                conn.commit()
            logger.info("Added stock_low_threshold column to cameras")
        
        if 'stock_critical_threshold' not in camera_columns:
            with db.engine.connect() as conn:
                conn.execute(text('ALTER TABLE cameras ADD COLUMN stock_critical_threshold INTEGER DEFAULT 20'))
                conn.commit()
            logger.info("Added stock_critical_threshold column to cameras")
        
        # Add new camera columns for streams and exclusion zones
        if 'main_stream_url' not in camera_columns:
            with db.engine.connect() as conn:
                conn.execute(text('ALTER TABLE cameras ADD COLUMN main_stream_url VARCHAR(500)'))
                conn.commit()
            logger.info("Added main_stream_url column to cameras")
        
        if 'exclusion_zones' not in camera_columns:
            with db.engine.connect() as conn:
                conn.execute(text('ALTER TABLE cameras ADD COLUMN exclusion_zones TEXT'))
                conn.commit()
            logger.info("Added exclusion_zones column to cameras")
        
        if 'is_dvr_channel' not in camera_columns:
            with db.engine.connect() as conn:
                conn.execute(text('ALTER TABLE cameras ADD COLUMN is_dvr_channel BOOLEAN DEFAULT 0'))
                conn.commit()
            logger.info("Added is_dvr_channel column to cameras")
        
        if 'require_motion' not in camera_columns:
            with db.engine.connect() as conn:
                conn.execute(text('ALTER TABLE cameras ADD COLUMN require_motion BOOLEAN DEFAULT 1'))
                conn.commit()
            logger.info("Added require_motion column to cameras")
        
        if 'min_consecutive_frames' not in camera_columns:
            with db.engine.connect() as conn:
                conn.execute(text('ALTER TABLE cameras ADD COLUMN min_consecutive_frames INTEGER DEFAULT 2'))
                conn.commit()
            logger.info("Added min_consecutive_frames column to cameras")
        
        # Add zone-only detection column
        if 'zone_only_detection' not in camera_columns:
            with db.engine.connect() as conn:
                conn.execute(text('ALTER TABLE cameras ADD COLUMN zone_only_detection BOOLEAN DEFAULT 0'))
                conn.commit()
            logger.info("Added zone_only_detection column to cameras")
        
        # Add time-based sensitivity columns
        if 'day_sensitivity' not in camera_columns:
            with db.engine.connect() as conn:
                conn.execute(text('ALTER TABLE cameras ADD COLUMN day_sensitivity REAL DEFAULT 0.5'))
                conn.commit()
            logger.info("Added day_sensitivity column to cameras")
        
        if 'night_sensitivity' not in camera_columns:
            with db.engine.connect() as conn:
                conn.execute(text('ALTER TABLE cameras ADD COLUMN night_sensitivity REAL DEFAULT 0.4'))
                conn.commit()
            logger.info("Added night_sensitivity column to cameras")

        if 'animal_sensitivity' not in camera_columns:
            with db.engine.connect() as conn:
                conn.execute(text('ALTER TABLE cameras ADD COLUMN animal_sensitivity REAL DEFAULT 0.88'))
                conn.commit()
            logger.info("Added animal_sensitivity column to cameras")

        if 'person_sensitivity' not in camera_columns:
            with db.engine.connect() as conn:
                conn.execute(text('ALTER TABLE cameras ADD COLUMN person_sensitivity REAL DEFAULT 0.75'))
                conn.commit()
            logger.info("Added person_sensitivity column to cameras")

        if 'night_ir_threshold' not in camera_columns:
            with db.engine.connect() as conn:
                conn.execute(text('ALTER TABLE cameras ADD COLUMN night_ir_threshold REAL DEFAULT 12.0'))
                conn.commit()
            logger.info("Added night_ir_threshold column to cameras")

        if 'detection_cooldown_seconds' not in camera_columns:
            with db.engine.connect() as conn:
                conn.execute(text('ALTER TABLE cameras ADD COLUMN detection_cooldown_seconds INTEGER DEFAULT 60'))
                conn.commit()
            logger.info("Added detection_cooldown_seconds column to cameras")

        if 'animal_min_size' not in camera_columns:
            with db.engine.connect() as conn:
                conn.execute(text('ALTER TABLE cameras ADD COLUMN animal_min_size INTEGER DEFAULT 1500'))
                conn.commit()
            logger.info("Added animal_min_size column to cameras")
        
        # Add snooze column
        if 'snooze_until' not in camera_columns:
            with db.engine.connect() as conn:
                conn.execute(text('ALTER TABLE cameras ADD COLUMN snooze_until DATETIME'))
                conn.commit()
            logger.info("Added snooze_until column to cameras")
        
        # Add weapon detection columns
        if 'enable_weapon_detection' not in camera_columns:
            with db.engine.connect() as conn:
                conn.execute(text('ALTER TABLE cameras ADD COLUMN enable_weapon_detection BOOLEAN DEFAULT 0'))
                conn.commit()
            logger.info("Added enable_weapon_detection column to cameras")
        
        if 'weapon_alert_sound' not in camera_columns:
            with db.engine.connect() as conn:
                conn.execute(text('ALTER TABLE cameras ADD COLUMN weapon_alert_sound BOOLEAN DEFAULT 1'))
                conn.commit()
            logger.info("Added weapon_alert_sound column to cameras")

        if 'enable_face_blur' not in camera_columns:
            with db.engine.connect() as conn:
                conn.execute(text('ALTER TABLE cameras ADD COLUMN enable_face_blur BOOLEAN DEFAULT 0'))
                conn.commit()
            logger.info("Added enable_face_blur column to cameras")

        if 'detect_falling' not in camera_columns:
            with db.engine.connect() as conn:
                conn.execute(text('ALTER TABLE cameras ADD COLUMN detect_falling BOOLEAN DEFAULT 1'))
                conn.commit()
            logger.info("Added detect_falling column to cameras")

        if 'enable_anomaly_detection' not in camera_columns:
            with db.engine.connect() as conn:
                conn.execute(text('ALTER TABLE cameras ADD COLUMN enable_anomaly_detection BOOLEAN DEFAULT 1'))
                conn.commit()
            logger.info("Added enable_anomaly_detection column to cameras")
        
        # Add stock control columns to detection_events table
        event_columns = [col['name'] for col in inspector.get_columns('detection_events')]
        if 'item_count' not in event_columns:
            with db.engine.connect() as conn:
                conn.execute(text('ALTER TABLE detection_events ADD COLUMN item_count INTEGER DEFAULT 0'))
                conn.commit()
            logger.info("Added item_count column to detection_events")
        
        if 'item_name' not in event_columns:
            with db.engine.connect() as conn:
                conn.execute(text('ALTER TABLE detection_events ADD COLUMN item_name VARCHAR(100)'))
                conn.commit()
            logger.info("Added item_name column to detection_events")
    except Exception as e:
        logger.debug(f"Stock control migration check: {e}")
    
    # Create new analytics tables
    try:
        from sqlalchemy import text, inspect
        inspector = inspect(db.engine)
        
        # Check if tables exist
        tables = inspector.get_table_names()
        
        if 'detection_zones' not in tables:
            logger.info("Creating detection_zones table...")
        if 'occupancy_logs' not in tables:
            logger.info("Creating occupancy_logs table...")
        if 'loitering_events' not in tables:
            logger.info("Creating loitering_events table...")
        
        # Create new zone analytics tables
        if 'zone_transitions' not in tables:
            logger.info("Creating zone_transitions table for entry/exit analytics...")
        if 'zone_heatmap_data' not in tables:
            logger.info("Creating zone_heatmap_data table for activity heatmaps...")
        if 'zone_daily_stats' not in tables:
            logger.info("Creating zone_daily_stats table for daily aggregations...")
        
        # Create all tables
        db.create_all()
        logger.info("Analytics tables created successfully")
        
        # Migrate detection_zones table for new features
        if 'detection_zones' in tables:
            columns = [c['name'] for c in inspector.get_columns('detection_zones')]
            with db.engine.connect() as conn:
                # Line crossing / tripwire columns
                if 'line_points' not in columns:
                    conn.execute(text('ALTER TABLE detection_zones ADD COLUMN line_points TEXT'))
                    logger.info("Added line_points column for tripwire detection")
                if 'line_direction' not in columns:
                    conn.execute(text('ALTER TABLE detection_zones ADD COLUMN line_direction VARCHAR(20) DEFAULT "both"'))
                    logger.info("Added line_direction column")
                
                # Zone scheduling columns
                if 'schedule_enabled' not in columns:
                    conn.execute(text('ALTER TABLE detection_zones ADD COLUMN schedule_enabled BOOLEAN DEFAULT 0'))
                    logger.info("Added schedule_enabled column")
                if 'active_start_time' not in columns:
                    conn.execute(text('ALTER TABLE detection_zones ADD COLUMN active_start_time VARCHAR(10) DEFAULT "00:00"'))
                    logger.info("Added active_start_time column")
                if 'active_end_time' not in columns:
                    conn.execute(text('ALTER TABLE detection_zones ADD COLUMN active_end_time VARCHAR(10) DEFAULT "23:59"'))
                    logger.info("Added active_end_time column")
                if 'active_days' not in columns:
                    conn.execute(text('ALTER TABLE detection_zones ADD COLUMN active_days VARCHAR(20) DEFAULT "0,1,2,3,4,5,6"'))
                    logger.info("Added active_days column")
                
                # Preset and path tracking columns
                if 'preset_type' not in columns:
                    conn.execute(text('ALTER TABLE detection_zones ADD COLUMN preset_type VARCHAR(50)'))
                    logger.info("Added preset_type column")
                if 'enable_path_tracking' not in columns:
                    conn.execute(text('ALTER TABLE detection_zones ADD COLUMN enable_path_tracking BOOLEAN DEFAULT 0'))
                    logger.info("Added enable_path_tracking column")
                if 'path_history_seconds' not in columns:
                    conn.execute(text('ALTER TABLE detection_zones ADD COLUMN path_history_seconds INTEGER DEFAULT 30'))
                    logger.info("Added path_history_seconds column")
                if 'min_confidence' not in columns:
                    conn.execute(text('ALTER TABLE detection_zones ADD COLUMN min_confidence FLOAT DEFAULT 0.35'))
                    logger.info("Added min_confidence column")
                if 'alert_cooldown_minutes' not in columns:
                    conn.execute(text('ALTER TABLE detection_zones ADD COLUMN alert_cooldown_minutes INTEGER DEFAULT 5'))
                    logger.info("Added alert_cooldown_minutes column")
                
                conn.commit()
    except Exception as e:
        logger.error(f"Error creating analytics tables: {e}")
    
    # Run migration to add pizza box detection columns (keep for backward compatibility)
    try:
        from sqlalchemy import text, inspect
        inspector = inspect(db.engine)
        
        # Add enable_pizza_box_detection to cameras table
        camera_columns = [col['name'] for col in inspector.get_columns('cameras')]
        if 'enable_pizza_box_detection' not in camera_columns:
            with db.engine.connect() as conn:
                conn.execute(text('ALTER TABLE cameras ADD COLUMN enable_pizza_box_detection BOOLEAN DEFAULT 0'))
                conn.commit()
            logger.info("Added enable_pizza_box_detection column to cameras")
        
        # Add pizza_box_count to detection_events table
        event_columns = [col['name'] for col in inspector.get_columns('detection_events')]
        if 'pizza_box_count' not in event_columns:
            with db.engine.connect() as conn:
                conn.execute(text('ALTER TABLE detection_events ADD COLUMN pizza_box_count INTEGER DEFAULT 0'))
                conn.commit()
            logger.info("Added pizza_box_count column to detection_events")
    except Exception as e:
        logger.debug(f"Pizza box migration check: {e}")
    
    # Run migration to add alert_cooldown column to cameras if needed
    try:
        from sqlalchemy import text, inspect
        inspector = inspect(db.engine)
        if inspector.has_table('cameras'):
            columns = [col['name'] for col in inspector.get_columns('cameras')]
            if 'alert_cooldown' not in columns:
                with db.engine.connect() as conn:
                    conn.execute(text('ALTER TABLE cameras ADD COLUMN alert_cooldown INTEGER DEFAULT 60'))
                    conn.commit()
                logger.info("Added alert_cooldown column to cameras via migration")
    except Exception as e:
        logger.debug(f"Camera migration check: {e}")
    
    # Run migration to add schedule columns to system_config if needed
    try:
        from sqlalchemy import text, inspect
        inspector = inspect(db.engine)
        if inspector.has_table('system_config'):
            columns = [col['name'] for col in inspector.get_columns('system_config')]
            
            if 'enable_auto_schedule' not in columns:
                with db.engine.connect() as conn:
                    conn.execute(text('ALTER TABLE system_config ADD COLUMN enable_auto_schedule BOOLEAN DEFAULT 0'))
                    conn.commit()
                logger.info("Added enable_auto_schedule column to system_config")
            
            if 'arm_time' not in columns:
                with db.engine.connect() as conn:
                    conn.execute(text('ALTER TABLE system_config ADD COLUMN arm_time VARCHAR(10) DEFAULT "22:00"'))
                    conn.commit()
                logger.info("Added arm_time column to system_config")
            
            if 'disarm_time' not in columns:
                with db.engine.connect() as conn:
                    conn.execute(text('ALTER TABLE system_config ADD COLUMN disarm_time VARCHAR(10) DEFAULT "07:00"'))
                    conn.commit()
                logger.info("Added disarm_time column to system_config")
            
            if 'schedule_days' not in columns:
                with db.engine.connect() as conn:
                    conn.execute(text('ALTER TABLE system_config ADD COLUMN schedule_days VARCHAR(20) DEFAULT "1,2,3,4,5"'))
                    conn.commit()
                logger.info("Added schedule_days column to system_config")
            
            if 'timezone' not in columns:
                with db.engine.connect() as conn:
                    conn.execute(text('ALTER TABLE system_config ADD COLUMN timezone VARCHAR(50) DEFAULT "UTC"'))
                    conn.commit()
                logger.info("Added timezone column to system_config")
    except Exception as e:
        logger.debug(f"Schedule migration check: {e}")
    
    try:
        from sqlalchemy import text, inspect
        inspector = inspect(db.engine)
        if inspector.has_table('cameras'):
            cam_cols = [c['name'] for c in inspector.get_columns('cameras')]
            with db.engine.connect() as conn:
                if 'alert_media' not in cam_cols:
                    conn.execute(text("ALTER TABLE cameras ADD COLUMN alert_media VARCHAR(20) DEFAULT 'both'"))
                    logger.info("Added alert_media column to cameras")
                if 'animal_classes' not in cam_cols:
                    conn.execute(text("ALTER TABLE cameras ADD COLUMN animal_classes TEXT"))
                    logger.info("Added animal_classes column to cameras")
                conn.commit()
    except Exception as e:
        logger.debug(f"alert_media migration: {e}")

    # Run migration for v3.9.8: acknowledged, clip_path, auto_delete_days, camera_offline_alert_minutes
    try:
        from sqlalchemy import text, inspect
        inspector = inspect(db.engine)
        if inspector.has_table('detection_events'):
            ev_cols = [c['name'] for c in inspector.get_columns('detection_events')]
            with db.engine.connect() as conn:
                if 'acknowledged' not in ev_cols:
                    conn.execute(text('ALTER TABLE detection_events ADD COLUMN acknowledged BOOLEAN DEFAULT 0'))
                    logger.info("Added acknowledged column to detection_events")
                if 'acknowledged_at' not in ev_cols:
                    conn.execute(text('ALTER TABLE detection_events ADD COLUMN acknowledged_at DATETIME'))
                    logger.info("Added acknowledged_at column to detection_events")
                if 'clip_path' not in ev_cols:
                    conn.execute(text('ALTER TABLE detection_events ADD COLUMN clip_path VARCHAR(500)'))
                    logger.info("Added clip_path column to detection_events")
                conn.commit()
        if inspector.has_table('system_config'):
            sc_cols = [c['name'] for c in inspector.get_columns('system_config')]
            with db.engine.connect() as conn:
                if 'auto_delete_days' not in sc_cols:
                    conn.execute(text('ALTER TABLE system_config ADD COLUMN auto_delete_days INTEGER DEFAULT 30'))
                    logger.info("Added auto_delete_days column to system_config")
                if 'camera_offline_alert_minutes' not in sc_cols:
                    conn.execute(text('ALTER TABLE system_config ADD COLUMN camera_offline_alert_minutes INTEGER DEFAULT 5'))
                    logger.info("Added camera_offline_alert_minutes column to system_config")
                conn.commit()
    except Exception as e:
        logger.debug(f"v3.9.8 migration check: {e}")

    # Migration: admin_username, viewer_username, theme_preference + audit_logs table
    try:
        from sqlalchemy import text, inspect
        inspector = inspect(db.engine)
        if inspector.has_table('system_config'):
            sc_cols = [c['name'] for c in inspector.get_columns('system_config')]
            with db.engine.connect() as conn:
                if 'admin_username' not in sc_cols:
                    conn.execute(text("ALTER TABLE system_config ADD COLUMN admin_username VARCHAR(100) DEFAULT 'admin'"))
                    logger.info("Added admin_username column")
                if 'viewer_username' not in sc_cols:
                    conn.execute(text("ALTER TABLE system_config ADD COLUMN viewer_username VARCHAR(100) DEFAULT 'viewer'"))
                    logger.info("Added viewer_username column")
                conn.commit()
        if not inspector.has_table('audit_logs'):
            db.create_all()
            logger.info("Created audit_logs table")
    except Exception as e:
        logger.debug(f"Username/audit migration: {e}")

    # Run initial cleanup
    cleanup_old_events()
    # Start scheduled cleanup
    schedule_cleanup()
    logger.info("Event cleanup scheduler started")

    # Start license expiry monitoring thread (checks hourly, sends Telegram alerts)
    # Note: _start_license_expiry_monitor is defined later in this file; call via lambda to defer resolution
    try:
        _start_license_expiry_monitor()
        logger.info("License expiry monitor started")
    except NameError:
        pass  # function defined later; will be called after module fully loads
    
    # Initialize and start auto-schedule service
    try:
        scheduler = init_scheduler_service(app)
        scheduler.start()
        logger.info("Auto-schedule service initialized and started")
    except Exception as e:
        logger.error(f"Failed to initialize scheduler service: {e}")
    
    # Setup telegram bot commands in menu
    try:
        telegram_service.setup_bot_commands()
        logger.info("Telegram bot commands registered successfully")
    except Exception as e:
        logger.error(f"Failed to register telegram commands: {e}")
    
    # Run migration for authentication and feature columns
    try:
        from sqlalchemy import text, inspect
        inspector = inspect(db.engine)
        if inspector.has_table('system_config'):
            columns = [col['name'] for col in inspector.get_columns('system_config')]
            
            # Add admin authentication columns
            if 'admin_password_hash' not in columns:
                with db.engine.connect() as conn:
                    conn.execute(text('ALTER TABLE system_config ADD COLUMN admin_password_hash VARCHAR(256)'))
                    conn.commit()
                logger.info("Added admin_password_hash column")
            
            if 'admin_password_set' not in columns:
                with db.engine.connect() as conn:
                    conn.execute(text('ALTER TABLE system_config ADD COLUMN admin_password_set BOOLEAN DEFAULT 0'))
                    conn.commit()
                logger.info("Added admin_password_set column")
            
            if 'first_login' not in columns:
                with db.engine.connect() as conn:
                    conn.execute(text('ALTER TABLE system_config ADD COLUMN first_login BOOLEAN DEFAULT 1'))
                    conn.commit()
                logger.info("Added first_login column")
            
            if 'feature_password' not in columns:
                with db.engine.connect() as conn:
                    conn.execute(text("ALTER TABLE system_config ADD COLUMN feature_password VARCHAR(100) DEFAULT 'sentinel2026'"))
                    conn.commit()
                logger.info("Added feature_password column")
            
            if 'feature_password_enabled' not in columns:
                with db.engine.connect() as conn:
                    conn.execute(text('ALTER TABLE system_config ADD COLUMN feature_password_enabled BOOLEAN DEFAULT 1'))
                    conn.commit()
                logger.info("Added feature_password_enabled column")

        # Create / migrate license_keys table
        try:
            from models import LicenseKey
            inspector2 = db.inspect(db.engine)
            if 'license_keys' not in inspector2.get_table_names():
                LicenseKey.__table__.create(db.engine)
                logger.info("Created license_keys table")
            else:
                # Add new columns if they don't exist yet
                lic_cols = [c['name'] for c in inspector2.get_columns('license_keys')]
                migrations = [
                    ('expires_at',      'ALTER TABLE license_keys ADD COLUMN expires_at DATETIME'),
                    ('covers_all',      'ALTER TABLE license_keys ADD COLUMN covers_all BOOLEAN DEFAULT 0'),
                    ('duration_months', 'ALTER TABLE license_keys ADD COLUMN duration_months INTEGER DEFAULT 1'),
                    ('duration_label',  "ALTER TABLE license_keys ADD COLUMN duration_label VARCHAR(20) DEFAULT '1 Month'"),
                ]
                for col_name, sql in migrations:
                    if col_name not in lic_cols:
                        with db.engine.connect() as conn:
                            conn.execute(text(sql))
                            conn.commit()
                        logger.info(f"Added license_keys.{col_name} column")
        except Exception as lic_err:
            logger.warning(f"License keys migration: {lic_err}")
            
            if 'site_name' not in columns:
                with db.engine.connect() as conn:
                    conn.execute(text("ALTER TABLE system_config ADD COLUMN site_name VARCHAR(200) DEFAULT 'Main Site'"))
                    conn.commit()
                logger.info("Added site_name column")
            
            if 'site_id' not in columns:
                with db.engine.connect() as conn:
                    conn.execute(text('ALTER TABLE system_config ADD COLUMN site_id VARCHAR(50)'))
                    conn.commit()
                logger.info("Added site_id column")
            
            if 'enable_people_counting' not in columns:
                with db.engine.connect() as conn:
                    conn.execute(text('ALTER TABLE system_config ADD COLUMN enable_people_counting BOOLEAN DEFAULT 1'))
                    conn.commit()
                logger.info("Added enable_people_counting column")
    except Exception as e:
        logger.debug(f"Authentication migration check: {e}")


# ==================== License Expiry Monitor ====================

# Track which license warnings we have already sent via Telegram (feature_id → last alert date)
_license_alert_sent: dict = {}

def _start_license_expiry_monitor():
    """Background thread: check license expiry hourly and send Telegram alerts."""
    def _monitor_loop():
        import time as _time
        while True:
            _time.sleep(3600)  # check every hour
            try:
                with app.app_context():
                    from license_manager import get_expiry_warnings, expire_old_licenses
                    expire_old_licenses()  # mark newly-expired keys as inactive
                    warnings = get_expiry_warnings()
                    today_str = datetime.utcnow().strftime('%Y-%m-%d')
                    for w in warnings:
                        key = w['feature_id']
                        last_sent = _license_alert_sent.get(key)
                        if last_sent == today_str:
                            continue  # already alerted today
                        if w['expired']:
                            msg = (
                                f"🔴 <b>License EXPIRED – {w['feature']}</b>\n"
                                f"Your {w['feature']} license expired on {w['expires_at']}.\n"
                                f"This feature is now DISABLED. Please renew your license immediately."
                            )
                        elif w['days_remaining'] <= 7:
                            msg = (
                                f"🟠 <b>License expiring soon – {w['feature']}</b>\n"
                                f"Expires: {w['expires_at']} ({w['days_remaining']} day{'' if w['days_remaining']==1 else 's'} left).\n"
                                f"Renew now to avoid service interruption."
                            )
                        else:
                            msg = (
                                f"🟡 <b>License renewal reminder – {w['feature']}</b>\n"
                                f"Expires: {w['expires_at']} ({w['days_remaining']} days left).\n"
                                f"Consider renewing your license soon."
                            )
                        telegram_service.send_message(msg)
                        _license_alert_sent[key] = today_str
                        _status = 'expired' if w['expired'] else str(w['days_remaining']) + 'd remaining'
                        logger.info(f"License alert sent for {key}: {_status}")
            except Exception as lic_mon_err:
                logger.error(f"License monitor error: {lic_mon_err}")

    t = threading.Thread(target=_monitor_loop, daemon=True, name='license-monitor')
    t.start()


@app.context_processor
def inject_license_warnings():
    """Inject license expiry warnings into every template render."""
    try:
        # Only run for logged-in HTML requests (not API/static)
        if not session.get('admin_logged_in'):
            return {'license_warnings': []}
        if request.is_json or (request.endpoint and request.endpoint.startswith('static')):
            return {'license_warnings': []}
        from license_manager import get_expiry_warnings
        return {'license_warnings': get_expiry_warnings()}
    except Exception:
        return {'license_warnings': []}


# ==================== Authentication ====================

# List of public endpoints that don't require authentication
PUBLIC_ENDPOINTS = ['login', 'logout', 'setup_password', 'static', 'forgot_password', 'viewer_login', 'viewer_logout']

# Endpoints a viewer-session is allowed to reach
VIEWER_ALLOWED_ENDPOINTS = {
    'events', 'api_events', 'api_acknowledge_event', 'api_unacknowledge_event',
    'viewer_logout', 'logout', 'static', 'uploaded_file', 'serve_clip',
}

@app.before_request
def check_authentication():
    """Global authentication check before every request"""
    # Skip for static files and public endpoints
    if request.endpoint in PUBLIC_ENDPOINTS or (request.endpoint and request.endpoint.startswith('static')):
        return None

    config = get_system_config()

    # If no password has been set, redirect to password setup
    if not getattr(config, 'admin_password_set', False) or not config.admin_password_hash:
        if request.endpoint != 'setup_password':
            return redirect(url_for('setup_password'))
        return None

    # Viewer session — only allow events-related endpoints
    if session.get('viewer_logged_in'):
        if request.endpoint not in VIEWER_ALLOWED_ENDPOINTS:
            return redirect(url_for('events'))
        return None

    # Admin check
    if not session.get('admin_logged_in'):
        if request.is_json:
            return jsonify({'success': False, 'error': 'Authentication required'}), 401
        return redirect(url_for('login'))

    return None


def login_required(f):
    """Decorator to require admin login for protected routes (legacy, now handled by before_request)"""
    @wraps(f)
    def decorated_function(*args, **kwargs):
        # Authentication is now handled by before_request
        # This decorator is kept for backwards compatibility
        return f(*args, **kwargs)
    return decorated_function


def license_required(feature_id):
    """Decorator factory: blocks access to a route unless a valid license key for
    *feature_id* is activated in the database."""
    def decorator(f):
        @wraps(f)
        def decorated_function(*args, **kwargs):
            from license_manager import is_feature_unlocked
            if not is_feature_unlocked(feature_id):
                if request.is_json:
                    return jsonify({
                        'success': False,
                        'error': 'License required',
                        'feature_id': feature_id,
                        'unlock_url': url_for('license_management')
                    }), 403
                flash(f'A valid license key is required to access this feature.', 'warning')
                return redirect(url_for('license_management'))
            return f(*args, **kwargs)
        return decorated_function
    return decorator

# Keep the old name as a no-op shim so legacy code doesn't crash
def feature_password_required(f):
    """Deprecated – replaced by license_required(). Kept for backwards compatibility."""
    @wraps(f)
    def decorated_function(*args, **kwargs):
        return f(*args, **kwargs)
    return decorated_function


def get_system_config():
    """Get or create system configuration"""
    config = SystemConfig.query.first()
    if not config:
        config = SystemConfig()
        db.session.add(config)
        db.session.commit()
    return config


def update_telegram_service():
    """Update telegram service with current config"""
    config = get_system_config()
    if config.telegram_chat_id:
        telegram_service.set_credentials(config.telegram_chat_id)
        # Register bot commands whenever credentials are updated
        try:
            telegram_service.setup_bot_commands()
            logger.info("✅ Telegram commands registered after credential update")
        except Exception as e:
            logger.error(f"Failed to register telegram commands: {e}")


def get_system_stats():
    """Get current system statistics"""
    try:
        cpu_percent = psutil.cpu_percent(interval=None)  # Non-blocking; returns last cached value
        memory = psutil.virtual_memory()
        disk = psutil.disk_usage('/')
        
        # Try to get Raspberry Pi temperature
        temp = None
        try:
            with open('/sys/class/thermal/thermal_zone0/temp', 'r') as f:
                temp = float(f.read()) / 1000.0
        except:
            pass
        
        # ── PEOPLE NOW ──────────────────────────────────────────────────────
        # Priority 1: sum of entrance_inside_counts (counting line zones) from
        #             the detection engine — updates every time someone crosses.
        # Priority 2: camera_raw_counts sum (live AI detections in frame).
        # Priority 3: DB fallback — today's entrance OccupancyLog entries-exits,
        #             so the counter works even if the engine is temporarily None
        #             or the Pi just restarted and no crossings have happened yet.
        # Requires an active people_counting license.
        people_now = 0
        try:
            from license_manager import is_feature_unlocked as _ifu
            _people_licensed = _ifu('people_counting')
        except Exception:
            _people_licensed = True  # fail-open
        if _people_licensed:
            if detection_engine:
                entrance_counts = getattr(detection_engine, 'entrance_inside_counts', {})
                if entrance_counts:
                    people_now = max(0, sum(entrance_counts.values()))
                if people_now == 0:
                    people_now = sum(getattr(detection_engine, 'camera_raw_counts', {}).values())
            if people_now == 0:
                try:
                    from models import OccupancyLog as _OL
                    from sqlalchemy import func as _func
                    _today = datetime.utcnow().date()
                    _row = db.session.query(
                        _func.sum(_OL.entries).label('e'),
                        _func.sum(_OL.exits).label('x')
                    ).filter(
                        _OL.count_type == 'entrance',
                        _OL.timestamp >= _today
                    ).one_or_none()
                    if _row and _row.e:
                        people_now = max(0, (_row.e or 0) - (_row.x or 0))
                except Exception:
                    pass
        # ────────────────────────────────────────────────────────────────────
        today = datetime.utcnow().date()
        return {
            'cpu_usage': cpu_percent,
            'memory_usage': memory.percent,
            'disk_usage': disk.percent,
            'disk_used_gb': round(disk.used / (1024**3), 1),
            'disk_total_gb': round(disk.total / (1024**3), 1),
            'temperature': temp,
            'active_cameras': Camera.query.filter_by(is_active=True).count(),
            'total_detections_today': DetectionEvent.query.filter(
                DetectionEvent.created_at >= today
            ).count(),
            'alerts_sent_today': DetectionEvent.query.filter(
                DetectionEvent.created_at >= today,
                DetectionEvent.telegram_sent == True
            ).count(),
            'people_now': people_now,
            'is_armed': bool(get_system_config().is_armed) if get_system_config() else False,
        }
    except Exception as e:
        logger.error(f"Failed to get system stats: {e}")
        return {}


# ==================== Routes ====================

# ==================== Authentication Routes ====================

@app.route('/login', methods=['GET', 'POST'])
def login():
    """Admin login page"""
    config = get_system_config()
    
    # If no password has been set, redirect to password setup
    if not getattr(config, 'admin_password_set', False) or not config.admin_password_hash:
        return redirect(url_for('setup_password'))
    
    # Already logged in
    if session.get('admin_logged_in'):
        return redirect(url_for('index'))
    
    if request.method == 'POST':
        ip = request.remote_addr or '0.0.0.0'
        allowed, wait = _check_login_rate_limit(ip)
        if not allowed:
            flash(f'Too many failed attempts. Please wait {wait} seconds before trying again.', 'error')
            return render_template('login.html', config=config)

        password = request.form.get('password', '')
        username_input = request.form.get('username', '').strip()
        admin_uname = getattr(config, 'admin_username', None) or 'admin'
        
        # If a username was supplied, it must match (case-insensitive)
        if username_input and username_input.lower() != admin_uname.lower():
            _record_login_failure(ip)
            flash('Invalid username or password', 'error')
        elif config.verify_admin_password(password):
            _login_attempts.pop(ip, None)  # Clear attempts on success
            session['admin_logged_in'] = True
            session['logged_in_username'] = admin_uname
            session.permanent = True
            log_audit('admin_login', username=admin_uname)
            flash('Login successful!', 'success')
            return redirect(url_for('index'))
        else:
            _record_login_failure(ip)
            log_audit('login_failed', username=username_input or admin_uname)
            flash('Invalid password', 'error')
    
    return render_template('login.html', config=config)


@app.route('/logout')
def logout():
    """Logout (admin or viewer)"""
    log_audit('logout')
    session.pop('admin_logged_in', None)
    session.pop('viewer_logged_in', None)
    session.pop('feature_unlocked', None)
    session.pop('logged_in_username', None)
    flash('Logged out successfully', 'success')
    return redirect(url_for('login'))


@app.route('/viewer-login', methods=['GET', 'POST'])
def viewer_login():
    """Viewer login — read-only access to Events page"""
    config = get_system_config()

    if session.get('admin_logged_in'):
        return redirect(url_for('events'))
    if session.get('viewer_logged_in'):
        return redirect(url_for('events'))

    if not getattr(config, 'viewer_account_enabled', False) or not config.viewer_password_hash:
        flash('Viewer account is not enabled on this system.', 'error')
        return redirect(url_for('login'))

    if request.method == 'POST':
        ip = request.remote_addr or '0.0.0.0'
        allowed, wait = _check_login_rate_limit(ip)
        if not allowed:
            flash(f'Too many failed attempts. Please wait {wait} seconds.', 'error')
            return render_template('viewer_login.html', config=config)

        password = request.form.get('password', '')
        username_input = request.form.get('username', '').strip()
        viewer_uname = getattr(config, 'viewer_username', None) or 'viewer'
        if username_input and username_input.lower() != viewer_uname.lower():
            _record_login_failure(ip)
            flash('Incorrect username or password.', 'error')
        elif config.verify_viewer_password(password):
            _login_attempts.pop(ip, None)
            session['viewer_logged_in'] = True
            session['logged_in_username'] = viewer_uname
            session.permanent = True
            log_audit('viewer_login', username=viewer_uname)
            return redirect(url_for('events'))
        else:
            _record_login_failure(ip)
            log_audit('viewer_login_failed', username=username_input or viewer_uname)
            flash('Incorrect viewer password.', 'error')

    return render_template('viewer_login.html', config=config)


@app.route('/viewer-logout')
def viewer_logout():
    """Viewer logout"""
    session.pop('viewer_logged_in', None)
    return redirect(url_for('viewer_login'))


@app.route('/api/set-viewer-password', methods=['POST'])
def api_set_viewer_password():
    """Admin sets or updates the viewer account password"""
    data = request.get_json() or {}
    password = data.get('password', '').strip()
    disable = data.get('disable', False)

    config = get_system_config()

    if disable:
        config.clear_viewer_password()
        db.session.commit()
        return jsonify({'success': True, 'message': 'Viewer account disabled.'})

    if not password or len(password) < 6:
        return jsonify({'success': False, 'message': 'Password must be at least 6 characters.'}), 400

    config.set_viewer_password(password)
    db.session.commit()
    logger.info('Viewer account password updated by admin.')
    return jsonify({'success': True, 'message': 'Viewer account password saved.'})


@app.route('/api/update-usernames', methods=['POST'])
@login_required
def api_update_usernames():
    """Admin updates admin and/or viewer display usernames"""
    data = request.get_json() or {}
    config = get_system_config()
    if 'admin_username' in data:
        val = data['admin_username'].strip()
        if val:
            config.admin_username = val
            session['logged_in_username'] = val
    if 'viewer_username' in data:
        val = data['viewer_username'].strip()
        if val:
            config.viewer_username = val
    db.session.commit()
    log_audit('update_usernames', target_type='system')
    return jsonify({'success': True})


@app.route('/api/audit-log', methods=['GET'])
@login_required
def api_audit_log():
    """Return the last 100 audit log entries"""
    try:
        from models import AuditLog
        entries = (AuditLog.query
                   .order_by(AuditLog.created_at.desc())
                   .limit(100)
                   .all())
        return jsonify([e.to_dict() for e in entries])
    except Exception as e:
        return jsonify({'error': str(e)}), 500


# In-memory brute-force tracker: {ip: {'count': n, 'locked_until': timestamp}}
_recovery_attempts = {}
_RECOVERY_MAX_TRIES  = 5
_RECOVERY_LOCKOUT_S  = 300  # 5 minutes

@app.route('/forgot-password', methods=['GET', 'POST'])
def forgot_password():
    """Password recovery using a recovery key stored in recovery.key file."""
    import hashlib, os, hmac
    recovery_file = os.path.join(os.path.dirname(__file__), 'recovery.key')
    key_exists = os.path.isfile(recovery_file)

    client_ip = request.remote_addr or 'unknown'
    now = time.time()

    # Clean up expired lockouts
    if client_ip in _recovery_attempts:
        entry = _recovery_attempts[client_ip]
        if entry.get('locked_until', 0) < now:
            _recovery_attempts[client_ip] = {'count': 0, 'locked_until': 0}

    attempt_entry = _recovery_attempts.get(client_ip, {'count': 0, 'locked_until': 0})
    locked = attempt_entry['locked_until'] > now
    lockout_remaining = max(0, int(attempt_entry['locked_until'] - now))

    if request.method == 'POST':
        if locked:
            error = f'Too many failed attempts. Please wait {lockout_remaining} seconds before trying again.'
            return render_template('forgot_password.html', error=error, key_exists=key_exists, locked=True, lockout_remaining=lockout_remaining)

        entered_key  = request.form.get('recovery_key', '').strip()
        new_password = request.form.get('new_password', '').strip()
        confirm_pw   = request.form.get('confirm_password', '').strip()

        error = None
        if not key_exists:
            error = 'No recovery key is configured. Log in via SSH and run: echo "YOUR_KEY" > recovery.key'
        elif not entered_key:
            error = 'Please enter your recovery key.'
        elif not new_password or len(new_password) < 6:
            error = 'New password must be at least 6 characters.'
        elif new_password != confirm_pw:
            error = 'Passwords do not match.'
        else:
            with open(recovery_file, 'r') as f:
                stored = f.read().strip()
            if not hmac.compare_digest(
                hashlib.sha256(entered_key.encode()).hexdigest(),
                hashlib.sha256(stored.encode()).hexdigest()
            ):
                # Increment failure counter
                attempt_entry['count'] = attempt_entry.get('count', 0) + 1
                if attempt_entry['count'] >= _RECOVERY_MAX_TRIES:
                    attempt_entry['locked_until'] = now + _RECOVERY_LOCKOUT_S
                    error = f'Too many failed attempts. Account locked for {_RECOVERY_LOCKOUT_S // 60} minutes.'
                else:
                    remaining_tries = _RECOVERY_MAX_TRIES - attempt_entry['count']
                    error = f'Incorrect recovery key. {remaining_tries} attempt{"s" if remaining_tries != 1 else ""} remaining.'
                _recovery_attempts[client_ip] = attempt_entry

        if error:
            return render_template('forgot_password.html', error=error, key_exists=key_exists,
                                   locked=(attempt_entry.get('locked_until', 0) > now),
                                   lockout_remaining=max(0, int(attempt_entry.get('locked_until', 0) - now)))

        # Key correct — clear attempts, reset password
        _recovery_attempts.pop(client_ip, None)
        config = get_system_config()
        config.set_admin_password(new_password)
        db.session.commit()
        logger.warning('Admin password was reset via recovery key from IP %s.', client_ip)
        flash('Password reset successfully. Please log in.', 'success')
        return redirect(url_for('login'))

    return render_template('forgot_password.html', error=None, key_exists=key_exists,
                           locked=locked, lockout_remaining=lockout_remaining)


@app.route('/api/set-recovery-key', methods=['POST'])
@login_required
def api_set_recovery_key():
    """Set or update the recovery key (admin only, must be logged in)."""
    import os
    new_key = request.json.get('recovery_key', '').strip() if request.is_json else request.form.get('recovery_key', '').strip()
    if not new_key or len(new_key) < 6:
        return jsonify({'success': False, 'message': 'Recovery key must be at least 6 characters.'})
    recovery_file = os.path.join(os.path.dirname(__file__), 'recovery.key')
    with open(recovery_file, 'w') as f:
        f.write(new_key)
    logger.info('Recovery key updated by admin.')
    return jsonify({'success': True, 'message': 'Recovery key saved.'})


@app.route('/setup-password', methods=['GET', 'POST'])
def setup_password():
    """First-time password setup"""
    config = get_system_config()
    
    # Only allow if password not yet set
    if getattr(config, 'admin_password_set', False) and config.admin_password_hash:
        return redirect(url_for('login'))
    
    if request.method == 'POST':
        password = request.form.get('password', '')
        confirm_password = request.form.get('confirm_password', '')
        
        if len(password) < 6:
            flash('Password must be at least 6 characters', 'error')
        elif password != confirm_password:
            flash('Passwords do not match', 'error')
        else:
            config.set_admin_password(password)
            db.session.commit()
            session['admin_logged_in'] = True
            flash('Password set successfully! Welcome to SentinelVision.', 'success')
            return redirect(url_for('index'))
    
    return render_template('setup_password.html', config=config)


@app.route('/change-password', methods=['GET', 'POST'])
@login_required
def change_password():
    """Change admin password"""
    config = get_system_config()
    
    if request.method == 'POST':
        current_password = request.form.get('current_password', '')
        new_password = request.form.get('new_password', '')
        confirm_password = request.form.get('confirm_password', '')
        
        if not config.verify_admin_password(current_password):
            flash('Current password is incorrect', 'error')
        elif len(new_password) < 6:
            flash('New password must be at least 6 characters', 'error')
        elif new_password != confirm_password:
            flash('New passwords do not match', 'error')
        else:
            config.set_admin_password(new_password)
            db.session.commit()
            flash('Password changed successfully!', 'success')
            return redirect(url_for('settings'))
    
    return render_template('change_password.html', config=config)


# ── Legacy redirect so any bookmarked /feature-unlock URLs still work ──────
@app.route('/feature-unlock')
def feature_unlock():
    return redirect(url_for('license_management'))


# ── License Management ──────────────────────────────────────────────────────
@app.route('/license')
@login_required
def license_management():
    """License key management page"""
    from license_manager import get_feature_status, get_device_serial
    feature_status = get_feature_status()
    device_serial  = get_device_serial()
    return render_template('license.html', features=feature_status, device_serial=device_serial)


@app.route('/api/license/activate', methods=['POST'])
@login_required
def api_license_activate():
    """Activate a new license key"""
    try:
        from license_manager import parse_license_key, FEATURES
        from models import LicenseKey
        from datetime import datetime, timedelta
        data = request.json or {}
        key = (data.get('key') or '').strip().upper()

        if not key:
            return jsonify({'success': False, 'error': 'License key is required'}), 400

        parsed = parse_license_key(key)
        if not parsed:
            return jsonify({'success': False, 'error': 'Invalid or tampered license key'}), 400

        covers_all      = parsed['covers_all']
        feature_ids     = parsed['feature_ids']
        duration_months = parsed['duration_months']
        duration_days   = parsed['duration_days']
        duration_label  = parsed['duration_label']
        expires_at      = datetime.utcnow() + timedelta(days=duration_days)

        # The primary feature_id stored is 'all' for bundle keys, else the single feature
        primary_fid = 'all' if covers_all else feature_ids[0]

        # Check if this exact key has ever been used (one-time use only)
        existing = LicenseKey.query.filter_by(key=key).first()
        if existing:
            return jsonify({'success': False, 'error': 'This license key has already been used. Each key can only be activated once on one device.'}), 409

        # Deactivate any previous active keys that overlap with this feature set
        if covers_all:
            LicenseKey.query.filter_by(is_active=True).update({'is_active': False})
        else:
            LicenseKey.query.filter(
                LicenseKey.is_active == True,
                (LicenseKey.feature_id == primary_fid) | (LicenseKey.covers_all == True)
            ).update({'is_active': False}, synchronize_session='fetch')

        new_key = LicenseKey(
            key=key,
            feature_id=primary_fid,
            covers_all=covers_all,
            duration_months=duration_months,
            duration_label=duration_label,
            expires_at=expires_at,
        )
        db.session.add(new_key)
        db.session.commit()

        if covers_all:
            msg = f'All Features unlocked – valid until {expires_at.strftime("%d %b %Y")}'
        else:
            fname = FEATURES[primary_fid]['name']
            msg = f'{fname} unlocked – valid until {expires_at.strftime("%d %b %Y")}'

        logger.info(f"License activated: {key} ({primary_fid}, {duration_label})")
        return jsonify({'success': True, 'message': msg})

    except Exception as e:
        db.session.rollback()
        logger.error(f"License activate error: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500


@app.route('/api/license/deactivate', methods=['POST'])
@login_required
def api_license_deactivate():
    """Deactivate (remove) a license key"""
    try:
        from models import LicenseKey
        data = request.json or {}
        feature_id = (data.get('feature_id') or '').strip().lower()

        if not feature_id:
            return jsonify({'success': False, 'error': 'feature_id required'}), 400

        updated = LicenseKey.query.filter_by(feature_id=feature_id, is_active=True)\
                                  .update({'is_active': False})
        db.session.commit()

        if updated:
            return jsonify({'success': True, 'message': 'License deactivated'})
        return jsonify({'success': False, 'error': 'No active license found for this feature'}), 404

    except Exception as e:
        db.session.rollback()
        return jsonify({'success': False, 'error': str(e)}), 500


@app.route('/api/license/status', methods=['GET'])
@login_required
def api_license_status():
    """Return current license status for all features"""
    try:
        from license_manager import get_feature_status
        return jsonify({'success': True, 'features': get_feature_status()})
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500


@app.route('/update-site-settings', methods=['POST'])
@login_required
def update_site_settings():
    """Update site name and ID settings"""
    try:
        config = get_system_config()
        
        site_name = request.form.get('site_name', '').strip()
        site_id = request.form.get('site_id', '').strip()
        
        if site_name:
            config.site_name = site_name
        if site_id:
            config.site_id = site_id
            
        db.session.commit()
        flash('Site settings updated successfully!', 'success')
    except Exception as e:
        flash(f'Error updating site settings: {str(e)}', 'error')
    
    return redirect(url_for('settings'))


@app.route('/')
@login_required
def index():
    """Main dashboard"""
    config = get_system_config()
    cameras = Camera.query.all()
    
    # Check if setup is complete
    setup_complete = bool(config.telegram_chat_id)
    
    # Get recent events
    recent_events = DetectionEvent.query.order_by(
        DetectionEvent.created_at.desc()
    ).limit(10).all()
    
    # Get stats
    stats = get_system_stats()

    # Detection breakdown by class for today
    today = datetime.utcnow().date()
    vehicle_classes = ['car', 'truck', 'bus', 'motorcycle', 'bicycle']
    animal_classes = ['dog', 'cat', 'bird', 'horse', 'cow', 'sheep', 'zebra', 'giraffe']
    object_classes = ['backpack', 'handbag', 'suitcase', 'umbrella']
    detection_breakdown = {
        'persons': DetectionEvent.query.filter(
            DetectionEvent.created_at >= today,
            DetectionEvent.detected_class == 'person'
        ).count(),
        'vehicles': DetectionEvent.query.filter(
            DetectionEvent.created_at >= today,
            DetectionEvent.detected_class.in_(vehicle_classes)
        ).count(),
        'animals': DetectionEvent.query.filter(
            DetectionEvent.created_at >= today,
            DetectionEvent.detected_class.in_(animal_classes)
        ).count(),
        'objects': DetectionEvent.query.filter(
            DetectionEvent.created_at >= today,
            DetectionEvent.detected_class.in_(object_classes)
        ).count(),
    }

    # Last detection time per camera
    camera_last_detections = {}
    for cam in cameras:
        last_ev = DetectionEvent.query.filter_by(camera_id=cam.id).order_by(
            DetectionEvent.created_at.desc()
        ).first()
        camera_last_detections[cam.id] = last_ev.created_at.isoformat() if last_ev else None

    # Online status per camera from CameraHealth
    from models import CameraHealth
    camera_online = {}
    for cam in cameras:
        health = CameraHealth.query.filter_by(camera_id=cam.id).first()
        camera_online[cam.id] = health.is_online if health else False

    return render_template('index.html',
                         cameras=cameras,
                         setup_complete=setup_complete,
                         recent_events=recent_events,
                         stats=stats,
                         detection_breakdown=detection_breakdown,
                         camera_last_detections=camera_last_detections,
                         camera_online=camera_online,
                         config=config)


@app.route('/setup', methods=['GET', 'POST'])
@login_required
def setup():
    """Initial setup page"""
    config = get_system_config()
    current_ip = get_local_ip()
    
    if request.method == 'POST':
        # Update system configuration
        config.system_name = request.form.get('system_name', 'SentinelVision Security Platform').strip()
        config.telegram_chat_id = request.form.get('telegram_chat_id', '').strip()
        
        # Network settings
        config.network_port = int(request.form.get('network_port', 5000))
        config.network_mode = request.form.get('network_mode', 'dhcp')
        if config.network_mode == 'static':
            config.network_ip = request.form.get('network_ip', '').strip()
        
        # Detection settings
        config.detection_confidence = float(request.form.get('detection_confidence', 0.5))
        config.min_detection_size = int(request.form.get('min_detection_size', 50))
        config.max_detection_size = int(request.form.get('max_detection_size', 5000))
        config.enable_tracking = 'enable_tracking' in request.form
        config.enable_zone_detection = 'enable_zone_detection' in request.form
        
        config.updated_at = datetime.utcnow()
        
        db.session.commit()
        
        # Update telegram service
        update_telegram_service()
        
        # Test connection
        success, message = telegram_service.test_connection()
        
        if success:
            flash(f'Setup successful! {message}', 'success')
            telegram_service.send_message(f'🎉 {config.system_name} is now active!')
            return redirect(url_for('index'))
        else:
            flash(f'Telegram connection test: {message}', 'warning')
            flash('Configuration saved. You can test Telegram later.', 'success')
            return redirect(url_for('index'))
    
    return render_template('setup.html', config=config, current_ip=current_ip)


@app.route('/cameras')
@login_required
def cameras():
    """Camera management page"""
    cameras_list = Camera.query.all()
    from license_manager import is_feature_unlocked
    return render_template('cameras.html', cameras=cameras_list,
                           stock_licensed=is_feature_unlocked('stock_control'),
                           weapon_licensed=is_feature_unlocked('weapon_detection'),
                           vehicle_licensed=is_feature_unlocked('vehicle_detection'),
                           object_licensed=is_feature_unlocked('object_detection'))


@app.route('/api/cameras', methods=['GET', 'POST'])
@login_required
def api_cameras():
    """API endpoint for camera management"""
    if request.method == 'GET':
        cameras_list = Camera.query.all()
        return jsonify([cam.to_dict() for cam in cameras_list])
    
    elif request.method == 'POST':
        data = request.json
        
        # Create new camera
        camera = Camera(
            name=data['name'],
            rtsp_url=data['rtsp_url'],
            location=data.get('location', ''),
            enable_person_detection=data.get('enable_person_detection', True),
            enable_vehicle_detection=data.get('enable_vehicle_detection', False),
            enable_animal_detection=data.get('enable_animal_detection', False),
            enable_object_detection=data.get('enable_object_detection', False),
            alert_cooldown=data.get('alert_cooldown', 300),
            alert_media=data.get('alert_media', 'both')
        )
        
        # Set custom classes if provided
        if 'custom_classes' in data:
            camera.set_custom_classes(data['custom_classes'])
        
        db.session.add(camera)
        db.session.commit()
        
        logger.info(f"New camera added: {camera.name}")
        
        return jsonify({'success': True, 'camera': camera.to_dict()}), 201


@app.route('/api/cameras/<int:camera_id>', methods=['GET', 'PUT', 'DELETE'])
def api_camera_detail(camera_id):
    """API endpoint for individual camera"""
    camera = Camera.query.get_or_404(camera_id)
    
    if request.method == 'GET':
        return jsonify(camera.to_dict())
    
    elif request.method == 'PUT':
        data = request.json
        
        # Update camera
        camera.name = data.get('name', camera.name)
        new_rtsp_url = data.get('rtsp_url', camera.rtsp_url)
        if new_rtsp_url != camera.rtsp_url:
            # URL changed — clear cached working URL so detection re-discovers the correct path
            camera.working_rtsp_url = None
        camera.rtsp_url = new_rtsp_url
        camera.location = data.get('location', camera.location)
        camera.is_active = data.get('is_active', camera.is_active)
        camera.enable_person_detection = data.get('enable_person_detection', camera.enable_person_detection)
        camera.enable_vehicle_detection = data.get('enable_vehicle_detection', camera.enable_vehicle_detection)
        camera.enable_animal_detection = data.get('enable_animal_detection', camera.enable_animal_detection)
        camera.enable_object_detection = data.get('enable_object_detection', camera.enable_object_detection)
        camera.enable_stock_control = data.get('enable_stock_control', camera.enable_stock_control)
        camera.alert_cooldown = data.get('alert_cooldown', camera.alert_cooldown)
        camera.updated_at = datetime.utcnow()
        
        # Update new fields if provided
        if 'main_stream_url' in data:
            camera.main_stream_url = data['main_stream_url']
        if 'exclusion_zones' in data:
            camera.exclusion_zones = data['exclusion_zones']
        if 'is_dvr_channel' in data:
            camera.is_dvr_channel = data['is_dvr_channel']
        if 'zone_only_detection' in data:
            camera.zone_only_detection = data['zone_only_detection']
        if 'day_sensitivity' in data:
            camera.day_sensitivity = data['day_sensitivity']
        if 'night_sensitivity' in data:
            camera.night_sensitivity = data['night_sensitivity']
        if 'animal_sensitivity' in data:
            camera.animal_sensitivity = data['animal_sensitivity']
        if 'person_sensitivity' in data:
            camera.person_sensitivity = data['person_sensitivity']
        if 'night_ir_threshold' in data:
            camera.night_ir_threshold = data['night_ir_threshold']
        if 'detection_cooldown_seconds' in data:
            camera.detection_cooldown_seconds = data['detection_cooldown_seconds']
        if 'animal_min_size' in data:
            camera.animal_min_size = data['animal_min_size']
        if 'animal_classes' in data:
            raw = data['animal_classes']
            # Accept a JSON string, a list, or a comma-separated string
            if isinstance(raw, list):
                camera.set_animal_classes(raw)
            elif isinstance(raw, str) and raw.strip():
                try:
                    import json as _json
                    camera.set_animal_classes(_json.loads(raw))
                except Exception:
                    camera.set_animal_classes([s.strip() for s in raw.split(',') if s.strip()])
            else:
                camera.set_animal_classes([])
        if 'require_motion' in data:
            camera.require_motion = data['require_motion']
        if 'min_consecutive_frames' in data:
            camera.min_consecutive_frames = data['min_consecutive_frames']
        
        # Weapon/threat detection settings
        if 'enable_weapon_detection' in data:
            camera.enable_weapon_detection = data['enable_weapon_detection']
        if 'weapon_alert_sound' in data:
            camera.weapon_alert_sound = data['weapon_alert_sound']
        if 'alert_media' in data:
            camera.alert_media = data['alert_media']
        # AI features
        if 'enable_face_blur' in data:
            camera.enable_face_blur = data['enable_face_blur']
        if 'detect_falling' in data:
            camera.detect_falling = data['detect_falling']
        if 'enable_anomaly_detection' in data:
            camera.enable_anomaly_detection = data['enable_anomaly_detection']
        
        if 'custom_classes' in data:
            camera.set_custom_classes(data['custom_classes'])
        
        db.session.commit()
        
        logger.info(f"Camera updated: {camera.name}")
        
        return jsonify({'success': True, 'camera': camera.to_dict()})
    
    elif request.method == 'DELETE':
        db.session.delete(camera)
        db.session.commit()
        
        logger.info(f"Camera deleted: {camera.name}")
        
        return jsonify({'success': True})


@app.route('/api/false-positive/<int:camera_id>', methods=['POST'])
def api_false_positive(camera_id):
    """Record a false positive for a camera — used by Telegram inline button and web UI"""
    try:
        camera = Camera.query.get_or_404(camera_id)
        if detection_engine:
            detection_engine.record_false_positive(camera_id)
        logger.info(f"False positive recorded for camera {camera.name} (id={camera_id})")
        return jsonify({'success': True, 'camera': camera.name})
    except Exception as e:
        logger.error(f"False positive recording error: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500


@app.route('/api/scan-network', methods=['POST'])
def api_scan_network():
    """Scan network for cameras and NVRs"""
    try:
        scanner = NetworkScanner()
        
        # Run scan in background thread to avoid timeout
        def scan_task():
            return scanner.scan_network()
        
        devices = scan_task()
        
        return jsonify({
            'success': True,
            'devices': devices,
            'count': len(devices)
        })
    except Exception as e:
        logger.error(f"Network scan failed: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500


@app.route('/api/nvr-channels', methods=['POST'])
def api_nvr_channels():
    """Get channels from an NVR/DVR"""
    try:
        data = request.json
        ip = data.get('ip')
        port = data.get('port', 80)
        username = data.get('username', 'admin')
        password = data.get('password', 'admin')
        
        scanner = NetworkScanner()
        channels = scanner.detect_nvr_channels(ip, port, username, password)
        
        return jsonify({
            'success': True,
            'channels': channels,
            'count': len(channels)
        })
    except Exception as e:
        logger.error(f"NVR channel detection failed: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500


@app.route('/api/test-rtsp', methods=['POST'])
@login_required
def api_test_rtsp():
    """Test RTSP connection to camera/NVR"""
    try:
        data = request.json
        rtsp_url = data.get('rtsp_url')
        
        if not rtsp_url:
            return jsonify({'success': False, 'error': 'RTSP URL required'}), 400
        
        import cv2
        import os
        
        results = {
            'url': rtsp_url,
            'tests': [],
            'success': False,
            'working_url': None,
            'frame_captured': False
        }
        
        # Test 1: Direct connection
        logger.info(f"Testing RTSP: {rtsp_url}")
        cap = cv2.VideoCapture(rtsp_url, cv2.CAP_FFMPEG)
        cap.set(cv2.CAP_PROP_BUFFERSIZE, 3)
        cap.set(cv2.CAP_PROP_OPEN_TIMEOUT_MSEC, 10000)
        
        if cap.isOpened():
            ret, frame = cap.read()
            cap.release()
            if ret and frame is not None:
                results['tests'].append({'method': 'direct', 'status': 'SUCCESS', 'message': 'Connected and captured frame'})
                results['success'] = True
                results['working_url'] = rtsp_url
                results['frame_captured'] = True
                return jsonify(results)
            else:
                results['tests'].append({'method': 'direct', 'status': 'PARTIAL', 'message': 'Connected but failed to capture frame'})
        else:
            results['tests'].append({'method': 'direct', 'status': 'FAILED', 'message': 'Could not open stream'})
            cap.release()
        
        # Test 2: TCP transport
        if '?' in rtsp_url:
            tcp_url = rtsp_url + '&rtsp_transport=tcp'
        else:
            tcp_url = rtsp_url + '?rtsp_transport=tcp'
        
        logger.info(f"Testing RTSP with TCP: {tcp_url}")
        cap = cv2.VideoCapture(tcp_url, cv2.CAP_FFMPEG)
        cap.set(cv2.CAP_PROP_BUFFERSIZE, 3)
        cap.set(cv2.CAP_PROP_OPEN_TIMEOUT_MSEC, 10000)
        
        if cap.isOpened():
            ret, frame = cap.read()
            cap.release()
            if ret and frame is not None:
                results['tests'].append({'method': 'tcp_transport', 'status': 'SUCCESS', 'message': 'Connected with TCP and captured frame'})
                results['success'] = True
                results['working_url'] = tcp_url
                results['frame_captured'] = True
                return jsonify(results)
            else:
                results['tests'].append({'method': 'tcp_transport', 'status': 'PARTIAL', 'message': 'Connected but failed to capture frame'})
        else:
            results['tests'].append({'method': 'tcp_transport', 'status': 'FAILED', 'message': 'Could not open stream with TCP'})
            cap.release()
        
        # Test 3: FFMPEG environment options
        logger.info(f"Testing RTSP with FFMPEG options: {rtsp_url}")
        os.environ['OPENCV_FFMPEG_CAPTURE_OPTIONS'] = 'rtsp_transport;tcp|analyzeduration;10000000|fflags;nobuffer'
        cap = cv2.VideoCapture(rtsp_url, cv2.CAP_FFMPEG)
        
        if cap.isOpened():
            ret, frame = cap.read()
            cap.release()
            if ret and frame is not None:
                results['tests'].append({'method': 'ffmpeg_options', 'status': 'SUCCESS', 'message': 'Connected with FFMPEG options'})
                results['success'] = True
                results['working_url'] = rtsp_url
                results['frame_captured'] = True
                return jsonify(results)
            else:
                results['tests'].append({'method': 'ffmpeg_options', 'status': 'PARTIAL', 'message': 'Connected but failed to capture frame'})
        else:
            results['tests'].append({'method': 'ffmpeg_options', 'status': 'FAILED', 'message': 'Could not open stream with FFMPEG options'})
            cap.release()
        
        # Provide troubleshooting suggestions
        results['suggestions'] = [
            'Verify the RTSP URL format: rtsp://username:password@ip:port/path',
            'Common NVR paths: /Streaming/Channels/101 (Hikvision), /cam/realmonitor?channel=1&subtype=0 (Dahua)',
            'Try port 554 (standard RTSP port)',
            'Check firewall settings on both NVR and computer',
            'Verify username/password are correct',
            'Try accessing the stream with VLC player first to verify it works'
        ]
        
        return jsonify(results)
        
    except Exception as e:
        logger.error(f"RTSP test failed: {e}")
        import traceback
        return jsonify({
            'success': False, 
            'error': str(e),
            'traceback': traceback.format_exc()
        }), 500


@app.route('/api/add-bulk-cameras', methods=['POST'])
def api_add_bulk_cameras():
    """Add multiple cameras from NVR/DVR"""
    try:
        data = request.json
        cameras_data = data.get('cameras', [])
        
        added_cameras = []
        for cam_data in cameras_data:
            camera = Camera(
                name=cam_data['name'],
                rtsp_url=cam_data['rtsp_url'],
                location=cam_data.get('location', ''),
                enable_person_detection=True,
                enable_vehicle_detection=False,
                enable_animal_detection=False,
                enable_object_detection=False
            )
            db.session.add(camera)
            added_cameras.append(camera.name)
        
        db.session.commit()
        
        logger.info(f"Bulk added {len(added_cameras)} cameras")
        
        return jsonify({
            'success': True,
            'count': len(added_cameras),
            'cameras': added_cameras
        })
    except Exception as e:
        db.session.rollback()
        logger.error(f"Bulk camera add failed: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500


@app.route('/api/events')
def api_events():
    """Get detection events"""
    limit = request.args.get('limit', 50, type=int)
    camera_id = request.args.get('camera_id', type=int)
    
    query = DetectionEvent.query
    
    if camera_id:
        query = query.filter_by(camera_id=camera_id)
    
    events = query.order_by(DetectionEvent.created_at.desc()).limit(limit).all()
    
    return jsonify([event.to_dict() for event in events])


@app.route('/api/events/<int:event_id>/acknowledge', methods=['PUT'])
def api_acknowledge_event(event_id):
    """Mark a detection event as acknowledged/reviewed"""
    try:
        event = DetectionEvent.query.get_or_404(event_id)
        event.acknowledged = True
        event.acknowledged_at = datetime.utcnow()
        db.session.commit()
        return jsonify({'success': True, 'event': event.to_dict()})
    except Exception as e:
        logger.error(f"Error acknowledging event {event_id}: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500


@app.route('/api/events/<int:event_id>/unacknowledge', methods=['PUT'])
def api_unacknowledge_event(event_id):
    """Clear the reviewed status from a detection event"""
    try:
        event = DetectionEvent.query.get_or_404(event_id)
        event.acknowledged = False
        event.acknowledged_at = None
        db.session.commit()
        return jsonify({'success': True, 'event': event.to_dict()})
    except Exception as e:
        logger.error(f"Error un-acknowledging event {event_id}: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500


@app.route('/api/events/<int:event_id>', methods=['DELETE'])
def api_delete_event(event_id):
    """Delete a single detection event"""
    try:
        event = DetectionEvent.query.get_or_404(event_id)
        db.session.delete(event)
        db.session.commit()
        return jsonify({'success': True})
    except Exception as e:
        logger.error(f"Error deleting event {event_id}: {e}")
        return jsonify({'success': False, 'message': str(e)}), 500


@app.route('/api/events/export.csv')
@login_required
def api_export_events_csv():
    """Export detection events as CSV download"""
    import csv, io
    camera_id = request.args.get('camera_id', type=int)
    query = DetectionEvent.query
    if camera_id:
        query = query.filter_by(camera_id=camera_id)
    events_list = query.order_by(DetectionEvent.created_at.desc()).limit(5000).all()

    output = io.StringIO()
    writer = csv.writer(output)
    writer.writerow(['ID', 'Timestamp', 'Camera', 'Location', 'Class', 'Confidence', 'Zone', 'Telegram Sent', 'Acknowledged'])
    for ev in events_list:
        writer.writerow([
            ev.id,
            ev.created_at.strftime('%Y-%m-%d %H:%M:%S'),
            ev.camera.name if ev.camera else ev.camera_id,
            ev.camera.location if ev.camera else '',
            ev.detected_class,
            f'{ev.confidence:.2f}' if ev.confidence else '',
            ev.zone_name or '',
            'Yes' if ev.telegram_sent else 'No',
            'Yes' if ev.acknowledged else 'No',
        ])

    from flask import Response
    csv_bytes = output.getvalue().encode('utf-8')
    filename = f'sentinelvision_events_{datetime.utcnow().strftime("%Y%m%d_%H%M%S")}.csv'
    return Response(
        csv_bytes,
        mimetype='text/csv',
        headers={'Content-Disposition': f'attachment; filename="{filename}"'}
    )


# Simple in-memory cache for /api/stats (3-second TTL)
_stats_cache: dict = {'data': None, 'ts': 0.0}

@app.route('/api/stats')
def api_stats():
    """Get system statistics (cached for 3 s to reduce DB load)"""
    now = time.time()
    if _stats_cache['data'] is not None and now - _stats_cache['ts'] < 3:
        return jsonify(_stats_cache['data'])

    stats = get_system_stats()

    # Add detection stats
    today = datetime.utcnow().date()
    week_ago = datetime.utcnow() - timedelta(days=7)

    stats['detections_today'] = DetectionEvent.query.filter(
        DetectionEvent.created_at >= today
    ).count()

    stats['detections_this_week'] = DetectionEvent.query.filter(
        DetectionEvent.created_at >= week_ago
    ).count()

    # Detections by class (today)
    from sqlalchemy import func
    detections_by_class = db.session.query(
        DetectionEvent.detected_class,
        func.count(DetectionEvent.id)
    ).filter(
        DetectionEvent.created_at >= today
    ).group_by(DetectionEvent.detected_class).all()

    stats['detections_by_class'] = {cls: count for cls, count in detections_by_class}

    _stats_cache['data'] = stats
    _stats_cache['ts']   = now
    return jsonify(stats)


@app.route('/api/config', methods=['GET', 'PUT'])
def api_config():
    """Get or update system configuration"""
    config = get_system_config()
    
    if request.method == 'GET':
        return jsonify(config.to_dict())
    
    elif request.method == 'PUT':
        data = request.json
        
        if 'telegram_chat_id' in data:
            config.telegram_chat_id = data['telegram_chat_id']
        
        if 'detection_confidence' in data:
            config.detection_confidence = data['detection_confidence']
        
        if 'is_armed' in data:
            config.is_armed = data['is_armed']
        
        config.updated_at = datetime.utcnow()
        db.session.commit()
        
        # Update telegram service
        update_telegram_service()
        
        return jsonify({'success': True, 'config': config.to_dict()})


@app.route('/api/arm', methods=['POST'])
@login_required
def api_arm():
    """Arm the system"""
    config = get_system_config()
    config.is_armed = True
    config.updated_at = datetime.utcnow()
    db.session.commit()
    
    logger.info("System armed via API")
    
    return jsonify({'success': True, 'is_armed': True})


@app.route('/api/disarm', methods=['POST'])
@login_required
def api_disarm():
    """Disarm the system"""
    config = get_system_config()
    config.is_armed = False
    config.updated_at = datetime.utcnow()
    db.session.commit()
    
    logger.info("System disarmed via API")
    
    return jsonify({'success': True, 'is_armed': False})


@app.route('/api/test-telegram', methods=['POST'])
def api_test_telegram():
    """Test Telegram connection"""
    update_telegram_service()
    success, message = telegram_service.test_connection()
    
    if success:
        telegram_service.send_message('🧪 Test message from SentinelVision')
    
    return jsonify({'success': success, 'message': message})


@app.route('/api/cameras/<int:camera_id>/test-alert', methods=['POST'])
def api_camera_test_alert(camera_id):
    """Send a test Telegram alert for a specific camera"""
    camera = Camera.query.get_or_404(camera_id)
    update_telegram_service()
    success, message = telegram_service.test_connection()
    if not success:
        return jsonify({'success': False, 'message': f'Telegram not configured: {message}'})
    test_msg = (
        f'🧪 *Test Alert — {camera.name}*\n\n'
        f'✅ Alerts are working correctly.\n\n'
        f'🏢 Site: {camera.location or "Not set"}\n'
        f'📷 Camera: {camera.name}\n'
        f'🔔 Cooldown: {camera.alert_cooldown}s'
    )
    telegram_service.send_message(test_msg)
    return jsonify({'success': True, 'message': 'Test alert sent to Telegram'})


@app.route('/api/register-telegram-commands', methods=['POST'])
def api_register_telegram_commands():
    """Manually register Telegram bot commands"""
    try:
        success = telegram_service.setup_bot_commands()
        if success:
            return jsonify({
                'success': True,
                'message': '✅ Telegram bot commands registered successfully!'
            })
        else:
            return jsonify({
                'success': False,
                'message': '❌ Failed to register Telegram bot commands'
            })
    except Exception as e:
        logger.error(f"Error registering commands: {e}")
        return jsonify({
            'success': False,
            'message': f'❌ Error: {str(e)}'
        })


@app.route('/events')
def events():
    """Events history page — accessible to both admin and viewer sessions"""
    camera_id = request.args.get('camera_id', type=int)

    query = DetectionEvent.query
    if camera_id:
        query = query.filter_by(camera_id=camera_id)

    events_list = query.order_by(DetectionEvent.created_at.desc()).limit(100).all()
    cameras_list = Camera.query.all()
    is_viewer = bool(session.get('viewer_logged_in'))

    return render_template('events.html', events=events_list, cameras=cameras_list, is_viewer=is_viewer)


@app.route('/settings', methods=['GET', 'POST'])
@login_required
def settings():
    """Settings page"""
    config = get_system_config()
    stats = get_system_stats()
    
    if request.method == 'POST':
        # Update telegram settings
        if 'telegram_users' in request.form:
            config.telegram_users = request.form.get('telegram_users', '{}')
            # Update legacy field
            try:
                users = json.loads(config.telegram_users)
                config.telegram_chat_id = ','.join(users.keys())
            except:
                pass
        
        # Update detection settings
        if 'detection_confidence' in request.form:
            config.detection_confidence = float(request.form.get('detection_confidence', 0.75))
        if 'min_detection_size' in request.form:
            config.min_detection_size = int(request.form.get('min_detection_size', 50))
        if 'max_detection_size' in request.form:
            config.max_detection_size = int(request.form.get('max_detection_size', 5000))
        
        config.enable_tracking = 'enable_tracking' in request.form
        config.enable_zone_detection = 'enable_zone_detection' in request.form
        
        # Data retention / offline alarm settings
        if 'auto_delete_days' in request.form:
            try:
                config.auto_delete_days = int(request.form.get('auto_delete_days', 30))
            except (ValueError, TypeError):
                pass
        if 'camera_offline_alert_minutes' in request.form:
            try:
                config.camera_offline_alert_minutes = int(request.form.get('camera_offline_alert_minutes', 5))
            except (ValueError, TypeError):
                pass
        
        config.updated_at = datetime.utcnow()
        db.session.commit()
        
        # Update telegram service
        update_telegram_service()
        
        flash('Settings updated successfully!', 'success')
        return redirect(url_for('settings'))
    
    return render_template('settings.html', config=config, stats=stats)


@app.route('/api/cleanup-events', methods=['POST'])
def api_cleanup_events():
    """Manually trigger event cleanup (7-day auto-cleanup)"""
    try:
        count = cleanup_old_events()
        return jsonify({
            'success': True,
            'message': f'Cleaned up {count} old events',
            'count': count
        })
    except Exception as e:
        return jsonify({
            'success': False,
            'message': str(e)
        }), 500


@app.route('/api/delete-all-events', methods=['POST'])
@login_required
def api_delete_all_events():
    """Delete every detection event and associated files — full wipe"""
    try:
        rows = (DetectionEvent.query
                .with_entities(DetectionEvent.id, DetectionEvent.image_path,
                               DetectionEvent.thumbnail_path, DetectionEvent.clip_path)
                .all())
        count = len(rows)
        for row in rows:
            for path in [row.image_path, row.thumbnail_path]:
                if path and os.path.exists(path):
                    try:
                        os.remove(path)
                    except Exception:
                        pass
            if row.clip_path:
                full_clip = os.path.join(os.path.dirname(__file__), row.clip_path)
                if os.path.exists(full_clip):
                    try:
                        os.remove(full_clip)
                    except Exception:
                        pass
        try:
            from models import ZoneTransition, OccupancyLog, LoiteringEvent
            ZoneTransition.query.delete(synchronize_session=False)
            OccupancyLog.query.delete(synchronize_session=False)
            LoiteringEvent.query.delete(synchronize_session=False)
        except Exception:
            pass
        DetectionEvent.query.delete(synchronize_session=False)
        db.session.commit()
        logger.info(f'Admin wiped all {count} detection events')
        return jsonify({'success': True, 'message': f'Deleted all {count} events', 'count': count})
    except Exception as e:
        db.session.rollback()
        return jsonify({'success': False, 'message': str(e)}), 500


@app.route('/api/version', methods=['GET'])
def api_version():
    """Get current system version"""
    try:
        import json
        with open('version.json', 'r') as f:
            version_data = json.load(f)
        return jsonify(version_data)
    except Exception as e:
        return jsonify({
            'version': 'Unknown',
            'error': str(e)
        })


@app.route('/api/latest-threat')
@login_required
def api_latest_threat():
    """Return the most recent weapon/threat event after a given timestamp.
    Used by the dashboard to trigger the browser alert sound.
    Query param: since=<ISO timestamp> (UTC)
    """
    since_str = request.args.get('since')
    try:
        since = datetime.fromisoformat(since_str) if since_str else (datetime.utcnow() - timedelta(seconds=10))
    except (ValueError, TypeError):
        since = datetime.utcnow() - timedelta(seconds=10)

    weapon_classes = ['gun', 'pistol', 'rifle', 'handgun', 'firearm', 'weapon',
                      'knife', 'sword', 'blade', 'baseball bat', 'threat',
                      'FIREARM', 'BLADE', 'BLUNT']

    event = DetectionEvent.query.filter(
        DetectionEvent.created_at > since,
        DetectionEvent.detected_class.in_(weapon_classes)
    ).order_by(DetectionEvent.created_at.desc()).first()

    if event:
        # Also check that the originating camera has weapon_alert_sound enabled
        cam = Camera.query.get(event.camera_id)
        sound_enabled = getattr(cam, 'weapon_alert_sound', True) if cam else True
        return jsonify({
            'threat': True,
            'sound_enabled': sound_enabled,
            'event_id': event.id,
            'class': event.detected_class,
            'camera_id': event.camera_id,
            'timestamp': event.created_at.isoformat()
        })

    return jsonify({'threat': False})


@app.route('/api/check-updates', methods=['GET'])
@login_required
def api_check_updates():
    """Check for available updates from remote server"""
    import requests
    
    # Get update URL from environment variable or update_config.json file
    update_url = os.environ.get('SENTINELVISION_UPDATE_URL', '')
    
    # Try to read from update_config.json if env var not set
    if not update_url:
        config_file = os.path.join(os.path.dirname(__file__), 'update_config.json')
        if os.path.exists(config_file):
            try:
                with open(config_file, 'r') as f:
                    update_config = json.load(f)
                    update_url = update_config.get('update_url', '')
            except:
                pass
    
    if not update_url:
        return jsonify({
            'success': False,
            'error': 'No update server configured. Contact SentinelVision at info.sentinelvision@gmail.com for update access.',
            'update_available': False
        })
    
    try:
        # Fetch remote version.json
        response = requests.get(update_url, timeout=10)
        response.raise_for_status()
        remote_version = response.json()
        
        # Get current version
        with open('version.json', 'r') as f:
            current_version = json.load(f)
        
        # Compare versions
        current_v = current_version.get('version', '0.0.0')
        remote_v = remote_version.get('version', '0.0.0')
        
        # Simple version comparison (works for semver like 3.7.1)
        def version_tuple(v):
            return tuple(map(int, v.split('.')))
        
        update_available = version_tuple(remote_v) > version_tuple(current_v)
        
        return jsonify({
            'success': True,
            'update_available': update_available,
            'current_version': current_v,
            'latest_version': remote_v,
            'changes': remote_version.get('changes', []) if update_available else [],
            'download_url': remote_version.get('download_url', ''),
            'message': f'New version {remote_v} available!' if update_available else f'You are running the latest version ({current_v})'
        })
    except requests.exceptions.RequestException as e:
        return jsonify({
            'success': False,
            'error': f'Could not connect to update server: {str(e)}',
            'update_available': False
        })
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e),
            'update_available': False
        })


@app.route('/api/system/restart', methods=['POST'])
@login_required
def api_system_restart():
    """Restart the SentinelVision service"""
    try:
        import threading
        
        def delayed_restart():
            import time, sys, subprocess, signal
            time.sleep(2)  # Give the response time to return to the browser
            if sys.platform == 'win32':
                app_dir = os.path.dirname(os.path.abspath(__file__))
                run_py = os.path.join(app_dir, 'run.py')
                DETACHED = 0x00000008
                NEW_GROUP = 0x00000200
                subprocess.Popen([sys.executable, run_py], cwd=app_dir,
                                 creationflags=DETACHED | NEW_GROUP,
                                 close_fds=True)
                time.sleep(0.5)
                os.kill(os.getpid(), signal.SIGTERM)
            else:
                # On Linux/Pi: use systemctl restart (passwordless sudo is configured
                # by install.sh for exactly this command). This is the most reliable
                # method because it works even when StartLimitBurst has been hit and
                # regardless of whether INVOCATION_ID is in the environment.
                try:
                    result = subprocess.run(
                        ['sudo', 'systemctl', 'restart', 'sentinelvision'],
                        timeout=10, capture_output=True
                    )
                    if result.returncode == 0:
                        return  # systemd takes it from here
                except Exception:
                    pass
                # Fallback 1: SIGTERM lets systemd's Restart=always kick in
                if os.environ.get('INVOCATION_ID'):
                    os.kill(os.getpid(), signal.SIGTERM)
                    return
                # Fallback 2: execv replaces the process in-place
                app_dir = os.path.dirname(os.path.abspath(__file__))
                run_py = os.path.join(app_dir, 'run.py')
                os.execv(sys.executable, [sys.executable, run_py])
        
        thread = threading.Thread(target=delayed_restart, daemon=True)
        thread.start()
        
        logger.info("🔄 Service restart initiated by user")
        return jsonify({
            'success': True,
            'message': 'Service restart initiated. Reconnecting in a few seconds…'
        })
    except Exception as e:
        logger.error(f"Error initiating restart: {e}")
        return jsonify({
            'success': False,
            'message': str(e)
        }), 500


@app.route('/api/system/reboot', methods=['POST'])
@login_required
def api_system_reboot():
    """Reboot the entire Raspberry Pi"""
    try:
        import subprocess
        import threading
        
        def delayed_reboot():
            import time
            time.sleep(3)  # Wait 3 seconds before rebooting
            try:
                subprocess.run(['sudo', 'reboot'], timeout=10, check=True)
            except Exception as e:
                # Fallback: systemd-style shutdown
                try:
                    subprocess.run(['sudo', 'shutdown', '-r', 'now'], timeout=10)
                except Exception as e2:
                    logger.error(f"Reboot failed: {e2}")
        
        # Start reboot in background thread
        thread = threading.Thread(target=delayed_reboot)
        thread.daemon = True
        thread.start()
        
        logger.info("🔌 System reboot initiated by user")
        return jsonify({
            'success': True,
            'message': 'System reboot initiated. Please wait 1-2 minutes.'
        })
    except Exception as e:
        logger.error(f"Error initiating reboot: {e}")
        return jsonify({
            'success': False,
            'message': str(e)
        }), 500


# Stock Control Routes
@app.route('/stock')
@login_required
@license_required('stock_control')
def stock_control():
    """Stock control dashboard"""
    try:
        from stock_control import StockAnalytics
        
        # Get all cameras (filter will be done in template if needed)
        cameras = Camera.query.all()
        
        # Get stock summary (no camera_id = all cameras)
        summary = StockAnalytics.get_stock_summary()
        
        return render_template('stock_control.html', 
                             cameras=cameras,
                             summary=summary)
    except Exception as e:
        logger.error(f"Error loading stock control: {e}", exc_info=True)
        flash(f'Error loading stock control: {str(e)}', 'error')
        return redirect(url_for('index'))


@app.route('/api/stock/items', methods=['GET', 'POST'])
def api_stock_items():
    """Get or create stock items"""
    if request.method == 'POST':
        try:
            data = request.json
            camera_id = data.get('camera_id')
            
            stock_item = StockItem(
                camera_id=camera_id,
                name=data.get('name'),
                current_count=data.get('current_count', 0),
                min_threshold=data.get('min_threshold', 50),
                critical_threshold=data.get('critical_threshold', 20)
            )
            stock_item.set_yolo_classes(data.get('yolo_classes', []))
            
            db.session.add(stock_item)
            db.session.commit()
            
            return jsonify({
                'success': True,
                'item': stock_item.to_dict()
            })
        except Exception as e:
            db.session.rollback()
            return jsonify({
                'success': False,
                'message': str(e)
            }), 400
    
    # GET request
    try:
        camera_id = request.args.get('camera_id', type=int)
        query = StockItem.query
        if camera_id:
            query = query.filter_by(camera_id=camera_id)
        
        items = query.all()
        return jsonify({
            'success': True,
            'items': [item.to_dict() for item in items]
        })
    except Exception as e:
        return jsonify({
            'success': False,
            'message': str(e)
        }), 400


@app.route('/api/stock/items/<int:item_id>', methods=['GET', 'PUT', 'DELETE'])
def api_stock_item(item_id):
    """Get, update, or delete a stock item"""
    item = StockItem.query.get_or_404(item_id)
    
    if request.method == 'DELETE':
        try:
            # Delete related records first
            StockDelivery.query.filter_by(stock_item_id=item_id).delete()
            StockWaste.query.filter_by(stock_item_id=item_id).delete()
            StockUsageHistory.query.filter_by(stock_item_id=item_id).delete()
            
            # Now delete the stock item
            db.session.delete(item)
            db.session.commit()
            return jsonify({'success': True})
        except Exception as e:
            db.session.rollback()
            return jsonify({
                'success': False,
                'error': str(e)
            }), 400
    
    if request.method == 'PUT':
        try:
            data = request.json
            
            if 'name' in data:
                item.name = data['name']
            if 'current_count' in data:
                item.current_count = data['current_count']
            if 'min_threshold' in data:
                item.min_threshold = data['min_threshold']
            if 'critical_threshold' in data:
                item.critical_threshold = data['critical_threshold']
            if 'yolo_classes' in data:
                item.set_yolo_classes(data['yolo_classes'])
            
            db.session.commit()
            
            return jsonify({
                'success': True,
                'item': item.to_dict()
            })
        except Exception as e:
            db.session.rollback()
            return jsonify({
                'success': False,
                'message': str(e)
            }), 400
    
    # GET request
    return jsonify({
        'success': True,
        'item': item.to_dict()
    })


@app.route('/api/stock/delivery', methods=['POST'])
def api_stock_delivery():
    """Record stock delivery"""
    try:
        from stock_control import StockAnalytics
        
        data = request.json
        delivery = StockAnalytics.add_stock_delivery(
            stock_item_id=data.get('stock_item_id'),
            quantity=data.get('quantity'),
            supplier=data.get('supplier'),
            notes=data.get('notes')
        )
        
        if delivery:
            return jsonify({
                'success': True,
                'delivery': delivery.to_dict()
            })
        else:
            return jsonify({
                'success': False,
                'message': 'Stock item not found'
            }), 404
    except Exception as e:
        db.session.rollback()
        return jsonify({
            'success': False,
            'message': str(e)
        }), 400


@app.route('/api/stock/waste', methods=['POST'])
def api_stock_waste():
    """Log stock waste"""
    try:
        from stock_control import StockAnalytics
        
        data = request.json
        waste = StockAnalytics.log_stock_waste(
            stock_item_id=data.get('stock_item_id'),
            quantity=data.get('quantity'),
            reason=data.get('reason'),
            notes=data.get('notes')
        )
        
        if waste:
            return jsonify({
                'success': True,
                'waste': waste.to_dict()
            })
        else:
            return jsonify({
                'success': False,
                'message': 'Stock item not found'
            }), 404
    except Exception as e:
        db.session.rollback()
        return jsonify({
            'success': False,
            'message': str(e)
        }), 400


@app.route('/api/stock/summary')
def api_stock_summary():
    """Get stock summary"""
    try:
        from stock_control import StockAnalytics
        
        camera_id = request.args.get('camera_id', type=int)
        summary = StockAnalytics.get_stock_summary(camera_id)
        
        return jsonify({
            'success': True,
            **summary
        })
    except Exception as e:
        return jsonify({
            'success': False,
            'message': str(e)
        }), 400


@app.route('/api/stock/usage/<int:item_id>')
def api_stock_usage(item_id):
    """Get usage trend for an item"""
    try:
        from stock_control import StockAnalytics
        
        days = request.args.get('days', default=30, type=int)
        trend = StockAnalytics.get_usage_trend(item_id, days)
        
        return jsonify({
            'success': True,
            'trend': trend
        })
    except Exception as e:
        return jsonify({
            'success': False,
            'message': str(e)
        }), 400


@app.route('/api/stock/report/daily')
def api_daily_stock_report():
    """Generate daily stock report"""
    try:
        from stock_control import StockReportGenerator
        
        camera_id = request.args.get('camera_id', type=int)
        report = StockReportGenerator.generate_daily_report(camera_id)
        
        return jsonify({
            'success': True,
            **report
        })
    except Exception as e:
        return jsonify({
            'success': False,
            'message': str(e)
        }), 400


@app.route('/api/stock/report/weekly')
def api_weekly_stock_report():
    """Generate weekly stock report"""
    try:
        from stock_control import StockReportGenerator
        
        camera_id = request.args.get('camera_id', type=int)
        report = StockReportGenerator.generate_weekly_report(camera_id)
        
        return jsonify({
            'success': True,
            **report
        })
    except Exception as e:
        return jsonify({
            'success': False,
            'message': str(e)
        }), 400


# System Update Routes
@app.route('/system/updates')
def system_updates():
    """System update management page"""
    from update_manager import UpdateManager
    
    version_info = UpdateManager.get_version_info()
    backups = UpdateManager.list_backups()
    
    return render_template('system_updates.html',
                         version_info=version_info,
                         backups=backups)


@app.route('/api/system/version')
def api_get_version():
    """Get current system version"""
    from update_manager import UpdateManager
    return jsonify(UpdateManager.get_version_info())


@app.route('/api/system/upload-update', methods=['POST'])
@login_required
def api_upload_update():
    """Upload and apply system update"""
    try:
        from update_manager import UpdateManager
        import tempfile
        
        if 'update_file' not in request.files:
            return jsonify({
                'success': False,
                'message': 'No update file provided'
            }), 400
        
        file = request.files['update_file']
        
        if file.filename == '':
            return jsonify({
                'success': False,
                'message': 'No file selected'
            }), 400
        
        if not file.filename.endswith('.zip'):
            return jsonify({
                'success': False,
                'message': 'Update file must be a ZIP archive'
            }), 400
        
        # Save temporary file
        with tempfile.NamedTemporaryFile(delete=False, suffix='.zip') as tmp:
            file.save(tmp.name)
            tmp_path = tmp.name
        
        try:
            # Validate package
            is_valid, message = UpdateManager.validate_update_package(tmp_path)
            if not is_valid:
                os.unlink(tmp_path)
                return jsonify({
                    'success': False,
                    'message': message
                }), 400
            
            # Apply update
            success, version_data = UpdateManager.apply_update(tmp_path)
            os.unlink(tmp_path)
            
            # Auto-restart after update so new code takes effect immediately
            import threading, signal as _signal
            def _do_restart():
                import time, sys, subprocess
                time.sleep(3)  # give the JSON response time to reach the browser
                if sys.platform == 'win32':
                    # Windows dev mode: spawn detached new process then exit
                    app_dir = os.path.dirname(os.path.abspath(__file__))
                    run_py = os.path.join(app_dir, 'run.py')
                    DETACHED = 0x00000008
                    NEW_GROUP = 0x00000200
                    subprocess.Popen([sys.executable, run_py], cwd=app_dir,
                                     creationflags=DETACHED | NEW_GROUP,
                                     close_fds=True)
                    time.sleep(0.5)
                    os.kill(os.getpid(), _signal.SIGTERM)
                else:
                    # On Linux/Pi: use systemctl restart (passwordless sudo is
                    # configured by install.sh for this exact command). Reliable
                    # even if StartLimitBurst was hit or INVOCATION_ID is missing.
                    try:
                        result = subprocess.run(
                            ['sudo', 'systemctl', 'restart', 'sentinelvision'],
                            timeout=10, capture_output=True
                        )
                        if result.returncode == 0:
                            return  # systemd takes it from here
                    except Exception:
                        pass
                    # Fallback 1: SIGTERM — lets Restart=always kick in
                    if os.environ.get('INVOCATION_ID'):
                        os.kill(os.getpid(), _signal.SIGTERM)
                        return
                    # Fallback 2: execv replaces the process in-place
                    app_dir = os.path.dirname(os.path.abspath(__file__))
                    run_py = os.path.join(app_dir, 'run.py')
                    os.execv(sys.executable, [sys.executable, run_py])
            threading.Thread(target=_do_restart, daemon=True).start()
            logger.info(f"🔄 Auto-restart triggered after update to v{version_data['version']}")
            
            return jsonify({
                'success': True,
                'message': f'Update to v{version_data["version"]} applied — restarting now…',
                'version': version_data['version'],
                'changes': version_data.get('changes', []),
                'restart_required': True,
                'auto_restarting': True
            })
        except Exception as e:
            if os.path.exists(tmp_path):
                os.unlink(tmp_path)
            raise
            
    except Exception as e:
        logger.error(f"Error uploading update: {e}")
        return jsonify({
            'success': False,
            'message': str(e)
        }), 500


@app.route('/api/system/rollback/<backup_name>', methods=['POST'])
@login_required
def api_rollback_update(backup_name):
    """Rollback to a previous backup"""
    try:
        from update_manager import UpdateManager
        import os

        # Block path traversal — backup_name must not escape the backups directory
        backup_root = os.path.abspath(UpdateManager.BACKUP_DIR)
        backup_path = os.path.abspath(os.path.join(UpdateManager.BACKUP_DIR, backup_name))
        if not backup_path.startswith(backup_root + os.sep):
            return jsonify({'success': False, 'message': 'Invalid backup name'}), 400

        if not os.path.exists(backup_path):
            return jsonify({
                'success': False,
                'message': 'Backup not found'
            }), 404
        
        UpdateManager.rollback_to_backup(backup_path)
        
        return jsonify({
            'success': True,
            'message': 'System rolled back successfully',
            'restart_required': True
        })
    except Exception as e:
        logger.error(f"Error rolling back: {e}")
        return jsonify({
            'success': False,
            'message': str(e)
        }), 500


@app.route('/api/camera/<int:camera_id>/snapshot')
def get_camera_snapshot(camera_id):
    """Get latest frame from a camera for zone drawing"""
    try:
        from io import BytesIO
        import cv2
        import numpy as np
        
        camera = Camera.query.get_or_404(camera_id)
        
        # Check for fast mode (for zone drawing - use cached or quick grab)
        fast_mode = request.args.get('fast', '0') == '1'
        
        def _is_blank(img):
            """Only reject truly blank/corrupt startup frames."""
            if img is None:
                return True
            try:
                g = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY) if len(img.shape) == 3 else img
                return np.var(g) < 30 or np.mean(g) < 3
            except:
                return True

        # First try to get frame from detection engine's cache (fastest).
        # This is the correct real-time frame already decoded by the detection
        # loop — works perfectly for Provision/Hikvision/IR cameras.
        if detection_engine and hasattr(detection_engine, 'camera_frames'):
            cached_frame = detection_engine.camera_frames.get(camera_id)
            if cached_frame is not None and not _is_blank(cached_frame):
                frame = cached_frame.copy()
                frame = cv2.resize(frame, (800, 600))
                _, buffer = cv2.imencode('.jpg', frame, [cv2.IMWRITE_JPEG_QUALITY, 85])
                return send_file(BytesIO(buffer), mimetype='image/jpeg')

        # Build ordered URL list to try for RTSP grab.
        # working_rtsp_url is the URL the detection engine ALREADY verified works
        # (important for Provision cameras whose path differs from user-entered URL).
        working_rtsp_url = getattr(camera, 'working_rtsp_url', None)
        base_url = camera.get_snapshot_url() if hasattr(camera, 'get_snapshot_url') else camera.rtsp_url
        snapshot_url = working_rtsp_url or base_url  # prefer verified URL
        
        frame = None
        
        # FAST MODE: Try HTTP snapshot FIRST (much faster than RTSP)
        if fast_mode:
            try:
                import re, urllib.request
                match = re.search(r'rtsp://([^:]+):([^@]+)@([^:/]+)', snapshot_url or camera.rtsp_url or '')
                if match:
                    user, passwd, host = match.groups()
                    # Try Provision CGI first (fastest for Provision ISR cameras),
                    # then generic snapshot.jpg, then Hikvision ISAPI
                    _http_candidates = [
                        f"http://{user}:{passwd}@{host}/cgi-bin/snapshot.cgi",
                        f"http://{user}:{passwd}@{host}/snapshot.jpg",
                        f"http://{user}:{passwd}@{host}/ISAPI/Streaming/channels/101/picture",
                    ]
                    for http_url in _http_candidates:
                        try:
                            req = urllib.request.Request(http_url)
                            req.add_header('User-Agent', 'Mozilla/5.0')
                            with urllib.request.urlopen(req, timeout=3) as response:
                                img_array = np.asarray(bytearray(response.read()), dtype=np.uint8)
                                frame = cv2.imdecode(img_array, cv2.IMREAD_COLOR)
                                if frame is not None and not _is_blank(frame):
                                    logger.info(f"Snapshot: Fast HTTP from {http_url}")
                                    frame = cv2.resize(frame, (800, 600))
                                    _, buffer = cv2.imencode('.jpg', frame, [cv2.IMWRITE_JPEG_QUALITY, 85])
                                    return send_file(BytesIO(buffer), mimetype='image/jpeg')
                        except Exception:
                            continue
            except Exception as e:
                logger.debug(f"Fast HTTP snapshot failed: {e}")
        
        def is_gray_frame(img):
            """Only reject truly blank/corrupt startup frames. Night IR frames are valid."""
            if img is None:
                return True
            try:
                gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
                if np.var(gray) < 30:   # truly solid / blank startup frame
                    return True
                if np.mean(gray) < 3:   # completely black (disconnected)
                    return True
                return False
            except:
                return False

        # Reduce attempts in fast mode for quicker loading
        max_frames = 5 if fast_mode else 30
        timeout_ms = 2000 if fast_mode else 10000

        def _grab_rtsp(url, n_frames=max_frames, t_ms=timeout_ms):
            """Open an RTSP URL with FFMPEG/TCP and return the first non-blank frame."""
            try:
                os.environ['OPENCV_FFMPEG_CAPTURE_OPTIONS'] = (
                    'rtsp_transport;tcp|analyzeduration;5000000|fflags;nobuffer|stimeout;8000000')
                cap = cv2.VideoCapture(url, cv2.CAP_FFMPEG)
                cap.set(cv2.CAP_PROP_BUFFERSIZE, 1)
                cap.set(cv2.CAP_PROP_OPEN_TIMEOUT_MSEC, t_ms)
                cap.set(cv2.CAP_PROP_READ_TIMEOUT_MSEC, t_ms)
                best = None
                if cap.isOpened():
                    for _ in range(n_frames):
                        ret, f = cap.read()
                        if ret and f is not None:
                            if not is_gray_frame(f):
                                best = f
                                break
                            best = f  # keep as fallback
                cap.release()
                return best
            except Exception as ex:
                logger.debug(f"RTSP grab failed for {url}: {ex}")
                return None

        # Build a prioritised list of URLs to try for RTSP snapshot
        # working_rtsp_url is the URL the detection engine already verified —
        # critical for Provision cameras whose path differs from the user URL.
        urls_to_snapshot = []
        if snapshot_url:
            urls_to_snapshot.append(snapshot_url)
        if base_url and base_url != snapshot_url:
            urls_to_snapshot.append(base_url)
        if camera.rtsp_url and camera.rtsp_url not in urls_to_snapshot:
            urls_to_snapshot.append(camera.rtsp_url)

        # Also generate Provision/Hikvision/Dahua alternate paths from the base URL
        import re as _re
        from urllib.parse import quote as _quote, unquote as _unquote
        _m = _re.match(r'rtsp://([^:]+):([^@]+)@([^:/]+)(?::([\d]+))?(/.*)?',
                       camera.rtsp_url or '')
        if _m:
            _u, _p, _h, _port, _path = _m.groups()
            _port = _port or '554'
            # Re-encode password to handle any special characters correctly
            _auth = f"{_u}:{_quote(_unquote(_p), safe='')}@{_h}:{_port}"
            for _alt in [
                # Provision ISR standalone IP camera — primary paths first
                f"rtsp://{_auth}/live/ch00_0",
                f"rtsp://{_auth}/live/ch00_1",
                f"rtsp://{_auth}/11",          # Provision PoE/encoder main stream
                f"rtsp://{_auth}/12",          # Provision PoE/encoder sub stream
                f"rtsp://{_auth}/stream1",
                f"rtsp://{_auth}/stream2",
                f"rtsp://{_auth}/live/main",
                f"rtsp://{_auth}/live/sub",
                f"rtsp://{_auth}/media/video1",
                f"rtsp://{_auth}/profile1",
                f"rtsp://{_auth}/profile2",
                f"rtsp://{_auth}/video",
                f"rtsp://{_auth}/cam/realmonitor?channel=1&subtype=0",
                f"rtsp://{_auth}/cam/realmonitor?channel=1&subtype=1",
                f"rtsp://{_auth}/cam/realmonitor?channel=1&subtype=2",
                f"rtsp://{_auth}/cam/realmonitor?channel=1&subtype=0&unicast=true&proto=Onvif",
                f"rtsp://{_auth}/Streaming/Channels/101",
                f"rtsp://{_auth}/h264/ch1/main/av_stream",
                f"rtsp://{_auth}/onvif1",
            ]:
                if _alt not in urls_to_snapshot:
                    urls_to_snapshot.append(_alt)

        # Method 1: Try RTSP URLs in priority order
        if frame is None:
            for _url in urls_to_snapshot:
                frame = _grab_rtsp(_url, n_frames=max_frames, t_ms=timeout_ms)
                if frame is not None:
                    logger.info(f"Snapshot: Connected via {_url}")
                    break

        # In fast mode return placeholder rather than hanging on remaining methods
        if fast_mode and frame is None:
            placeholder = np.zeros((600, 800, 3), dtype=np.uint8)
            placeholder[:] = (60, 60, 60)
            cv2.putText(placeholder, 'Loading Camera...', (260, 280),
                       cv2.FONT_HERSHEY_SIMPLEX, 1.2, (255, 255, 255), 2)
            cv2.putText(placeholder, camera.name, (300, 330),
                       cv2.FONT_HERSHEY_SIMPLEX, 1, (200, 200, 200), 2)
            cv2.putText(placeholder, 'Click Refresh if needed', (230, 370),
                       cv2.FONT_HERSHEY_SIMPLEX, 0.7, (150, 150, 150), 1)
            _, buffer = cv2.imencode('.jpg', placeholder)
            return send_file(BytesIO(buffer), mimetype='image/jpeg')

        # Method 2: HTTP snapshot (Hikvision ISAPI) - slow mode only
        if frame is None and not fast_mode:
            try:
                import urllib.request
                _m2 = _re.search(r'rtsp://([^:]+):([^@]+)@([^:/]+)', camera.rtsp_url or '')
                if _m2:
                    _u2, _p2, _h2 = _m2.groups()
                    http_url = f"http://{_u2}:{_p2}@{_h2}/ISAPI/Streaming/channels/101/picture"
                    req = urllib.request.Request(http_url)
                    req.add_header('User-Agent', 'Mozilla/5.0')
                    with urllib.request.urlopen(req, timeout=5) as response:
                        img_array = np.asarray(bytearray(response.read()), dtype=np.uint8)
                        frame = cv2.imdecode(img_array, cv2.IMREAD_COLOR)
                        if frame is not None:
                            logger.info(f"Snapshot: HTTP ISAPI snapshot for {camera.name}")
            except Exception as e:
                logger.debug(f"Method 2 (HTTP snapshot) failed: {e}")

        # Method 3: HTTP snapshot (Provision / Dahua CGI)
        if frame is None and not fast_mode:
            try:
                import urllib.request
                _m3 = _re.search(r'rtsp://([^:]+):([^@]+)@([^:/]+)', camera.rtsp_url or '')
                if _m3:
                    _u3, _p3, _h3 = _m3.groups()
                    for _cgi in [
                        f"http://{_u3}:{_p3}@{_h3}/cgi-bin/snapshot.cgi",
                        f"http://{_u3}:{_p3}@{_h3}/snapshot.jpg",
                        f"http://{_u3}:{_p3}@{_h3}/image/jpeg.cgi",
                    ]:
                        try:
                            req = urllib.request.Request(_cgi)
                            req.add_header('User-Agent', 'Mozilla/5.0')
                            with urllib.request.urlopen(req, timeout=4) as response:
                                img_array = np.asarray(bytearray(response.read()), dtype=np.uint8)
                                _f = cv2.imdecode(img_array, cv2.IMREAD_COLOR)
                                if _f is not None and not is_gray_frame(_f):
                                    frame = _f
                                    logger.info(f"Snapshot: CGI snapshot from {_cgi}")
                                    break
                        except:
                            continue
            except Exception as e:
                logger.debug(f"Method 3 (Provision CGI) failed: {e}")

        if frame is None:
            # Return placeholder image
            placeholder = np.zeros((600, 800, 3), dtype=np.uint8)
            placeholder[:] = (50, 50, 50)  # Dark gray
            cv2.putText(placeholder, 'Failed to Capture Snapshot', (180, 280), 
                       cv2.FONT_HERSHEY_SIMPLEX, 1.2, (255, 255, 255), 2)
            cv2.putText(placeholder, camera.name, (300, 330), 
                       cv2.FONT_HERSHEY_SIMPLEX, 1, (200, 200, 200), 2)
            cv2.putText(placeholder, 'Check camera connection', (240, 370), 
                       cv2.FONT_HERSHEY_SIMPLEX, 0.8, (150, 150, 150), 1)
            frame = placeholder
        else:
            # Fix gray/color issues for DVR streams
            is_dvr = getattr(camera, 'is_dvr_channel', False)
            if is_dvr or len(frame.shape) == 2:
                if len(frame.shape) == 2:
                    # Grayscale - convert to BGR
                    frame = cv2.cvtColor(frame, cv2.COLOR_GRAY2BGR)
                elif frame.shape[2] == 4:
                    # BGRA - convert to BGR
                    frame = cv2.cvtColor(frame, cv2.COLOR_BGRA2BGR)
        
        # Resize to 800x600 for zone canvas
        frame = cv2.resize(frame, (800, 600))
        
        # Convert to JPEG with good quality
        _, buffer = cv2.imencode('.jpg', frame, [cv2.IMWRITE_JPEG_QUALITY, 90])
        img_bytes = BytesIO(buffer)
        
        return send_file(img_bytes, mimetype='image/jpeg')
    except Exception as e:
        logger.error(f"Error getting camera snapshot: {e}")
        # Return error placeholder
        placeholder = np.zeros((600, 800, 3), dtype=np.uint8)
        placeholder[:] = (100, 0, 0)  # Dark red
        cv2.putText(placeholder, 'Error Loading Camera', (200, 300), 
                   cv2.FONT_HERSHEY_SIMPLEX, 1.5, (255, 255, 255), 2)
        _, buffer = cv2.imencode('.jpg', placeholder)
        return send_file(BytesIO(buffer), mimetype='image/jpeg')


# =============================================================================
# MULTI-VIEW GRID
# =============================================================================
@app.route('/multiview')
@login_required
def multiview():
    """Multi-camera view page (1x1, 2x2, 3x3, 4x4 grid)"""
    cameras = Camera.query.filter_by(is_active=True).all()
    return render_template('multiview.html', cameras=cameras)


@app.route('/api/camera/<int:camera_id>/stream')
def camera_stream(camera_id):
    """MJPEG stream from camera (for live view) - Enhanced for Provision/Hikvision/Dahua"""
    camera = Camera.query.get_or_404(camera_id)
    rtsp_url = camera.rtsp_url
    # Use working URL from detection engine if available
    working_rtsp_url = getattr(camera, 'working_rtsp_url', None)
    
    def is_gray_frame(img):
        """Only reject truly blank/corrupt startup frames. Night IR frames are valid."""
        if img is None:
            return True
        try:
            gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
            if np.var(gray) < 30:   # truly solid / blank startup frame
                return True
            if np.mean(gray) < 3:   # completely black (disconnected)
                return True
            return False
        except:
            return False

    def try_connect(url):
        """Try to connect to camera with FFMPEG options"""
        try:
            # Set FFMPEG options for better compatibility
            os.environ['OPENCV_FFMPEG_CAPTURE_OPTIONS'] = 'rtsp_transport;tcp|analyzeduration;5000000|fflags;nobuffer|stimeout;5000000'
            cap = cv2.VideoCapture(url, cv2.CAP_FFMPEG)
            cap.set(cv2.CAP_PROP_BUFFERSIZE, 3)
            cap.set(cv2.CAP_PROP_OPEN_TIMEOUT_MSEC, 10000)
            cap.set(cv2.CAP_PROP_READ_TIMEOUT_MSEC, 5000)
            if cap.isOpened():
                ret, test = cap.read()
                if ret and test is not None:
                    return cap
            cap.release()
        except:
            pass
        return None
    
    def generate_frames():
        # Try working URL first if detection engine found one
        urls_to_try = []
        if working_rtsp_url:
            urls_to_try.append(working_rtsp_url)
            logger.info(f"Using working RTSP URL from detection: {working_rtsp_url}")
        urls_to_try.append(rtsp_url)
        
        # Parse URL and generate alternates
        import re
        from urllib.parse import quote as _q, unquote as _uq
        match = re.match(r'rtsp://([^:]+):([^@]+)@([^:/]+)(?::([\d]+))?(/.*)?', rtsp_url)
        if match:
            user, passwd, host, port, path = match.groups()
            port = port or '554'
            auth = f"{user}:{_q(_uq(passwd), safe='')}@{host}:{port}"
            
            # Add common stream path formats (Provision ISR standalone priority first)
            urls_to_try.extend([
                # Provision ISR standalone IP camera — primary paths first
                f"rtsp://{auth}/live/ch00_0",
                f"rtsp://{auth}/live/ch00_1",
                f"rtsp://{auth}/11",
                f"rtsp://{auth}/12",
                f"rtsp://{auth}/stream1",
                f"rtsp://{auth}/stream2",
                f"rtsp://{auth}/live/main",
                f"rtsp://{auth}/live/sub",
                f"rtsp://{auth}/media/video1",
                f"rtsp://{auth}/media/video2",
                f"rtsp://{auth}/profile1",
                f"rtsp://{auth}/profile2",
                f"rtsp://{auth}/video",
                f"rtsp://{auth}/videoinput_1/h264_1",
                f"rtsp://{auth}/videoMain",
                f"rtsp://{auth}/videoSub",
                # Provision/Dahua NVR formats
                f"rtsp://{auth}/cam/realmonitor?channel=1&subtype=0",
                f"rtsp://{auth}/cam/realmonitor?channel=1&subtype=1",
                f"rtsp://{auth}/cam/realmonitor?channel=1&subtype=2",
                f"rtsp://{auth}/cam/realmonitor?channel=1&subtype=0&unicast=true&proto=Onvif",
                f"rtsp://{auth}/live",
                # Hikvision formats
                f"rtsp://{auth}/Streaming/Channels/101",
                f"rtsp://{auth}/Streaming/Channels/102",
                f"rtsp://{auth}/h264/ch1/main/av_stream",
                f"rtsp://{auth}/h264/ch1/sub/av_stream",
                # ONVIF standard
                f"rtsp://{auth}/onvif1",
                f"rtsp://{auth}/onvif2",
                # Generic
                f"rtsp://{auth}/",
            ])
        
        cap = None
        working_url = None
        
        # Try each URL format
        for url in urls_to_try:
            cap = try_connect(url)
            if cap and cap.isOpened():
                working_url = url
                logger.info(f"Live stream connected: {url}")
                break
        
        if not cap:
            logger.error(f"Failed to connect to camera {camera_id} for live stream")
            # Yield error placeholder
            placeholder = np.zeros((360, 640, 3), dtype=np.uint8)
            placeholder[:] = (30, 30, 30)
            cv2.putText(placeholder, 'Camera Offline', (200, 180), cv2.FONT_HERSHEY_SIMPLEX, 1, (100, 100, 100), 2)
            cv2.putText(placeholder, 'Check RTSP Connection', (180, 220), cv2.FONT_HERSHEY_SIMPLEX, 0.7, (80, 80, 80), 1)
            _, buffer = cv2.imencode('.jpg', placeholder)
            yield (b'--frame\r\n' b'Content-Type: image/jpeg\r\n\r\n' + buffer.tobytes() + b'\r\n')
            return
        
        consecutive_failures = 0
        gray_frame_count = 0
        
        while True:
            ret, frame = cap.read()
            if not ret:
                consecutive_failures += 1
                if consecutive_failures >= 10:
                    # Try to reconnect
                    cap.release()
                    logger.warning(f"Reconnecting to camera {camera_id}...")
                    time.sleep(2)
                    cap = try_connect(working_url or rtsp_url)
                    if not cap:
                        # Try other URLs
                        for url in urls_to_try:
                            cap = try_connect(url)
                            if cap:
                                working_url = url
                                break
                    consecutive_failures = 0
                    if not cap:
                        logger.error(f"Failed to reconnect to camera {camera_id}")
                        break
                time.sleep(0.1)
                continue
            
            consecutive_failures = 0
            
            # Skip gray/blank frames (common on Hikvision DVR)
            if is_gray_frame(frame):
                gray_frame_count += 1
                if gray_frame_count < 30:  # Skip up to 30 gray frames
                    continue
                # After 30 gray frames, show anyway with warning
                gray_frame_count = 0
            else:
                gray_frame_count = 0
            
            # Resize for web viewing
            frame = cv2.resize(frame, (640, 360))
            
            _, buffer = cv2.imencode('.jpg', frame, [cv2.IMWRITE_JPEG_QUALITY, 70])
            frame_bytes = buffer.tobytes()
            
            yield (b'--frame\r\n'
                   b'Content-Type: image/jpeg\r\n\r\n' + frame_bytes + b'\r\n')
            # Adaptive FPS cap: slower when more streams are open to protect Pi CPU
            # Each browser tab × each camera opens a separate stream thread
            _active = max(1, len(getattr(detection_engine, 'threads', {})))
            _target_fps = max(5, 20 - _active)  # 5-15 fps depending on camera count
            time.sleep(1.0 / _target_fps)
        
        if cap:
            cap.release()
    
    return Response(generate_frames(), mimetype='multipart/x-mixed-replace; boundary=frame')


@app.route('/video_feed/<int:camera_id>')
def video_feed(camera_id):
    """Single frame from camera - Enhanced for Provision/Hikvision/Dahua with gray frame skip"""
    try:
        camera = Camera.query.get_or_404(camera_id)
        rtsp_url = camera.rtsp_url
        # Use working URL from detection engine if available
        working_rtsp_url = getattr(camera, 'working_rtsp_url', None)
        
        def is_gray_frame(img):
            """Only reject truly blank/corrupt startup frames. Night IR frames are valid."""
            if img is None:
                return True
            try:
                gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
                if np.var(gray) < 30:   # truly solid / blank startup frame
                    return True
                if np.mean(gray) < 3:   # completely black (disconnected)
                    return True
                return False
            except:
                return False

        def try_connect(url):
            """Try to connect with FFMPEG options"""
            try:
                os.environ['OPENCV_FFMPEG_CAPTURE_OPTIONS'] = 'rtsp_transport;tcp|analyzeduration;5000000|fflags;nobuffer'
                cap = cv2.VideoCapture(url, cv2.CAP_FFMPEG)
                cap.set(cv2.CAP_PROP_BUFFERSIZE, 3)
                cap.set(cv2.CAP_PROP_OPEN_TIMEOUT_MSEC, 10000)
                cap.set(cv2.CAP_PROP_READ_TIMEOUT_MSEC, 5000)
                return cap
            except:
                return None
        
        # Try working URL first, then user URL, then fallbacks
        urls_to_try = []
        if working_rtsp_url:
            urls_to_try.append(working_rtsp_url)
        urls_to_try.append(rtsp_url)
        
        import re
        from urllib.parse import quote as _q, unquote as _uq
        match = re.match(r'rtsp://([^:]+):([^@]+)@([^:/]+)(?::([\d]+))?(/.*)?', rtsp_url)
        if match:
            user, passwd, host, port, path = match.groups()
            port = port or '554'
            auth = f"{user}:{_q(_uq(passwd), safe='')}@{host}:{port}"
            # Add all common stream formats (Provision ISR standalone priority first)
            urls_to_try.extend([
                # Provision ISR standalone IP camera — primary paths first
                f"rtsp://{auth}/live/ch00_0",
                f"rtsp://{auth}/live/ch00_1",
                f"rtsp://{auth}/11",
                f"rtsp://{auth}/12",
                f"rtsp://{auth}/stream1",
                f"rtsp://{auth}/stream2",
                f"rtsp://{auth}/live/main",
                f"rtsp://{auth}/live/sub",
                f"rtsp://{auth}/media/video1",
                f"rtsp://{auth}/media/video2",
                f"rtsp://{auth}/profile1",
                f"rtsp://{auth}/profile2",
                f"rtsp://{auth}/video",
                f"rtsp://{auth}/videoinput_1/h264_1",
                f"rtsp://{auth}/videoMain",
                f"rtsp://{auth}/videoSub",
                # Provision/Dahua NVR fallback formats
                f"rtsp://{auth}/cam/realmonitor?channel=1&subtype=0",
                f"rtsp://{auth}/cam/realmonitor?channel=1&subtype=1",
                f"rtsp://{auth}/cam/realmonitor?channel=1&subtype=2",
                f"rtsp://{auth}/cam/realmonitor?channel=1&subtype=0&unicast=true&proto=Onvif",
                f"rtsp://{auth}/live",
                # Hikvision formats
                f"rtsp://{auth}/Streaming/Channels/101",
                f"rtsp://{auth}/Streaming/Channels/102",
                f"rtsp://{auth}/h264/ch1/main/av_stream",
                f"rtsp://{auth}/h264/ch1/sub/av_stream",
                # ONVIF standard
                f"rtsp://{auth}/onvif1",
                f"rtsp://{auth}/onvif2",
                # Generic
                f"rtsp://{auth}/",
            ])
        
        frame = None
        
        for url in urls_to_try:
            cap = try_connect(url)
            if not cap or not cap.isOpened():
                continue
            
            # Try to get a non-gray frame
            for attempt in range(30):
                ret, temp_frame = cap.read()
                if ret and temp_frame is not None:
                    if not is_gray_frame(temp_frame):
                        frame = temp_frame
                        cap.release()
                        break
                    # Keep last frame as fallback
                    frame = temp_frame
            else:
                cap.release()
            
            if frame is not None and not is_gray_frame(frame):
                break
        
        if frame is None:
            # Return placeholder
            frame = np.zeros((360, 640, 3), dtype=np.uint8)
            frame[:] = (30, 30, 30)
            cv2.putText(frame, 'Camera Offline', (200, 180), 
                       cv2.FONT_HERSHEY_SIMPLEX, 1, (100, 100, 100), 2)
            cv2.putText(frame, camera.name, (240, 220), 
                       cv2.FONT_HERSHEY_SIMPLEX, 0.7, (80, 80, 80), 1)
        else:
            frame = cv2.resize(frame, (640, 360))
        
        _, buffer = cv2.imencode('.jpg', frame, [cv2.IMWRITE_JPEG_QUALITY, 75])
        return Response(buffer.tobytes(), mimetype='image/jpeg')
        
    except Exception as e:
        logger.error(f"Video feed error: {e}")
        # Return error placeholder
        frame = np.zeros((360, 640, 3), dtype=np.uint8)
        frame[:] = (50, 0, 0)
        cv2.putText(frame, 'Error', (280, 180), cv2.FONT_HERSHEY_SIMPLEX, 1, (255, 255, 255), 2)
        _, buffer = cv2.imencode('.jpg', frame)
        return Response(buffer.tobytes(), mimetype='image/jpeg')


@app.route('/api/recent-detections')
def get_recent_detections():
    """Get recent detections for live view badges"""
    limit = request.args.get('limit', 10, type=int)
    seconds = request.args.get('seconds', 30, type=int)
    
    cutoff = datetime.utcnow() - timedelta(seconds=seconds)
    
    detections = DetectionEvent.query.filter(
        DetectionEvent.created_at >= cutoff
    ).order_by(DetectionEvent.created_at.desc()).limit(limit).all()
    
    return jsonify([{
        'id': d.id,
        'camera_id': d.camera_id,
        'detected_class': d.detected_class,
        'confidence': d.confidence,
        'created_at': d.created_at.isoformat()
    } for d in detections])


# =============================================================================
# PTZ CONTROL
# =============================================================================
@app.route('/api/camera/<int:camera_id>/ptz/move', methods=['POST'])
@login_required
def ptz_move(camera_id):
    """Move PTZ camera"""
    camera = Camera.query.get_or_404(camera_id)
    
    if not camera.has_ptz:
        return jsonify({'success': False, 'message': 'Camera does not support PTZ'}), 400
    
    data = request.get_json()
    direction = data.get('direction', 'stop')
    
    try:
        # ONVIF PTZ control
        from onvif import ONVIFCamera  # type: ignore
        
        # Parse ONVIF URL
        onvif_url = camera.ptz_onvif_url or camera.rtsp_url.replace('rtsp://', '').split('/')[0].split('@')[-1]
        host = onvif_url.split(':')[0]
        port = int(onvif_url.split(':')[1]) if ':' in onvif_url else 80
        
        cam = ONVIFCamera(host, port, camera.ptz_username or 'admin', camera.ptz_password or 'admin')
        ptz_service = cam.create_ptz_service()
        media_service = cam.create_media_service()
        
        profiles = media_service.GetProfiles()
        profile_token = profiles[0].token
        
        # Create PTZ request
        ptz_request = ptz_service.create_type('ContinuousMove')
        ptz_request.ProfileToken = profile_token
        
        velocity = {'PanTilt': {'x': 0, 'y': 0}, 'Zoom': {'x': 0}}
        
        speed = 0.5
        if 'up' in direction:
            velocity['PanTilt']['y'] = speed
        if 'down' in direction:
            velocity['PanTilt']['y'] = -speed
        if 'left' in direction:
            velocity['PanTilt']['x'] = -speed
        if 'right' in direction:
            velocity['PanTilt']['x'] = speed
        if direction == 'home':
            ptz_service.GotoHomePosition({'ProfileToken': profile_token})
            return jsonify({'success': True, 'message': 'Moving to home position'})
        
        ptz_request.Velocity = velocity
        ptz_service.ContinuousMove(ptz_request)
        
        # Stop after short movement
        time.sleep(0.3)
        ptz_service.Stop({'ProfileToken': profile_token})
        
        return jsonify({'success': True, 'message': f'PTZ moved: {direction}'})
        
    except ImportError:
        return jsonify({'success': False, 'message': 'ONVIF library not installed. Run: pip install onvif-zeep'}), 500
    except Exception as e:
        logger.error(f"PTZ move error: {e}")
        return jsonify({'success': False, 'message': str(e)}), 500


@app.route('/api/camera/<int:camera_id>/ptz/zoom', methods=['POST'])
@login_required
def ptz_zoom(camera_id):
    """Zoom PTZ camera"""
    camera = Camera.query.get_or_404(camera_id)
    
    if not camera.has_ptz:
        return jsonify({'success': False, 'message': 'Camera does not support PTZ'}), 400
    
    data = request.get_json()
    direction = data.get('direction', 'stop')  # 'in' or 'out'
    
    try:
        from onvif import ONVIFCamera  # type: ignore
        
        onvif_url = camera.ptz_onvif_url or camera.rtsp_url.replace('rtsp://', '').split('/')[0].split('@')[-1]
        host = onvif_url.split(':')[0]
        port = int(onvif_url.split(':')[1]) if ':' in onvif_url else 80
        
        cam = ONVIFCamera(host, port, camera.ptz_username or 'admin', camera.ptz_password or 'admin')
        ptz_service = cam.create_ptz_service()
        media_service = cam.create_media_service()
        
        profiles = media_service.GetProfiles()
        profile_token = profiles[0].token
        
        ptz_request = ptz_service.create_type('ContinuousMove')
        ptz_request.ProfileToken = profile_token
        
        zoom_speed = 0.5 if direction == 'in' else -0.5
        ptz_request.Velocity = {'Zoom': {'x': zoom_speed}}
        
        ptz_service.ContinuousMove(ptz_request)
        time.sleep(0.3)
        ptz_service.Stop({'ProfileToken': profile_token})
        
        return jsonify({'success': True, 'message': f'Zoomed {direction}'})
        
    except ImportError:
        return jsonify({'success': False, 'message': 'ONVIF library not installed'}), 500
    except Exception as e:
        logger.error(f"PTZ zoom error: {e}")
        return jsonify({'success': False, 'message': str(e)}), 500


# =============================================================================
# CAMERA HEALTH MONITORING
# =============================================================================
@app.route('/api/camera-health')
@login_required
def get_camera_health():
    """Get health status of all cameras"""
    from models import CameraHealth
    
    cameras = Camera.query.all()
    health_data = []
    
    for camera in cameras:
        health = CameraHealth.query.filter_by(camera_id=camera.id).first()
        
        if not health:
            # Create health record
            health = CameraHealth(camera_id=camera.id)
            db.session.add(health)
        
        # Quick check if camera is online
        try:
            cap = cv2.VideoCapture(camera.rtsp_url)
            cap.set(cv2.CAP_PROP_OPEN_TIMEOUT_MSEC, 3000)
            is_online = cap.isOpened()
            if is_online:
                ret, _ = cap.read()
                is_online = ret
            cap.release()
        except:
            is_online = False
        
        # Update health record
        health.last_check_time = datetime.utcnow()
        health.total_checks = (health.total_checks or 0) + 1
        
        if is_online:
            health.is_online = True
            health.last_frame_time = datetime.utcnow()
            health.consecutive_failures = 0
            health.offline_since = None
            health.offline_alert_sent = False
        else:
            health.failed_checks = (health.failed_checks or 0) + 1
            health.consecutive_failures = (health.consecutive_failures or 0) + 1
            if health.is_online:  # Just went offline
                health.offline_since = datetime.utcnow()
            health.is_online = False
        
        # Calculate uptime
        if health.total_checks > 0:
            health.uptime_percent = ((health.total_checks - (health.failed_checks or 0)) / health.total_checks) * 100
        
        health_data.append({
            'camera_id': camera.id,
            'camera_name': camera.name,
            'is_online': health.is_online,
            'uptime_percent': round(health.uptime_percent or 100, 1),
            'consecutive_failures': health.consecutive_failures or 0,
            'last_check': health.last_check_time.isoformat() if health.last_check_time else None,
            'offline_since': health.offline_since.isoformat() if health.offline_since else None
        })
    
    db.session.commit()
    
    return jsonify({
        'cameras': health_data,
        'total': len(cameras),
        'online': sum(1 for h in health_data if h['is_online']),
        'offline': sum(1 for h in health_data if not h['is_online'])
    })


# =============================================================================
# USER MANAGEMENT (Role-Based Access)
# =============================================================================
@app.route('/api/users', methods=['GET'])
@login_required
def get_users():
    """Get all users (admin only)"""
    from models import User
    
    # Check if admin (simplified - in production use proper session)
    users = User.query.all()
    return jsonify([u.to_dict() for u in users])


@app.route('/api/users', methods=['POST'])
@login_required
def create_user():
    """Create a new user (admin only)"""
    from models import User
    
    data = request.get_json()
    
    # Check if username exists
    if User.query.filter_by(username=data.get('username')).first():
        return jsonify({'success': False, 'message': 'Username already exists'}), 400
    
    user = User(
        username=data.get('username'),
        email=data.get('email')
    )
    user.set_password(data.get('password', 'changeme'))
    user.set_role(data.get('role', 'viewer'))
    
    db.session.add(user)
    db.session.commit()
    
    return jsonify({'success': True, 'user': user.to_dict()})


@app.route('/api/users/<int:user_id>', methods=['PUT'])
@login_required
def update_user(user_id):
    """Update a user"""
    from models import User
    
    user = User.query.get_or_404(user_id)
    data = request.get_json()
    
    if 'role' in data:
        user.set_role(data['role'])
    if 'email' in data:
        user.email = data['email']
    if 'password' in data and data['password']:
        user.set_password(data['password'])
    if 'is_active' in data:
        user.is_active = data['is_active']
    
    db.session.commit()
    
    return jsonify({'success': True, 'user': user.to_dict()})


@app.route('/api/users/<int:user_id>', methods=['DELETE'])
@login_required
def delete_user(user_id):
    """Delete a user"""
    from models import User
    
    user = User.query.get_or_404(user_id)
    db.session.delete(user)
    db.session.commit()
    
    return jsonify({'success': True, 'message': 'User deleted'})


# =============================================================================
# DASHBOARD WIDGETS & STATS
# =============================================================================
@app.route('/api/dashboard/widgets')
@login_required
def get_dashboard_widgets():
    """Get comprehensive dashboard widget data"""
    from models import BehaviorEvent, CameraHealth
    
    now = datetime.utcnow()
    today_start = now.replace(hour=0, minute=0, second=0, microsecond=0)
    
    # Detection stats
    detections_today = DetectionEvent.query.filter(DetectionEvent.created_at >= today_start).count()
    detections_hour = DetectionEvent.query.filter(DetectionEvent.created_at >= now - timedelta(hours=1)).count()
    
    # Detection by class
    class_stats = db.session.query(
        DetectionEvent.detected_class,
        db.func.count(DetectionEvent.id)
    ).filter(
        DetectionEvent.created_at >= today_start
    ).group_by(DetectionEvent.detected_class).all()
    
    # Camera stats
    total_cameras = Camera.query.count()
    active_cameras = Camera.query.filter_by(is_active=True).count()
    
    # System stats
    stats = get_system_stats()
    
    # Recent alerts
    recent_alerts = DetectionEvent.query.filter(
        DetectionEvent.telegram_sent == True
    ).order_by(DetectionEvent.created_at.desc()).limit(5).all()
    
    # Behavior events today
    behavior_counts = {}
    try:
        behavior_events = BehaviorEvent.query.filter(BehaviorEvent.created_at >= today_start).all()
        for event in behavior_events:
            behavior_counts[event.behavior_type] = behavior_counts.get(event.behavior_type, 0) + 1
    except:
        pass
    
    return jsonify({
        'detections': {
            'today': detections_today,
            'last_hour': detections_hour,
            'by_class': {cls: count for cls, count in class_stats}
        },
        'cameras': {
            'total': total_cameras,
            'active': active_cameras,
            'offline': total_cameras - active_cameras
        },
        'system': {
            'cpu_usage': stats.get('cpu_usage', 0),
            'memory_usage': stats.get('memory_usage', 0),
            'temperature': stats.get('temperature', 0),
            'disk_usage': stats.get('disk_usage', 0)
        },
        'recent_alerts': [{
            'id': a.id,
            'class': a.detected_class,
            'camera': a.camera.name if a.camera else 'Unknown',
            'time': a.created_at.isoformat(),
            'confidence': a.confidence
        } for a in recent_alerts],
        'behaviors': behavior_counts
    })


@app.route('/api/stats/hourly')
@login_required
def get_hourly_stats():
    """Get hourly detection stats for charts"""
    hours = request.args.get('hours', 24, type=int)
    
    now = datetime.utcnow()
    hourly_data = []
    
    for i in range(hours, 0, -1):
        hour_start = now - timedelta(hours=i)
        hour_end = now - timedelta(hours=i-1)
        
        count = DetectionEvent.query.filter(
            DetectionEvent.created_at >= hour_start,
            DetectionEvent.created_at < hour_end
        ).count()
        
        hourly_data.append({
            'hour': hour_start.strftime('%H:%M'),
            'count': count
        })
    
    return jsonify(hourly_data)


# Error handlers
@app.errorhandler(404)
def not_found(error):
    return jsonify({'error': 'Not found'}), 404


@app.errorhandler(500)
def internal_error(error):
    db.session.rollback()
    logger.error(f"Internal error: {error}")
    return jsonify({'error': 'Internal server error'}), 500


# Analytics & Monitoring Routes
@app.route('/analytics')
@login_required
@license_required('people_counting')
def analytics_dashboard():
    """People counting, occupancy, and analytics dashboard"""
    try:
        from models import OccupancyLog, DetectionZone
        from datetime import timedelta
        
        cameras = Camera.query.all()
        
        # Get current occupancy for each camera
        now = datetime.utcnow()
        hour_ago = now - timedelta(hours=1)
        
        # Compute today_start in the configured local timezone so "today" counts
        # reflect the site's local day, not UTC midnight.
        try:
            from zoneinfo import ZoneInfo
            config = SystemConfig.query.first()
            tz_name = (config.timezone if config and config.timezone else 'UTC') or 'UTC'
            local_tz = ZoneInfo(tz_name)
            local_now = now.replace(tzinfo=ZoneInfo('UTC')).astimezone(local_tz)
            today_start_local = local_now.replace(hour=0, minute=0, second=0, microsecond=0)
            # Convert local midnight back to UTC naive for DB comparison
            today_start = today_start_local.astimezone(ZoneInfo('UTC')).replace(tzinfo=None)
        except Exception:
            today_start = now.replace(hour=0, minute=0, second=0, microsecond=0)
        
        camera_stats = []
        for camera in cameras:
            # Get latest occupancy
            latest_log = OccupancyLog.query.filter_by(
                camera_id=camera.id,
                count_type='people'
            ).order_by(OccupancyLog.timestamp.desc()).first()
            
            current_count = latest_log.count if latest_log else 0

            # Also check entrance (counting line) logs for People Now
            if current_count == 0:
                entrance_log = OccupancyLog.query.filter_by(
                    camera_id=camera.id,
                    count_type='entrance'
                ).order_by(OccupancyLog.timestamp.desc()).first()
                if entrance_log:
                    current_count = entrance_log.count or 0

            # Fallback: use live in-memory count when no logged data yet
            if current_count == 0 and detection_engine:
                live_dets = getattr(detection_engine, 'camera_detections', {}).get(camera.id, [])
                current_count = len([d for d in live_dets if d.get('class') == 'person'])
            
            # Get today's entries/exits (uses today_start computed above in local tz)
            today_logs = OccupancyLog.query.filter(
                OccupancyLog.camera_id == camera.id,
                OccupancyLog.timestamp >= today_start
            ).all()
            
            total_entries = sum((log.entries or 0) for log in today_logs)
            total_exits = sum((log.exits or 0) for log in today_logs)

            # Compute peak hour from today's logs (hour with most entries, or most count)
            hourly_entries = {}
            for log in today_logs:
                h = log.timestamp.hour
                hourly_entries[h] = hourly_entries.get(h, 0) + (log.entries or log.count or 0)
            if hourly_entries:
                peak_h = max(hourly_entries, key=hourly_entries.get)
                peak_hour = f"{peak_h:02d}:00"
            else:
                peak_hour = None

            camera_stats.append({
                'camera': camera,
                'current_count': current_count,
                'total_entries': total_entries,
                'total_exits': total_exits,
                'peak_hour': peak_hour,
                'zones': DetectionZone.query.filter_by(camera_id=camera.id).all()
            })
        
        return render_template('analytics.html', camera_stats=camera_stats)
    except Exception as e:
        logger.error(f"Error loading analytics: {e}", exc_info=True)
        flash(f'Error loading analytics: {str(e)}', 'error')
        return redirect(url_for('index'))


@app.route('/zones')
@login_required
def zone_management():
    """Zone detection management page"""
    try:
        from models import DetectionZone
        from license_manager import is_feature_unlocked

        cameras = Camera.query.all()
        zones = DetectionZone.query.all()

        return render_template('zones.html', cameras=cameras, zones=zones,
                               line_crossing_licensed=is_feature_unlocked('zone_detection'),
                               people_counting_licensed=is_feature_unlocked('people_counting'))
    except Exception as e:
        logger.error(f"Error loading zones: {e}", exc_info=True)
        flash(f'Error loading zones: {str(e)}', 'error')
        return redirect(url_for('index'))


# API Routes for Analytics
@app.route('/api/zones', methods=['GET', 'POST'])
def api_zones():
    """Get or create detection zones with enhanced rectangular support"""
    from models import DetectionZone
    
    if request.method == 'POST':
        try:
            data = request.json
            
            # Create new zone (backward compatible)
            zone = DetectionZone(
                camera_id=data['camera_id'],
                name=data['name'],
                zone_type=data.get('zone_type', 'alert'),
                is_active=data.get('is_active', True),
                alert_on_entry=data.get('alert_on_entry', True),
                alert_on_exit=data.get('alert_on_exit', True),
                loiter_threshold_seconds=data.get('loiter_threshold_seconds') if data.get('loiter_threshold_seconds') is not None else 300,
                detect_person=data.get('detect_person', True),
                detect_vehicle=data.get('detect_vehicle', False),
                detect_animal=data.get('detect_animal', False),
                # New fields for advanced zone features
                max_capacity=data.get('max_capacity', 0),
                crowd_alert_threshold=data.get('crowd_alert_threshold', 80),
                schedule_enabled=data.get('schedule_enabled', False),
                active_start_time=data.get('active_start_time', '00:00'),
                active_end_time=data.get('active_end_time', '23:59'),
                active_days=data.get('active_days', '0,1,2,3,4,5,6'),
                preset_type=data.get('preset_type'),
                enable_path_tracking=data.get('enable_path_tracking', False),
                path_history_seconds=data.get('path_history_seconds', 30),
                line_direction=data.get('line_direction', 'both'),
                alert_cooldown_minutes=data.get('alert_cooldown_minutes', 5),
                min_confidence=data.get('min_confidence', 0.35)
            )
            
            # Handle line points for tripwire mode
            if data.get('line_points'):
                zone.set_line_points(data.get('line_points'))
            
            # Handle zone creation - rectangular or polygon (backward compatible)
            # Skip polygon setup for tripwire zones (they use line_points instead)
            is_tripwire = data.get('line_points') and len(data.get('line_points', [])) >= 2
            is_rectangular = data.get('is_rectangular', True)
            
            if is_tripwire:
                # Tripwire zones don't need polygon points - set empty/dummy
                zone.polygon_points = json.dumps([[0,0], [0,0], [0,0], [0,0]])
                logger.info(f"Created tripwire zone: {zone.name}")
            elif is_rectangular and 'dimensions' in data:
                # Create rectangular zone from dimensions
                dims = data['dimensions']
                # Create simple 4-corner rectangle
                x, y = dims.get('x', 0), dims.get('y', 0)
                w, h = dims.get('width', 100), dims.get('height', 100)
                
                rectangle_points = [
                    [x, y],           # Top-left
                    [x + w, y],       # Top-right
                    [x + w, y + h],   # Bottom-right
                    [x, y + h]        # Bottom-left
                ]
                
                zone.set_polygon_points(rectangle_points)
                logger.info(f"Created rectangular zone: {zone.name} at ({x}, {y}) size {w}x{h}")
            elif 'polygon_points' in data:
                # Use provided polygon points
                zone.set_polygon_points(data.get('polygon_points', []))
            else:
                # Default rectangular zone (200x150 at position 100,100)
                default_rectangle = [
                    [100, 100],    # Top-left
                    [300, 100],    # Top-right
                    [300, 250],    # Bottom-right
                    [100, 250]     # Bottom-left
                ]
                zone.set_polygon_points(default_rectangle)
                logger.info(f"Created default rectangular zone: {zone.name}")
            
            db.session.add(zone)
            db.session.commit()
            
            return jsonify({'success': True, 'zone': zone.to_dict()})
        except Exception as e:
            logger.error(f"Error creating zone: {e}")
            db.session.rollback()
            return jsonify({'success': False, 'error': str(e)}), 400
    
    # GET - return all zones
    camera_id = request.args.get('camera_id')
    
    query = DetectionZone.query
    if camera_id:
        query = query.filter_by(camera_id=int(camera_id))
    
    zones = query.all()
    return jsonify({'success': True, 'zones': [z.to_dict() for z in zones]})


# =========================================================================
# ZONE ANALYTICS API ENDPOINTS
# =========================================================================

@app.route('/api/zones/<int:zone_id>/analytics', methods=['GET'])
def api_zone_analytics(zone_id):
    """Get comprehensive analytics for a specific zone"""
    try:
        from models import DetectionZone, ZoneTransition, ZoneDailyStats, OccupancyLog
        from datetime import datetime, timedelta
        
        zone = DetectionZone.query.get(zone_id)
        if not zone:
            return jsonify({'success': False, 'error': 'Zone not found'}), 404
        
        # Get date range from query params (default: last 7 days)
        days = request.args.get('days', 7, type=int)
        end_date = datetime.utcnow()
        start_date = end_date - timedelta(days=days)
        
        # Get daily stats
        daily_stats = ZoneDailyStats.query.filter(
            ZoneDailyStats.zone_id == zone_id,
            ZoneDailyStats.date >= start_date.date()
        ).order_by(ZoneDailyStats.date.desc()).all()
        
        # Calculate totals
        total_entries = sum(s.total_entries or 0 for s in daily_stats)
        total_exits = sum(s.total_exits or 0 for s in daily_stats)
        avg_dwell_time = 0
        if daily_stats:
            dwell_times = [s.avg_dwell_time_seconds for s in daily_stats if s.avg_dwell_time_seconds]
            if dwell_times:
                avg_dwell_time = sum(dwell_times) / len(dwell_times)
        
        # Get current occupancy
        current_occupancy = zone.current_occupancy or 0
        
        # Aggregate hourly patterns
        hourly_entries = {}
        hourly_exits = {}
        for s in daily_stats:
            for hour, count in s.get_hourly_entries().items():
                hourly_entries[hour] = hourly_entries.get(hour, 0) + count
            for hour, count in s.get_hourly_exits().items():
                hourly_exits[hour] = hourly_exits.get(hour, 0) + count
        
        # Aggregate direction patterns
        entry_directions = {}
        exit_directions = {}
        for s in daily_stats:
            for dir, count in s.get_entry_directions().items():
                entry_directions[dir] = entry_directions.get(dir, 0) + count
            for dir, count in s.get_exit_directions().items():
                exit_directions[dir] = exit_directions.get(dir, 0) + count
        
        # Find peak hours
        peak_entry_hour = max(hourly_entries, key=hourly_entries.get) if hourly_entries else None
        peak_exit_hour = max(hourly_exits, key=hourly_exits.get) if hourly_exits else None
        
        return jsonify({
            'success': True,
            'zone': zone.to_dict(),
            'period_days': days,
            'analytics': {
                'total_entries': total_entries,
                'total_exits': total_exits,
                'net_flow': total_entries - total_exits,
                'current_occupancy': current_occupancy,
                'avg_dwell_time_seconds': round(avg_dwell_time, 1),
                'avg_dwell_time_formatted': f"{int(avg_dwell_time // 60)}m {int(avg_dwell_time % 60)}s",
                'peak_entry_hour': peak_entry_hour,
                'peak_exit_hour': peak_exit_hour,
                'hourly_entries': hourly_entries,
                'hourly_exits': hourly_exits,
                'entry_directions': entry_directions,
                'exit_directions': exit_directions
            },
            'daily_stats': [s.to_dict() for s in daily_stats]
        })
    except Exception as e:
        logger.error(f"Error getting zone analytics: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500


@app.route('/api/zones/<int:zone_id>/transitions', methods=['GET'])
def api_zone_transitions(zone_id):
    """Get recent zone transitions for a specific zone"""
    try:
        from models import ZoneTransition, DetectionZone
        from datetime import datetime, timedelta
        
        zone = DetectionZone.query.get(zone_id)
        if not zone:
            return jsonify({'success': False, 'error': 'Zone not found'}), 404
        
        # Get query params
        limit = request.args.get('limit', 100, type=int)
        hours = request.args.get('hours', 24, type=int)
        transition_type = request.args.get('type')  # 'entry' or 'exit'
        
        cutoff = datetime.utcnow() - timedelta(hours=hours)
        
        query = ZoneTransition.query.filter(
            ZoneTransition.zone_id == zone_id,
            ZoneTransition.timestamp >= cutoff
        )
        
        if transition_type:
            query = query.filter(ZoneTransition.transition_type == transition_type)
        
        transitions = query.order_by(ZoneTransition.timestamp.desc()).limit(limit).all()
        
        return jsonify({
            'success': True,
            'zone_id': zone_id,
            'zone_name': zone.name,
            'count': len(transitions),
            'transitions': [t.to_dict() for t in transitions]
        })
    except Exception as e:
        logger.error(f"Error getting zone transitions: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500


@app.route('/api/zones/<int:zone_id>/heatmap', methods=['GET'])
def api_zone_heatmap(zone_id):
    """Get heatmap data for a specific zone"""
    try:
        from models import ZoneHeatmapData, DetectionZone
        from datetime import datetime, timedelta
        
        zone = DetectionZone.query.get(zone_id)
        if not zone:
            return jsonify({'success': False, 'error': 'Zone not found'}), 404
        
        # Get query params
        days = request.args.get('days', 7, type=int)
        hour = request.args.get('hour', type=int)  # Optional: specific hour filter
        
        cutoff = (datetime.utcnow() - timedelta(days=days)).date()
        
        query = ZoneHeatmapData.query.filter(
            ZoneHeatmapData.zone_id == zone_id,
            ZoneHeatmapData.date >= cutoff
        )
        
        if hour is not None:
            query = query.filter(ZoneHeatmapData.hour_of_day == hour)
        
        heatmap_data = query.all()
        
        # Aggregate into grid
        grid = {}
        for h in heatmap_data:
            key = f"{h.grid_x},{h.grid_y}"
            if key not in grid:
                grid[key] = {'x': h.grid_x, 'y': h.grid_y, 'count': 0}
            grid[key]['count'] += h.activity_count
        
        # Convert to list and sort by count
        grid_list = sorted(grid.values(), key=lambda x: x['count'], reverse=True)
        
        # Calculate max for normalization
        max_count = max([g['count'] for g in grid_list]) if grid_list else 1
        
        # Normalize counts to 0-1 range
        for g in grid_list:
            g['intensity'] = g['count'] / max_count if max_count > 0 else 0
        
        return jsonify({
            'success': True,
            'zone_id': zone_id,
            'zone_name': zone.name,
            'period_days': days,
            'grid_size': 20,  # Matches heatmap_grid_size in detection_engine
            'max_count': max_count,
            'grid_data': grid_list
        })
    except Exception as e:
        logger.error(f"Error getting zone heatmap: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500


@app.route('/api/zones/summary', methods=['GET'])
def api_zones_summary():
    """Get summary analytics for all zones"""
    try:
        from models import DetectionZone, ZoneDailyStats
        from datetime import datetime, timedelta
        
        camera_id = request.args.get('camera_id', type=int)
        days = request.args.get('days', 1, type=int)
        
        # Get zones
        query = DetectionZone.query.filter_by(is_active=True)
        if camera_id:
            query = query.filter_by(camera_id=camera_id)
        zones = query.all()
        
        cutoff = (datetime.utcnow() - timedelta(days=days)).date()
        
        summaries = []
        for zone in zones:
            # Get daily stats
            stats = ZoneDailyStats.query.filter(
                ZoneDailyStats.zone_id == zone.id,
                ZoneDailyStats.date >= cutoff
            ).all()
            
            total_entries = sum(s.total_entries or 0 for s in stats)
            total_exits = sum(s.total_exits or 0 for s in stats)
            
            summaries.append({
                'zone_id': zone.id,
                'zone_name': zone.name,
                'zone_type': zone.zone_type,
                'camera_id': zone.camera_id,
                'current_occupancy': zone.current_occupancy or 0,
                'total_entries': total_entries,
                'total_exits': total_exits,
                'net_flow': total_entries - total_exits
            })
        
        # Sort by total traffic
        summaries.sort(key=lambda x: x['total_entries'] + x['total_exits'], reverse=True)
        
        return jsonify({
            'success': True,
            'period_days': days,
            'zones': summaries
        })
    except Exception as e:
        logger.error(f"Error getting zones summary: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500


@app.route('/api/analytics/occupancy', methods=['GET'])
@license_required('people_counting')
def api_occupancy_analytics():
    """Get real-time and historical occupancy data"""
    try:
        from models import OccupancyLog, DetectionZone
        from datetime import datetime, timedelta
        
        camera_id = request.args.get('camera_id', type=int)
        zone_id = request.args.get('zone_id', type=int)
        hours = request.args.get('hours', 24, type=int)
        
        cutoff = datetime.utcnow() - timedelta(hours=hours)
        
        query = OccupancyLog.query.filter(OccupancyLog.timestamp >= cutoff)
        
        if camera_id:
            query = query.filter(OccupancyLog.camera_id == camera_id)
        if zone_id:
            query = query.filter(OccupancyLog.zone_id == zone_id)
        
        logs = query.order_by(OccupancyLog.timestamp.desc()).limit(500).all()
        
        # Get current occupancy for all active zones
        zones = DetectionZone.query.filter_by(is_active=True).all()
        current_occupancy = {}
        for zone in zones:
            current_occupancy[zone.id] = {
                'zone_name': zone.name,
                'count': zone.current_occupancy or 0,
                'max_capacity': zone.max_capacity or 0
            }
        
        return jsonify({
            'success': True,
            'current_occupancy': current_occupancy,
            'history': [log.to_dict() for log in logs]
        })
    except Exception as e:
        logger.error(f"Error getting occupancy analytics: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500


@app.route('/webhook/telegram', methods=['POST'])
def telegram_webhook():
    """Handle Telegram webhook for bot commands"""
    try:
        data = request.get_json()
        
        # Check if it's a message
        if 'message' in data:
            message = data['message']
            chat_id = message['chat']['id']
            
            # Check if user is authorized
            config = SystemConfig.query.first()
            if config:
                authorized_chat_ids = [int(cid.strip()) for cid in str(config.telegram_chat_id).split(',') if cid.strip()]
                if chat_id not in authorized_chat_ids:
                    return jsonify({'ok': False, 'error': 'Unauthorized'}), 403
                
                # Check if it's a text message with command
                if 'text' in message:
                    text = message['text'].strip()
                    if text.startswith('/'):
                        # Process command
                        response = telegram_service.handle_telegram_command(text, chat_id)
                        return jsonify({'ok': True})
        
        return jsonify({'ok': True})
    except Exception as e:
        logger.error(f"Telegram webhook error: {e}")
        return jsonify({'ok': False, 'error': str(e)}), 500

@app.route('/schedule')
def schedule_settings():
    """Schedule configuration page"""
    try:
        config = SystemConfig.query.first()
        if not config:
            flash('System not configured yet', 'error')
            return redirect(url_for('setup'))
        
        return render_template('schedule.html', config=config)
    except Exception as e:
        logger.error(f"Error loading schedule page: {e}")
        flash(f'Error loading schedule settings: {str(e)}', 'error')
        return redirect(url_for('index'))

@app.route('/api/schedule', methods=['GET', 'POST'])
def api_schedule():
    """Get or update schedule configuration"""
    try:
        config = SystemConfig.query.first()
        if not config:
            return jsonify({'success': False, 'error': 'No configuration found'}), 404
        
        if request.method == 'POST':
            data = request.json
            
            # Update schedule settings
            config.enable_auto_schedule = data.get('enable_auto_schedule', False)
            config.arm_time = data.get('arm_time')
            config.disarm_time = data.get('disarm_time')
            config.timezone = data.get('timezone', 'UTC')
            
            if 'schedule_days' in data:
                config.set_schedule_days(data['schedule_days'])
            
            db.session.commit()
            
            # Restart scheduler with new settings
            try:
                from scheduler_service import get_scheduler_service
                scheduler = get_scheduler_service()
                if scheduler:
                    scheduler.update_schedule(config)
                    
                # Send confirmation
                telegram_service.send_message(
                    f"⏰ Schedule updated: Arm at {config.arm_time}, Disarm at {config.disarm_time}"
                )
            except Exception as e:
                logger.error(f"Error updating scheduler: {e}")
            
            return jsonify({'success': True, 'config': config.to_dict()})
        
        # GET request - return current config
        return jsonify({
            'success': True,
            'config': {
                'enable_auto_schedule': config.enable_auto_schedule,
                'arm_time': config.arm_time,
                'disarm_time': config.disarm_time,
                'timezone': config.timezone,
                'schedule_days': config.get_schedule_days_list(),
                'schedule_info': config.get_schedule_info()
            }
        })
    except Exception as e:
        logger.error(f"Schedule API error: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500

@app.route('/api/schedule/test', methods=['POST'])
def api_schedule_test():
    """Test schedule actions (arm/disarm)"""
    try:
        data = request.json
        action = data.get('action')
        
        if action not in ['arm', 'disarm']:
            return jsonify({'success': False, 'error': 'Invalid action'}), 400
        
        config = SystemConfig.query.first()
        if not config:
            return jsonify({'success': False, 'error': 'No configuration found'}), 404
        
        # Perform the action
        if action == 'arm':
            config.is_armed = True
            Camera.query.update({Camera.is_armed: True})
            message = "🛡️ Test ARM command executed - all cameras armed"
        else:
            config.is_armed = False
            Camera.query.update({Camera.is_armed: False})
            message = "🔓 Test DISARM command executed - all cameras disarmed"
        
        db.session.commit()
        
        # Send telegram notification
        telegram_service.send_message(message)
        
        return jsonify({'success': True, 'message': message})
    except Exception as e:
        logger.error(f"Schedule test error: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500

@app.route('/api/zones/<int:zone_id>', methods=['GET', 'PUT', 'DELETE'])
def api_zone_detail(zone_id):
    
    zone = DetectionZone.query.get_or_404(zone_id)
    
    if request.method == 'DELETE':
        try:
            # Import related models
            from models import ZoneTransition, ZoneHeatmapData, ZoneDailyStats, OccupancyLog, LoiteringEvent
            
            # Delete all related records first to prevent foreign key constraint errors
            ZoneTransition.query.filter(ZoneTransition.zone_id == zone_id).delete()
            ZoneHeatmapData.query.filter(ZoneHeatmapData.zone_id == zone_id).delete()
            ZoneDailyStats.query.filter(ZoneDailyStats.zone_id == zone_id).delete()
            OccupancyLog.query.filter(OccupancyLog.zone_id == zone_id).delete()
            LoiteringEvent.query.filter(LoiteringEvent.zone_id == zone_id).delete()
            
            # Now delete the zone itself
            db.session.delete(zone)
            db.session.commit()
            
            logger.info(f"Zone {zone_id} '{zone.name}' deleted successfully with all related data")
            return jsonify({'success': True, 'message': f"Zone '{zone.name}' deleted successfully"})
        except Exception as e:
            db.session.rollback()
            logger.error(f"Error deleting zone {zone_id}: {e}")
            return jsonify({'success': False, 'error': str(e)}), 500
    
    if request.method == 'PUT':
        data = request.json
        zone.name = data.get('name', zone.name)
        zone.zone_type = data.get('zone_type', zone.zone_type)
        zone.is_active = data.get('is_active', zone.is_active)
        zone.alert_on_entry = data.get('alert_on_entry', zone.alert_on_entry)
        zone.alert_on_exit = data.get('alert_on_exit', zone.alert_on_exit)
        zone.loiter_threshold_seconds = data.get('loiter_threshold_seconds') if data.get('loiter_threshold_seconds') is not None else zone.loiter_threshold_seconds
        zone.detect_person = data.get('detect_person', zone.detect_person)
        zone.detect_vehicle = data.get('detect_vehicle', zone.detect_vehicle)
        zone.detect_animal = data.get('detect_animal', zone.detect_animal)
        
        # Handle new advanced zone fields
        if 'max_capacity' in data:
            zone.max_capacity = data.get('max_capacity', 0)
        if 'crowd_alert_threshold' in data:
            zone.crowd_alert_threshold = data.get('crowd_alert_threshold', 80)
        if 'schedule_enabled' in data:
            zone.schedule_enabled = data.get('schedule_enabled', False)
        if 'active_start_time' in data:
            zone.active_start_time = data.get('active_start_time', '00:00')
        if 'active_end_time' in data:
            zone.active_end_time = data.get('active_end_time', '23:59')
        if 'active_days' in data:
            zone.active_days = data.get('active_days', '0,1,2,3,4,5,6')
        if 'preset_type' in data:
            zone.preset_type = data.get('preset_type')
        if 'enable_path_tracking' in data:
            zone.enable_path_tracking = data.get('enable_path_tracking', False)
        if 'path_history_seconds' in data:
            zone.path_history_seconds = data.get('path_history_seconds', 30)
        if 'line_direction' in data:
            zone.line_direction = data.get('line_direction', 'both')
        if 'line_points' in data:
            zone.set_line_points(data.get('line_points'))
        if 'alert_cooldown_minutes' in data:
            zone.alert_cooldown_minutes = data.get('alert_cooldown_minutes', 5)
        if 'min_confidence' in data:
            zone.min_confidence = data.get('min_confidence', 0.35)
        
        # Handle polygon/rectangle updates (backward compatible)
        if 'dimensions' in data:
            # Create rectangular polygon from dimensions
            dims = data['dimensions']
            x, y = dims.get('x', 0), dims.get('y', 0)
            w, h = dims.get('width', 100), dims.get('height', 100)
            
            rectangle_points = [
                [x, y],           # Top-left
                [x + w, y],       # Top-right
                [x + w, y + h],   # Bottom-right
                [x, y + h]        # Bottom-left
            ]
            
            zone.set_polygon_points(rectangle_points)
            logger.info(f"Updated zone '{zone.name}' to rectangular: {dims}")
        elif 'polygon_points' in data:
            zone.set_polygon_points(data['polygon_points'])
            logger.info(f"Updated zone '{zone.name}' polygon points")
        
        db.session.commit()
        logger.info(f"Zone '{zone.name}' updated successfully")
        return jsonify({'success': True, 'zone': zone.to_dict()})
    
    return jsonify({'success': True, 'zone': zone.to_dict()})


@app.route('/api/cameras/<int:camera_id>/tracking', methods=['GET'])
def api_camera_tracking(camera_id):
    """Return live movement trail data for all currently tracked objects on a camera.
    Coordinates are in 800x600 canvas space (matching zone polygon coordinate system).
    Only returns data when at least one active zone on this camera has path tracking enabled.
    """
    try:
        from models import DetectionZone
        has_tracking = DetectionZone.query.filter_by(
            camera_id=camera_id, is_active=True, enable_path_tracking=True
        ).first() is not None

        trails = {}
        if detection_engine and has_tracking:
            raw = detection_engine.get_track_trails(camera_id)
            # Convert integer track_id keys to strings for JSON serialisation
            trails = {str(k): v for k, v in raw.items()}

        return jsonify({
            'success': True,
            'camera_id': camera_id,
            'trails': trails,
            'canvas_width': 800,
            'canvas_height': 600
        })
    except Exception as e:
        logger.error(f"Error getting camera tracking data: {e}")
        return jsonify({'success': False, 'error': str(e), 'trails': {}}), 200


@app.route('/api/zones/<int:zone_id>/test', methods=['POST'])
def test_zone(zone_id):
    """Test if a point is inside a zone"""
    try:
        zone = DetectionZone.query.get_or_404(zone_id)
        data = request.json
        
        test_x = data.get('x', 0)
        test_y = data.get('y', 0)
        
        # Test the point using simplified polygon detection
        polygon_points = zone.get_polygon_points()
        
        if not polygon_points or len(polygon_points) < 4:
            return jsonify({
                'success': False,
                'error': 'Invalid polygon points',
                'polygon': polygon_points
            })
        
        # Simple point-in-polygon test
        def point_in_polygon_simple(point, polygon):
            x, y = point
            n = len(polygon)
            inside = False
            
            p1x, p1y = polygon[0]
            for i in range(1, n + 1):
                p2x, p2y = polygon[i % n]
                if y > min(p1y, p2y):
                    if y <= max(p1y, p2y):
                        if x <= max(p1x, p2x):
                            if p1y != p2y:
                                xinters = (y - p1y) * (p2x - p1x) / (p2y - p1y) + p1x
                            if p1x == p2x or x <= xinters:
                                inside = not inside
                p1x, p1y = p2x, p2y
            return inside
        
        is_inside = point_in_polygon_simple([test_x, test_y], polygon_points)
        
        return jsonify({
            'success': True,
            'point': [test_x, test_y],
            'inside_zone': is_inside,
            'zone_name': zone.name,
            'polygon_points': polygon_points,
            'zone_settings': {
                'detect_person': zone.detect_person,
                'detect_vehicle': zone.detect_vehicle,
                'detect_animal': zone.detect_animal,
                'is_active': zone.is_active
            }
        })
        
    except Exception as e:
        logger.error(f"Zone test error: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500


@app.route('/api/cameras/<int:camera_id>/zones/validate', methods=['GET'])
def validate_camera_zones(camera_id):
    """Validate all zones for a camera"""
    try:
        camera = Camera.query.get_or_404(camera_id)
        zones = DetectionZone.query.filter_by(camera_id=camera_id).all()
        
        # Get detection engine for validation
        from detection_engine import DetectionEngine
        detection_engine = DetectionEngine()
        
        zone_results = []
        for zone in zones:
            polygon_points = zone.get_polygon_points()
            validated_polygon = detection_engine.validate_polygon_points(polygon_points)
            
            result = {
                'zone_id': zone.id,
                'zone_name': zone.name,
                'is_active': zone.is_active,
                'raw_polygon': polygon_points,
                'validated_polygon': validated_polygon,
                'is_valid': len(validated_polygon) >= 3,
                'point_count': len(validated_polygon),
                'detection_settings': {
                    'detect_person': zone.detect_person,
                    'detect_vehicle': zone.detect_vehicle,
                    'detect_animal': zone.detect_animal
                }
            }
            
            # Calculate polygon area if valid
            if result['is_valid']:
                try:
                    # Simple area calculation using shoelace formula
                    points = validated_polygon
                    n = len(points)
                    area = 0
                    for i in range(n):
                        j = (i + 1) % n
                        area += points[i][0] * points[j][1]
                        area -= points[j][0] * points[i][1]
                    result['area'] = abs(area) / 2
                except:
                    result['area'] = 0
            else:
                result['area'] = 0
                
            zone_results.append(result)
        
        return jsonify({
            'success': True,
            'camera_id': camera_id,
            'camera_name': camera.name,
            'total_zones': len(zones),
            'valid_zones': sum(1 for r in zone_results if r['is_valid']),
            'zones': zone_results
        })
        
    except Exception as e:
        logger.error(f"Zone validation error: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500


@app.route('/api/occupancy/current')
@license_required('people_counting')
def api_current_occupancy():
    """Get current occupancy for all cameras"""
    from models import OccupancyLog
    from datetime import timedelta
    
    camera_id = request.args.get('camera_id')
    count_type = request.args.get('type', 'people')
    
    query = OccupancyLog.query.filter_by(count_type=count_type)
    if camera_id:
        query = query.filter_by(camera_id=int(camera_id))
    
    # Get latest log for each camera
    latest_logs = query.order_by(OccupancyLog.timestamp.desc()).limit(50).all()
    # Deduplicate: keep only the most-recent log per camera (logs are desc → first = newest)
    seen_cams = set()
    deduped = []
    for log in latest_logs:
        if log.camera_id not in seen_cams:
            seen_cams.add(log.camera_id)
            deduped.append(log)
    logs_data = [log.to_dict() for log in deduped]
    
    # If no recent DB data, synthesise live counts from in-memory detections
    recent_cutoff = datetime.utcnow() - timedelta(minutes=5)
    if detection_engine and count_type == 'people':
        def _parse_ts(ts_str):
            """Parse isoformat timestamp string to UTC datetime, returns None on failure."""
            try:
                return datetime.fromisoformat(ts_str)
            except (ValueError, TypeError):
                return None
        cameras_with_recent = {log['camera_id'] for log in logs_data
                               if _parse_ts(log.get('timestamp', '')) is not None
                               and _parse_ts(log['timestamp']) >= recent_cutoff}
        camera_detections = getattr(detection_engine, 'camera_detections', {})
        for cam_id, dets in camera_detections.items():
            if camera_id and int(camera_id) != cam_id:
                continue
            if cam_id not in cameras_with_recent:
                live_count = len([d for d in dets if d.get('class') == 'person'])
                logs_data.append({
                    'camera_id': cam_id,
                    'count': live_count,
                    'count_type': 'people',
                    'entries': 0,
                    'exits': 0,
                    'zone_id': None,
                    'timestamp': datetime.utcnow().isoformat(),
                })
    
    return jsonify({
        'success': True,
        'logs': logs_data
    })


@app.route('/api/occupancy/history')
@license_required('people_counting')
def api_occupancy_history():
    """Get occupancy history for charts"""
    from models import OccupancyLog
    from datetime import timedelta
    
    camera_id = request.args.get('camera_id')
    hours = int(request.args.get('hours', 24))
    count_type = request.args.get('type', 'people')
    limit = min(int(request.args.get('limit', 1000)), 5000)
    
    start_time = datetime.utcnow() - timedelta(hours=hours)
    
    query = OccupancyLog.query.filter(
        OccupancyLog.timestamp >= start_time,
        OccupancyLog.count_type == count_type
    )
    
    if camera_id:
        query = query.filter_by(camera_id=int(camera_id))
    
    logs = query.order_by(OccupancyLog.timestamp).limit(limit).all()
    
    return jsonify({
        'success': True,
        'logs': [log.to_dict() for log in logs]
    })


@app.route('/api/loitering')
def api_loitering_events():
    """Get loitering events"""
    from models import LoiteringEvent
    from datetime import timedelta
    
    camera_id = request.args.get('camera_id')
    days = int(request.args.get('days', 7))
    
    start_time = datetime.utcnow() - timedelta(days=days)
    
    query = LoiteringEvent.query.filter(LoiteringEvent.first_seen >= start_time)
    
    if camera_id:
        query = query.filter_by(camera_id=int(camera_id))
    
    events = query.order_by(LoiteringEvent.first_seen.desc()).all()
    
    return jsonify({
        'success': True,
        'events': [e.to_dict() for e in events]
    })


if __name__ == '__main__':
    # Update telegram service on startup
    with app.app_context():
        update_telegram_service()
        
        # Force register telegram commands
        try:
            telegram_service.setup_bot_commands()
            logger.info("✅ Telegram bot commands force-registered on startup")
        except Exception as e:
            logger.error(f"Failed to force-register telegram commands: {e}")
    
    # Run the app
    app.run(host='0.0.0.0', port=5000, debug=os.environ.get('DEBUG', 'False') == 'True')

