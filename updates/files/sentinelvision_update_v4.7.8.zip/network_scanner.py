"""
Network Scanner - Find IP cameras and NVRs/DVRs on the local network
"""
import socket
import subprocess
import re
import logging
from concurrent.futures import ThreadPoolExecutor, as_completed
import requests
from requests.auth import HTTPDigestAuth, HTTPBasicAuth
import xml.etree.ElementTree as ET

logger = logging.getLogger(__name__)


class NetworkScanner:
    """Scan network for IP cameras, NVRs, and DVRs"""
    
    # Common camera/NVR ports
    COMMON_PORTS = [80, 8000, 554, 8080, 37777, 34567]
    
    # ONVIF ports
    ONVIF_PORTS = [80, 8080, 8081, 8899]
    
    # Common default credentials
    COMMON_CREDENTIALS = [
        ('admin', 'admin'),
        ('admin', '12345'),
        ('admin', ''),
        ('admin', 'admin123'),
        ('root', 'root'),
        ('root', ''),
        ('admin', 'password'),
        ('admin', '123456'),
        ('', ''),
    ]
    
    def __init__(self):
        self.local_ip = self.get_local_ip()
        self.network_prefix = '.'.join(self.local_ip.split('.')[:-1])
    
    def get_local_ip(self):
        """Get the local IP address"""
        try:
            s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            s.connect(("8.8.8.8", 80))
            ip = s.getsockname()[0]
            s.close()
            return ip
        except:
            return "192.168.1.1"
    
    def check_port(self, ip, port, timeout=1):
        """Check if a port is open"""
        try:
            sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            sock.settimeout(timeout)
            result = sock.connect_ex((ip, port))
            sock.close()
            return result == 0
        except:
            return False
    
    def probe_http(self, ip, port):
        """Try to get device information via HTTP"""
        try:
            url = f"http://{ip}:{port}"
            
            # Try without authentication
            response = requests.get(url, timeout=2, verify=False)
            if response.status_code == 200:
                return {
                    'type': 'camera',
                    'url': url,
                    'name': f'Camera/NVR at {ip}:{port}',
                    'auth_required': False
                }
            
            # Try with common credentials
            for username, password in self.COMMON_CREDENTIALS:
                try:
                    # Try Basic Auth
                    response = requests.get(
                        url,
                        auth=HTTPBasicAuth(username, password),
                        timeout=2,
                        verify=False
                    )
                    if response.status_code == 200:
                        return {
                            'type': 'camera',
                            'url': url,
                            'name': f'Camera/NVR at {ip}:{port}',
                            'auth_required': True,
                            'username': username,
                            'password': password
                        }
                    
                    # Try Digest Auth
                    response = requests.get(
                        url,
                        auth=HTTPDigestAuth(username, password),
                        timeout=2,
                        verify=False
                    )
                    if response.status_code == 200:
                        return {
                            'type': 'camera',
                            'url': url,
                            'name': f'Camera/NVR at {ip}:{port}',
                            'auth_required': True,
                            'username': username,
                            'password': password,
                            'auth_type': 'digest'
                        }
                except:
                    continue
        except:
            pass
        
        return None
    
    def probe_rtsp(self, ip):
        """Check for RTSP service (port 554)"""
        if self.check_port(ip, 554, timeout=1):
            # Try to get RTSP stream info
            for username, password in self.COMMON_CREDENTIALS:
                rtsp_url = f"rtsp://{username}:{password}@{ip}:554/stream1"
                return {
                    'type': 'rtsp',
                    'url': rtsp_url,
                    'name': f'RTSP Camera at {ip}',
                    'username': username,
                    'password': password
                }
        return None
    
    def detect_nvr_channels(self, ip, port, username='admin', password='admin'):
        """Try to detect NVR/DVR channels"""
        channels = []
        
        try:
            # Hikvision API
            url = f"http://{ip}:{port}/ISAPI/Streaming/channels"
            response = requests.get(
                url,
                auth=HTTPDigestAuth(username, password),
                timeout=3,
                verify=False
            )
            
            if response.status_code == 200:
                # Parse XML response
                try:
                    root = ET.fromstring(response.content)
                    for channel in root.findall('.//StreamingChannel'):
                        channel_id = channel.find('id').text if channel.find('id') is not None else None
                        channel_name = channel.find('channelName').text if channel.find('channelName') is not None else f"Channel {channel_id}"
                        
                        if channel_id:
                            rtsp_url = f"rtsp://{username}:{password}@{ip}:554/Streaming/Channels/{channel_id}"
                            channels.append({
                                'id': channel_id,
                                'name': channel_name,
                                'rtsp_url': rtsp_url
                            })
                except:
                    pass
        except:
            pass
        
        # Try Dahua API
        try:
            url = f"http://{ip}:{port}/cgi-bin/magicBox.cgi?action=getProductDefinition"
            response = requests.get(
                url,
                auth=HTTPDigestAuth(username, password),
                timeout=3,
                verify=False
            )
            
            if response.status_code == 200:
                # Dahua returns channel count
                content = response.text
                match = re.search(r'MaxExtraStream=(\d+)', content)
                if match:
                    num_channels = int(match.group(1))
                    for i in range(1, num_channels + 1):
                        rtsp_url = f"rtsp://{username}:{password}@{ip}:554/cam/realmonitor?channel={i}&subtype=0"
                        channels.append({
                            'id': str(i),
                            'name': f"Channel {i}",
                            'rtsp_url': rtsp_url
                        })
        except:
            pass
        
        # Generic NVR - try common channel patterns for Provision/Hikvision/Dahua
        if not channels:
            for i in range(1, 17):  # Try up to 16 channels
                # Add multiple RTSP URL formats for each channel
                channel_urls = [
                    # Hikvision format (most common)
                    f"rtsp://{username}:{password}@{ip}:554/Streaming/Channels/{i}01",
                    # Hikvision alternate
                    f"rtsp://{username}:{password}@{ip}:554/ISAPI/Streaming/Channels/{i}01",
                    # Provision/Dahua format
                    f"rtsp://{username}:{password}@{ip}:554/cam/realmonitor?channel={i}&subtype=0",
                    # Generic format
                    f"rtsp://{username}:{password}@{ip}:554/ch{i:02d}/0",
                    # Alternative format
                    f"rtsp://{username}:{password}@{ip}:554/live/ch{i:02d}_0",
                ]
                channels.append({
                    'id': str(i),
                    'name': f"Channel {i}",
                    'rtsp_url': channel_urls[0],  # Primary URL (Hikvision)
                    'alternate_urls': channel_urls[1:]  # Backup URLs to try
                })
        
        return channels
    
    def scan_ip(self, ip):
        """Scan a single IP for cameras/NVRs"""
        devices = []
        
        # Check RTSP first (most common for cameras)
        rtsp_device = self.probe_rtsp(ip)
        if rtsp_device:
            devices.append(rtsp_device)
        
        # Check HTTP ports
        for port in [80, 8000, 8080]:
            if self.check_port(ip, port, timeout=1):
                http_device = self.probe_http(ip, port)
                if http_device:
                    # Check if it's an NVR/DVR
                    channels = self.detect_nvr_channels(
                        ip, port,
                        http_device.get('username', 'admin'),
                        http_device.get('password', 'admin')
                    )
                    
                    if channels:
                        http_device['is_nvr'] = True
                        http_device['channels'] = channels
                        http_device['type'] = 'nvr'
                        http_device['name'] = f'NVR/DVR at {ip}:{port}'
                    
                    devices.append(http_device)
                    break  # Found device on this port, no need to check others
        
        return devices if devices else None
    
    def scan_network(self, ip_range=None, max_workers=50):
        """Scan entire network for cameras and NVRs"""
        if ip_range is None:
            # Scan local subnet
            ip_range = [f"{self.network_prefix}.{i}" for i in range(1, 255)]
        
        logger.info(f"Scanning network {self.network_prefix}.0/24 for cameras and NVRs...")
        found_devices = []
        
        with ThreadPoolExecutor(max_workers=max_workers) as executor:
            future_to_ip = {executor.submit(self.scan_ip, ip): ip for ip in ip_range}
            
            for future in as_completed(future_to_ip):
                ip = future_to_ip[future]
                try:
                    devices = future.result()
                    if devices:
                        for device in devices:
                            device['ip'] = ip
                            found_devices.append(device)
                            logger.info(f"Found device: {device['name']} at {ip}")
                except Exception as e:
                    logger.debug(f"Error scanning {ip}: {e}")
        
        logger.info(f"Scan complete. Found {len(found_devices)} device(s)")
        return found_devices


def scan_network_for_cameras():
    """Convenience function to scan network"""
    scanner = NetworkScanner()
    return scanner.scan_network()


def get_nvr_channels(ip, port=80, username='admin', password='admin'):
    """Get channels from an NVR/DVR"""
    scanner = NetworkScanner()
    return scanner.detect_nvr_channels(ip, port, username, password)


if __name__ == '__main__':
    # Test scanner
    logging.basicConfig(level=logging.INFO)
    devices = scan_network_for_cameras()
    
    print("\n" + "="*50)
    print("FOUND DEVICES:")
    print("="*50)
    
    for device in devices:
        print(f"\n{device['name']}")
        print(f"  IP: {device['ip']}")
        print(f"  Type: {device['type']}")
        print(f"  URL: {device['url']}")
        
        if device.get('is_nvr'):
            print(f"  Channels: {len(device.get('channels', []))}")
            for channel in device.get('channels', [])[:3]:
                print(f"    - {channel['name']}: {channel['rtsp_url']}")
