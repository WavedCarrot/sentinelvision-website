#!/bin/bash
# =============================================================================
# SentinelVision — Deploy to Raspberry Pi
# =============================================================================
# Run this from your Windows/Mac/Linux machine (NOT on the Pi itself).
#
# What it does:
#   1. Copies ONLY the update ZIP to the Pi (not the whole dev folder)
#   2. SSHs into the Pi and runs the fresh install (first time) OR update
#
# Usage:
#   chmod +x deploy_to_pi.sh
#   ./deploy_to_pi.sh 192.168.1.50            # default user 'pi'
#   ./deploy_to_pi.sh 192.168.1.50 myuser     # custom user
#   ./deploy_to_pi.sh 192.168.1.50 myuser 22  # custom user + port
# =============================================================================

PI_IP="${1}"
PI_USER="${2:-pi}"
PI_PORT="${3:-22}"
ZIP="sentinelvision_update_v4.1.1.zip"
REMOTE_DIR="/opt/sentinelvision"

if [ -z "$PI_IP" ]; then
    echo "Usage: ./deploy_to_pi.sh <pi-ip> [user] [port]"
    echo "Example: ./deploy_to_pi.sh 192.168.1.50"
    exit 1
fi

if [ ! -f "$ZIP" ]; then
    echo "ERROR: $ZIP not found. Build the package first (python make_package.py)."
    exit 1
fi

echo "============================================="
echo " SentinelVision Deployer"
echo "============================================="
echo " Pi:   $PI_USER@$PI_IP:$PI_PORT"
echo " ZIP:  $ZIP"
echo " Dest: $REMOTE_DIR"
echo "============================================="
echo ""

# ── Step 1: copy ZIP to Pi ──────────────────────────────────────────────────
echo ">>> Copying $ZIP to Pi..."
scp -P "$PI_PORT" "$ZIP" "$PI_USER@$PI_IP:/tmp/$ZIP"

if [ $? -ne 0 ]; then
    echo "ERROR: scp failed. Check Pi IP, SSH user, and that SSH is enabled on the Pi."
    exit 1
fi

# ── Step 2: SSH in and install / update ────────────────────────────────────
echo ""
echo ">>> Installing on Pi..."
ssh -p "$PI_PORT" "$PI_USER@$PI_IP" bash << REMOTE_SCRIPT

set -e

REMOTE_DIR="$REMOTE_DIR"
ZIP_PATH="/tmp/$ZIP"

# ── First install: directory doesn't exist yet ────────────────────────────
if [ ! -d "\$REMOTE_DIR" ]; then
    echo "[*] First install — creating \$REMOTE_DIR"
    sudo mkdir -p "\$REMOTE_DIR"
    sudo chown \$USER:\$USER "\$REMOTE_DIR"

    # Extract ZIP
    cd "\$REMOTE_DIR"
    python3 -c "import zipfile; zipfile.ZipFile('\$ZIP_PATH').extractall('.')"

    # Create required folders
    mkdir -p uploads/clips instance models

    # Python virtual environment
    echo "[*] Creating virtual environment..."
    python3 -m venv venv
    source venv/bin/activate
    pip install --upgrade pip
    echo "[*] Installing Python dependencies (may take 15-30 min first time)..."
    pip install -r requirements.txt

    # Download YOLO model
    if [ ! -f "yolov8n.pt" ]; then
        echo "[*] Downloading YOLOv8n model..."
        python -c "from ultralytics import YOLO; YOLO('yolov8n.pt')"
    fi

    # Lock down folder permissions
    echo "[*] Locking folder permissions..."
    sudo chown -R \$USER:\$USER "\$REMOTE_DIR"
    chmod 700 "\$REMOTE_DIR"
    find "\$REMOTE_DIR" -type f -name "*.py" -exec chmod 600 {} \;
    find "\$REMOTE_DIR" -type f -name "*.json" -exec chmod 600 {} \;
    find "\$REMOTE_DIR" -name "run.py" -exec chmod 700 {} \;
    find "\$REMOTE_DIR" -name "*.sh" -exec chmod 700 {} \;
    chmod 700 "\$REMOTE_DIR/venv/bin/python" 2>/dev/null || true

    # Install systemd service
    echo "[*] Installing systemd service..."
    sudo tee /etc/systemd/system/sentinelvision.service > /dev/null <<SVC
[Unit]
Description=SentinelVision Security Platform
After=network.target network-online.target
Wants=network-online.target

[Service]
Type=simple
User=\$USER
WorkingDirectory=\$REMOTE_DIR
Environment="PATH=\$REMOTE_DIR/venv/bin:/usr/bin:/bin"
ExecStart=\$REMOTE_DIR/venv/bin/python run.py
Restart=always
RestartSec=10
StartLimitIntervalSec=60
StartLimitBurst=3
ProtectSystem=strict
ReadWritePaths=\$REMOTE_DIR /tmp
NoNewPrivileges=true

[Install]
WantedBy=multi-user.target
SVC

    sudo systemctl daemon-reload
    sudo systemctl enable sentinelvision.service

    # Passwordless sudo for service restart / reboot
    echo "\$USER ALL=(ALL) NOPASSWD: /sbin/reboot, /sbin/shutdown, /bin/systemctl restart sentinelvision" \
        | sudo tee /etc/sudoers.d/sentinelvision > /dev/null
    sudo chmod 440 /etc/sudoers.d/sentinelvision

    echo ""
    echo "✅ First install complete!"

# ── Update: already installed ─────────────────────────────────────────────
else
    echo "[*] Updating existing installation..."
    cd "\$REMOTE_DIR"

    # Stop service
    sudo systemctl stop sentinelvision.service 2>/dev/null || true

    # Extract new files (venv and instance are never overwritten)
    python3 -c "
import zipfile, os, shutil

PROTECTED = {'instance/', 'venv/', 'uploads/', '.sentinelvision_secret'}
z = zipfile.ZipFile('\$ZIP_PATH')
for name in z.namelist():
    # Block path traversal
    target = os.path.abspath(os.path.join('.', name))
    if not target.startswith(os.path.abspath('.') + os.sep):
        print(f'  SKIP (traversal): {name}')
        continue
    # Skip protected paths
    if any(name.startswith(p) for p in PROTECTED):
        print(f'  SKIP (protected): {name}')
        continue
    z.extract(name, '.')
    print(f'  Updated: {name}')
z.close()
"
    # Restart service
    sudo systemctl start sentinelvision.service

    echo ""
    echo "✅ Update applied!"
fi

# Show service status
echo ""
sudo systemctl status sentinelvision.service --no-pager -l | head -20

REMOTE_SCRIPT

echo ""
echo "============================================="
echo " Done — SentinelVision is running on the Pi"
echo " Open: http://$PI_IP:5000"
echo "============================================="
