#!/bin/bash
# =============================================================================
#  SentinelVision — Pi Setup Script
#  Run this ON the Raspberry Pi after copying the ZIP here.
#
#  How to use:
#    1. Copy sentinelvision_update_v4.1.1.zip + this file to the Pi
#       (USB drive, file manager drag-and-drop, Samba share, etc.)
#    2. Open a terminal on the Pi in the same folder
#    3. Run:  bash pi_setup.sh
# =============================================================================

set -e

APP_DIR="/opt/sentinelvision"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

echo "============================================="
echo "  SentinelVision — Pi Setup"
echo "============================================="
echo ""

# ── Find the ZIP ──────────────────────────────────────────────────────────────
ZIP=$(ls "$SCRIPT_DIR"/sentinelvision_update_v*.zip 2>/dev/null | head -1)
if [ -z "$ZIP" ]; then
    echo "ERROR: No sentinelvision_update_v*.zip found in $SCRIPT_DIR"
    echo "Copy the ZIP file to the same folder as this script and try again."
    exit 1
fi
echo "Found: $ZIP"
echo ""

# ── Detect: first install or update ──────────────────────────────────────────
if [ -d "$APP_DIR" ] && [ -f "$APP_DIR/run.py" ]; then
    MODE="update"
else
    MODE="install"
fi
echo "Mode: $MODE"
echo ""

# ══════════════════════════════════════════════════════════════════════════════
# FIRST INSTALL
# ══════════════════════════════════════════════════════════════════════════════
if [ "$MODE" = "install" ]; then

    echo "Step 1: Creating install directory at $APP_DIR ..."
    sudo mkdir -p "$APP_DIR"
    sudo chown "$USER":"$USER" "$APP_DIR"

    echo "Step 2: Extracting files..."
    cd "$APP_DIR"
    python3 -c "import zipfile; zipfile.ZipFile('$ZIP').extractall('.')"

    echo "Step 3: Creating folders..."
    mkdir -p uploads/clips instance models

    echo "Step 4: Creating Python virtual environment..."
    python3 -m venv venv
    source venv/bin/activate

    echo "Step 5: Installing Python packages (may take 15-30 min)..."
    pip install --upgrade pip
    pip install -r requirements.txt

    echo "Step 6: Downloading YOLOv8n model..."
    if [ ! -f "yolov8n.pt" ]; then
        python -c "from ultralytics import YOLO; YOLO('yolov8n.pt')"
    else
        echo "  Model already exists, skipping."
    fi

    echo "Step 7: Installing systemd service..."
    sudo tee /etc/systemd/system/sentinelvision.service > /dev/null <<SVC
[Unit]
Description=SentinelVision Security Platform
After=network.target network-online.target
Wants=network-online.target

[Service]
Type=simple
User=$USER
WorkingDirectory=$APP_DIR
Environment="PATH=$APP_DIR/venv/bin:/usr/bin:/bin"
ExecStart=$APP_DIR/venv/bin/python run.py
Restart=always
RestartSec=10
StartLimitIntervalSec=60
StartLimitBurst=3
ProtectSystem=strict
ReadWritePaths=$APP_DIR /tmp
NoNewPrivileges=true

[Install]
WantedBy=multi-user.target
SVC

    sudo systemctl daemon-reload
    sudo systemctl enable sentinelvision.service

    # Passwordless sudo for service restart and reboot
    SUDOERS_LINE="$USER ALL=(ALL) NOPASSWD: /sbin/reboot, /sbin/shutdown, /bin/systemctl restart sentinelvision"
    echo "$SUDOERS_LINE" | sudo tee /etc/sudoers.d/sentinelvision > /dev/null
    sudo chmod 440 /etc/sudoers.d/sentinelvision

    echo "Step 8: Locking folder (only $USER can access it)..."
    sudo chown -R "$USER":"$USER" "$APP_DIR"
    chmod 700 "$APP_DIR"
    find "$APP_DIR" -type f -name "*.py"   -exec chmod 600 {} \;
    find "$APP_DIR" -type f -name "*.json" -exec chmod 600 {} \;
    find "$APP_DIR" -name "run.py"         -exec chmod 700 {} \;
    find "$APP_DIR" -name "*.sh"           -exec chmod 700 {} \;
    chmod 700 "$APP_DIR/uploads"  2>/dev/null || true
    chmod 700 "$APP_DIR/instance" 2>/dev/null || true

    echo "Step 9: Starting SentinelVision..."
    sudo systemctl start sentinelvision.service

    echo ""
    echo "============================================="
    echo "  ✅ Install complete!"
    echo "  Open: http://$(hostname -I | awk '{print $1}'):5000"
    echo "============================================="

# ══════════════════════════════════════════════════════════════════════════════
# UPDATE (already installed)
# ══════════════════════════════════════════════════════════════════════════════
else

    echo "Step 1: Stopping service..."
    sudo systemctl stop sentinelvision.service 2>/dev/null || true

    echo "Step 2: Extracting updated files..."
    cd "$APP_DIR"
    python3 -c "
import zipfile, os

PROTECTED = {'instance/', 'venv/', 'uploads/', '.sentinelvision_secret'}
z = zipfile.ZipFile('$ZIP')
for name in z.namelist():
    # Block path traversal
    target = os.path.abspath(os.path.join('.', name))
    if not target.startswith(os.path.abspath('.') + os.sep):
        print(f'  SKIP (traversal): {name}')
        continue
    # Skip protected paths
    if any(name.startswith(p) for p in PROTECTED):
        print(f'  SKIP (protected): {name}')
        continue
    z.extract(name, '.')
    print(f'  Updated: {name}')
z.close()
print('Done.')
"

    echo "Step 3: Re-locking folder permissions..."
    sudo chown -R "$USER":"$USER" "$APP_DIR"
    chmod 700 "$APP_DIR"
    find "$APP_DIR" -type f -name "*.py"   -exec chmod 600 {} \;
    find "$APP_DIR" -type f -name "*.json" -exec chmod 600 {} \;
    find "$APP_DIR" -name "run.py"         -exec chmod 700 {} \;
    find "$APP_DIR" -name "*.sh"           -exec chmod 700 {} \;

    echo "Step 4: Restarting service..."
    sudo systemctl start sentinelvision.service

    sleep 2
    echo ""
    sudo systemctl status sentinelvision.service --no-pager -l | head -15

    echo ""
    echo "============================================="
    echo "  ✅ Update applied!"
    echo "  Open: http://$(hostname -I | awk '{print $1}'):5000"
    echo "============================================="

fi
