#!/usr/bin/env python3
"""
generate_license.py  — SentinelVision Pro licence-key generator
================================================================
Run with:  python generate_license.py

Generates SVP licence keys that can be given to customers.
Keys are OFFLINE-verifiable (HMAC-SHA256) and carry the feature
code and duration code inside them.

Key format:
    SVP-{FC}{DC}-{8HEX}-{4HEX}

    FC  = Feature Code  : Z S L P W  (or A = all features)
    DC  = Duration Code : 1 3 Y      (1 month / 3 months / 12 months)
    8HEX = 8 random hex chars (the 'base' segment)
    4HEX = 4-char HMAC checksum

Example:  SVP-Z1-A3F9C201-4D2E
"""

import sys
import os
import re

# ── Make sure we can import license_manager from the same directory ──────────
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

try:
    from license_manager import (
        generate_license_key,
        FEATURES,
        DURATIONS,
        ALL_FEATURE_IDS,
    )
except ImportError as e:
    print(f"[ERROR] Could not import license_manager: {e}")
    sys.exit(1)

# ─────────────────────────────────────────────────────────────────────────────

FEATURE_MENU = {
    "1": ("zone_detection",  "Zone Detection  (includes Tripwire / Line Crossing)"),
    "2": ("stock_control",   "Stock Control   (Experimental)"),
    "3": ("people_counting", "People Counting"),
    "4": ("weapon_detection","Weapon Detection (Experimental)"),
    "5": ("all",             "ALL FEATURES BUNDLE"),
}

DURATION_MENU = {
    "1": ("1", "1 Month   (31 days)"),
    "2": ("3", "3 Months  (92 days)"),
    "3": ("Y", "12 Months (365 days)"),
}

DIVIDER = "─" * 56


def print_banner():
    print()
    print("╔══════════════════════════════════════════════════════╗")
    print("║      SentinelVision Pro — Licence Key Generator     ║")
    print("╚══════════════════════════════════════════════════════╝")
    print()
    print("  Keys are device-locked. You need the customer's Pi serial.")
    print("  The customer finds it on their Licence Management page.")
    print()


def pick_serial() -> str:
    """Prompt for the customer's Pi device serial."""
    print()
    print("Enter the customer's device serial (from their Licence Management page):")
    print(DIVIDER)
    while True:
        serial = input("  Device serial: ").strip().upper()
        if serial:
            return serial
        print("   → Serial cannot be empty.")


def pick_feature() -> str:
    """Prompt user to choose a feature and return its feature_id."""
    print("Select feature to licence:")
    print(DIVIDER)
    for num, (fid, label) in FEATURE_MENU.items():
        print(f"  {num})  {label}")
    print(DIVIDER)
    while True:
        choice = input("Enter number (1-6): ").strip()
        if choice in FEATURE_MENU:
            return FEATURE_MENU[choice][0]
        print("   → Please enter a number between 1 and 6.")


def pick_duration() -> str:
    """Prompt user to choose a duration and return its duration_code."""
    print()
    print("Select licence duration:")
    print(DIVIDER)
    for num, (code, label) in DURATION_MENU.items():
        print(f"  {num})  {label}")
    print(DIVIDER)
    while True:
        choice = input("Enter number (1-3): ").strip()
        if choice in DURATION_MENU:
            return DURATION_MENU[choice][0]
        print("   → Please enter 1, 2, or 3.")


def generate_one():
    """Interactive: generate a single key and print it."""
    device_serial = pick_serial()
    feature_id    = pick_feature()
    duration_code = pick_duration()

    key = generate_license_key(feature_id, duration_code, device_serial)

    dur_info = DURATIONS[duration_code]
    if feature_id == "all":
        feat_label = "All Features Bundle"
    else:
        feat_label = FEATURES[feature_id]["name"]

    print()
    print(DIVIDER)
    print("  ✅  LICENCE KEY GENERATED  (device-locked)")
    print(DIVIDER)
    print(f"  Device   : {device_serial}")
    print(f"  Feature  : {feat_label}")
    print(f"  Duration : {dur_info['label']}  ({dur_info['days']} days)")
    print()
    print(f"  KEY:  {key}")
    print()
    print("  This key will ONLY activate on the Pi with that serial.")
    print("  Copy and send to the customer to enter on their Licence page.")
    print(DIVIDER)
    print()


def batch_generate():
    """Generate multiple keys at once and write to a text file."""
    print()
    print("Batch mode — generate multiple keys at once.")
    print("You will be asked feature, duration, and quantity.")
    print()

    device_serial = pick_serial()
    feature_id    = pick_feature()
    duration_code = pick_duration()

    while True:
        qty_str = input("\nHow many keys to generate? (1-100): ").strip()
        if qty_str.isdigit() and 1 <= int(qty_str) <= 100:
            qty = int(qty_str)
            break
        print("   → Please enter a number between 1 and 100.")

    keys = [generate_license_key(feature_id, duration_code, device_serial) for _ in range(qty)]

    dur_info   = DURATIONS[duration_code]
    feat_label = "All Features Bundle" if feature_id == "all" else FEATURES[feature_id]["name"]

    # Print to console
    print()
    print(DIVIDER)
    print(f"  {qty} KEY(S) — {feat_label} / {dur_info['label']}  [device-locked: {device_serial}]")
    print(DIVIDER)
    for k in keys:
        print(f"  {k}")
    print(DIVIDER)

    # Optionally save to file
    save = input("\nSave to a file? (y/n): ").strip().lower()
    if save == "y":
        safe_feat = re.sub(r"[^a-z0-9]", "_", feature_id)
        fname = f"keys_{safe_feat}_{duration_code}_{qty}.txt"
        with open(fname, "w") as f:
            f.write(f"SentinelVision Pro Licence Keys\n")
            f.write(f"Device   : {device_serial}\n")
            f.write(f"Feature  : {feat_label}\n")
            f.write(f"Duration : {dur_info['label']} ({dur_info['days']} days)\n")
            f.write(f"Count    : {qty}\n")
            f.write(DIVIDER + "\n")
            for k in keys:
                f.write(k + "\n")
        print(f"  → Saved to: {os.path.abspath(fname)}")
    print()


def main_menu():
    print_banner()
    while True:
        print("What would you like to do?")
        print(DIVIDER)
        print("  1)  Generate a single key (interactive)")
        print("  2)  Batch generate multiple keys")
        print("  0)  Exit")
        print(DIVIDER)
        choice = input("Enter choice: ").strip()

        if choice == "1":
            generate_one()
        elif choice == "2":
            batch_generate()
        elif choice == "0":
            print("Goodbye.\n")
            break
        else:
            print("   → Please enter 0, 1, or 2.\n")


if __name__ == "__main__":
    # Allow quick non-interactive usage:
    #   python generate_license.py zone_detection 1
    #   python generate_license.py all Y
    if len(sys.argv) == 3:
        fid  = sys.argv[1].lower()
        dc   = sys.argv[2].upper()
        valid_fids = list(FEATURES.keys()) + ["all"]
        if fid not in valid_fids:
            print(f"Unknown feature '{fid}'. Choose from: {', '.join(valid_fids)}")
            sys.exit(1)
        if dc not in DURATIONS:
            print(f"Unknown duration '{dc}'. Choose from: 1, 3, Y")
            sys.exit(1)
        key = generate_license_key(fid, dc)
        dur = DURATIONS[dc]
        print(f"\nFeature  : {fid}")
        print(f"Duration : {dur['label']}")
        print(f"Key      : {key}\n")
    else:
        main_menu()
