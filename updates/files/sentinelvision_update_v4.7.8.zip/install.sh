#!/bin/bash
# SentinelVision Raspberry Pi Edition - Installation Script
# For Raspberry Pi OS (Debian-based)
# Run this script from the sentinelvision folder

echo "========================================="
echo "SentinelVision Raspberry Pi Edition"
echo "Installation Script"
echo "========================================="
echo ""

# Get the directory where this script is located
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
echo "Installing from: $SCRIPT_DIR"
echo ""

# Check if running on Raspberry Pi
if [ ! -f /proc/device-tree/model ]; then
    echo "Warning: This doesn't appear to be a Raspberry Pi"
    read -p "Continue anyway? (y/n) " -n 1 -r
    echo
    if [[ ! $REPLY =~ ^[Yy]$ ]]; then
        exit 1
    fi
fi

# Update system
echo "Step 1: Updating system packages..."
sudo apt-get update
sudo apt-get upgrade -y

# Install system dependencies
echo ""
echo "Step 2: Installing system dependencies..."
sudo apt-get install -y \
    python3 \
    python3-pip \
    python3-venv \
    libopencv-dev \
    python3-opencv \
    libatlas-base-dev \
    libhdf5-dev \
    libhdf5-serial-dev \
    libharfbuzz0b \
    libwebp7 \
    libjasper1 \
    libilmbase25 \
    libopenexr25 \
    libgstreamer1.0-0 \
    libavcodec-dev \
    libavformat-dev \
    libswscale-dev \
    ffmpeg \
    git

# Create application directory
echo ""
echo "Step 3: Setting up application directory..."
APP_DIR="/opt/sentinelvision"
sudo mkdir -p $APP_DIR
sudo chown $USER:$USER $APP_DIR

# Copy files from the script directory
echo "Copying application files..."
cp -r "$SCRIPT_DIR"/* $APP_DIR/
cp -r "$SCRIPT_DIR"/.[!.]* $APP_DIR/ 2>/dev/null || true

cd $APP_DIR

# Create required directories
mkdir -p uploads
mkdir -p instance
mkdir -p models

# Create virtual environment
echo ""
echo "Step 4: Creating Python virtual environment..."
python3 -m venv venv
source venv/bin/activate

# Upgrade pip
pip install --upgrade pip

# Install Python dependencies
echo ""
echo "Step 5: Installing Python dependencies..."
echo "This may take 15-30 minutes on Raspberry Pi..."
pip install -r requirements.txt

# Download YOLO11s model if not present
if [ ! -f "models/yolo11s.pt" ]; then
    echo ""
    echo "Downloading AI model..."
    mkdir -p models
    python -c "from ultralytics import YOLO; m=YOLO('yolo11s.pt'); m.save('models/yolo11s.pt')"
fi

# Create systemd service
echo ""
echo "Step 6: Creating systemd service..."
sudo tee /etc/systemd/system/sentinelvision.service > /dev/null <<EOF
[Unit]
Description=SentinelVision Raspberry Pi Edition
After=network.target network-online.target
Wants=network-online.target

[Service]
Type=simple
User=$USER
WorkingDirectory=$APP_DIR
Environment="PATH=$APP_DIR/venv/bin:/usr/bin:/bin"
ExecStart=$APP_DIR/venv/bin/python run.py
Restart=always
RestartSec=10
StartLimitAction=none
ProtectSystem=strict
ReadWritePaths=$APP_DIR /tmp
NoNewPrivileges=true

[Install]
WantedBy=multi-user.target
EOF

# Enable service
sudo systemctl daemon-reload
sudo systemctl enable sentinelvision.service

# Allow the app user to reboot and use systemctl without a password
# (restart is handled via SIGTERM, but reboot still needs sudo)
echo ""
echo "Step 7: Configuring passwordless sudo for reboot..."
# Include both /bin and /usr/bin paths — older Pi OS has them as real files,
# newer Pi OS (Bookworm) has /bin -> /usr/bin symlink. Sudo matches canonical
# paths so we list both to guarantee the passwordless restart works on all versions.
SUDOERS_LINE="$USER ALL=(ALL) NOPASSWD: /sbin/reboot, /usr/sbin/reboot, /sbin/shutdown, /usr/sbin/shutdown, /bin/systemctl restart sentinelvision, /usr/bin/systemctl restart sentinelvision"
echo "$SUDOERS_LINE" | sudo tee /etc/sudoers.d/sentinelvision > /dev/null
sudo chmod 440 /etc/sudoers.d/sentinelvision
echo "  Sudoers entry added for reboot / service restart."

# Set permissions
echo ""
echo "Step 8: Setting permissions and locking folder..."
chmod +x run.py
chmod +x start.sh

# Lock down the install directory so only the app user can read/write it
# (prevents other OS users — or a web vulnerability — reading config/API keys)
sudo chown -R $USER:$USER $APP_DIR
chmod 700 $APP_DIR
find $APP_DIR -type f -name "*.py"   -exec chmod 600 {} \;
find $APP_DIR -type f -name "*.json" -exec chmod 600 {} \;
find $APP_DIR -name "run.py"  -exec chmod 700 {} \;
find $APP_DIR -name "*.sh"    -exec chmod 700 {} \;
# Keep uploads/ and instance/ writable by the app
chmod 700 $APP_DIR/uploads  2>/dev/null || true
chmod 700 $APP_DIR/instance 2>/dev/null || true
echo "  Folder locked — readable only by $USER"

echo ""
echo "========================================="
echo "Installation Complete!"
echo "========================================="
echo ""
echo "To start SentinelVision:"
echo "  sudo systemctl start sentinelvision"
echo ""
echo "To check status:"
echo "  sudo systemctl status sentinelvision"
echo ""
echo "To view logs:"
echo "  sudo journalctl -u sentinelvision -f"
echo ""
echo "Access the web interface at:"
echo "  http://$(hostname -I | awk '{print $1}'):5000"
echo ""
echo "Your Telegram settings are pre-configured!"
echo "Just add/update your cameras in the web interface."
echo ""
echo "========================================="
echo ""

read -p "Start SentinelVision now? (y/n) " -n 1 -r
echo
if [[ $REPLY =~ ^[Yy]$ ]]; then
    sudo systemctl start sentinelvision
    sleep 3
    echo ""
    echo "SentinelVision started!"
    sudo systemctl status sentinelvision --no-pager
fi
