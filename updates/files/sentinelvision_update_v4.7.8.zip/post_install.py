#!/usr/bin/env python3
"""Post-install script for SentinelVision v4.0.5+"""
import subprocess
import sys
import os
import sqlite3
import glob

print("=" * 50)
print("SentinelVision Post-Install v4.0.5")
print("=" * 50)


# ── 1. Database migrations ────────────────────────────────
print("\n[1/3] Applying database fixes...")
try:
    # Find the database file
    db_paths = glob.glob('instance/*.db')
    db_path = db_paths[0] if db_paths else None

    if db_path:
        conn = sqlite3.connect(db_path)
        c = conn.cursor()

        # Fix sensitivity thresholds (old default was 0.75–0.85, now 0.55/0.50)
        c.execute("UPDATE cameras SET day_sensitivity=0.55 WHERE day_sensitivity IS NULL OR day_sensitivity > 0.55")
        rows_day = c.rowcount
        c.execute("UPDATE cameras SET night_sensitivity=0.50 WHERE night_sensitivity IS NULL OR night_sensitivity > 0.50")
        rows_night = c.rowcount

        # Remove clip mode — always use image for instant alerts
        c.execute("UPDATE cameras SET alert_media='image' WHERE alert_media IN ('clip', 'both')")
        rows_media = c.rowcount

        # Clear stuck alert cooldowns so alerts fire immediately after install
        c.execute("UPDATE cameras SET last_alert_time=NULL")

        # Enable loitering zone alerts if they have none configured
        try:
            c.execute("""UPDATE detection_zones SET alert_on_exit=1
                         WHERE zone_type='loitering'
                           AND alert_on_entry=0 AND alert_on_exit=0""")
        except Exception:
            pass  # Table may not exist on older installs

        conn.commit()
        conn.close()

        print(f"  ✓ Camera sensitivity capped (day:{rows_day} rows, night:{rows_night} rows)")
        print(f"  ✓ Alert media set to image ({rows_media} rows updated)")
        print(f"  ✓ Alert cooldown reset")
    else:
        print("  ⚠ No database found - will be created on first run")

except Exception as e:
    print(f"  ⚠ DB migration warning: {e}")


# ── 2. Ensure yolov8s model is present ───────────────────
print("\n[2/3] Checking AI model...")
model_dir = "models"
model_path = os.path.join(model_dir, "yolo11s.pt")

if os.path.exists(model_path):
    size_mb = os.path.getsize(model_path) / (1024 * 1024)
    print(f"  ✓ yolo11s.pt already present ({size_mb:.1f} MB)")
else:
    print("  ↓ Downloading yolo11s.pt (19 MB - requires internet)...")
    try:
        os.makedirs(model_dir, exist_ok=True)
        from ultralytics import YOLO
        model = YOLO("yolo11s.pt")  # auto-downloads
        import shutil
        cached = os.path.join(os.path.expanduser("~"), ".cache", "ultralytics", "yolo11s.pt")
        if os.path.exists(cached):
            shutil.copy2(cached, model_path)
        else:
            model.save(model_path)
        print(f"  ✓ yolo11s.pt downloaded successfully")
    except Exception as e:
        print(f"  ⚠ Could not download model: {e}")
        print("    The model will auto-download when the service starts (needs internet)")


# ── 3. Install/update dependencies ───────────────────────
print("\n[3/3] Checking dependencies...")
pip_ok = True
try:
    result = subprocess.run(
        [sys.executable, '-m', 'pip', 'install', '-r', 'requirements.txt'],
        capture_output=True, text=True
    )
    if result.returncode != 0:
        pip_ok = False
        print(f"  ✗ pip install FAILED (exit {result.returncode})")
        print(result.stderr[-2000:] if result.stderr else "(no stderr)")
    else:
        # Show any "Successfully installed …" lines from pip output
        for line in result.stdout.splitlines():
            if 'Successfully installed' in line or 'already satisfied' in line.lower():
                print(f"  pip: {line.strip()}")
        print("  ✓ Dependencies installed/verified")
except Exception as e:
    pip_ok = False
    print(f"  ✗ pip install error: {e}")

# ── 4. Verify critical imports and report versions ───────
print("\n[4/4] Verifying critical packages...")
critical = [
    ('flask',        'flask',        '__version__'),
    ('cv2',          'opencv-python','__version__'),
    ('ultralytics',  'ultralytics',  '__version__'),
    ('torch',        'torch',        '__version__'),
]
all_ok = True
for mod, pkg_name, ver_attr in critical:
    try:
        m = __import__(mod)
        ver = getattr(m, ver_attr, 'unknown')
        print(f"  ✓ {pkg_name} {ver}")
    except ImportError:
        all_ok = False
        print(f"  ✗ {pkg_name} NOT importable — try: pip install {pkg_name}")

if not all_ok:
    print("\n  ⚠ Some packages failed to import. If the service fails to start")
    print("    run: pip install -r requirements.txt")

print("\n" + "=" * 50)
if pip_ok and all_ok:
    print("✅ Post-install complete!")
else:
    print("⚠  Post-install finished with warnings — check output above.")
print("   Restart service: sudo systemctl restart sentinelvision")
print("=" * 50)
