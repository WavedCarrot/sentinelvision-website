"""
Main entry point for SentinelVision Security Platform
"""
from app import app, set_detection_engine
from detection_engine import init_detection_engine
from telegram_service import telegram_service
from telegram_bot_commands import init_bot_commands
from stock_scheduler import start_stock_scheduler
from license_manager import start_heartbeat
import logging
import signal
import sys

# Setup logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('sentinelvision.log'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

# Global references
engine = None
bot_commands_handler = None
stock_scheduler = None


def signal_handler(sig, frame):
    """Handle shutdown signals gracefully"""
    logger.info("Shutting down SentinelVision...")
    if engine:
        engine.stop()
    if bot_commands_handler:
        bot_commands_handler.stop_polling()
    if stock_scheduler:
        stock_scheduler.shutdown()
    sys.exit(0)


if __name__ == '__main__':
    # Register signal handlers
    signal.signal(signal.SIGINT, signal_handler)
    signal.signal(signal.SIGTERM, signal_handler)
    
    logger.info("="*50)
    logger.info("SentinelVision Security Platform")
    logger.info("AI-Powered Security Camera System")
    logger.info("="*50)
    
    # Initialize detection engine
    with app.app_context():
        engine = init_detection_engine(app)
        set_detection_engine(engine)  # make live engine visible to snapshot/stream routes

        # Start cloud heartbeat — reports device online/offline status to license dashboard
        start_heartbeat(app_version="4.8.2", flask_app=app)
        
        # Initialize bot commands handler
        bot_commands_handler = init_bot_commands(app, telegram_service)
        
        # Wire bot handler into detection engine for tamper alerts with action buttons
        engine.set_bot_commands_handler(bot_commands_handler)
        
        # Check if system is configured
        from models import SystemConfig
        config = SystemConfig.query.first()
        
        if config and config.telegram_chat_id:
            logger.info("System configuration found")
            system_name = config.system_name or "SentinelVision Security Platform"
            telegram_service.set_credentials(config.telegram_chat_id)
            
            # Update bot commands handler
            bot_commands_handler.update_credentials(config.telegram_chat_id)
            
            # Set bot commands menu
            if bot_commands_handler.set_bot_commands():
                logger.info("Telegram bot commands registered successfully")
            else:
                logger.warning("Failed to register Telegram bot commands")
            
            # Start bot command polling
            bot_commands_handler.start_polling()
            
            # Start stock control scheduler
            stock_scheduler = start_stock_scheduler(app)
            logger.info("Stock control scheduler initialized")
            
            # Send startup notification
            armed_status = "🔒 ARMED" if config.is_armed else "🔓 DISARMED"
            telegram_service.send_message(
                f'🚀 <b>{system_name} Started</b>\n\n'
                f'System Status: {armed_status}\n'
                f'Use /start to open the control menu'
            )
            
            # Start detection engine
            if engine.start():
                logger.info("Detection engine started successfully")
            else:
                logger.warning("Detection engine failed to start")
        else:
            logger.warning("System not configured yet. Please complete setup via web interface.")
    
    # Start Flask application
    logger.info("Starting web server on http://0.0.0.0:5000")
    logger.info("Press Ctrl+C to stop")
    
    try:
        app.run(
            host='0.0.0.0',
            port=5000,
            debug=False,
            threaded=True
        )
    except Exception as e:
        logger.error(f"Application error: {e}")
    finally:
        if engine:
            engine.stop()
        if bot_commands_handler:
            bot_commands_handler.stop_polling()
        logger.info("SentinelVision stopped")
