"""
AI Detection Engine for SentinelVision Raspberry Pi Edition
Optimized for Raspberry Pi 5 with YOLOv8/11 support
"""
import cv2
import numpy as np
from ultralytics import YOLO
import logging
import collections
from pathlib import Path
from datetime import datetime, timedelta
from models import db, Camera, DetectionEvent, SystemConfig, OccupancyLog, LoiteringEvent, DetectionZone, ZoneTransition, ZoneDailyStats, ZoneHeatmapData
from telegram_service import telegram_service
import threading
import time
import os
# import easyocr  # Optional OCR - commented out to avoid dependency issues
import json

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Lightweight license feature cache — avoids a DB query on every camera frame
# ---------------------------------------------------------------------------
_lic_cache: dict = {}      # feature_id -> bool
_lic_cache_ts: dict = {}   # feature_id -> float (unix time of last check)
_LIC_TTL = 60              # seconds before re-querying the DB


def _check_license(feature_id: str) -> bool:
    """Return True if the feature license is active.  Results cached for _LIC_TTL seconds."""
    import time as _t
    now = _t.time()
    if now - _lic_cache_ts.get(feature_id, 0) < _LIC_TTL:
        return _lic_cache.get(feature_id, True)  # default allow while warm
    try:
        from license_manager import is_feature_unlocked
        result = is_feature_unlocked(feature_id)
    except Exception:
        result = True  # fail-open if license manager unavailable
    _lic_cache[feature_id] = result
    _lic_cache_ts[feature_id] = now
    return result


class DetectionEngine:
    """
    AI Detection Engine optimized for Raspberry Pi 5
    """
    
    def __init__(self, app, telegram_service=None):
        self.app = app
        self.telegram_service = telegram_service  # For threat alerts
        self.model = None
        self.weapon_model = None  # Separate model for weapon detection
        self.running = False
        self.threads = {}

        # Coarse reentrant lock protecting dicts written from multiple camera threads:
        # zone_alert_times, track_movement, camera_status, people_tracker
        self._tracking_lock = threading.RLock()
        
        # Object tracking for stock items (prevent double counting)
        self.tracked_items = {}  # camera_id: {item_name: {track_id: last_seen_time}}
        self.tracking_timeout = 300  # Seconds (5 minutes) - items not seen are considered removed/sold
        
        # Detection class mappings
        self.class_categories = {
            'person': ['person'],
            'vehicle': ['car', 'truck', 'bus', 'motorcycle', 'bicycle'],
            'animal': [
                # COCO animals (natively detected by YOLOv8)
                'dog', 'cat', 'bird', 'horse', 'sheep', 'cow',
                'zebra', 'giraffe',
            ],
            'object': []  # Will include all other classes
        }

        # Per-class confidence overrides
        self.class_confidence_overrides = {
            'dog':      0.60,
            'cat':      0.60,
            'bird':     0.60,
            'horse':    0.60,
            'sheep':    0.60,
            'cow':      0.60,
            'zebra':    0.60,
            'giraffe':  0.60,
        }
        
        # Weapon detection classes (from specialized model or COCO-like detection)
        # Note: Standard YOLO doesn't have weapon classes - these are detected via specialized model
        self.weapon_classes = {
            'firearm': ['gun', 'pistol', 'rifle', 'handgun', 'firearm', 'weapon', 'revolver'],
            'blade': ['knife', 'sword', 'machete', 'blade'],  # knife is in COCO
            'blunt': ['baseball bat']  # baseball bat is in COCO - can be used as weapon
        }
        
        # Threat detection tracking (prevent spam alerts)
        self.threat_alerts = {}  # camera_id: {last_alert_time, threat_type}
        
        # Model path
        self.models_dir = Path(__file__).parent / 'models'
        self.models_dir.mkdir(exist_ok=True)
        
        # OCR Reader for text verification (lazy load)
        self.ocr_reader = None
        
        # People tracking for zone-based counting
        self.people_tracker = {}  # camera_id: {track_id: {zones, last_seen, position}}
        
        # Camera status tracking for offline detection
        self.camera_status = {}  # camera_id: {online: bool, last_seen: datetime, offline_notified: bool}
        
        # Zone alert cooldown tracking (prevent duplicate zone alerts)
        self.zone_alert_times = {}  # key: last_alert_time
        self.zone_alert_cooldown = 30  # seconds between same zone alerts
        
        # Camera offline/online notification cooldown
        self.camera_notification_cooldown = 120  # 2 minutes between camera status notifications
        
        # Detection alert debouncing — per-class so person + dog cooldowns are independent
        self.last_detection_alerts = {}  # camera_id: {class_name: last_alert_time}
        self.detection_alert_cooldown = 60  # seconds between detection alerts per class per camera

        # Consecutive-frame confirmation buffer: detection must be seen in N consecutive
        # processed frames before it triggers an alert (anti-flash / anti-noise filter)
        self.pending_detection_counts = {}  # camera_id -> {track_key: consecutive_count}
        
        # Consecutive detection tracking for anti-false-positive
        self.consecutive_detections = {}  # camera_id: {detection_key: count}
        
        # Track movement to detect stationary objects (furniture)
        self.track_movement = {}  # track_key: {x, y, time}
        
        # Previous frame for motion detection
        self.previous_frames = {}  # camera_id: frame
        
        # Behavior analysis tracking
        self.person_positions = {}  # camera_id: {track_id: [(x, y, timestamp), ...]}
        self.behavior_alerts = {}  # camera_id: {behavior_type: last_alert_time}
        
        # Crowd counting per zone
        self.zone_occupancy = {}  # zone_id: {count: N, last_update: timestamp}
        
        # GPU acceleration flag
        self.use_gpu = False
        self.gpu_type = None  # 'coral', 'hailo', 'cuda'
        
        # =====================================================================
        # ENHANCED ZONE TRACKING FEATURES
        # =====================================================================
        
        # Enhanced tracking with velocity prediction (Kalman-like smoothing)
        self.track_velocities = {}  # camera_id: {track_id: (vx, vy)}
        self.velocity_smoothing = 0.7  # Smoothing factor for velocity updates
        
        # IOU-based track matching when YOLO loses track
        self.previous_detections = {}  # camera_id: [detections] for IOU matching
        self.iou_match_threshold = 0.3  # Minimum IOU to consider a match
        
        # Multi-point detection for better zone accuracy
        self.detection_anchor_point = 'feet'  # 'center', 'feet', 'head', 'bottom_center'
        
        # Directional line crossing detection  
        self.crossing_lines = {}  # zone_id: {'line': [(x1,y1), (x2,y2)], 'direction': 'in/out'}

        # Entrance/counting line — cumulative inside count per zone (reset daily)
        # zone_id → int  (entries - exits since midnight today)
        self.entrance_inside_counts = {}
        self.entrance_last_reset = {}  # zone_id → date (for midnight reset)

        # Previous positions for tripwire line-crossing detection
        # Structure: {camera_id: {track_id: [x, y]}}
        self.tripwire_prev_positions = {}
        
        # Heatmap data collection settings
        self.heatmap_grid_size = 20  # Divide zone into 20x20 grid
        self.heatmap_update_interval = 5  # Update heatmap every 5 seconds
        self.last_heatmap_update = {}  # camera_id: timestamp
        
        # Track history for smooth transitions (prevents flickering)
        self.track_zone_history = {}  # camera_id: {track_id: [zone_id, zone_id, ...]}
        self.zone_confirmation_frames = 3  # Must be in zone for N frames to confirm entry
        
        # Zone transition logging batch (for performance)
        self.pending_transitions = []  # Queue of transitions to save
        self._transitions_lock = threading.Lock()  # Protects pending_transitions across camera threads
        self.transition_batch_size = 10  # Save every N transitions
        
        # Daily stats cache
        self.daily_stats_cache = {}  # zone_id_date: ZoneDailyStats object

        # Global occupancy tracking (for analytics without zones)
        self._occupancy_prev_count = {}  # camera_id: last logged people count
        
        # Cache of latest frames for fast snapshot access (zone drawing)
        self.camera_frames = {}  # camera_id: latest_frame

        # Cache of latest annotated frames for live stream (with bounding boxes)
        self.camera_annotated_frames = {}  # camera_id: latest annotated frame

        # Timestamp of last RAW frame update per camera
        self.camera_frame_times = {}  # camera_id: float (time.time())

        # Timestamp of last ANNOTATED frame update per camera (set only after inference)
        self.camera_annotated_frame_times = {}  # camera_id: float (time.time())

        # Latest detections per camera (for zone/line alert annotation)
        self.camera_detections = {}  # camera_id: latest detections list

        # Path trail history per camera/track (800x600 canvas coords, for live trail overlay)
        self.camera_track_trails = {}  # camera_id: {track_id: [{'x':x,'y':y,'t':timestamp}, ...]}

        # Pending zone entries waiting for next-frame direction calculation
        # {camera_id: {track_id: {zone_id: initial_position}}}
        self.pending_zone_entries = {}

        # Exponential backoff for camera reconnects {camera_id: attempt_count}
        self.camera_retry_attempts = {}

        # Default zone alert cooldown: 5 minutes to reduce Telegram spam
        self.zone_alert_cooldown_seconds = 300

        # Detection tracking
        self.camera_detections = {}  # camera_id: latest detections list

        # Timestamp of last YOLO inference per camera (for stale-detection cleanup)
        self._last_yolo_time = {}  # camera_id: float (time.time())

        # Raw person count from the latest YOLO run per camera (no consecutive-frame gate).
        # Used exclusively for the live "PEOPLE NOW" dashboard counter so that a person
        # standing still for >15 s doesn't cause the count to drop to zero.
        self.camera_raw_counts = {}  # camera_id: int
        # Cache of static (non-person) object labels so they stay visible even
        # when YOLO tracker drops them between frames.
        # {camera_id: {grid_key: {'bbox': (x1,y1,x2,y2), 'conf': float, 'class': str, 'ts': float}}}
        self._persistent_labels = {}

        # Per-camera set of track_ids for real entry/exit counting
        self._seen_person_track_ids = {}  # camera_id: set of track_ids seen in last window

        # =====================================================================
        # ANOMALY DETECTION  (learns normal activity, flags deviations)
        # =====================================================================
        # Rolling hourly baseline: camera_id -> {hour_of_day: deque of daily counts}
        self.activity_baseline = {}       # camera_id -> {0..23: collections.deque(maxlen=14)}
        self.anomaly_z_threshold = 2.5    # z-score above this triggers an anomaly alert
        self._last_anomaly_alert = {}     # camera_id -> datetime  (cooldown)

        # =====================================================================
        # FACE BLURRING  (blur detected faces before saving / sending snapshots)
        # =====================================================================
        self.face_blur_kernel = 61        # GaussianBlur kernel (larger = more blur, must be odd)

        # =====================================================================
        # PER-CAMERA CONFIDENCE AUTO-TUNING
        # =====================================================================
        self.camera_fp_counts = {}        # camera_id -> int  (false positives this window)
        self.camera_fp_window_start = {}  # camera_id -> float (time.time() of window start)
        self.camera_conf_thresholds = {}  # camera_id -> float (current adjusted threshold)
        self._conf_window_seconds = 3600  # 1-hour evaluation window
        self._conf_base = 0.80            # Default YOLO confidence — high accuracy, low false alarms
        self._conf_min = 0.70             # Never go below
        self._conf_max = 0.92             # Never go above

        # =====================================================================
        # HEARTBEAT — updated every frame so the watchdog can detect threads
        # that are alive() but frozen (e.g. cap.read() blocked on a stalled
        # RTSP TCP connection).  time.time() float, 0.0 means never started.
        # =====================================================================
        self.camera_heartbeats = {}  # camera_id -> float (time.time() of last frame)

        # =====================================================================
        # PER-CAMERA MODELS + INFERENCE LOCK
        # Each camera gets its own YOLO instance so persist=True tracker IDs
        # stay isolated per-camera.  A Semaphore(1) ensures only one inference
        # runs at a time — no CPU thrashing on 6-camera Pi 5 setups.
        # =====================================================================
        self._camera_models = {}          # camera_id -> YOLO instance
        self._infer_sem = threading.Semaphore(1)  # serialise CPU access

        # =====================================================================
        # TAMPER DETECTION — detect camera being moved, covered, or spray-painted
        # =====================================================================
        self.tamper_reference_frames = {}   # camera_id: grayscale reference frame
        self.tamper_consecutive_counts = {} # camera_id: int (consecutive tamper frames)
        self.tamper_alert_times = {}        # camera_id: float (last alert time.time())
        self.tamper_ref_set_times = {}      # camera_id: float (when reference was last set)
        self.tamper_message_ids = {}        # camera_id: [(chat_id, message_id), ...]
        self.tamper_ref_sat = {}            # camera_id: float (mean saturation of reference frame)
        self.bot_commands_handler = None    # set via set_bot_commands_handler()

    def set_bot_commands_handler(self, handler):
        """Store reference to telegram_bot_commands handler for tamper alerts with action buttons"""
        self.bot_commands_handler = handler

    def validate_polygon_points(self, points):
        """Simple polygon validation"""
        if not points:
            return []
        
        try:
            if isinstance(points, str):
                import json
                points = json.loads(points)
            
            if not isinstance(points, list) or len(points) < 4:
                return []
            
            # Simple validation - just check if we have valid coordinate pairs
            validated = []
            for point in points:
                if isinstance(point, (list, tuple)) and len(point) >= 2:
                    try:
                        x, y = float(point[0]), float(point[1])
                        validated.append([x, y])
                    except (ValueError, TypeError):
                        continue
            
            return validated if len(validated) >= 3 else []
            
        except Exception:
            return []
    
    def point_in_exclusion_zone(self, point, camera):
        """Check if a point is inside any exclusion zone"""
        try:
            exclusion_zones = camera.get_exclusion_zones() if hasattr(camera, 'get_exclusion_zones') else []
            if not exclusion_zones:
                return False
            
            for zone in exclusion_zones:
                if self.point_in_rectangle(point, zone):
                    return True
            return False
        except:
            return False
    
    def detect_motion(self, frame, camera_id, threshold=25, min_area=500):
        """Detect motion between frames - returns True if motion detected"""
        try:
            gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
            gray = cv2.GaussianBlur(gray, (21, 21), 0)
            
            if camera_id not in self.previous_frames:
                self.previous_frames[camera_id] = gray
                return True  # First frame, assume motion
            
            # Compute difference
            frame_delta = cv2.absdiff(self.previous_frames[camera_id], gray)
            thresh = cv2.threshold(frame_delta, threshold, 255, cv2.THRESH_BINARY)[1]
            thresh = cv2.dilate(thresh, None, iterations=2)
            
            # Find contours
            contours, _ = cv2.findContours(thresh.copy(), cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
            
            # Update previous frame
            self.previous_frames[camera_id] = gray
            
            # Check if any contour is large enough
            for contour in contours:
                if cv2.contourArea(contour) > min_area:
                    return True
            
            return False
        except Exception as e:
            logger.error(f"Motion detection error: {e}")
            return True  # On error, assume motion (safety)
    
    def check_consecutive_detection(self, camera_id, detection_key, min_frames=3):
        """Track consecutive detections - returns True if detection is consistent"""
        if camera_id not in self.consecutive_detections:
            self.consecutive_detections[camera_id] = {}
        
        tracker = self.consecutive_detections[camera_id]
        
        # Increment counter for this detection
        if detection_key not in tracker:
            tracker[detection_key] = 1
        else:
            tracker[detection_key] += 1
        
        # Clean up old detections (not seen in this frame)
        # This is called per-detection, so we handle cleanup separately
        
        return tracker[detection_key] >= min_frames
    
    def reset_consecutive_detections(self, camera_id):
        """Reset detection counters for a camera (call at end of frame)"""
        if camera_id in self.consecutive_detections:
            self.consecutive_detections[camera_id] = {}
    
    def load_model(self, model_name='yolov8n.pt'):
        """
        Load YOLO model (optimized for Raspberry Pi)
        Use yolov8n (nano) for best performance on RPi 5
        """
        try:
            model_path = self.models_dir / model_name
            
            # Download model if not exists
            if not model_path.exists():
                logger.info(f"Downloading {model_name}...")
                self.model = YOLO(model_name)  # Will auto-download
                self.model.save(str(model_path))
            else:
                self.model = YOLO(str(model_path))
            
            logger.info(f"Model loaded: {model_name}")
            
            # Load weapon model in a background thread so Flask starts immediately
            import threading as _t
            _t.Thread(target=self.load_weapon_model, daemon=True).start()
            
            return True
        except Exception as e:
            logger.error(f"Failed to load model: {e}")
            return False
    
    def load_weapon_model(self, model_name='weapon_yolov8n.pt'):
        """
        Load specialized weapon detection model.
        
        Supports multiple detection methods:
        1. Custom weapon model (weapon_yolov8n.pt) - Best accuracy
        2. YOLO-World (yolov8s-worldv2.pt) - Open vocabulary detection
        3. Visual shape analysis - Fallback method
        
        To use weapon detection:
        1. Download a weapon detection model (e.g., from Roboflow or train your own)
        2. Place it in the 'models' folder as 'weapon_yolov8n.pt'
        
        Or use YOLO-World for open vocabulary detection (no custom model needed).
        """
        try:
            weapon_model_path = self.models_dir / model_name
            
            # First try dedicated weapon model
            if weapon_model_path.exists():
                self.weapon_model = YOLO(str(weapon_model_path))
                self.weapon_model_classes = self.weapon_model.names
                self.weapon_model_type = 'custom'
                logger.info(f"🔫 Weapon detection model loaded: {model_name}")
                logger.info(f"🔫 Weapon classes: {list(self.weapon_model_classes.values())}")
                return True
            
            # Try YOLO-World for open vocabulary detection
            yolo_world_success = self._try_load_yolo_world()
            if yolo_world_success:
                return True
            
            logger.info(f"ℹ️ No weapon model found at {weapon_model_path}")
            logger.info("ℹ️ Using visual analysis for gun detection (lower accuracy)")
            logger.info("ℹ️ For better detection, run: python download_weapon_model.py")
            self.weapon_model = None
            self.weapon_model_classes = {}
            self.weapon_model_type = 'visual'
            return False
            
        except Exception as e:
            logger.error(f"Failed to load weapon model: {e}")
            self.weapon_model = None
            self.weapon_model_classes = {}
            self.weapon_model_type = 'visual'
            return False
    
    def _try_load_yolo_world(self):
        """
        Try to load YOLO-World for open vocabulary weapon detection.
        YOLO-World can detect any object using text descriptions.
        """
        try:
            yolo_world_path = self.models_dir / 'yolov8s-worldv2.pt'
            
            # Define weapon classes for YOLO-World
            weapon_text_classes = ['gun', 'pistol', 'rifle', 'handgun', 'firearm', 'revolver', 'shotgun']
            
            if yolo_world_path.exists():
                logger.info("🌍 Loading YOLO-World for weapon detection...")
                self.weapon_model = YOLO(str(yolo_world_path))
                self.weapon_model.set_classes(weapon_text_classes)
                self.weapon_model_classes = {i: c for i, c in enumerate(weapon_text_classes)}
                self.weapon_model_type = 'yolo-world'
                logger.info(f"🌍 YOLO-World loaded with weapon classes: {weapon_text_classes}")
                return True
            else:
                # Try to download YOLO-World (smaller version for Pi)
                try:
                    logger.info("🌍 Attempting to download YOLO-World for weapon detection...")
                    self.weapon_model = YOLO('yolov8s-worldv2.pt')
                    self.weapon_model.set_classes(weapon_text_classes)
                    self.weapon_model_classes = {i: c for i, c in enumerate(weapon_text_classes)}
                    self.weapon_model_type = 'yolo-world'
                    logger.info(f"🌍 YOLO-World downloaded and configured for weapons")
                    return True
                except Exception as e:
                    logger.debug(f"YOLO-World download failed: {e}")
                    return False
                    
        except Exception as e:
            logger.debug(f"YOLO-World setup failed: {e}")
            return False
    
    def detect_with_weapon_model(self, frame, camera):
        """
        Run weapon detection using dedicated weapon model or YOLO-World.
        Returns list of weapon detections.
        """
        if self.weapon_model is None:
            return []
        
        if not hasattr(camera, 'enable_weapon_detection') or not camera.enable_weapon_detection:
            return []
        
        try:
            # For YOLO-World, we need to ensure classes are set
            if hasattr(self, 'weapon_model_type') and self.weapon_model_type == 'yolo-world':
                weapon_text_classes = ['gun', 'pistol', 'rifle', 'handgun', 'firearm', 'revolver', 'shotgun']
                try:
                    self.weapon_model.set_classes(weapon_text_classes)
                except:
                    pass  # Classes may already be set
            
            # Run weapon model inference
            results = self.weapon_model(frame, verbose=False)
            
            weapon_detections = []
            
            for result in results:
                if result.boxes is None:
                    continue
                
                for box in result.boxes:
                    confidence = float(box.conf[0])
                    class_id = int(box.cls[0])
                    class_name = self.weapon_model_classes.get(class_id, 'weapon')
                    
                    # For YOLO-World, use higher confidence threshold
                    min_conf = 0.3 if hasattr(self, 'weapon_model_type') and self.weapon_model_type == 'yolo-world' else 0.4
                    
                    # Only high-confidence weapon detections
                    if confidence > min_conf:
                        x1, y1, x2, y2 = map(int, box.xyxy[0])
                        
                        # Determine threat type based on class name
                        class_lower = class_name.lower()
                        if any(w in class_lower for w in ['gun', 'pistol', 'rifle', 'handgun', 'revolver', 'firearm', 'shotgun']):
                            threat_type = 'FIREARM'
                            severity = 'CRITICAL'
                        elif any(w in class_lower for w in ['knife', 'blade', 'machete', 'sword']):
                            threat_type = 'BLADE'
                            severity = 'HIGH'
                        else:
                            threat_type = 'WEAPON'
                            severity = 'HIGH'
                        
                        model_type = getattr(self, 'weapon_model_type', 'custom')
                        
                        weapon_detections.append({
                            'type': threat_type,
                            'class': class_name,
                            'confidence': confidence,
                            'severity': severity,
                            'bbox': {'x1': x1, 'y1': y1, 'x2': x2, 'y2': y2},
                            'message': f'🚨 {threat_type} DETECTED: {class_name}',
                            'from_weapon_model': True,
                            'model_type': model_type
                        })
                        
                        logger.warning(f"🔫 WEAPON DETECTED ({model_type}): {class_name} with {confidence:.1%} confidence")
            
            return weapon_detections
            
        except Exception as e:
            logger.error(f"Weapon model detection error: {e}")
            return []
    
    def get_enabled_classes(self, camera):
        """Get list of enabled detection classes for a camera"""
        enabled_classes = []
        
        if camera.enable_person_detection:
            enabled_classes.extend(self.class_categories['person'])
        
        if camera.enable_vehicle_detection and _check_license('vehicle_detection'):
            enabled_classes.extend(self.class_categories['vehicle'])

        if getattr(camera, 'enable_object_detection', False) and _check_license('object_detection'):
            object_classes = [
                'backpack', 'umbrella', 'handbag', 'tie', 'suitcase',
                'chair', 'couch', 'bed', 'dining table', 'toilet',
                'tv', 'laptop', 'mouse', 'remote', 'keyboard', 'cell phone',
                'book', 'clock', 'vase', 'scissors', 'teddy bear', 'hair drier', 'toothbrush',
                'bench', 'potted plant', 'sink', 'refrigerator', 'microwave', 'oven', 'toaster',
            ]
            enabled_classes.extend(object_classes)
        
        if camera.enable_animal_detection:
            all_animal_classes = self.class_categories['animal']
            selected = getattr(camera, 'get_animal_classes', lambda: [])()
            if selected:
                # Only detect the specific animals the user selected
                enabled_classes.extend([a for a in all_animal_classes if a in selected])
            else:
                # No filter set — detect all animals
                enabled_classes.extend(all_animal_classes)
        
        # Enhanced stock control items with comprehensive item detection
        if camera.enable_stock_control:
            try:
                # Enhanced stock items that YOLO can detect with high accuracy
                food_items = [
                    'pizza', 'hot dog', 'donut', 'cake', 'sandwich',
                    'banana', 'apple', 'orange', 'broccoli', 'carrot'
                ]
                
                beverage_items = [
                    'bottle', 'cup', 'wine glass', 'beer'
                ]
                
                container_items = [
                    'bowl', 'spoon', 'fork', 'knife', 'plate'
                ]
                
                # Combine all stock control items
                stock_classes = food_items + beverage_items + container_items
                enabled_classes.extend(stock_classes)
                
                # Add pizza box detection (detected as generic 'box' but verified with OCR)
                if 'pizza' in stock_classes:
                    # Enable box detection for pizza box verification
                    enabled_classes.append('suitcase')  # YOLO sometimes detects boxes as suitcases
                
                logger.info(f"Camera {camera.name}: Added {len(stock_classes)} enhanced stock control classes")
                logger.debug(f"Stock classes: {stock_classes}")
                
            except Exception as e:
                logger.error(f"Error loading stock control items: {e}")
        
        # Add custom classes
        custom_classes = camera.get_custom_classes()
        if custom_classes:
            enabled_classes.extend(custom_classes)
        
        # Add weapon-related classes from COCO that could be threats
        if hasattr(camera, 'enable_weapon_detection') and camera.enable_weapon_detection:
            # COCO has 'knife' and 'baseball bat' which could be weapons
            # We'll also use visual analysis for gun-like objects
            weapon_coco_classes = ['knife', 'baseball bat']
            enabled_classes.extend(weapon_coco_classes)
            logger.info(f"Camera {camera.name}: ⚠️ Weapon detection ENABLED")
        
        logger.info(f"Camera {camera.name}: Enabled classes = {enabled_classes}")
        return enabled_classes
    
    def detect_weapon_threat(self, frame, detections, camera):
        """
        Analyze detections for potential weapon threats.
        Uses multiple methods:
        1. Dedicated weapon model (if available) - MOST RELIABLE
        2. COCO classes: knife, baseball bat
        3. Visual analysis: gun-like shapes near person detections
        
        Returns list of threat detections with severity
        """
        threats = []
        
        if not hasattr(camera, 'enable_weapon_detection') or not camera.enable_weapon_detection:
            return threats
        
        # METHOD 1: Use dedicated weapon detection model (most reliable)
        if self.weapon_model is not None:
            weapon_model_threats = self.detect_with_weapon_model(frame, camera)
            threats.extend(weapon_model_threats)
            # If weapon model found threats, we can return early (most reliable)
            if weapon_model_threats:
                return threats
        
        # METHOD 2: Check COCO classes (knife, baseball bat)
        # Get all person detections
        person_boxes = [d for d in detections if d.get('class') == 'person']
        
        for det in detections:
            class_name = det.get('class', '').lower()
            confidence = det.get('confidence', 0)
            
            # Check for COCO weapon classes
            if class_name == 'knife':
                # Check if knife is near a person (being held)
                knife_center = self._get_box_center(det)
                near_person = any(self._is_near_box(knife_center, p, threshold=100) for p in person_boxes)
                
                if near_person and confidence > 0.4:
                    threats.append({
                        'type': 'BLADE',
                        'class': 'knife',
                        'confidence': confidence,
                        'severity': 'HIGH',
                        'bbox': det.get('bbox'),
                        'message': '⚠️ KNIFE DETECTED near person'
                    })
                    logger.warning(f"🔪 THREAT: Knife detected near person - confidence {confidence:.2%}")
            
            elif class_name == 'baseball bat':
                # Baseball bat could be a weapon if held aggressively
                bat_center = self._get_box_center(det)
                near_person = any(self._is_near_box(bat_center, p, threshold=80) for p in person_boxes)
                
                if near_person and confidence > 0.5:
                    threats.append({
                        'type': 'BLUNT',
                        'class': 'baseball bat',
                        'confidence': confidence,
                        'severity': 'MEDIUM',
                        'bbox': det.get('bbox'),
                        'message': '⚠️ BASEBALL BAT detected being held'
                    })
                    logger.warning(f"🏏 THREAT: Baseball bat detected - confidence {confidence:.2%}")
        
        # Visual gun detection using shape analysis
        gun_threats = self._detect_gun_shapes(frame, person_boxes)
        threats.extend(gun_threats)
        
        return threats
    
    def _get_box_center(self, detection):
        """Get center point of a detection bounding box.
        Supports both x1/y1/x2/y2 format AND x/y/width/height format."""
        bbox = detection.get('bbox', {})
        if isinstance(bbox, dict):
            if 'x1' in bbox:
                x1, y1, x2, y2 = bbox['x1'], bbox['y1'], bbox['x2'], bbox['y2']
            else:
                x = bbox.get('x', 0)
                y = bbox.get('y', 0)
                x1, y1 = x, y
                x2 = x + bbox.get('width', 0)
                y2 = y + bbox.get('height', 0)
        else:
            x1, y1, x2, y2 = bbox[:4] if len(bbox) >= 4 else (0, 0, 0, 0)
        return ((x1 + x2) / 2, (y1 + y2) / 2)
    
    def _is_near_box(self, point, detection, threshold=100):
        """Check if a point is near a detection box.
        Supports both x1/y1/x2/y2 format AND x/y/width/height format."""
        bbox = detection.get('bbox', {})
        if isinstance(bbox, dict):
            if 'x1' in bbox:
                x1, y1, x2, y2 = bbox['x1'], bbox['y1'], bbox['x2'], bbox['y2']
            else:
                x = bbox.get('x', 0)
                y = bbox.get('y', 0)
                x1, y1 = x, y
                x2 = x + bbox.get('width', 0)
                y2 = y + bbox.get('height', 0)
        else:
            x1, y1, x2, y2 = bbox[:4] if len(bbox) >= 4 else (0, 0, 0, 0)
        
        px, py = point
        return (x1 - threshold <= px <= x2 + threshold and 
                y1 - threshold <= py <= y2 + threshold)
    
    def _detect_gun_shapes(self, frame, person_boxes):
        """
        Visual fallback to detect gun-like shapes near person hands.
        Only used when no trained weapon model is loaded.
        Uses edge detection and shape analysis with strict thresholds to reduce false positives.
        """
        threats = []
        
        # Skip visual shape detection when a trained weapon model is available —
        # the model is far more accurate; visual shapes cause false positives (umbrellas, bags, straps)
        if getattr(self, 'weapon_model', None) is not None:
            return threats
        
        try:
            if len(person_boxes) == 0:
                return threats
            
            gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
            
            for person in person_boxes:
                bbox = person.get('bbox', {})
                if isinstance(bbox, dict):
                    if 'x1' in bbox:
                        x1, y1, x2, y2 = int(bbox['x1']), int(bbox['y1']), int(bbox['x2']), int(bbox['y2'])
                    else:
                        x1 = int(bbox.get('x', 0))
                        y1 = int(bbox.get('y', 0))
                        x2 = x1 + int(bbox.get('width', 0))
                        y2 = y1 + int(bbox.get('height', 0))
                else:
                    continue
                
                # Focus on hand regions (sides of person box)
                person_width = x2 - x1
                person_height = y2 - y1
                
                # Check right side (right hand area)
                hand_region_right = gray[max(0, y1 + person_height//3):y2, x2:min(frame.shape[1], x2 + person_width//2)]
                # Check left side (left hand area)
                hand_region_left = gray[max(0, y1 + person_height//3):y2, max(0, x1 - person_width//2):x1]
                
                for region_name, region in [('right', hand_region_right), ('left', hand_region_left)]:
                    if region.size == 0:
                        continue
                    
                    # Edge detection
                    edges = cv2.Canny(region, 50, 150)
                    
                    # Find contours
                    contours, _ = cv2.findContours(edges, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
                    
                    for contour in contours:
                        area = cv2.contourArea(contour)
                        # Strict size range — must be large enough to be a real handheld object
                        # (rules out pens, straps, thin bags that are too small)
                        if area < 800 or area > 3500:
                            continue
                        
                        # Check aspect ratio — guns are elongated but not as extreme as umbrellas/straps
                        x, y, w, h = cv2.boundingRect(contour)
                        aspect_ratio = w / h if h > 0 else 0
                        
                        # Tighter aspect ratio range (2.0–3.5) reduces bags/umbrellas
                        if 2.0 <= aspect_ratio <= 3.5:
                            # Additional check: contour complexity
                            perimeter = cv2.arcLength(contour, True)
                            complexity = perimeter ** 2 / (4 * 3.14159 * area) if area > 0 else 0
                            
                            # Tighter complexity: excludes simple rectangles (bags) and very jagged shapes
                            if 2.5 <= complexity <= 7.0:
                                threats.append({
                                    'type': 'FIREARM_POSSIBLE',
                                    'class': 'gun-like object',
                                    'confidence': 0.40,
                                    'severity': 'HIGH',
                                    'bbox': {'x1': x1, 'y1': y1, 'x2': x2, 'y2': y2},
                                    'message': '🔫 POSSIBLE FIREARM detected (visual analysis — no trained model)',
                                    'visual_detection': True
                                })
                                logger.warning(f"🔫 POTENTIAL THREAT: Gun-like shape detected near person ({region_name} hand area)")
                                break  # One detection per person is enough
                
        except Exception as e:
            logger.error(f"Error in visual gun shape detection: {e}")
        
        return threats
    
    def send_threat_alert(self, camera, threat, frame, telegram_service):
        """
        Send HIGH PRIORITY threat alert via Telegram.
        Threat alerts bypass normal cooldown and snooze.
        """
        try:
            camera_id = camera.id
            current_time = datetime.utcnow()
            
            # Threat-specific cooldown (30 seconds between same threat type)
            if camera_id in self.threat_alerts:
                last_alert = self.threat_alerts[camera_id]
                if (current_time - last_alert.get('time', current_time)).total_seconds() < 30:
                    if last_alert.get('type') == threat.get('type'):
                        return  # Don't spam same threat
            
            # Update threat tracking
            self.threat_alerts[camera_id] = {
                'time': current_time,
                'type': threat.get('type')
            }
            
            severity = threat.get('severity', 'HIGH')
            threat_type = threat.get('type', 'UNKNOWN')
            message = threat.get('message', 'Threat detected')
            confidence = threat.get('confidence', 0)
            
            # Build alert message
            alert_text = (
                f"🚨🚨🚨 <b>THREAT ALERT</b> 🚨🚨🚨\n\n"
                f"⚠️ <b>Severity:</b> {severity}\n"
                f"🔫 <b>Type:</b> {threat_type}\n"
                f"📷 <b>Camera:</b> {camera.name}\n"
                f"📍 <b>Location:</b> {camera.location or 'Unknown'}\n"
                f"🎯 <b>Confidence:</b> {confidence:.1%}\n\n"
                f"<b>{message}</b>\n\n"
                f"⏰ {current_time.strftime('%Y-%m-%d %H:%M:%S')}\n\n"
                f"<i>🚨 IMMEDIATE ATTENTION REQUIRED 🚨</i>"
            )
            
            # Draw threat box on frame
            if frame is not None and threat.get('bbox'):
                annotated = frame.copy()
                bbox = threat['bbox']
                if isinstance(bbox, dict):
                    x1, y1, x2, y2 = int(bbox['x1']), int(bbox['y1']), int(bbox['x2']), int(bbox['y2'])
                else:
                    x1, y1, x2, y2 = map(int, bbox[:4])
                
                # Draw red box for threat
                cv2.rectangle(annotated, (x1, y1), (x2, y2), (0, 0, 255), 3)
                cv2.putText(annotated, f"THREAT: {threat_type}", (x1, y1-10), 
                           cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 0, 255), 2)
                
                # Send with image
                telegram_service.send_alert_with_image(alert_text, annotated, camera.name)
            else:
                telegram_service.send_message(alert_text)
            
            logger.warning(f"🚨 THREAT ALERT SENT: {threat_type} on {camera.name}")
            
        except Exception as e:
            logger.error(f"Error sending threat alert: {e}")
    
    # =========================================================================
    # BEHAVIOR ANALYSIS
    # =========================================================================
    def analyze_behavior(self, frame, detections, camera):
        """
        Analyze person behavior patterns:
        - Running (fast movement)
        - Fighting (multiple people, rapid movements)
        - Falling (sudden vertical position change)
        - Crowd formation (many people gathering)
        
        Returns list of behavior events
        """
        behaviors = []
        
        if not hasattr(camera, 'enable_behavior_analysis') or not camera.enable_behavior_analysis:
            return behaviors
        
        camera_id = camera.id
        current_time = datetime.utcnow()
        
        # Filter person detections
        person_detections = [d for d in detections if d.get('class') == 'person']
        
        if not person_detections:
            return behaviors
        
        # Initialize tracking for this camera
        if camera_id not in self.person_positions:
            self.person_positions[camera_id] = {}
        
        # Update position history
        for det in person_detections:
            track_id = det.get('track_id', id(det))  # Use object id if no track_id
            center = self._get_box_center(det)
            
            if track_id not in self.person_positions[camera_id]:
                self.person_positions[camera_id][track_id] = []
            
            # Keep last 30 positions (about 1-2 seconds at 15-30fps)
            positions = self.person_positions[camera_id][track_id]
            positions.append({
                'x': center[0], 
                'y': center[1], 
                'time': current_time,
                'bbox': det.get('bbox')
            })
            
            # Limit history
            if len(positions) > 30:
                self.person_positions[camera_id][track_id] = positions[-30:]
        
        # Detect running
        if getattr(camera, 'detect_running', True):
            running = self._detect_running(camera_id)
            if running:
                behaviors.append(running)
        
        # Detect falling
        if getattr(camera, 'detect_falling', True):
            falling = self._detect_falling(camera_id)
            if falling:
                behaviors.append(falling)
        
        # Detect fighting (requires 2+ people)
        if getattr(camera, 'detect_fighting', True) and len(person_detections) >= 2:
            fighting = self._detect_fighting(camera_id, person_detections)
            if fighting:
                behaviors.append(fighting)
        
        # Clean up old tracking data
        self._cleanup_behavior_tracking(camera_id)
        
        return behaviors
    
    def _detect_running(self, camera_id):
        """Detect if any person is running (fast horizontal movement)"""
        positions = self.person_positions.get(camera_id, {})
        
        for track_id, pos_history in positions.items():
            if len(pos_history) < 10:
                continue
            
            # Calculate speed over recent frames
            recent = pos_history[-10:]
            if len(recent) < 2:
                continue
            
            time_diff = (recent[-1]['time'] - recent[0]['time']).total_seconds()
            if time_diff <= 0:
                continue
            
            # Calculate distance moved
            dx = recent[-1]['x'] - recent[0]['x']
            dy = recent[-1]['y'] - recent[0]['y']
            distance = (dx**2 + dy**2) ** 0.5
            
            speed = distance / time_diff  # pixels per second
            
            # Running threshold: >200 pixels/second with mostly horizontal movement
            if speed > 200 and abs(dx) > abs(dy) * 0.7:
                return {
                    'type': 'running',
                    'severity': 'medium',
                    'track_id': track_id,
                    'speed': speed,
                    'description': f'Person running detected (speed: {speed:.0f} px/s)',
                    'bbox': recent[-1].get('bbox')
                }
        
        return None
    
    def _detect_falling(self, camera_id):
        """Detect if any person has fallen (rapid vertical movement + low position)"""
        positions = self.person_positions.get(camera_id, {})
        
        for track_id, pos_history in positions.items():
            if len(pos_history) < 5:
                continue
            
            recent = pos_history[-5:]
            
            # Check for rapid downward movement
            y_start = recent[0]['y']
            y_end = recent[-1]['y']
            
            time_diff = (recent[-1]['time'] - recent[0]['time']).total_seconds()
            if time_diff <= 0:
                continue
            
            vertical_speed = (y_end - y_start) / time_diff
            
            # Falling: >150 pixels/second downward
            if vertical_speed > 150:
                # Check if now in lower portion of frame (fallen position)
                bbox = recent[-1].get('bbox', {})
                if isinstance(bbox, dict):
                    # Support both x1/y1/x2/y2 and x/y/width/height bbox formats
                    height = bbox.get('height', bbox.get('y2', 0) - bbox.get('y1', 0))
                    # Trigger only when bounding box is very flat — person is truly lying down
                    if height < 60:  # Truly horizontal/lying (not just bending over)
                        return {
                            'type': 'fall',
                            'severity': 'high',
                            'track_id': track_id,
                            'description': 'Person may have fallen!',
                            'bbox': bbox
                        }
        
        return None
    
    def _detect_fighting(self, camera_id, person_detections):
        """Detect potential fighting (close proximity + rapid movements of 2+ people)"""
        if len(person_detections) < 2:
            return None
        
        positions = self.person_positions.get(camera_id, {})
        
        # Check for close proximity between people
        for i, det1 in enumerate(person_detections):
            center1 = self._get_box_center(det1)
            
            for det2 in person_detections[i+1:]:
                center2 = self._get_box_center(det2)
                
                # Distance between people
                distance = ((center1[0] - center2[0])**2 + (center1[1] - center2[1])**2) ** 0.5
                
                # Very close proximity (fighting distance)
                if distance < 80:  # Adjust threshold
                    # Check if both are moving rapidly
                    track1 = det1.get('track_id', id(det1))
                    track2 = det2.get('track_id', id(det2))
                    
                    moving_fast = 0
                    for track_id in [track1, track2]:
                        if track_id in positions and len(positions[track_id]) >= 5:
                            recent = positions[track_id][-5:]
                            dx = recent[-1]['x'] - recent[0]['x']
                            dy = recent[-1]['y'] - recent[0]['y']
                            movement = (dx**2 + dy**2) ** 0.5
                            if movement > 50:  # Significant movement
                                moving_fast += 1
                    
                    if moving_fast >= 2:
                        return {
                            'type': 'fighting',
                            'severity': 'critical',
                            'person_count': 2,
                            'description': 'Possible altercation detected!',
                            'bbox': det1.get('bbox')
                        }
        
        return None
    
    def _cleanup_behavior_tracking(self, camera_id):
        """Remove stale tracking data"""
        if camera_id not in self.person_positions:
            return
        
        current_time = datetime.utcnow()
        to_remove = []
        
        for track_id, positions in self.person_positions[camera_id].items():
            if positions:
                last_seen = positions[-1]['time']
                if (current_time - last_seen).total_seconds() > 5:
                    to_remove.append(track_id)
        
        for track_id in to_remove:
            del self.person_positions[camera_id][track_id]

        # Prune track_movement entries for this camera older than 30 seconds
        # (track IDs accumulate forever without this — causes OOM on 24/7 Pi operation)
        cam_prefix = f"{camera_id}_"
        with self._tracking_lock:
            stale_move_keys = [
                k for k, v in list(self.track_movement.items())
                if k.startswith(cam_prefix) and (current_time - v['time']).total_seconds() > 30
            ]
            for k in stale_move_keys:
                self.track_movement.pop(k, None)

            # Prune zone_alert_times entries older than 10 minutes
            # (keys include track_ids for crossing events — grow without bound otherwise)
            stale_alert_keys = [
                k for k, v in list(self.zone_alert_times.items())
                if (current_time - v).total_seconds() > 600
            ]
            for k in stale_alert_keys:
                self.zone_alert_times.pop(k, None)

            # Prune daily_stats_cache entries for dates older than today
            today_str = current_time.strftime('%Y-%m-%d')
            stale_stats_keys = [
                k for k in list(self.daily_stats_cache.keys())
                if not k.endswith(today_str)
            ]
            for k in stale_stats_keys:
                self.daily_stats_cache.pop(k, None)
    
    def get_track_trails(self, camera_id):
        """Return live movement trails for all tracked objects on a camera.
        Coordinates are in 800x600 canvas space matching zone polygon coordinates.
        Stale trails (older than 5s) are automatically pruned.
        """
        cutoff = time.time() - 5.0
        raw = self.camera_track_trails.get(camera_id, {})
        result = {}
        for tid, pts in list(raw.items()):
            recent = [p for p in pts if p.get('t', 0) > cutoff]
            if recent:
                result[tid] = recent
        # Store pruned version back
        self.camera_track_trails[camera_id] = {tid: pts for tid, pts in raw.items() if tid in result}
        return result

    def send_behavior_alert(self, camera, behavior, frame, telegram_service):
        """Send behavior analysis alert"""
        try:
            camera_id = camera.id
            behavior_type = behavior.get('type')
            current_time = datetime.utcnow()
            
            # Cooldown per behavior type (60 seconds)
            if camera_id not in self.behavior_alerts:
                self.behavior_alerts[camera_id] = {}
            
            last_alert = self.behavior_alerts[camera_id].get(behavior_type)
            if last_alert and (current_time - last_alert).total_seconds() < 60:
                return
            
            self.behavior_alerts[camera_id][behavior_type] = current_time
            
            severity = behavior.get('severity', 'medium')
            severity_emoji = {'low': '⚠️', 'medium': '🟡', 'high': '🔴', 'critical': '🚨'}
            
            alert_text = (
                f"{severity_emoji.get(severity, '⚠️')} <b>BEHAVIOR ALERT</b>\n\n"
                f"📋 <b>Type:</b> {behavior_type.upper()}\n"
                f"📷 <b>Camera:</b> {camera.name}\n"
                f"📍 <b>Location:</b> {camera.location or 'Unknown'}\n"
                f"📝 <b>Details:</b> {behavior.get('description', 'N/A')}\n"
                f"⏰ {current_time.strftime('%Y-%m-%d %H:%M:%S')}"
            )
            
            if frame is not None:
                telegram_service.send_alert_with_image(alert_text, frame, camera.name)
            else:
                telegram_service.send_message(alert_text)
            
            logger.info(f"🏃 Behavior alert sent: {behavior_type} on {camera.name}")
            
        except Exception as e:
            logger.error(f"Error sending behavior alert: {e}")
    
    # =========================================================================
    # CROWD COUNTING
    # =========================================================================
    def count_people_in_zone(self, detections, zone):
        """Count people inside a detection zone"""
        if not zone or not zone.is_active:
            return 0
        
        polygon_points = zone.get_polygon_points()
        if not polygon_points:
            return 0
        
        # Convert to numpy polygon
        polygon = np.array(polygon_points, dtype=np.float32)
        
        count = 0
        for det in detections:
            if det.get('class') != 'person':
                continue
            
            center = self._get_box_center(det)
            # Check if center is inside polygon
            if self.point_in_polygon((center[0], center[1]), polygon_points):
                count += 1
        
        return count
    
    def check_crowd_capacity(self, camera, zones, detections, telegram_service=None):
        """Check if any zone is over capacity and send alerts"""
        alerts = []
        
        for zone in zones:
            if zone.zone_type != 'crowd' or not zone.max_capacity or zone.max_capacity <= 0:
                continue
            
            count = self.count_people_in_zone(detections, zone)
            
            # Update zone occupancy
            zone.current_occupancy = count
            
            # Check capacity threshold
            threshold_percent = zone.crowd_alert_threshold or 80
            capacity_percent = (count / zone.max_capacity) * 100
            
            if capacity_percent >= threshold_percent:
                is_over = count >= zone.max_capacity
                
                alert = {
                    'zone_id': zone.id,
                    'zone_name': zone.name,
                    'current_count': count,
                    'max_capacity': zone.max_capacity,
                    'capacity_percent': capacity_percent,
                    'is_over_capacity': is_over
                }
                alerts.append(alert)
                
                # Send alert
                if telegram_service:
                    self._send_crowd_alert(camera, zone, count, is_over, telegram_service)
        
        return alerts
    
    def _send_crowd_alert(self, camera, zone, count, is_over, telegram_service):
        """Send crowd capacity alert"""
        try:
            zone_id = zone.id
            current_time = datetime.utcnow()
            
            # Cooldown (5 minutes per zone)
            if zone_id not in self.zone_occupancy:
                self.zone_occupancy[zone_id] = {}
            
            last_alert = self.zone_occupancy[zone_id].get('last_alert')
            if last_alert and (current_time - last_alert).total_seconds() < 300:
                return
            
            self.zone_occupancy[zone_id]['last_alert'] = current_time
            
            if is_over:
                emoji = "🚨"
                status = "OVER CAPACITY"
            else:
                emoji = "⚠️"
                status = "NEAR CAPACITY"
            
            alert_text = (
                f"{emoji} <b>CROWD ALERT - {status}</b>\n\n"
                f"📍 <b>Zone:</b> {zone.name}\n"
                f"📷 <b>Camera:</b> {camera.name}\n"
                f"👥 <b>Current:</b> {count} people\n"
                f"📊 <b>Capacity:</b> {zone.max_capacity}\n"
                f"📈 <b>Usage:</b> {(count/zone.max_capacity)*100:.0f}%\n"
                f"⏰ {current_time.strftime('%Y-%m-%d %H:%M:%S')}"
            )
            
            telegram_service.send_message(alert_text)
            logger.info(f"👥 Crowd alert sent: {zone.name} at {count}/{zone.max_capacity}")
            
        except Exception as e:
            logger.error(f"Error sending crowd alert: {e}")
    
    # =========================================================================
    # GPU ACCELERATION
    # =========================================================================
    def init_gpu_acceleration(self):
        """Initialize GPU acceleration if available"""
        try:
            # Try Coral TPU
            try:
                from pycoral.utils import edgetpu  # type: ignore
                interpreters = edgetpu.list_edge_tpus()
                if interpreters:
                    self.use_gpu = True
                    self.gpu_type = 'coral'
                    logger.info("🚀 Coral TPU detected and enabled for acceleration")
                    return True
            except ImportError:
                pass
            
            # Try CUDA (NVIDIA)
            try:
                import torch
                if torch.cuda.is_available():
                    self.use_gpu = True
                    self.gpu_type = 'cuda'
                    logger.info(f"🚀 CUDA GPU detected: {torch.cuda.get_device_name(0)}")
                    return True
            except ImportError:
                pass
            
            # Try Hailo
            try:
                import hailo_platform  # type: ignore
                self.use_gpu = True
                self.gpu_type = 'hailo'
                logger.info("🚀 Hailo accelerator detected")
                return True
            except ImportError:
                pass
            
            logger.info("ℹ️ No GPU acceleration available, using CPU")
            return False
            
        except Exception as e:
            logger.debug(f"GPU init error: {e}")
            return False
    
    def should_send_alert(self, camera, detection=None, detected_class=None):
        """Check if alert should be sent based on cooldown, snooze, and zone-only mode"""
        # Check if camera is snoozed
        if hasattr(camera, 'is_snoozed') and camera.is_snoozed():
            logger.info(f"🔇 Camera {camera.name} is snoozed - skipping alert")
            return False
        
        # Per-class in-memory cooldown — each class (person, dog, etc.) has its own timer
        if detected_class:
            class_alerts = self.last_detection_alerts.get(camera.id, {})
            last_class_alert = class_alerts.get(detected_class)
            if last_class_alert:
                elapsed = (datetime.utcnow() - last_class_alert).total_seconds()
                cam_cooldown = getattr(camera, 'detection_cooldown_seconds', None) or camera.alert_cooldown
                if elapsed < cam_cooldown:
                    return False
        else:
            # Fallback to camera-wide DB cooldown when no class is specified
            if camera.last_alert_time:
                time_since_alert = datetime.utcnow() - camera.last_alert_time
                if time_since_alert.total_seconds() < camera.alert_cooldown:
                    return False
        
        # Check zone-only detection mode
        if hasattr(camera, 'zone_only_detection') and camera.zone_only_detection:
            # Only send alert if detection is in a zone
            if detection and 'zones' in detection:
                if not detection['zones']:
                    logger.info(f"📍 Zone-only mode: Detection not in any zone - skipping alert")
                    return False
            else:
                # No detection info, check if there are any zones defined
                from models import DetectionZone
                zones = DetectionZone.query.filter_by(camera_id=camera.id, is_active=True).all()
                if zones:
                    logger.info(f"📍 Zone-only mode: Detection has no zone info - skipping alert")
                    return False
        
        return True
    
    def get_ocr_reader(self):
        """Lazy load OCR reader (only when needed) - DISABLED for now"""
        # OCR disabled to avoid dependency issues
        return None
    
    def verify_pizza_box_text(self, frame, bbox):
        """
        Enhanced pizza box verification with better OCR and visual pattern recognition
        Returns True if 'pizza' text or pizza-related patterns are found
        """
        try:
            reader = self.get_ocr_reader()
            if reader is None:
                logger.warning("OCR not available, using visual pattern recognition")
                return self.verify_pizza_box_visual(frame, bbox)
            
            # Extract bounding box coordinates with padding for better OCR
            x1, y1, x2, y2 = map(int, bbox.values()) if isinstance(bbox, dict) else map(int, bbox)
            
            # Add padding around the box for better text capture
            padding = 10
            h, w = frame.shape[:2]
            x1 = max(0, x1 - padding)
            y1 = max(0, y1 - padding)
            x2 = min(w, x2 + padding)
            y2 = min(h, y2 + padding)
            
            # Crop the box region from frame
            box_region = frame[y1:y2, x1:x2]
            
            # Enhance image for better OCR
            enhanced_region = self.enhance_image_for_ocr(box_region)
            
            # Run OCR on the enhanced region
            results = reader.readtext(enhanced_region, detail=0, width_ths=0.7, height_ths=0.7)
            
            # Convert all text to lowercase and check for pizza-related keywords
            text = ' '.join(results).lower()
            
            # Enhanced pizza-related keywords
            pizza_keywords = [
                'pizza', 'pizzeria', 'pie', 'slice', 'margherita', 'pepperoni',
                'domino', 'papa', 'hut', 'little', 'caesar', 'delivery',
                'italian', 'cheese', 'tomato', 'dough', 'crust'
            ]
            
            found = any(keyword in text for keyword in pizza_keywords)
            
            # Also check for common pizza brand patterns
            brand_patterns = ['domino\'s', 'pizza hut', 'papa john', 'little caesar']
            brand_found = any(pattern in text for pattern in brand_patterns)
            
            if found or brand_found:
                logger.info(f"Pizza text/brand verified: '{text}'")
                return True
            
            # Fallback to visual pattern recognition
            visual_match = self.verify_pizza_box_visual(frame, [x1, y1, x2, y2])
            if visual_match:
                logger.info("Pizza box verified by visual patterns")
                return True
            
            logger.debug(f"No pizza indicators found. OCR result: '{text}'")
            return False
            
        except Exception as e:
            logger.error(f"Enhanced OCR verification failed: {e}")
            return self.verify_pizza_box_visual(frame, bbox)
    
    def enhance_image_for_ocr(self, image):
        """Enhance image quality for better OCR recognition"""
        try:
            # Convert to grayscale
            gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
            
            # Apply adaptive thresholding for better text contrast
            thresh = cv2.adaptiveThreshold(gray, 255, cv2.ADAPTIVE_THRESH_GAUSSIAN_C, cv2.THRESH_BINARY, 11, 2)
            
            # Denoise the image
            denoised = cv2.fastNlMeansDenoising(thresh)
            
            # Resize image for better OCR (if too small)
            h, w = denoised.shape
            if w < 200 or h < 100:
                scale_factor = max(200/w, 100/h, 1.5)
                new_w, new_h = int(w * scale_factor), int(h * scale_factor)
                denoised = cv2.resize(denoised, (new_w, new_h), interpolation=cv2.INTER_CUBIC)
            
            return denoised
        except Exception as e:
            logger.error(f"Error enhancing image for OCR: {e}")
            return image
    
    def verify_pizza_box_visual(self, frame, bbox):
        """Visual pattern recognition for pizza boxes (fallback method)"""
        try:
            x1, y1, x2, y2 = map(int, bbox.values()) if isinstance(bbox, dict) else map(int, bbox)
            
            # Extract box region
            box_region = frame[y1:y2, x1:x2]
            h, w = box_region.shape[:2]
            
            # Check aspect ratio (pizza boxes are typically square or slightly rectangular)
            aspect_ratio = w / h if h > 0 else 1
            if not (0.7 <= aspect_ratio <= 1.4):
                return False
            
            # Check size (pizza boxes should be reasonably large)
            box_area = w * h
            if box_area < 5000:  # Too small to be a pizza box
                return False
            
            # Check for rectangular/square shape patterns
            gray = cv2.cvtColor(box_region, cv2.COLOR_BGR2GRAY)
            edges = cv2.Canny(gray, 50, 150)
            
            # Find contours to check for box-like shape
            contours, _ = cv2.findContours(edges, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
            
            for contour in contours:
                # Approximate contour to polygon
                epsilon = 0.02 * cv2.arcLength(contour, True)
                approx = cv2.approxPolyDP(contour, epsilon, True)
                
                # Check if it's roughly rectangular (4 corners)
                if len(approx) >= 4:
                    contour_area = cv2.contourArea(contour)
                    if contour_area > (box_area * 0.3):  # Significant portion of the box
                        logger.debug("Visual pizza box pattern detected")
                        return True
            
            # Check color patterns (pizza boxes often have white/brown colors)
            mean_color = np.mean(box_region, axis=(0, 1))
            # Pizza boxes typically have colors in certain ranges
            if (mean_color[0] > 180 and mean_color[1] > 180 and mean_color[2] > 180) or \
               (mean_color[0] < 100 and mean_color[1] > 120 and mean_color[2] > 150):
                logger.debug("Visual pizza box color pattern detected")
                return True
            
            return False
            
        except Exception as e:
            logger.error(f"Error in visual pizza box verification: {e}")
            return False  # fail-safe: don't count on error
    
    def is_gray_frame(self, frame):
        """
        Detect truly blank / corrupt startup frames (Hikvision/DVR issue).
        ONLY rejects frames that are essentially solid-colour (no real content).
        Valid night/IR frames, low-contrast day scenes, concrete yards, etc.
        are NOT flagged - those are real images and must be used as-is.
        """
        if frame is None:
            return True
        try:
            if len(frame.shape) == 3:
                gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
            else:
                gray = frame

            variance = np.var(gray)
            mean_val  = np.mean(gray)

            # Truly blank / solid-color DVR startup frame
            if variance < 30:
                logger.debug(f"Blank startup frame: variance={variance:.1f}")
                return True

            # Completely black frame (disconnected camera / lens cap)
            if mean_val < 3:
                logger.debug(f"Black frame: mean={mean_val:.1f}")
                return True

            return False
        except Exception as e:
            logger.debug(f"Gray frame check error: {e}")
            return False
    
    def capture_main_stream_snapshot(self, camera, detections=None):
        """
        Return the best available frame for an alert snapshot.

        Priority order:
          1. The already-cached live frame from the detection loop  — fastest,
             correct colour/IR state, zero RTSP startup latency.
          2. A new RTSP grab from the main stream (higher resolution) — only
             used when no cached frame exists yet (camera just added).

        Opening a fresh RTSP connection for every alert was the main cause of
        gray alert photos: Hikvision/Provision cameras send ~20 blank startup
        frames before real video; by the time real frames arrive the alert may
        already have picked a blank one.
        """
        try:
            camera_id = camera.id
            frame = None

            # ── Step 1: prefer the live cached frame ─────────────────────────
            if hasattr(self, 'camera_frames'):
                cached = self.camera_frames.get(camera_id)
                if cached is not None and not self.is_gray_frame(cached):
                    frame = cached.copy()
                    logger.info(f"📷 Using cached live frame for alert on {camera.name}")

            # ── Step 2: RTSP fallback (only when cache is empty / truly blank) ─
            if frame is None:
                # Prefer working_rtsp_url (already verified), then main_stream_url, then rtsp_url
                snapshot_url = (
                    getattr(camera, 'working_rtsp_url', None)
                    or (camera.main_stream_url if camera.main_stream_url else None)
                    or camera.rtsp_url
                )
                if not snapshot_url:
                    logger.error(f"❌ No RTSP URL available for {camera.name}")
                    return None
                logger.info(f"📷 Capturing RTSP snapshot for {camera.name} (no cached frame)")
                import os
                os.environ['OPENCV_FFMPEG_CAPTURE_OPTIONS'] = 'rtsp_transport;tcp|analyzeduration;5000000|fflags;+nobuffer+discardcorrupt|err_detect;ignore_err|stimeout;8000000'
                _cap = cv2.VideoCapture(snapshot_url, cv2.CAP_FFMPEG)
                _cap.set(cv2.CAP_PROP_BUFFERSIZE, 1)
                _cap.set(cv2.CAP_PROP_OPEN_TIMEOUT_MSEC, 10000)
                _cap.set(cv2.CAP_PROP_READ_TIMEOUT_MSEC, 5000)
                try:
                    for _ in range(30):
                        ret, temp_frame = _cap.read()
                        if ret and temp_frame is not None:
                            if not self.is_gray_frame(temp_frame):
                                frame = temp_frame
                                break
                            frame = temp_frame  # keep last as fallback
                finally:
                    _cap.release()

            if frame is None:
                logger.error(f"❌ Could not capture snapshot from {camera.name}")
                return None

            # Draw detections if provided
            if detections:
                frame = self.draw_detections(frame.copy(), detections)

            return frame

        except Exception as e:
            logger.error(f"Error capturing main stream snapshot: {e}")
            return None
    
    def save_detection_image(self, frame, camera_id, detection_id):
        """Save detection image and thumbnail"""
        try:
            uploads_dir = Path(self.app.config['UPLOAD_FOLDER'])
            
            # Create camera folder
            camera_dir = uploads_dir / f"camera_{camera_id}"
            camera_dir.mkdir(exist_ok=True)
            
            # Generate filename
            timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
            filename = f"detection_{detection_id}_{timestamp}.jpg"
            thumb_filename = f"thumb_{detection_id}_{timestamp}.jpg"
            
            # Save full image
            image_path = camera_dir / filename
            cv2.imwrite(str(image_path), frame)
            
            # Create thumbnail
            thumb_frame = cv2.resize(frame, (320, 240))
            thumb_path = camera_dir / thumb_filename
            cv2.imwrite(str(thumb_path), thumb_frame)
            
            # Return relative paths from uploads folder
            relative_image = f"camera_{camera_id}/{filename}"
            relative_thumb = f"camera_{camera_id}/{thumb_filename}"
            
            return relative_image, relative_thumb
        except Exception as e:
            logger.error(f"Failed to save detection image: {e}")
            return None, None
    
    def process_detections(self, frame, results, camera, config):
        """Process YOLO detection results - ACCURATE HUMAN DETECTION with people counting and stock control"""
        # Get enabled classes based on camera settings
        enabled_classes = self.get_enabled_classes(camera)
        
        detections = []
        frame_height, frame_width = frame.shape[:2] if frame is not None else (480, 640)
        
        # Track people count for this frame
        people_count = 0
        
        # FIRST PASS: Collect all vehicle, bag, and ANIMAL detections to filter false person detections
        vehicle_classes = ['car', 'truck', 'bus', 'motorcycle', 'bicycle']
        vehicle_boxes = []
        
        # Also collect bag/luggage detections - often misdetected as persons
        bag_classes = ['backpack', 'handbag', 'suitcase', 'umbrella', 'tie']
        bag_boxes = []

        # Collect animal detections - dogs/cats frequently misdetected as persons at night
        animal_classes_filter = ['dog', 'cat', 'bird', 'horse', 'sheep', 'cow', 'zebra', 'giraffe']
        animal_boxes = []

        # Detect if the frame is night/IR mode (near-grayscale) for stricter thresholding
        is_night_ir_frame = False
        if frame is not None and len(frame.shape) == 3:
            import numpy as np
            b_ch, g_ch, r_ch = frame[:,:,0], frame[:,:,1], frame[:,:,2]
            channel_diff = max(abs(float(np.mean(r_ch)) - float(np.mean(g_ch))),
                               abs(float(np.mean(r_ch)) - float(np.mean(b_ch))),
                               abs(float(np.mean(g_ch)) - float(np.mean(b_ch))))
            ir_thresh = getattr(camera, 'night_ir_threshold', None) or 12.0
            if channel_diff < ir_thresh:  # All channels nearly equal = IR / night grayscale mode
                is_night_ir_frame = True
                logger.debug(f"🌙 Night/IR frame detected (channel diff={channel_diff:.1f}) - using strict thresholds")
        
        for result in results:
            if result.boxes is None:
                continue
            for box in result.boxes:
                cls_id = int(box.cls[0])
                cls_name = result.names[cls_id]
                conf = float(box.conf[0])
                if cls_name in vehicle_classes and conf > 0.3:
                    x1, y1, x2, y2 = box.xyxy[0].tolist()
                    vehicle_boxes.append({'x1': x1, 'y1': y1, 'x2': x2, 'y2': y2, 'class': cls_name})
                elif cls_name in bag_classes and conf > 0.25:
                    x1, y1, x2, y2 = box.xyxy[0].tolist()
                    bag_boxes.append({'x1': x1, 'y1': y1, 'x2': x2, 'y2': y2, 'class': cls_name})
                elif cls_name in animal_classes_filter and conf > 0.15:
                    # Lower bar (0.15) so even borderline dog/cat detections suppress nearby person false alarms
                    x1, y1, x2, y2 = box.xyxy[0].tolist()
                    animal_boxes.append({'x1': x1, 'y1': y1, 'x2': x2, 'y2': y2, 'class': cls_name})
        
        if vehicle_boxes:
            logger.info(f"🚗 Found {len(vehicle_boxes)} vehicles - will filter overlapping person detections")
        if bag_boxes:
            logger.info(f"🎒 Found {len(bag_boxes)} bags/luggage - will filter overlapping person detections")
        if animal_boxes:
            logger.info(f"🐾 Found {len(animal_boxes)} animals - will filter false person detections nearby")
        
        # Pre-fetch zones ONCE per frame (not once per detection inside the loop)
        cached_zones = []
        if config.enable_zone_detection:
            cached_zones = DetectionZone.query.filter_by(camera_id=camera.id, is_active=True).all()
        
        for result in results:
            boxes = result.boxes
            if boxes is None:
                continue
                
            for box in boxes:
                # Get detection info
                cls_id = int(box.cls[0])
                conf = float(box.conf[0])
                cls_name = result.names[cls_id]
                
                logger.debug(f"🔍 YOLO detected: {cls_name} with confidence {conf:.3f}")
                
                # SKIP VEHICLES when vehicle detection is disabled or unlicensed
                # (they were already collected for filtering, don't add to detections)
                vehicle_classes_set = {'car', 'truck', 'bus', 'motorcycle', 'bicycle'}
                if cls_name in vehicle_classes_set:
                    if not camera.enable_vehicle_detection or not _check_license('vehicle_detection'):
                        logger.debug(f"⏭️ Skipping {cls_name} - vehicle detection is disabled or unlicensed")
                        continue

                # SKIP OBJECTS when object detection is disabled or unlicensed
                object_classes_set = {
                    'backpack', 'umbrella', 'handbag', 'tie', 'suitcase',
                    'chair', 'couch', 'bed', 'dining table', 'toilet',
                    'tv', 'laptop', 'mouse', 'remote', 'keyboard', 'cell phone',
                    'book', 'clock', 'vase', 'scissors', 'teddy bear', 'hair drier', 'toothbrush',
                    'bench', 'potted plant', 'sink', 'refrigerator', 'microwave', 'oven', 'toaster',
                }
                if cls_name in object_classes_set:
                    if not getattr(camera, 'enable_object_detection', False) or not _check_license('object_detection'):
                        logger.debug(f"⏭️ Skipping {cls_name} - object detection is disabled or unlicensed")
                        continue
                
                # Stock control mode - allow more classes
                if camera.enable_stock_control:
                    # Enhanced stock item detection including pizza boxes
                    stock_classes = ['pizza', 'box', 'suitcase', 'bottle', 'cup', 'bowl',
                                   'banana', 'apple', 'orange', 'sandwich', 'donut', 'cake',
                                   'hot dog', 'carrot', 'broccoli', 'fork', 'knife', 'spoon',
                                   'wine glass', 'plate']
                    
                    if cls_name.lower() in stock_classes or cls_name.lower() in [c.lower() for c in enabled_classes]:
                        # Get bounding box
                        x1, y1, x2, y2 = box.xyxy[0].tolist()
                        bbox_width = int(x2 - x1)
                        bbox_height = int(y2 - y1)
                        
                        # Track ID for item tracking
                        track_id = None
                        if hasattr(box, 'id') and box.id is not None:
                            track_id = int(box.id[0])
                        
                        detection = {
                            'class': cls_name,
                            'confidence': conf,
                            'track_id': track_id,
                            'bbox': {
                                'x': int(x1),
                                'y': int(y1),
                                'width': bbox_width,
                                'height': bbox_height
                            },
                            'center': [(x1 + x2) / 2, (y1 + y2) / 2],
                            'zones': [],
                            'is_stock_item': True
                        }
                        
                        detections.append(detection)
                        logger.debug(f"✅ Stock item detected: {cls_name}")
                        continue
                
                # Person detection with enhanced validation
                if cls_name != 'person':
                    if cls_name not in enabled_classes:
                        logger.debug(f"❌ Ignoring non-enabled detection: {cls_name}")
                        continue
                
                # Use TIME-BASED sensitivity from camera if available, otherwise use config
                if hasattr(camera, 'get_current_sensitivity') and camera.get_current_sensitivity():
                    config_confidence = camera.get_current_sensitivity()
                    logger.debug(f"📊 Using camera time-based sensitivity: {config_confidence:.2f}")
                else:
                    # Fallback to system config
                    config_confidence = config.detection_confidence if config and hasattr(config, 'detection_confidence') else 0.75
                    # Ensure it's in 0-1 range (handle if stored as percentage)
                    if config_confidence > 1:
                        config_confidence = config_confidence / 100.0

                # Always also respect the system-wide detection_confidence so that raising
                # it in Settings actually tightens alerts — the per-camera day/night slider
                # defaults to 0.35 which was silently ignoring the system setting.
                system_conf = config.detection_confidence if config and hasattr(config, 'detection_confidence') else 0.75
                if system_conf > 1:
                    system_conf /= 100.0

                # For person detection, use the sensitivity setting
                # Use a soft minimum so the per-camera person_sensitivity slider
                # actually controls the threshold (0.75 day / 0.85 night floor).
                if cls_name == 'person':
                    cam_person_sens = getattr(camera, 'person_sensitivity', None)
                    base = cam_person_sens if cam_person_sens and 0.3 <= cam_person_sens <= 0.99 else max(config_confidence, system_conf)
                    if is_night_ir_frame:
                        confidence_threshold = max(base, 0.88)
                    else:
                        confidence_threshold = max(base, 0.80)
                elif cls_name in self.class_confidence_overrides:
                    # Animals: use per-camera animal_sensitivity slider (default 0.88)
                    # This prevents misclassifications like dog→bear at lower confidences
                    cam_animal_sens = getattr(camera, 'animal_sensitivity', None)
                    if cam_animal_sens and 0.3 <= cam_animal_sens <= 0.99:
                        confidence_threshold = cam_animal_sens
                    else:
                        confidence_threshold = self.class_confidence_overrides[cls_name]
                elif cls_name in vehicle_classes_set:
                    # Vehicles: use per-camera vehicle_sensitivity slider (default 0.65)
                    # Raise to 0.75-0.85 to avoid stationary objects (trailers, parked cars) causing false alerts
                    cam_vehicle_sens = getattr(camera, 'vehicle_sensitivity', None)
                    confidence_threshold = cam_vehicle_sens if cam_vehicle_sens and 0.3 <= cam_vehicle_sens <= 0.99 else 0.65
                else:
                    confidence_threshold = max(config_confidence - 0.10, 0.50)  # Minimum 50% for other classes
                
                logger.debug(f"📊 Using confidence threshold: {confidence_threshold:.2f}")
                
                if conf < confidence_threshold:
                    logger.debug(f"❌ Detection filtered - confidence too low ({conf:.3f} < {confidence_threshold})")
                    continue
                
                # Get bounding box
                x1, y1, x2, y2 = box.xyxy[0].tolist()
                bbox_width = int(x2 - x1)
                bbox_height = int(y2 - y1)
                bbox_area = bbox_width * bbox_height

                # === ANIMAL SIZE VALIDATION ===
                if cls_name in self.class_categories['animal']:
                    animal_min_px = getattr(camera, 'animal_min_size', None) or 1500
                    if bbox_area < animal_min_px:  # per-camera px² threshold
                        logger.debug(f"❌ Animal detection too small: {bbox_area}px² (min {animal_min_px})")
                        continue
                    # Exclusion zone still applies to animals
                    det_center = [(x1 + x2) / 2, (y1 + y2) / 2]
                    if self.point_in_exclusion_zone(det_center, camera):
                        logger.debug(f"❌ Animal detection in exclusion zone")
                        continue

                # === HUMAN SHAPE VALIDATION (only for person class) ===
                if cls_name == 'person':
                    # 1. Minimum size - humans should be reasonably large in frame
                    min_area = 500  # 500 pixels to catch smaller/distant people
                    if bbox_area < min_area:
                        logger.info(f"❌ Detection too small for human: {bbox_area} < {min_area} pixels")
                        continue

                    # Small detection guard: tiny bounding boxes (< 4000px²) are easily
                    # confused with small animals (puppies, cats). Animals tend to be
                    # roughly square (aspect_ratio < 1.2); children/people are always
                    # taller than wide (aspect_ratio >= 1.2). Only apply the high-conf
                    # guard to wide/square detections so distant kids still pass through.
                    if bbox_area < 4000:
                        aspect_ratio_prelim = bbox_height / bbox_width if bbox_width > 0 else 0
                        if aspect_ratio_prelim < 1.2 and conf < 0.88:
                            logger.info(f"❌ Small square detection ({bbox_area}px², AR={aspect_ratio_prelim:.2f}) conf={conf:.2f} - likely animal false alarm")
                            continue
                    
                    # 2. Aspect ratio check - humans are typically taller than wide
                    aspect_ratio = bbox_height / bbox_width if bbox_width > 0 else 0
                    
                    # Allow seated/crouching people (aspect_ratio >= 0.5)
                    if aspect_ratio < 0.5:
                        logger.info(f"❌ Aspect ratio too wide for human ({aspect_ratio:.2f}) - likely furniture")
                        continue
                    
                    if aspect_ratio > 5.0:
                        logger.info(f"❌ Aspect ratio too narrow ({aspect_ratio:.2f}) - unlikely to be human")
                        continue
                    
                    # 3. Size relative to frame
                    frame_area = frame_width * frame_height
                    size_ratio = bbox_area / frame_area
                    
                    if size_ratio < 0.001:  # Reduced from 0.005 to allow smaller detections
                        logger.info(f"❌ Detection too small relative to frame ({size_ratio:.4f})")
                        continue
                    
                    # 4. Position sanity check
                    if x1 < 0 or y1 < 0 or x2 > frame_width or y2 > frame_height:
                        logger.info(f"❌ Detection partially outside frame bounds")
                        continue
                    
                    # 5. STATIONARY OBJECT CHECK - Reject detections that don't move
                    # Chairs/furniture are stationary, humans move
                    # Get track_id for movement check
                    track_id = None
                    if hasattr(box, 'id') and box.id is not None:
                        track_id = int(box.id[0])
                    
                    if track_id is not None:
                        track_key = f"{camera.id}_{track_id}"
                        self.track_movement[track_key] = {'x': x1, 'y': y1, 'time': datetime.utcnow()}
                    
                    # 6. Additional check for medium confidence - stricter at night
                    if is_night_ir_frame:
                        if conf < 0.75 and aspect_ratio < 0.8:
                            logger.info(f"❌ Night IR: low confidence ({conf:.2f}) with poor aspect ratio ({aspect_ratio:.2f}) - rejecting")
                            continue
                    elif conf < 0.55 and aspect_ratio < 0.8:
                        logger.info(f"❌ Low confidence ({conf:.2f}) with poor aspect ratio ({aspect_ratio:.2f}) - rejecting")
                        continue
                    
                    # ANIMAL OVERLAP / PROXIMITY CHECK - Reject person detections near/overlapping with animals
                    # Dogs/cats are frequently misdetected as persons, especially at night in IR mode
                    if animal_boxes:
                        person_center_x = (x1 + x2) / 2
                        person_center_y = (y1 + y2) / 2
                        overlaps_animal = False
                        for abox in animal_boxes:
                            # Check bounding box overlap
                            ix1 = max(x1, abox['x1'])
                            iy1 = max(y1, abox['y1'])
                            ix2 = min(x2, abox['x2'])
                            iy2 = min(y2, abox['y2'])
                            if ix1 < ix2 and iy1 < iy2:
                                intersection = (ix2 - ix1) * (iy2 - iy1)
                                overlap_ratio = intersection / bbox_area if bbox_area > 0 else 0
                                if overlap_ratio > 0.25:  # 25% overlap = likely same object misclassified
                                    logger.info(f"❌ Person detection overlaps {overlap_ratio:.1%} with {abox['class']} - REJECTING as animal false alarm")
                                    overlaps_animal = True
                                    break
                            # Check proximity - if animal is very close and confidence is not very high
                            abox_center_x = (abox['x1'] + abox['x2']) / 2
                            abox_center_y = (abox['y1'] + abox['y2']) / 2
                            distance = ((person_center_x - abox_center_x)**2 + (person_center_y - abox_center_y)**2) ** 0.5
                            bbox_diagonal = (bbox_width**2 + bbox_height**2) ** 0.5
                            # If animal centroid is within bbox size distance and confidence < 0.90, reject
                            if distance < bbox_diagonal * 0.75 and conf < 0.90:
                                logger.info(f"❌ Person detection too close to {abox['class']} (dist={distance:.0f}) conf={conf:.2f} - REJECTING as animal false alarm")
                                overlaps_animal = True
                                break
                        if overlaps_animal:
                            continue

                    # 7. VEHICLE OVERLAP CHECK - Filter person detections that overlap with vehicles
                    if vehicle_boxes:
                        person_box = {'x1': x1, 'y1': y1, 'x2': x2, 'y2': y2}
                        overlaps_vehicle = False
                        for vbox in vehicle_boxes:
                            # Calculate intersection over union (IoU) or simple overlap
                            ix1 = max(person_box['x1'], vbox['x1'])
                            iy1 = max(person_box['y1'], vbox['y1'])
                            ix2 = min(person_box['x2'], vbox['x2'])
                            iy2 = min(person_box['y2'], vbox['y2'])
                            
                            if ix1 < ix2 and iy1 < iy2:
                                intersection = (ix2 - ix1) * (iy2 - iy1)
                                person_area = bbox_area
                                overlap_ratio = intersection / person_area if person_area > 0 else 0
                                
                                # Also check if person center is inside vehicle box
                                person_center_x = (person_box['x1'] + person_box['x2']) / 2
                                person_center_y = (person_box['y1'] + person_box['y2']) / 2
                                center_in_vehicle = (vbox['x1'] <= person_center_x <= vbox['x2'] and 
                                                    vbox['y1'] <= person_center_y <= vbox['y2'])
                                
                                # If person center is inside vehicle, very likely false positive
                                if center_in_vehicle and conf < 0.75:
                                    logger.info(f"❌ Person center inside {vbox['class']} with conf {conf:.2f} - REJECTING as vehicle misdetection")
                                    overlaps_vehicle = True
                                    break
                                
                                # If more than 40% of person box overlaps with vehicle, it's likely a false positive
                                if overlap_ratio > 0.4:
                                    logger.info(f"❌ Person detection overlaps {overlap_ratio:.1%} with {vbox['class']} - REJECTING as false positive")
                                    overlaps_vehicle = True
                                    break
                                # For medium confidence, even 25% overlap is suspicious
                                elif overlap_ratio > 0.25 and conf < 0.65:
                                    logger.info(f"❌ Medium confidence person ({conf:.2f}) overlaps {overlap_ratio:.1%} with {vbox['class']} - REJECTING")
                                    overlaps_vehicle = True
                                    break
                        
                        if overlaps_vehicle:
                            continue
                    
                    # 7. BAG/LUGGAGE OVERLAP CHECK - Filter person detections that overlap with bags
                    if bag_boxes:
                        person_box = {'x1': x1, 'y1': y1, 'x2': x2, 'y2': y2}
                        overlaps_bag = False
                        for bbox in bag_boxes:
                            ix1 = max(person_box['x1'], bbox['x1'])
                            iy1 = max(person_box['y1'], bbox['y1'])
                            ix2 = min(person_box['x2'], bbox['x2'])
                            iy2 = min(person_box['y2'], bbox['y2'])
                            
                            if ix1 < ix2 and iy1 < iy2:
                                intersection = (ix2 - ix1) * (iy2 - iy1)
                                bag_area = (bbox['x2'] - bbox['x1']) * (bbox['y2'] - bbox['y1'])
                                person_area = bbox_area
                                
                                # Check overlap ratio for both boxes
                                overlap_with_person = intersection / person_area if person_area > 0 else 0
                                overlap_with_bag = intersection / bag_area if bag_area > 0 else 0
                                
                                # If person box significantly overlaps with bag, likely a false positive
                                if overlap_with_person > 0.6 or overlap_with_bag > 0.6:
                                    logger.info(f"❌ Person detection overlaps {overlap_with_person:.1%} with {bbox['class']} - REJECTING as bag misdetection")
                                    overlaps_bag = True
                                    break
                                # Medium confidence with bag overlap
                                elif overlap_with_person > 0.3 and conf < 0.60:
                                    logger.info(f"❌ Medium confidence person ({conf:.2f}) overlaps {overlap_with_person:.1%} with {bbox['class']} - REJECTING")
                                    overlaps_bag = True
                                    break
                        
                        if overlaps_bag:
                            continue
                    
                    # 8. STATIC OBJECT CHECK - Reject small, low-confidence detections in corners
                    # These are often bags, tarps, or stored items
                    if conf < 0.55:
                        # Check if detection is in corner region (likely stored items)
                        center_x = (x1 + x2) / 2
                        center_y = (y1 + y2) / 2
                        
                        # Define corner regions (outer 15% of frame)
                        corner_margin_x = frame_width * 0.15
                        corner_margin_y = frame_height * 0.15
                        
                        in_corner = (center_x < corner_margin_x or center_x > frame_width - corner_margin_x) and \
                                   (center_y > frame_height - corner_margin_y)  # Bottom corners
                        
                        if in_corner and bbox_area < 15000:
                            logger.info(f"❌ Low confidence ({conf:.2f}) small detection in corner - likely storage item, REJECTING")
                            continue
                    
                    # 9. EXCLUSION ZONE CHECK - Skip detections in user-defined exclusion zones
                    detection_center = [(x1 + x2) / 2, (y1 + y2) / 2]
                    if self.point_in_exclusion_zone(detection_center, camera):
                        logger.info(f"❌ Detection in exclusion zone - REJECTING")
                        continue
                    
                    # Count valid person detection
                    people_count += 1
                
                logger.info(f"✅ Valid detection: {cls_name} conf={conf:.3f}")
                
                # Track ID for object tracking
                track_id = None
                if hasattr(box, 'id') and box.id is not None:
                    track_id = int(box.id[0])
                
                detection = {
                    'class': cls_name,
                    'confidence': conf,
                    'track_id': track_id,
                    'bbox': {
                        'x': int(x1),
                        'y': int(y1),
                        'width': bbox_width,
                        'height': bbox_height
                    },
                    'center': [(x1 + x2) / 2, (y1 + y2) / 2],
                    'zones': []
                }
                
                # Check zone detection (uses pre-fetched list — no DB query per detection)
                if config.enable_zone_detection:
                    for zone in cached_zones:
                        # Check if detection center is in zone
                        polygon_points = zone.get_polygon_points()
                        if polygon_points and self.point_in_rectangle(
                        self.get_detection_anchor_point(detection, self.detection_anchor_point),
                        polygon_points):
                            # Check class filter
                            if cls_name == 'person' and zone.detect_person:
                                detection['zones'].append(zone.id)
                                logger.info(f"🎯 Person in zone '{zone.name}'")
                            elif cls_name in ['car', 'truck', 'bus', 'motorcycle'] and zone.detect_vehicle:
                                detection['zones'].append(zone.id)
                            elif cls_name in self.class_categories['animal'] and zone.detect_animal:
                                detection['zones'].append(zone.id)
                
                detections.append(detection)
                logger.info(f"✅✅✅ DETECTION ADDED - will trigger alert!")
        
        # Store people count for alerts
        if people_count > 0:
            for det in detections:
                if det['class'] == 'person':
                    det['people_count'] = people_count
        
        logger.info(f"🎯 Returning {len(detections)} verified detections (People count: {people_count})")
        return detections
    
    def draw_detections(self, frame, detections):
        """Draw bounding boxes and labels on frame (green for normal detections)"""
        for det in detections:
            bbox = det['bbox']
            x, y, w, h = bbox['x'], bbox['y'], bbox['width'], bbox['height']

            # Draw red rectangle for normal detections
            cv2.rectangle(frame, (x, y), (x + w, y + h), (0, 0, 255), 2)

            # Draw label with red text
            label = f"{det['class']}: {det['confidence']:.2f}"
            cv2.putText(frame, label, (x, max(y - 10, 10)),
                       cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 0, 255), 2)

        return frame
    
    def point_in_rectangle(self, point, rect_points):
        """Zone detection — works for rectangles (4 pts), triangles (3 pts), or any polygon"""
        if not rect_points:
            return False
            
        try:
            x, y = float(point[0]), float(point[1])
            
            # Convert to float coordinate list
            points = []
            for p in rect_points:
                if isinstance(p, (list, tuple)) and len(p) >= 2:
                    points.append([float(p[0]), float(p[1])])
            
            if len(points) < 3:
                return False
            
            # Enhanced 4-corner rectangle detection
            if len(points) == 4:
                # Sort points to create proper rectangle
                points = self.sort_rectangle_points(points)
                
                x_coords = [p[0] for p in points]
                y_coords = [p[1] for p in points]
                
                min_x, max_x = min(x_coords), max(x_coords)
                min_y, max_y = min(y_coords), max(y_coords)
                
                # Enhanced bounding box check with margin
                margin = 2.0  # Small margin for edge cases
                if x < (min_x - margin) or x > (max_x + margin) or y < (min_y - margin) or y > (max_y + margin):
                    return False
                
                # Check if it's axis-aligned rectangle
                unique_x = len(set(round(xi, 1) for xi in x_coords))
                unique_y = len(set(round(yi, 1) for yi in y_coords))
                
                if unique_x == 2 and unique_y == 2:
                    # Perfect axis-aligned rectangle
                    return min_x <= x <= max_x and min_y <= y <= max_y
                else:
                    # Use enhanced polygon test for rotated rectangles
                    return self.point_in_polygon_enhanced(point, points)
            
            # General polygon test for any shape
            return self.point_in_polygon_general(point, points)
            
        except Exception as e:
            logger.error(f"Error in rectangle detection: {e}")
            return False
            
    def sort_rectangle_points(self, points):
        """Sort rectangle points in clockwise order starting from top-left"""
        try:
            if len(points) != 4:
                return points
            
            # Find center point
            center_x = sum(p[0] for p in points) / 4
            center_y = sum(p[1] for p in points) / 4
            
            # Sort points by angle from center
            import math
            def angle_from_center(point):
                return math.atan2(point[1] - center_y, point[0] - center_x)
            
            sorted_points = sorted(points, key=angle_from_center)
            return sorted_points
            
        except Exception:
            return points
    
    def point_in_polygon_enhanced(self, point, polygon):
        """Enhanced point-in-polygon test with better accuracy for rectangles"""
        if not polygon or len(polygon) < 4:
            return False
            
        try:
            x, y = float(point[0]), float(point[1])
            n = len(polygon)
            inside = False
            
            # Enhanced ray casting algorithm
            j = n - 1
            for i in range(n):
                xi, yi = float(polygon[i][0]), float(polygon[i][1])
                xj, yj = float(polygon[j][0]), float(polygon[j][1])
                
                # Check if point is exactly on edge
                if self.point_on_edge([x, y], [xi, yi], [xj, yj]):
                    return True
                
                # Ray casting test
                if ((yi > y) != (yj > y)) and (x < (xj - xi) * (y - yi) / (yj - yi) + xi):
                    inside = not inside
                j = i
            
            return inside
        except (ValueError, TypeError, ZeroDivisionError, IndexError):
            return False
    
    def point_on_edge(self, point, edge_start, edge_end):
        """Check if point lies on edge of polygon"""
        try:
            x, y = point
            x1, y1 = edge_start
            x2, y2 = edge_end
            
            # Calculate cross product to check if point is on line
            cross_product = (y - y1) * (x2 - x1) - (x - x1) * (y2 - y1)
            
            # If cross product is 0, point is on the line
            if abs(cross_product) < 1e-6:  # Small tolerance for floating point
                # Check if point is within the segment bounds
                dot_product = (x - x1) * (x2 - x1) + (y - y1) * (y2 - y1)
                squared_distance = (x2 - x1) * (x2 - x1) + (y2 - y1) * (y2 - y1)
                
                if 0 <= dot_product <= squared_distance:
                    return True
            
            return False
        except Exception:
            return False
    
    def is_axis_aligned_rectangle(self, points):
        """Check if rectangle is axis-aligned (not rotated)"""
        try:
            x_coords = [p[0] for p in points]
            y_coords = [p[1] for p in points]
            
            unique_x = len(set(round(x, 2) for x in x_coords))
            unique_y = len(set(round(y, 2) for y in y_coords))
            
            return unique_x == 2 and unique_y == 2
        except:
            return False
    
    def point_in_polygon_general(self, point, polygon):
        """Working point-in-polygon test using ray casting"""
        if not polygon or len(polygon) < 4:
            return False
            
        try:
            x, y = float(point[0]), float(point[1])
            n = len(polygon)
            inside = False
            
            j = n - 1
            for i in range(n):
                xi, yi = float(polygon[i][0]), float(polygon[i][1])
                xj, yj = float(polygon[j][0]), float(polygon[j][1])
                
                if ((yi > y) != (yj > y)) and (x < (xj - xi) * (y - yi) / (yj - yi) + xi):
                    inside = not inside
                j = i
            
            return inside
        except (ValueError, TypeError, ZeroDivisionError, IndexError):
            return False
    
    def point_in_polygon(self, point, polygon_points):
        """
        Check if a point is inside a polygon.
        This is the main method used for zone detection.
        Delegates to point_in_polygon_general for actual calculation.
        """
        if not polygon_points or len(polygon_points) < 3:
            return False
        
        try:
            # Normalize points format
            points = []
            for p in polygon_points:
                if isinstance(p, (list, tuple)) and len(p) >= 2:
                    points.append([float(p[0]), float(p[1])])
            
            if len(points) < 3:
                return False
            
            # Use the general polygon test
            return self.point_in_polygon_general(point, points)
        except Exception as e:
            logger.debug(f"point_in_polygon error: {e}")
            return False
    
    def find_closest_track(self, camera_id, position, max_distance=150):
        """Find the closest existing track to a position (for matching when track_id unavailable)"""
        try:
            if camera_id not in self.people_tracker:
                return None
            
            current_time = datetime.utcnow()
            closest_id = None
            closest_dist = float('inf')
            
            for track_id, track_data in self.people_tracker[camera_id].items():
                # Only consider recent tracks (within 3 seconds - increased for frame skipping)
                age = (current_time - track_data['last_seen']).total_seconds()
                if age > 3:
                    continue
                
                # Calculate distance with velocity prediction
                old_pos = track_data['position']
                
                # Apply velocity prediction if available
                predicted_pos = self.predict_position(camera_id, track_id, old_pos, age)
                
                dist = ((position[0] - predicted_pos[0])**2 + (position[1] - predicted_pos[1])**2)**0.5
                
                if dist < closest_dist and dist < max_distance:
                    closest_dist = dist
                    closest_id = track_id
            
            return closest_id
        except Exception:
            return None
    
    # =========================================================================
    # ENHANCED ZONE TRACKING METHODS
    # =========================================================================
    
    def predict_position(self, camera_id, track_id, last_position, time_delta):
        """Predict position using velocity (Kalman-like prediction)"""
        try:
            if camera_id not in self.track_velocities:
                return last_position
            
            velocity = self.track_velocities[camera_id].get(track_id, (0, 0))
            
            # Predict based on last known velocity
            predicted_x = last_position[0] + velocity[0] * time_delta
            predicted_y = last_position[1] + velocity[1] * time_delta
            
            return [predicted_x, predicted_y]
        except Exception:
            return last_position
    
    def update_velocity(self, camera_id, track_id, old_position, new_position, time_delta):
        """Update track velocity with exponential smoothing"""
        try:
            if camera_id not in self.track_velocities:
                self.track_velocities[camera_id] = {}
            
            if time_delta <= 0:
                time_delta = 0.033  # Assume 30fps if no time info
            
            # Calculate instantaneous velocity
            vx = (new_position[0] - old_position[0]) / time_delta
            vy = (new_position[1] - old_position[1]) / time_delta
            
            # Apply exponential smoothing
            old_velocity = self.track_velocities[camera_id].get(track_id, (0, 0))
            smoothed_vx = self.velocity_smoothing * old_velocity[0] + (1 - self.velocity_smoothing) * vx
            smoothed_vy = self.velocity_smoothing * old_velocity[1] + (1 - self.velocity_smoothing) * vy
            
            self.track_velocities[camera_id][track_id] = (smoothed_vx, smoothed_vy)
            
        except Exception as e:
            logger.debug(f"Velocity update error: {e}")
    
    def calculate_iou(self, box1, box2):
        """Calculate Intersection over Union between two bounding boxes"""
        try:
            # Extract coordinates
            if isinstance(box1, dict):
                x1_1 = box1.get('x', box1.get('x1', 0))
                y1_1 = box1.get('y', box1.get('y1', 0))
                x2_1 = x1_1 + box1.get('width', box1.get('x2', x1_1) - x1_1)
                y2_1 = y1_1 + box1.get('height', box1.get('y2', y1_1) - y1_1)
            else:
                x1_1, y1_1, x2_1, y2_1 = box1[:4]
            
            if isinstance(box2, dict):
                x1_2 = box2.get('x', box2.get('x1', 0))
                y1_2 = box2.get('y', box2.get('y1', 0))
                x2_2 = x1_2 + box2.get('width', box2.get('x2', x1_2) - x1_2)
                y2_2 = y1_2 + box2.get('height', box2.get('y2', y1_2) - y1_2)
            else:
                x1_2, y1_2, x2_2, y2_2 = box2[:4]
            
            # Calculate intersection
            x_left = max(x1_1, x1_2)
            y_top = max(y1_1, y1_2)
            x_right = min(x2_1, x2_2)
            y_bottom = min(y2_1, y2_2)
            
            if x_right < x_left or y_bottom < y_top:
                return 0.0
            
            intersection_area = (x_right - x_left) * (y_bottom - y_top)
            
            # Calculate union
            box1_area = (x2_1 - x1_1) * (y2_1 - y1_1)
            box2_area = (x2_2 - x1_2) * (y2_2 - y1_2)
            union_area = box1_area + box2_area - intersection_area
            
            if union_area <= 0:
                return 0.0
            
            return intersection_area / union_area
        except Exception:
            return 0.0
    
    def match_tracks_iou(self, camera_id, current_detections):
        """Match current detections to previous detections using IOU"""
        try:
            if camera_id not in self.previous_detections:
                self.previous_detections[camera_id] = current_detections
                return current_detections
            
            prev_dets = self.previous_detections[camera_id]
            matched = []
            
            for curr_det in current_detections:
                if curr_det.get('class') != 'person':
                    matched.append(curr_det)
                    continue
                
                curr_bbox = curr_det.get('bbox', {})
                best_match = None
                best_iou = self.iou_match_threshold
                
                for prev_det in prev_dets:
                    if prev_det.get('class') != 'person':
                        continue
                    
                    prev_bbox = prev_det.get('bbox', {})
                    iou = self.calculate_iou(curr_bbox, prev_bbox)
                    
                    if iou > best_iou:
                        best_iou = iou
                        best_match = prev_det
                
                # If matched, carry over track_id
                if best_match and best_match.get('track_id'):
                    if not curr_det.get('track_id') or curr_det.get('track_id') != best_match.get('track_id'):
                        logger.debug(f"🔄 IOU matched: {curr_det.get('track_id')} -> {best_match.get('track_id')} (IOU: {best_iou:.2f})")
                        curr_det['track_id'] = best_match.get('track_id')
                        curr_det['iou_matched'] = True
                
                matched.append(curr_det)
            
            # Store for next frame
            self.previous_detections[camera_id] = current_detections
            
            return matched
        except Exception as e:
            logger.debug(f"IOU matching error: {e}")
            return current_detections
    
    def get_detection_anchor_point(self, detection, anchor_type='feet'):
        """
        Get the anchor point for zone detection based on configuration.
        - 'center': Center of bounding box (default YOLO behavior)
        - 'feet': Bottom center of bounding box (more accurate for people)
        - 'head': Top center of bounding box
        - 'bottom_center': Same as feet
        """
        try:
            bbox = detection.get('bbox', {})
            
            if isinstance(bbox, dict):
                x = bbox.get('x', 0)
                y = bbox.get('y', 0)
                width = bbox.get('width', 0)
                height = bbox.get('height', 0)
            else:
                return detection.get('center', [0, 0])
            
            center_x = x + width / 2
            
            if anchor_type == 'feet' or anchor_type == 'bottom_center':
                # Bottom center - where feet would be (most accurate for ground-level zones)
                return [center_x, y + height]
            elif anchor_type == 'head':
                # Top center - where head would be
                return [center_x, y]
            else:  # 'center'
                return [center_x, y + height / 2]
                
        except Exception:
            return detection.get('center', [0, 0])
    
    def confirm_zone_entry(self, camera_id, track_id, zone_id):
        """
        Confirm zone entry only after detection in zone for N consecutive frames.
        Prevents flickering entries/exits at zone boundaries.
        """
        try:
            if camera_id not in self.track_zone_history:
                self.track_zone_history[camera_id] = {}
            
            if track_id not in self.track_zone_history[camera_id]:
                self.track_zone_history[camera_id][track_id] = []
            
            history = self.track_zone_history[camera_id][track_id]
            
            # Add current zone to history
            history.append(zone_id)
            
            # Keep only last N frames
            if len(history) > self.zone_confirmation_frames:
                history = history[-self.zone_confirmation_frames:]
                self.track_zone_history[camera_id][track_id] = history
            
            # Check if zone appears in all recent frames
            if len(history) >= self.zone_confirmation_frames:
                return history.count(zone_id) >= self.zone_confirmation_frames
            
            return False
        except Exception:
            return True  # Default to immediate confirmation
    
    def log_zone_transition(self, camera_id, zone_id, track_id, transition_type, position, direction, dwell_time=0, confidence=1.0):
        """
        Log zone entry/exit transition to database for analytics.
        Uses batching for performance.
        """
        try:
            transition = {
                'camera_id': camera_id,
                'zone_id': zone_id,
                'track_id': str(track_id),
                'transition_type': transition_type,
                'direction': direction,
                'position_x': position[0] if position else None,
                'position_y': position[1] if position else None,
                'dwell_time_seconds': dwell_time,
                'confidence': confidence,
                'timestamp': datetime.utcnow()
            }
            
            with self._transitions_lock:
                self.pending_transitions.append(transition)
                # Batch save for performance
                if len(self.pending_transitions) >= self.transition_batch_size:
                    self._save_pending_transitions()
            
            # Also update daily stats
            self._update_daily_stats(camera_id, zone_id, transition_type, direction, dwell_time)
            
        except Exception as e:
            logger.error(f"Error logging zone transition: {e}")
    
    def _save_pending_transitions(self):
        """Save batched transitions to database (call with _transitions_lock held or standalone)"""
        try:
            with self._transitions_lock:
                if not self.pending_transitions:
                    return
                to_save = self.pending_transitions[:]
                self.pending_transitions = []
            
            with self.app.app_context():
                for t in to_save:
                    transition = ZoneTransition(
                        camera_id=t['camera_id'],
                        zone_id=t['zone_id'],
                        track_id=t['track_id'],
                        transition_type=t['transition_type'],
                        direction=t['direction'],
                        position_x=t['position_x'],
                        position_y=t['position_y'],
                        dwell_time_seconds=t['dwell_time_seconds'],
                        confidence=t['confidence'],
                        timestamp=t['timestamp']
                    )
                    db.session.add(transition)
                
                db.session.commit()
                logger.debug(f"Saved {len(to_save)} zone transitions")
            
        except Exception as e:
            logger.error(f"Error saving zone transitions: {e}")
    
    def _update_daily_stats(self, camera_id, zone_id, transition_type, direction, dwell_time):
        """Update daily statistics for zone"""
        try:
            today = datetime.utcnow().date()
            current_hour = datetime.utcnow().hour
            cache_key = f"{zone_id}_{today}"
            
            # Get or create daily stats
            if cache_key not in self.daily_stats_cache:
                with self.app.app_context():
                    stats = ZoneDailyStats.query.filter_by(
                        zone_id=zone_id,
                        date=today
                    ).first()
                    
                    if not stats:
                        stats = ZoneDailyStats(
                            camera_id=camera_id,
                            zone_id=zone_id,
                            date=today,
                            hourly_entries=json.dumps({}),
                            hourly_exits=json.dumps({}),
                            entry_directions=json.dumps({}),
                            exit_directions=json.dumps({})
                        )
                        db.session.add(stats)
                    
                    self.daily_stats_cache[cache_key] = stats
            
            stats = self.daily_stats_cache[cache_key]
            
            # Update counts
            if transition_type == 'entry':
                stats.total_entries = (stats.total_entries or 0) + 1
                
                # Update hourly entries
                hourly = stats.get_hourly_entries()
                hourly[str(current_hour)] = hourly.get(str(current_hour), 0) + 1
                stats.hourly_entries = json.dumps(hourly)
                
                # Update entry directions
                dirs = stats.get_entry_directions()
                dirs[direction] = dirs.get(direction, 0) + 1
                stats.entry_directions = json.dumps(dirs)
                
            elif transition_type == 'exit':
                stats.total_exits = (stats.total_exits or 0) + 1
                
                # Update hourly exits
                hourly = stats.get_hourly_exits()
                hourly[str(current_hour)] = hourly.get(str(current_hour), 0) + 1
                stats.hourly_exits = json.dumps(hourly)
                
                # Update exit directions
                dirs = stats.get_exit_directions()
                dirs[direction] = dirs.get(direction, 0) + 1
                stats.exit_directions = json.dumps(dirs)
                
                # Update dwell time statistics
                if dwell_time > 0:
                    if not stats.avg_dwell_time_seconds:
                        stats.avg_dwell_time_seconds = dwell_time
                    else:
                        # Running average
                        total_exits = stats.total_exits
                        stats.avg_dwell_time_seconds = (
                            (stats.avg_dwell_time_seconds * (total_exits - 1) + dwell_time) / total_exits
                        )
                    
                    if dwell_time > (stats.max_dwell_time_seconds or 0):
                        stats.max_dwell_time_seconds = dwell_time
                    
                    if stats.min_dwell_time_seconds is None or dwell_time < stats.min_dwell_time_seconds:
                        stats.min_dwell_time_seconds = dwell_time
            
            # Commit periodically (every 10 updates)
            if (stats.total_entries + stats.total_exits) % 10 == 0:
                with self.app.app_context():
                    db.session.commit()
                    
        except Exception as e:
            logger.debug(f"Error updating daily stats: {e}")
    
    def update_heatmap_data(self, camera_id, detections, zones):
        """Update heatmap data for activity tracking (batched - one DB query per flush)"""
        try:
            current_time = datetime.utcnow()
            
            # Check update interval
            last_update = self.last_heatmap_update.get(camera_id)
            if last_update and (current_time - last_update).total_seconds() < self.heatmap_update_interval:
                return
            
            self.last_heatmap_update[camera_id] = current_time
            
            today = current_time.date()
            current_hour = current_time.hour
            day_of_week = current_time.weekday()
            
            # First pass: accumulate increments in memory (no DB queries yet)
            increments = {}  # (zone_id, grid_x, grid_y) -> delta count
            for det in detections:
                if det.get('class') != 'person':
                    continue
                
                center = det.get('center', [0, 0])
                
                for zone in zones:
                    polygon = zone.get_polygon_points()
                    if not polygon:
                        continue
                    
                    if not self.point_in_polygon(center, polygon):
                        continue
                    
                    min_x = min(p[0] for p in polygon)
                    max_x = max(p[0] for p in polygon)
                    min_y = min(p[1] for p in polygon)
                    max_y = max(p[1] for p in polygon)
                    
                    zone_width = max_x - min_x
                    zone_height = max_y - min_y
                    
                    if zone_width <= 0 or zone_height <= 0:
                        continue
                    
                    grid_x = int((center[0] - min_x) / zone_width * self.heatmap_grid_size)
                    grid_y = int((center[1] - min_y) / zone_height * self.heatmap_grid_size)
                    
                    grid_x = max(0, min(grid_x, self.heatmap_grid_size - 1))
                    grid_y = max(0, min(grid_y, self.heatmap_grid_size - 1))
                    
                    key = (zone.id, grid_x, grid_y)
                    increments[key] = increments.get(key, 0) + 1
            
            if not increments:
                return
            
            with self.app.app_context():
                # ONE query to load all existing records for this camera/date/hour
                existing_rows = ZoneHeatmapData.query.filter_by(
                    camera_id=camera_id,
                    date=today,
                    hour_of_day=current_hour
                ).all()
                existing_map = {(r.zone_id, r.grid_x, r.grid_y): r for r in existing_rows}
                
                # Apply all increments - update existing or insert new rows
                for (zone_id, grid_x, grid_y), delta in increments.items():
                    key = (zone_id, grid_x, grid_y)
                    if key in existing_map:
                        existing_map[key].activity_count += delta
                    else:
                        new_row = ZoneHeatmapData(
                            camera_id=camera_id,
                            zone_id=zone_id,
                            grid_x=grid_x,
                            grid_y=grid_y,
                            date=today,
                            hour_of_day=current_hour,
                            day_of_week=day_of_week,
                            activity_count=delta
                        )
                        db.session.add(new_row)
                
                db.session.commit()
                
        except Exception as e:
            logger.debug(f"Heatmap update error: {e}")
    
    def should_send_zone_alert(self, camera_id, zone_id, action, track_id=None, zone_cooldown_seconds=None):
        """Check if we should send a zone alert (with configurable cooldown).
        For 'crossing' action, track_id is included in the key so multiple people
        can cross simultaneously without blocking each other."""
        try:
            if not hasattr(self, 'zone_alert_times'):
                self.zone_alert_times = {}

            # Crossings are per-person (include track_id) so busy doorways don't miss events
            if action == 'crossing' and track_id is not None:
                key = f"{camera_id}_{zone_id}_{action}_{track_id}"
                cooldown = 10  # 10s per-person crossing cooldown
            else:
                key = f"{camera_id}_{zone_id}_{action}"
                # Use per-zone cooldown if provided, else global default (5 min)
                cooldown = zone_cooldown_seconds if zone_cooldown_seconds is not None else getattr(self, 'zone_alert_cooldown_seconds', 300)

            current_time = datetime.utcnow()
            with self._tracking_lock:
                last_alert = self.zone_alert_times.get(key)
                if last_alert and (current_time - last_alert).total_seconds() < cooldown:
                    return False
                self.zone_alert_times[key] = current_time
            return True
        except Exception:
            return True
    
    def update_people_tracker(self, camera_id, track_id, zones, position, bbox=None):
        """Enhanced people tracker with zone entry/exit detection, velocity tracking, and dwell time"""
        try:
            current_time = datetime.utcnow()
            
            # Initialize tracker for this camera
            if camera_id not in self.people_tracker:
                self.people_tracker[camera_id] = {}
            
            # Get zone IDs safely
            current_zones = []
            zone_objects = []
            for zone in zones:
                try:
                    zone_id = getattr(zone, 'id', None)
                    if zone_id:
                        current_zones.append(zone_id)
                        zone_objects.append(zone)
                except:
                    continue
            
            logger.debug(f"📍 Tracker: person {track_id} at {position}, in {len(current_zones)} zones: {current_zones}")
            
            # Check if this person was previously tracked
            previous_track = self.people_tracker[camera_id].get(track_id)
            
            if previous_track:
                # Update velocity for predictive tracking
                previous_position = previous_track['position']
                time_delta = (current_time - previous_track['last_seen']).total_seconds()
                if time_delta > 0:
                    self.update_velocity(camera_id, track_id, previous_position, position, time_delta)

                # Handle pending zone entries from first frame (direction was unknown then)
                if camera_id in self.pending_zone_entries:
                    pending = self.pending_zone_entries[camera_id].get(track_id, {})
                    if pending:
                        for zone_id in list(pending.keys()):
                            if zone_id in set(current_zones):
                                zone_obj = next((z for z in zone_objects if z.id == zone_id), None)
                                if not zone_obj:
                                    try:
                                        zone_obj = DetectionZone.query.get(zone_id)
                                    except Exception:
                                        pass
                                if zone_obj:
                                    direction = self.calculate_movement_direction(pending[zone_id], position)
                                    logger.info(f"🚨 PENDING ENTRY: zone '{zone_obj.name}' direction: {direction}")
                                    self.trigger_zone_alert(camera_id, zone_obj, 'entry', track_id, position, direction, dwell_time=0)
                            del pending[zone_id]
                        if not pending:
                            self.pending_zone_entries[camera_id].pop(track_id, None)
                        else:
                            self.pending_zone_entries[camera_id][track_id] = pending

                # Analyze zone transitions for entry/exit detection
                previous_zones = set(previous_track['zones'])
                current_zones_set = set(current_zones)

                logger.debug(f"📊 Previous zones: {previous_zones}, Current zones: {current_zones_set}")

                # Detect zone entries
                entered_zones = current_zones_set - previous_zones
                if entered_zones:
                    logger.debug(f"🚪 ENTRY DETECTED: zones {entered_zones}")
                for zone_id in entered_zones:
                    zone = next((z for z in zone_objects if z.id == zone_id), None)
                    if zone:
                        try:
                            direction = self.calculate_movement_direction(previous_position, position)
                            logger.info(f"🚨 Calling trigger_zone_alert for ENTRY zone '{zone.name}'")
                            self.trigger_zone_alert(camera_id, zone, 'entry', track_id, position, direction, dwell_time=0)
                        except Exception as alert_err:
                            logger.error(f"Entry alert error: {alert_err}")
                
                # Detect zone exits — log for dwell-time tracking only.
                # The actual "Zone Exited" alert is intentionally deferred to
                # cleanup_stale_tracks_with_exit(), which fires only once the
                # person's track has gone stale (i.e. they are no longer visible
                # in the frame at all).  This prevents a false "Zone Exited"
                # message every time someone steps across the zone boundary but
                # is still clearly visible on camera.
                exited_zones = previous_zones - current_zones_set
                if exited_zones:
                    logger.debug(f"🚪 Person {track_id} stepped out of zones {exited_zones} (still in frame — no alert yet)")
            else:
                # First time seeing this person - queue zone entries for next frame
                # (we need two positions to calculate direction accurately)
                if current_zones:
                    logger.info(f"👤 NEW person {track_id} first seen in zones: {current_zones}")
                    if camera_id not in self.pending_zone_entries:
                        self.pending_zone_entries[camera_id] = {}
                    if track_id not in self.pending_zone_entries[camera_id]:
                        self.pending_zone_entries[camera_id][track_id] = {}
                    for zone_id in current_zones:
                        self.pending_zone_entries[camera_id][track_id][zone_id] = position
                    logger.debug(f"📌 Queued {len(current_zones)} zone entries — direction will be calculated next frame")
            
            # Track first_seen_in_zone per zone for accurate loitering and dwell time.
            # We intentionally keep zone_first_seen entries even when a person steps
            # OUTSIDE the zone polygon (while still visible in frame). This ensures
            # cleanup_stale_tracks_with_exit() can compute a correct total dwell time
            # when the person eventually leaves the frame.
            zone_first_seen = previous_track.get('zone_first_seen', {}) if previous_track else {}
            for zone_id in current_zones:
                if zone_id not in zone_first_seen:
                    zone_first_seen[zone_id] = current_time
            # Do NOT delete entries for zones the person has just stepped out of —
            # they might step back in, and cleanup_stale_tracks_with_exit needs these.

            # Check for loitering in current zones
            # Pass updated zone_first_seen so the entry time is correct even on first detection frame
            for zone in zone_objects:
                try:
                    self.check_loitering(camera_id, track_id, zone, current_time, previous_track, zone_first_seen=zone_first_seen, current_zones=current_zones)
                except Exception as loiter_err:
                    logger.error(f"Loitering check error: {loiter_err}")
            
            # Update or create track with enhanced data
            first_seen = previous_track.get('first_seen', current_time) if previous_track else current_time
            
            self.people_tracker[camera_id][track_id] = {
                'zones': current_zones,
                'last_seen': current_time,
                'first_seen': first_seen,
                'zone_first_seen': zone_first_seen,  # Track when entered each zone
                'position': position,
                'bbox': bbox,  # Native-frame bounding box for alert annotation
                'loiter_alerted': previous_track.get('loiter_alerted', {}) if previous_track else {},
                'movement_history': self.update_movement_history(
                    previous_track.get('movement_history', []) if previous_track else [],
                    position,
                    current_time
                )
            }
            
        except Exception as e:
            logger.error(f"Error updating people tracker: {e}")
    
    def check_loitering(self, camera_id, track_id, zone, current_time, previous_track, zone_first_seen=None, current_zones=None):
        """Check if person has been in zone too long (loitering detection)"""
        try:
            if not previous_track:
                return

            # Check armed status — no loitering alerts when disarmed
            try:
                # Use cached armed state where possible to avoid per-person DB queries.
                # Falls back to a fresh DB read only if the cache is absent.
                config = getattr(self, '_cached_config', None) or SystemConfig.query.first()
                camera_obj = getattr(self, '_cached_cameras', {}).get(camera_id) or Camera.query.get(camera_id)
                if not config or not config.is_armed:
                    return
                if camera_obj and not camera_obj.is_armed:
                    return
            except Exception:
                pass

            zone_id = zone.id
            zone_name = zone.name

            # Get loitering threshold (0 = disabled)
            loiter_threshold = getattr(zone, 'loiter_threshold_seconds', 300)
            if not loiter_threshold or loiter_threshold <= 0:
                return  # Loitering detection disabled for this zone

            # Determine current zone membership
            # Use passed current_zones if available, else fall back to current tracker state
            if current_zones is not None:
                zones_to_check = current_zones
            else:
                current_track = self.people_tracker.get(camera_id, {}).get(track_id, previous_track)
                zones_to_check = current_track.get('zones', [])

            if zone_id not in zones_to_check:
                return  # Person isn't in this zone
            
            # Calculate time in THIS SPECIFIC ZONE (not global first_seen)
            # Prefer the passed-in zone_first_seen (already updated for current frame)
            effective_zone_first_seen = zone_first_seen if zone_first_seen is not None else previous_track.get('zone_first_seen', {})
            zone_entry_time = effective_zone_first_seen.get(zone_id)
            if not zone_entry_time:
                # Fallback to global first_seen only when zone entry time is genuinely unknown
                zone_entry_time = previous_track.get('first_seen', current_time)
            
            time_in_zone = (current_time - zone_entry_time).total_seconds()
            
            # Check if already alerted for this zone
            loiter_alerted = previous_track.get('loiter_alerted', {})
            # Also check live tracker state in case it was updated already
            if not loiter_alerted.get(zone_id):
                live_track = self.people_tracker.get(camera_id, {}).get(track_id)
                if live_track:
                    loiter_alerted = live_track.get('loiter_alerted', loiter_alerted)
            if loiter_alerted.get(zone_id):
                return  # Already sent loitering alert
            
            # Check if exceeded threshold
            if time_in_zone >= loiter_threshold:
                logger.info(f"⏱️ LOITERING DETECTED: person {track_id} in zone '{zone_name}' for {time_in_zone:.0f}s (threshold: {loiter_threshold}s)")
                self.trigger_loitering_alert(camera_id, zone, track_id, time_in_zone)
                
                # Mark as alerted
                if camera_id in self.people_tracker and track_id in self.people_tracker[camera_id]:
                    if 'loiter_alerted' not in self.people_tracker[camera_id][track_id]:
                        self.people_tracker[camera_id][track_id]['loiter_alerted'] = {}
                    self.people_tracker[camera_id][track_id]['loiter_alerted'][zone_id] = True
                    
        except Exception as e:
            logger.error(f"Error checking loitering: {e}")
    
    def trigger_loitering_alert(self, camera_id, zone, track_id, duration_seconds):
        """Send loitering alert - Telegram only (no database to prevent conflicts)"""
        try:
            zone_id = zone.id
            zone_name = zone.name
            
            logger.info(f"⏱️ LOITERING ALERT: person {track_id} in zone '{zone_name}' for {duration_seconds:.0f}s")
            
            # Send telegram notification
            try:
                from telegram_service import telegram_service
                from models import Camera
                
                # Get camera name safely
                try:
                    camera = Camera.query.get(camera_id)
                    camera_name = camera.name if camera else f"Camera {camera_id}"
                except:
                    camera_name = f"Camera {camera_id}"
                
                minutes = int(duration_seconds // 60)
                seconds = int(duration_seconds % 60)
                duration_str = f"{minutes}m {seconds}s" if minutes > 0 else f"{seconds}s"
                
                message = f"⏱️ Loitering Alert\n"
                message += f"📹 Camera: {camera_name}\n"
                message += f"🏷️ Zone: {zone_name}\n"
                message += f"⏰ Duration: {duration_str}\n"
                message += f"🕐 Time: {datetime.now().strftime('%H:%M:%S')}"
                
                # Attach current frame so the operator can see who is loitering
                frame = self.camera_frames.get(camera_id)
                if frame is not None:
                    try:
                        # Draw the loitering person's bounding box on the frame
                        annotated = frame.copy()
                        track_info = self.people_tracker.get(camera_id, {}).get(track_id)
                        if track_info and track_info.get('bbox'):
                            tb = track_info['bbox']
                            if isinstance(tb, dict):
                                bx = int(tb.get('x', 0))
                                by = int(tb.get('y', 0))
                                bw = int(tb.get('width', 0))
                                bh = int(tb.get('height', 0))
                                cv2.rectangle(annotated, (bx, by), (bx + bw, by + bh), (0, 165, 255), 3)
                                cv2.putText(annotated, f'Loitering {duration_str}',
                                            (bx, max(by - 10, 10)),
                                            cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 165, 255), 2)
                        telegram_service.send_alert_with_image(message, annotated, camera_name)
                    except Exception:
                        telegram_service.send_message(message)
                else:
                    telegram_service.send_message(message)
                logger.info(f"✅ Loitering alert sent for zone '{zone_name}'")
                
            except Exception as tg_err:
                logger.error(f"Error sending loitering telegram alert: {tg_err}")
                
        except Exception as e:
            logger.error(f"Error triggering loitering alert: {e}")
    
    def update_movement_history(self, history, position, timestamp):
        """Update movement history for better directional analysis"""
        try:
            # Add new position to history
            history.append({
                'position': position,
                'timestamp': timestamp
            })
            
            # Keep only last 10 positions (last ~5 seconds)
            if len(history) > 10:
                history = history[-10:]
            
            return history
        except Exception:
            return []
    
    def calculate_movement_direction(self, old_pos, new_pos):
        """Enhanced movement direction calculation with 8-directional support"""
        try:
            if not old_pos or not new_pos:
                return 'unknown'
            
            dx = new_pos[0] - old_pos[0]
            dy = new_pos[1] - old_pos[1]
            
            # Calculate angle for more precise direction
            import math
            angle = math.atan2(dy, dx) * 180 / math.pi
            
            # Normalize angle to 0-360 degrees
            if angle < 0:
                angle += 360
            
            # Map angle to 8 directions
            directions = [
                'right',      # 0° (337.5° - 22.5°)
                'down-right', # 45° (22.5° - 67.5°)
                'down',       # 90° (67.5° - 112.5°)
                'down-left',  # 135° (112.5° - 157.5°)
                'left',       # 180° (157.5° - 202.5°)
                'up-left',    # 225° (202.5° - 247.5°)
                'up',         # 270° (247.5° - 292.5°)
                'up-right'    # 315° (292.5° - 337.5°)
            ]
            
            direction_index = int((angle + 22.5) / 45) % 8
            precise_direction = directions[direction_index]
            
            # Calculate movement magnitude for confidence
            magnitude = math.sqrt(dx*dx + dy*dy)
            
            # For small movements, return simple direction
            if magnitude < 10:  # Very small movement
                if abs(dx) > abs(dy):
                    return 'right' if dx > 0 else 'left'
                else:
                    return 'down' if dy > 0 else 'up'
            
            logger.debug(f"Movement: ({dx:.1f}, {dy:.1f}) -> {precise_direction} (angle: {angle:.1f}°, mag: {magnitude:.1f})")
            return precise_direction
            
        except Exception as e:
            logger.error(f"Error calculating movement direction: {e}")
            return 'unknown'
    
    def trigger_zone_alert(self, camera_id, zone, action, track_id, position, direction='unknown', dwell_time=0, frame=None):
        """Enhanced zone entry/exit alerts with analytics logging and photo"""
        try:
            # Gate counting zone alerts behind people_counting licence
            if getattr(zone, 'zone_type', None) == 'counting' and not _check_license('people_counting'):
                logger.debug(f"Counting zone alert suppressed — people_counting licence not active")
                return

            # Respect armed status — zone alerts must not fire when disarmed
            try:
                config = SystemConfig.query.first()
                camera_obj = Camera.query.get(camera_id)
                if not config or not config.is_armed:
                    logger.debug(f"Zone alert suppressed — system disarmed")
                    return
                if camera_obj and not camera_obj.is_armed:
                    logger.debug(f"Zone alert suppressed — camera disarmed")
                    return
            except Exception:
                pass

            # Get zone attributes safely to avoid detached session errors
            zone_id = zone.id
            zone_name = zone.name

            # Check if alerts are enabled for this action (default to True if not set)
            alert_on_entry = getattr(zone, 'alert_on_entry', True)
            alert_on_exit = getattr(zone, 'alert_on_exit', True)
            
            # ALWAYS log the transition for analytics, even if alerts are disabled
            try:
                self.log_zone_transition(
                    camera_id=camera_id,
                    zone_id=zone_id,
                    track_id=track_id,
                    transition_type=action,
                    position=position,
                    direction=direction,
                    dwell_time=dwell_time,
                    confidence=1.0
                )
            except Exception as log_err:
                logger.debug(f"Error logging zone transition: {log_err}")
            
            if action == 'entry' and not alert_on_entry:
                logger.info(f"Zone '{zone_name}' entry alert disabled, skipping notification")
                return
            if action == 'exit' and not alert_on_exit:
                logger.info(f"Zone '{zone_name}' exit alert disabled, skipping notification")
                return
            # 'crossing' action (tripwire) always fires - no entry/exit gate needed
            
            # Check zone alert cooldown (5 min default; per-person for crossings)
            zone_cooldown = getattr(zone, 'alert_cooldown_minutes', 5) * 60 if hasattr(zone, 'alert_cooldown_minutes') else None
            if not self.should_send_zone_alert(camera_id, zone_id, action, track_id=track_id, zone_cooldown_seconds=zone_cooldown):
                logger.info(f"Zone '{zone_name}' {action} alert on cooldown, skipping notification")
                return
            
            logger.info(f"🚨 ZONE ALERT SENDING: {action} for zone '{zone_name}' person {track_id}")
            
            # Send telegram notification with photo
            try:
                from telegram_service import telegram_service
                from models import Camera
                import cv2
                
                # Get camera name safely
                try:
                    camera = Camera.query.get(camera_id)
                    camera_name = camera.name if camera else f"Camera {camera_id}"
                except:
                    camera_name = f"Camera {camera_id}"
                
                # Enhanced direction arrows and emojis
                direction_emoji = {
                    'up': '⬆️', 'down': '⬇️', 'left': '⬅️', 'right': '➡️',
                    'up-left': '↖️', 'up-right': '↗️', 'down-left': '↙️', 'down-right': '↘️',
                    'unknown': '•', 'left-frame': '🚶'
                }
                
                if action == 'entry':
                    action_emoji = '📥'
                elif action == 'crossing':
                    action_emoji = '⚡'
                else:
                    action_emoji = '📤'

                if action == 'crossing':
                    action_label = 'Line Crossing'
                else:
                    action_label = f'Zone {action.title()}'

                message = f"{action_emoji} {action_label} Alert\n"
                message += f"📹 Camera: {camera_name}\n"
                message += f"🏷️ Zone: {zone_name}\n"
                message += f"{direction_emoji.get(direction, '•')} Direction: {direction}\n"
                
                # Add dwell time for exits
                if action == 'exit' and dwell_time > 0:
                    minutes = int(dwell_time // 60)
                    seconds = int(dwell_time % 60)
                    if minutes > 0:
                        message += f"⏱️ Time in zone: {minutes}m {seconds}s\n"
                    else:
                        message += f"⏱️ Time in zone: {seconds}s\n"
                
                message += f"🕐 Time: {datetime.now().strftime('%H:%M:%S')}"
                
                # Try to get cached frame for photo — ENTRY only.
                # Exit alerts are sent as text-only: the person has already left
                # the frame so the cached image would show an empty scene.
                alert_frame = None
                if action != 'exit':
                    alert_frame = frame
                    if alert_frame is None and hasattr(self, 'camera_frames'):
                        alert_frame = self.camera_frames.get(camera_id)
                
                if alert_frame is not None:
                    try:
                        # Draw zone on the frame
                        annotated = alert_frame.copy()
                        frame_h, frame_w = annotated.shape[:2]
                        scale_x = frame_w / 800.0
                        scale_y = frame_h / 600.0

                        # Draw all detected persons in GREEN first (background persons)
                        all_detections = self.camera_detections.get(camera_id, [])
                        for other_det in all_detections:
                            if other_det.get('class') != 'person':
                                continue
                            ob = other_det.get('bbox', {})
                            if not ob:
                                continue
                            ox = int(ob.get('x', 0))
                            oy = int(ob.get('y', 0))
                            ow = int(ob.get('width', 0))
                            oh = int(ob.get('height', 0))
                            if ow > 0 and oh > 0:
                                cv2.rectangle(annotated, (ox, oy), (ox + ow, oy + oh), (0, 255, 0), 2)
                                cv2.putText(annotated, 'person', (ox, max(oy - 6, 10)),
                                           cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 255, 0), 2)

                        # Highlight the TRIGGERING person with a label (green box already drawn above)
                        trigger_bbox = None
                        if camera_id in self.people_tracker and track_id in self.people_tracker[camera_id]:
                            trigger_bbox = self.people_tracker[camera_id][track_id].get('bbox')
                        if trigger_bbox is None:
                            # Fallback: find nearest detection to position
                            best_det = None
                            best_dist = float('inf')
                            for d in all_detections:
                                if d.get('class') != 'person':
                                    continue
                                dc = d.get('center', [0, 0])
                                dist = ((dc[0] - position[0])**2 + (dc[1] - position[1])**2)**0.5
                                if dist < best_dist:
                                    best_dist = dist
                                    best_det = d
                            if best_det:
                                trigger_bbox = best_det.get('bbox')
                        if trigger_bbox:
                            tx = int(trigger_bbox.get('x', 0))
                            ty = int(trigger_bbox.get('y', 0))
                            tw = int(trigger_bbox.get('width', 0))
                            th = int(trigger_bbox.get('height', 0))
                            if tw > 0 and th > 0:
                                # Add label only (no second box — green box already drawn above)
                                lbl = 'ZONE ALERT' if action != 'crossing' else 'LINE CROSSED'
                                cv2.putText(annotated, lbl, (tx, max(ty - 10, 10)),
                                           cv2.FONT_HERSHEY_SIMPLEX, 0.6, (0, 255, 0), 2)

                        # Draw the zone polygon
                        polygon_points = zone.get_polygon_points()
                        if polygon_points:
                            import numpy as np
                            points = np.array(polygon_points, np.int32)
                            scaled_points = points.copy().astype(float)
                            scaled_points[:, 0] = (points[:, 0] * scale_x)
                            scaled_points[:, 1] = (points[:, 1] * scale_y)
                            scaled_points = scaled_points.astype(np.int32)

                            # Draw filled polygon with transparency
                            overlay = annotated.copy()
                            zone_color = (0, 255, 0) if action == 'entry' else (0, 0, 255)  # Green entry, Red exit
                            cv2.fillPoly(overlay, [scaled_points], zone_color)
                            cv2.addWeighted(overlay, 0.25, annotated, 0.75, 0, annotated)
                            cv2.polylines(annotated, [scaled_points], True, zone_color, 2)

                            # Add zone name label
                            cv2.putText(annotated, zone_name, (scaled_points[0][0], max(scaled_points[0][1] - 10, 10)),
                                       cv2.FONT_HERSHEY_SIMPLEX, 0.7, zone_color, 2)

                        # Save to temp file and send
                        import tempfile
                        import os
                        temp_path = os.path.join(tempfile.gettempdir(), f'zone_alert_{camera_id}_{action}.jpg')
                        cv2.imwrite(temp_path, annotated)

                        telegram_service.send_alert_with_image(message, annotated, camera_name)
                        logger.info(f"✅ Zone {action} alert with photo sent for zone '{zone_name}' — person highlighted in RED")
                    except Exception as img_err:
                        logger.error(f"Error sending zone alert with image: {img_err}")
                        telegram_service.send_message(message)
                else:
                    telegram_service.send_message(message)
                    logger.info(f"✅ Zone {action} alert sent (no photo) for zone '{zone_name}'")
                
            except Exception as tg_err:
                logger.error(f"Error sending zone telegram alert: {tg_err}")
            
        except Exception as e:
            logger.error(f"Error triggering zone alert: {e}")
    
    def cleanup_stale_tracks_with_exit(self, camera_id, seen_track_ids, zone_objects, current_time):
        """Clean up tracks for people who left the frame and trigger exit alerts with dwell time"""
        try:
            if camera_id not in self.people_tracker:
                return
            
            stale_threshold = 5  # Seconds before considering a track stale (increased for frame skipping)
            tracks_to_remove = []
            
            for track_id, track_data in self.people_tracker[camera_id].items():
                # If we didn't see this person this frame
                if track_id not in seen_track_ids:
                    time_since_seen = (current_time - track_data['last_seen']).total_seconds()
                    
                    # If stale (not seen for X seconds), trigger exits and remove
                    if time_since_seen > stale_threshold:
                        # Trigger EXIT alerts for all zones the person was EVER in.
                        # We intentionally use zone_first_seen (not 'zones') because
                        # 'zones' only reflects the CURRENT zone polygon membership.
                        # If someone walked out of the zone polygon while still visible
                        # in the camera frame, 'zones' would be [] at removal time and
                        # no exit would ever fire.  zone_first_seen preserves every zone
                        # that was entered during the track's lifetime.
                        # If a person was only seen for a single frame, they may have
                        # a pending first-frame entry (queued for direction calculation
                        # next frame) that was never flushed.  Fire those entries now so
                        # the DB entry/exit counts stay balanced.
                        pending = {}
                        if camera_id in self.pending_zone_entries:
                            pending = self.pending_zone_entries[camera_id].pop(track_id, {})
                        for pzone_id, pposition in pending.items():
                            pzone = zone_objects.get(pzone_id)
                            if pzone:
                                try:
                                    logger.info(f"🚪 Flushing pending ENTRY for person {track_id} zone '{pzone.name}' (1-frame track)")
                                    self.trigger_zone_alert(camera_id, pzone, 'entry', track_id,
                                                           track_data.get('position', [0, 0]), 'unknown', dwell_time=0)
                                except Exception as pe_err:
                                    logger.error(f"Pending entry flush error: {pe_err}")

                        previous_zones = list(track_data.get('zone_first_seen', {}).keys())
                        if previous_zones:
                            logger.info(f"🚪 Person {track_id} left frame - was in zones: {previous_zones}")
                            for zone_id in previous_zones:
                                zone = zone_objects.get(zone_id)
                                if zone:
                                    try:
                                        # Calculate dwell time for this zone
                                        zone_first_seen = track_data.get('zone_first_seen', {})
                                        entry_time = zone_first_seen.get(zone_id)
                                        dwell_time = 0
                                        if entry_time:
                                            # Use last_seen time so the 5s stale-threshold isn't
                                            # counted as time-in-zone (fixes inflated dwell times)
                                            dwell_time = max(0, int((track_data['last_seen'] - entry_time).total_seconds()))
                                        
                                        logger.info(f"🚨 Triggering EXIT for zone '{zone.name}' - person left frame (dwell: {dwell_time}s)")
                                        self.trigger_zone_alert(camera_id, zone, 'exit', track_id, 
                                                               track_data.get('position', [0, 0]), 'left-frame', dwell_time=dwell_time)
                                    except Exception as exit_err:
                                        logger.error(f"Exit alert error for departed person: {exit_err}")
                        
                        # Clean up velocity tracking
                        if camera_id in self.track_velocities and track_id in self.track_velocities[camera_id]:
                            del self.track_velocities[camera_id][track_id]
                        
                        tracks_to_remove.append(track_id)
            
            # Remove stale tracks
            for track_id in tracks_to_remove:
                del self.people_tracker[camera_id][track_id]
                # Clean up tripwire position history too
                if camera_id in self.tripwire_prev_positions:
                    self.tripwire_prev_positions[camera_id].pop(track_id, None)
                # Clean up any leftover pending zone entries (shouldn't normally exist
                # after the flush above, but guards against other code paths)
                if camera_id in self.pending_zone_entries:
                    self.pending_zone_entries[camera_id].pop(track_id, None)
                logger.debug(f"Removed stale track {track_id}")
            
            # Periodically flush pending transitions
            if len(self.pending_transitions) > 0:
                self._save_pending_transitions()
        except Exception as e:
            logger.error(f"Error cleaning up stale tracks: {e}")
    
    def get_zone_occupancy_count(self, camera_id, zone_id):
        """Get current occupancy count for a zone"""
        try:
            current_count = 0
            if camera_id in self.people_tracker:
                for track_data in self.people_tracker[camera_id].values():
                    if zone_id in track_data.get('zones', []):
                        current_count += 1
            return current_count
        except Exception:
            return 0
    
    def log_zone_occupancy(self, camera_id, zone_id, timestamp):
        """Log current occupancy count for a zone"""
        try:
            # Count current people in this zone
            current_count = 0
            if camera_id in self.people_tracker:
                for track_data in self.people_tracker[camera_id].values():
                    if zone_id in track_data['zones']:
                        current_count += 1
            
            # Create occupancy log entry
            occupancy_log = OccupancyLog(
                camera_id=camera_id,
                zone_id=zone_id,
                count_type='people',
                count=current_count,
                timestamp=timestamp
            )
            
            db.session.add(occupancy_log)
            db.session.commit()
            
        except Exception as e:
            logger.error(f"Error logging zone occupancy: {e}")
            db.session.rollback()

    @staticmethod
    def segments_cross(p1, p2, p3, p4):
        """Return True if line segment p1->p2 crosses line segment p3->p4.
        Uses the cross-product / orientation test."""
        def cross(o, a, b):
            return (a[0] - o[0]) * (b[1] - o[1]) - (a[1] - o[1]) * (b[0] - o[0])

        d1 = cross(p3, p4, p1)
        d2 = cross(p3, p4, p2)
        d3 = cross(p1, p2, p3)
        d4 = cross(p1, p2, p4)

        if ((d1 > 0 and d2 < 0) or (d1 < 0 and d2 > 0)) and \
           ((d3 > 0 and d4 < 0) or (d3 < 0 and d4 > 0)):
            return True
        return False

    def check_tripwire_crossings(self, camera_id, track_id, curr_pos, tripwire_zones, zone_objects_dict, current_time):
        """Check whether a person's movement path crosses any tripwire/counting lines."""
        try:
            # Initialise camera bucket
            if camera_id not in self.tripwire_prev_positions:
                self.tripwire_prev_positions[camera_id] = {}

            prev_pos = self.tripwire_prev_positions[camera_id].get(track_id)

            # Store current position for next frame
            self.tripwire_prev_positions[camera_id][track_id] = curr_pos

            if prev_pos is None:
                return  # Need at least two positions

            for zone in tripwire_zones:
                try:
                    line_pts = zone.get_line_points()
                    if not line_pts or len(line_pts) < 2:
                        continue

                    lp1, lp2 = line_pts[0], line_pts[1]

                    if not self.segments_cross(prev_pos, curr_pos, lp1, lp2):
                        continue

                    # ── COUNTING / ENTRANCE ZONE ────────────────────────────────
                    # For counting zones, determine entry vs exit from the crossing
                    # direction and maintain a running inside count.
                    # Cross-product sign tells us which side of the line each
                    # position is on.  Positive = "left" when facing P1→P2.
                    if zone.zone_type == 'counting':
                        # People counting requires an active people_counting license
                        if not _check_license('people_counting'):
                            continue  # skip entrance counting without license
                        # Reset count at midnight
                        today = current_time.date()
                        if self.entrance_last_reset.get(zone.id) != today:
                            self.entrance_inside_counts[zone.id] = 0
                            self.entrance_last_reset[zone.id] = today

                        dx = lp2[0] - lp1[0]
                        dy = lp2[1] - lp1[1]
                        prev_side = dx * (prev_pos[1] - lp1[1]) - dy * (prev_pos[0] - lp1[0])
                        curr_side = dx * (curr_pos[1] - lp1[1]) - dy * (curr_pos[0] - lp1[0])

                        # Crossing from negative→positive side = "left-to-right" relative
                        # to the line direction.  line_direction controls which is "entry".
                        line_dir = getattr(zone, 'line_direction', 'left_to_right') or 'left_to_right'
                        crossed_positive = (prev_side < 0 and curr_side >= 0)  # neg→pos
                        crossed_negative = (prev_side > 0 and curr_side <= 0)  # pos→neg

                        # Default: left_to_right (neg→pos) = entry
                        if line_dir in ('left_to_right', 'both', 'down', ''):
                            is_entry = crossed_positive
                        else:  # right_to_left / up
                            is_entry = crossed_negative

                        inside = self.entrance_inside_counts.get(zone.id, 0)
                        if is_entry:
                            inside = max(0, inside + 1)
                            log_entries, log_exits = 1, 0
                            direction_label = 'entry'
                        else:
                            inside = max(0, inside - 1)
                            log_entries, log_exits = 0, 1
                            direction_label = 'exit'

                        self.entrance_inside_counts[zone.id] = inside
                        logger.info(
                            f"🚶 COUNTING LINE '{zone.name}': {direction_label} "
                            f"by track {track_id} | inside={inside}"
                        )

                        # Write one entry to OccupancyLog so analytics and the DB
                        # fallback for PEOPLE NOW both get accurate data.
                        try:
                            occ = OccupancyLog(
                                camera_id=camera_id,
                                zone_id=zone.id,
                                count_type='entrance',
                                count=inside,
                                entries=log_entries,
                                exits=log_exits,
                                timestamp=current_time,
                            )
                            db.session.add(occ)

                            # Entry crossings count as a person detection on the main
                            # dashboard.  Exit crossings are analytics-only — they must
                            # NOT inflate the dashboard people total.
                            if is_entry:
                                entry_event = DetectionEvent(
                                    camera_id=camera_id,
                                    detected_class='person',
                                    confidence=1.0,
                                )
                                db.session.add(entry_event)

                            db.session.commit()
                        except Exception as _db_err:
                            logger.debug(f"Entrance OccupancyLog write error: {_db_err}")
                            try:
                                db.session.rollback()
                            except Exception:
                                pass
                        continue  # skip tripwire alert for counting zones

                    # ── TRIPWIRE ALERT ───────────────────────────────────────────
                    direction = self.calculate_movement_direction(prev_pos, curr_pos)
                    logger.info(f"⚡ TRIPWIRE CROSSING: zone '{zone.name}' by track {track_id}")
                    self.trigger_zone_alert(
                        camera_id, zone, 'crossing', track_id, curr_pos, direction, dwell_time=0
                    )
                except Exception as zone_err:
                    logger.error(f"Tripwire zone check error: {zone_err}")

        except Exception as e:
            logger.error(f"check_tripwire_crossings error: {e}")

    def process_zone_detections(self, camera_id, detections):
        """Process detections for zone-based analytics with enhanced tracking and accuracy"""
        try:
            # Skip if zone detection is not enabled
            config = SystemConfig.query.first()
            if not config or not config.enable_zone_detection:
                logger.debug(f"Zone detection disabled in config")
                return

            # License check — stop if zone_detection license has expired
            if not _check_license('zone_detection'):
                logger.warning("Zone Detection license expired — zone processing disabled. Renew at /license")
                return
            
            current_time = datetime.utcnow()
            
            # Track which people we see this frame (for detecting exits)
            seen_track_ids = set()
            
            # Get all active zones for this camera
            active_zones = DetectionZone.query.filter_by(camera_id=camera_id, is_active=True).all()
            
            # If no zones configured, still need to cleanup stale tracks
            if not active_zones:
                logger.debug(f"No active zones for camera {camera_id}")
                # Still process for exit detection when person leaves frame
                zone_objects = {}
                for detection in detections:
                    if detection['class'] == 'person':
                        track_id = detection.get('track_id')
                        if track_id is not None:
                            seen_track_ids.add(track_id)
                self.cleanup_stale_tracks_with_exit(camera_id, seen_track_ids, zone_objects, current_time)
                return
            
            logger.debug(f"📍 Processing {len(detections)} detections for {len(active_zones)} zones on camera {camera_id}")
            
            # Cache zone objects to avoid repeated queries
            zone_objects = {z.id: z for z in active_zones}

            # Collect tripwire zones AND entrance/counting lines for line-crossing detection
            # Tripwires require line_crossing license.
            # Counting (entrance) zones only require people_counting license.
            _zone_ok = _check_license('zone_detection')
            _count_ok = _check_license('people_counting')
            tripwire_zones = []
            if _zone_ok:
                tripwire_zones += [z for z in active_zones if z.zone_type == 'tripwire']
            if _zone_ok or _count_ok:
                tripwire_zones += [z for z in active_zones
                                   if z.zone_type == 'counting' and z.get_line_points()]
            
            # Get camera object for alerts
            camera = Camera.query.get(camera_id)
            if not camera:
                return
            
            # ENHANCED: Apply IOU matching to improve track continuity
            detections = self.match_tracks_iou(camera_id, detections)
            
            # Get frame dimensions to scale detection coords → zone canvas coords (800×600)
            cached_frame = self.camera_frames.get(camera_id)
            if cached_frame is not None:
                frame_h, frame_w = cached_frame.shape[:2]
            else:
                frame_h, frame_w = 600, 800  # fallback: already in zone space
            
            # RE-CHECK ZONE MEMBERSHIP for each detection using enhanced anchor point
            for detection in detections:
                if detection['class'] == 'person':
                    # Use configurable anchor point for better zone accuracy
                    center = self.get_detection_anchor_point(detection, self.detection_anchor_point)
                    
                    # Scale from camera frame resolution → zone canvas coordinates (800×600)
                    # Zones are drawn on an 800×600 canvas; detections are in native frame pixels
                    if frame_w > 0 and frame_h > 0 and (frame_w != 800 or frame_h != 600):
                        zone_center = [
                            center[0] * 800.0 / frame_w,
                            center[1] * 600.0 / frame_h
                        ]
                    else:
                        zone_center = center
                    
                    detection['center'] = zone_center  # Use zone-space coords for all downstream checks

                    # Update movement trail for path tracking overlay
                    track_id = detection.get('track_id')
                    if track_id is not None:
                        if camera_id not in self.camera_track_trails:
                            self.camera_track_trails[camera_id] = {}
                        trail = self.camera_track_trails[camera_id].setdefault(track_id, [])
                        trail.append({'x': round(zone_center[0], 1), 'y': round(zone_center[1], 1), 't': time.time()})
                        if len(trail) > 60:  # keep last 60 points (~2s at 30fps)
                            self.camera_track_trails[camera_id][track_id] = trail[-60:]

                    detection_zones = []
                    
                    # Check each zone
                    for zone in active_zones:
                        polygon_points = zone.get_polygon_points()
                        # Apply per-zone confidence threshold (default 0.35)
                        zone_min_conf = getattr(zone, 'min_confidence', 0.35) or 0.35
                        det_confidence = detection.get('confidence', 1.0)
                        if polygon_points and zone.detect_person and det_confidence >= zone_min_conf:
                            if self.point_in_polygon(zone_center, polygon_points):
                                detection_zones.append(zone.id)
                                logger.debug(f"🎯 Person in zone '{zone.name}' (anchor: {self.detection_anchor_point})")
                    
                    detection['zones'] = detection_zones
            
            # Update heatmap data periodically
            try:
                self.update_heatmap_data(camera_id, detections, active_zones)
            except Exception as heatmap_err:
                logger.debug(f"Heatmap update error: {heatmap_err}")
            
            # Check crowd capacity for counting zones
            crowd_zones = [z for z in active_zones if z.zone_type == 'crowd' and z.max_capacity and z.max_capacity > 0]
            if crowd_zones:
                try:
                    from telegram_service import telegram_service
                    self.check_crowd_capacity(camera, crowd_zones, detections, telegram_service)
                except Exception as crowd_err:
                    logger.error(f"Crowd capacity check error: {crowd_err}")
            
            # Process each person detection for entry/exit tracking
            for detection in detections:
                # Update people tracker for entry/exit detection
                if detection['class'] == 'person':
                    track_id = detection.get('track_id')
                    center = detection.get('center', [0, 0])
                    
                    # IMPROVED: If no track_id OR if track_id is NEW (not in tracker),
                    # try to match by position to maintain continuity
                    if track_id is None:
                        track_id = self.find_closest_track(camera_id, center, max_distance=150)
                        if track_id is None:
                            # No close match - generate new ID
                            track_id = f"person_{int(current_time.timestamp() * 1000) % 100000}"
                    elif camera_id in self.people_tracker and track_id not in self.people_tracker[camera_id]:
                        # YOLO gave us a NEW track_id - try to match to existing track by position
                        matched_id = self.find_closest_track(camera_id, center, max_distance=150)
                        if matched_id is not None:
                            logger.info(f"🔄 Matched new YOLO track {track_id} to existing track {matched_id} by position")
                            track_id = matched_id
                    
                    # Track which IDs we've seen this frame
                    seen_track_ids.add(track_id)
                    
                    # Get zones this person is in
                    person_zones = []
                    for zone_id in detection.get('zones', []):
                        if zone_id in zone_objects:
                            person_zones.append(zone_objects[zone_id])
                    
                    logger.debug(f"👤 Person track_id={track_id} center={center} in {len(person_zones)} zones")
                    
                    # ALWAYS call update_people_tracker to detect entry/exit transitions
                    # This must be called even when person_zones is empty to detect exits!
                    try:
                        self.update_people_tracker(
                            camera_id,
                            track_id,
                            person_zones,
                            center,
                            bbox=detection.get('bbox')
                        )
                    except Exception as tracker_err:
                        logger.error(f"People tracker error: {tracker_err}")

                    # Check for tripwire line crossings
                    if tripwire_zones:
                        try:
                            self.check_tripwire_crossings(
                                camera_id, track_id, center,
                                tripwire_zones, zone_objects, current_time
                            )
                        except Exception as tw_err:
                            logger.error(f"Tripwire check error: {tw_err}")
            
            # Store latest detections for use in zone/line alert annotation
            self.camera_detections[camera_id] = detections

            # CRITICAL: Detect exits for people who left the frame entirely
            self.cleanup_stale_tracks_with_exit(camera_id, seen_track_ids, zone_objects, current_time)
            
            # Log zone occupancy periodically (every 10 seconds)
            for zone in active_zones:
                count = self.count_people_in_zone(detections, zone)
                zone.current_occupancy = count
                logger.debug(f"📊 Zone '{zone.name}': {count} people")
            
            try:
                db.session.commit()
            except:
                db.session.rollback()
            
        except Exception as e:
            logger.error(f"Error processing zone detections: {e}")
            import traceback
            logger.error(traceback.format_exc())
    
    def update_camera_status(self, camera_id, is_online, camera_name=None, location=None):
        """Update camera online/offline status and send notifications with cooldown"""
        current_time = datetime.utcnow()
        
        # Initialize camera status if not exists
        if camera_id not in self.camera_status:
            self.camera_status[camera_id] = {
                'online': True,
                'last_seen': current_time,
                'offline_notified': False,
                'offline_since': None,
                'last_notification_time': None,
                'consecutive_failures': 0
            }
        
        camera_status = self.camera_status[camera_id]
        previous_status = camera_status['online']
        
        # Update status
        camera_status['online'] = is_online
        
        # Check notification cooldown (prevent spam)
        last_notif = camera_status.get('last_notification_time')
        if last_notif:
            time_since_notif = (current_time - last_notif).total_seconds()
            if time_since_notif < self.camera_notification_cooldown:
                # Still in cooldown, just update status quietly
                if is_online:
                    camera_status['last_seen'] = current_time
                    camera_status['consecutive_failures'] = 0
                return
        
        if is_online:
            camera_status['last_seen'] = current_time
            camera_status['consecutive_failures'] = 0
            
            # If camera was offline, send back online notification
            if not previous_status and camera_status['offline_notified']:
                # Only notify if it was offline for at least 2 minutes
                if camera_status['offline_since']:
                    offline_delta = current_time - camera_status['offline_since']
                    if offline_delta.total_seconds() < 120:
                        # Short disconnection, don't spam
                        camera_status['offline_notified'] = False
                        camera_status['offline_since'] = None
                        logger.info(f"Camera {camera_id} back online (short outage, no notification)")
                        return
                    
                    hours = int(offline_delta.total_seconds() // 3600)
                    minutes = int((offline_delta.total_seconds() % 3600) // 60)
                    if hours > 0:
                        offline_duration = f"{hours}h {minutes}m"
                    else:
                        offline_duration = f"{minutes}m"
                else:
                    offline_duration = None
                
                telegram_service.send_camera_online_alert(
                    camera_name or f"Camera {camera_id}",
                    location,
                    offline_duration
                )
                
                camera_status['offline_notified'] = False
                camera_status['offline_since'] = None
                camera_status['last_notification_time'] = current_time
                logger.info(f"Camera {camera_id} back online - notification sent")
        
        else:
            # Camera is offline - require multiple consecutive failures before alerting
            camera_status['consecutive_failures'] = camera_status.get('consecutive_failures', 0) + 1
            
            # After 3 consecutive failures, record when the camera went offline
            if camera_status.get('consecutive_failures', 0) >= 3 and camera_status.get('offline_since') is None:
                camera_status['offline_since'] = current_time
                # Clear stale detections so people_now drops to 0 immediately
                self.camera_detections[camera_id] = []
                self.camera_raw_counts[camera_id] = 0
                self._seen_person_track_ids.pop(camera_id, None)
                logger.warning(f"Camera {camera_id} went offline - waiting for threshold before alerting")
            
            # Only alert if we haven't already notified AND the camera has been offline long enough
            if not camera_status['offline_notified'] and camera_status.get('offline_since'):
                # Read threshold from system config
                try:
                    with self.app.app_context():
                        cfg = SystemConfig.query.first()
                        threshold_minutes = int(getattr(cfg, 'camera_offline_alert_minutes', 5)) if cfg else 5
                except Exception:
                    threshold_minutes = 5
                
                offline_secs = (current_time - camera_status['offline_since']).total_seconds()
                if offline_secs >= threshold_minutes * 60:
                    telegram_service.send_camera_offline_alert(
                        camera_name or f"Camera {camera_id}",
                        location,
                        camera_status['last_seen'].strftime('%Y-%m-%d %H:%M:%S')
                    )
                    camera_status['offline_notified'] = True
                    camera_status['last_notification_time'] = current_time
                    logger.warning(f"Camera {camera_id} offline for {offline_secs/60:.1f}m - notification sent")
    
    def generate_alternate_rtsp_urls(self, original_url):
        """Generate alternate RTSP URL formats for different NVR/camera brands"""
        alternate_urls = []
        
        try:
            # Parse the original URL to extract components
            import re
            from urllib.parse import urlparse, quote
            
            parsed = urlparse(original_url)
            
            # Extract credentials and host
            if '@' in parsed.netloc:
                auth_part, host_part = parsed.netloc.rsplit('@', 1)
                if ':' in auth_part:
                    username, password = auth_part.split(':', 1)
                else:
                    username = auth_part
                    password = ''
            else:
                host_part = parsed.netloc
                username = 'admin'
                password = 'admin'
            
            # Extract host and port
            if ':' in host_part:
                host, port = host_part.split(':')
            else:
                host = host_part
                port = '554'
            
            # URL-encode password if it contains special characters
            encoded_password = quote(password, safe='')
            
            # Build base auth string
            auth = f"{username}:{encoded_password}@{host}:{port}"
            
            # Try to determine channel number from path
            path = parsed.path
            channel = 1
            
            # Extract channel from various formats
            channel_match = re.search(r'[Cc]hannel[s]?[/=]?(\d+)', path)
            if channel_match:
                channel = int(channel_match.group(1))
                # Hikvision uses 101, 201 format - extract actual channel
                if channel >= 100:
                    channel = channel // 100
            
            ch_match = re.search(r'ch(\d+)', path, re.IGNORECASE)
            if ch_match:
                channel = int(ch_match.group(1))
            
            realmonitor_match = re.search(r'channel=(\d+)', path)
            if realmonitor_match:
                channel = int(realmonitor_match.group(1))
            
            # Generate URLs for different NVR/camera brands

            # ── Bare root path (some Provision ISR IP cameras use rtsp://ip:554/) ──
            alternate_urls.append(f"rtsp://{auth}/")

            # Hikvision formats
            alternate_urls.append(f"rtsp://{auth}/Streaming/Channels/{channel}01")
            alternate_urls.append(f"rtsp://{auth}/Streaming/Channels/{channel}02")  # Sub stream
            alternate_urls.append(f"rtsp://{auth}/ISAPI/Streaming/Channels/{channel}01")
            alternate_urls.append(f"rtsp://{auth}/h264/ch{channel}/main/av_stream")
            alternate_urls.append(f"rtsp://{auth}/h264/ch{channel}/sub/av_stream")  # Sub stream
            alternate_urls.append(f"rtsp://{auth}/Streaming/Channels/{channel}")

            # Hikvision formats (continued)
            alternate_urls.append(f"rtsp://{auth}/cam/realmonitor?channel={channel}&subtype=1")
            # Provision NVR-8200 / NVR-8300 / AHD NVR unicast variant
            alternate_urls.append(f"rtsp://{auth}/cam/realmonitor?channel={channel}&subtype=0&unicast=true&proto=Onvif")
            alternate_urls.append(f"rtsp://{auth}/cam/realmonitor?channel={channel}&subtype=2")
            # Provision ISR NVR — zero-padded channel is common
            for _ch in [channel, 1]:
                alternate_urls.append(f"rtsp://{auth}/cam/realmonitor?channel={_ch:02d}&subtype=0")
            alternate_urls.append(f"rtsp://{auth}/live")
            alternate_urls.append(f"rtsp://{auth}/live/ch{channel:02d}_0")
            alternate_urls.append(f"rtsp://{auth}/live/ch{channel:02d}_1")
            alternate_urls.append(f"rtsp://{auth}/live/ch00_0")  # Provision standalone camera
            alternate_urls.append(f"rtsp://{auth}/live/ch00_1")
            alternate_urls.append(f"rtsp://{auth}/live/main")
            alternate_urls.append(f"rtsp://{auth}/live/sub")
            # Provision ISR PoE cameras
            alternate_urls.append(f"rtsp://{auth}/11")
            alternate_urls.append(f"rtsp://{auth}/12")
            
            # Provision standalone IP camera formats
            alternate_urls.append(f"rtsp://{auth}/stream1")
            alternate_urls.append(f"rtsp://{auth}/stream2")
            alternate_urls.append(f"rtsp://{auth}/media/video1")  # Uniview/Provision
            alternate_urls.append(f"rtsp://{auth}/media/video2")
            alternate_urls.append(f"rtsp://{auth}/profile1")
            alternate_urls.append(f"rtsp://{auth}/profile2")
            alternate_urls.append(f"rtsp://{auth}/video")
            alternate_urls.append(f"rtsp://{auth}/videoinput_1/h264_1")
            alternate_urls.append(f"rtsp://{auth}/videoMain")
            alternate_urls.append(f"rtsp://{auth}/videoSub")
            
            # ONVIF standard
            alternate_urls.append(f"rtsp://{auth}/onvif1")
            alternate_urls.append(f"rtsp://{auth}/onvif2")
            alternate_urls.append(f"rtsp://{auth}/onvif/profile1/media.smp")
            alternate_urls.append(f"rtsp://{auth}/onvif/profile2/media.smp")
            
            # Generic formats
            alternate_urls.append(f"rtsp://{auth}/ch{channel:02d}/0")
            alternate_urls.append(f"rtsp://{auth}/ch{channel:02d}/main")
            alternate_urls.append(f"rtsp://{auth}/stream{channel}")
            alternate_urls.append(f"rtsp://{auth}/video{channel}")
            alternate_urls.append(f"rtsp://{auth}/MediaInput/h264/stream_1")
            # (bare root rtsp://ip:554/ is added at the top of this list)

            # Remove duplicates and the original URL
            alternate_urls = list(dict.fromkeys(alternate_urls))
            if original_url in alternate_urls:
                alternate_urls.remove(original_url)
            
            logger.info(f"Generated {len(alternate_urls)} alternate RTSP URLs to try")
            
        except Exception as e:
            logger.error(f"Error generating alternate RTSP URLs: {e}")
        
        return alternate_urls
    
    def check_camera_timeouts(self):
        """Check for cameras that have been offline too long"""
        current_time = datetime.utcnow()
        timeout_seconds = 180  # 3 minutes timeout
        
        for camera_id, status in self.camera_status.items():
            if status['online']:
                # Check if camera hasn't been seen recently
                time_since_seen = (current_time - status['last_seen']).total_seconds()
                if time_since_seen > timeout_seconds:
                    # Mark camera as offline
                    with self.app.app_context():
                        camera = Camera.query.get(camera_id)
                        if camera:
                            self.update_camera_status(camera_id, False, camera.name, camera.location)
    
    # =========================================================================
    # ANOMALY DETECTION
    # =========================================================================
    def update_activity_baseline(self, camera_id, count):
        """
        Update the rolling hourly activity baseline for a camera.
        Call once per processed YOLO frame with the number of detections seen.
        The baseline accumulates total detections per hour-of-day over the last 14 days.
        Zero extra CPU cost — pure Python math on small deques.
        """
        hour = datetime.utcnow().hour
        if camera_id not in self.activity_baseline:
            self.activity_baseline[camera_id] = {}
        cam = self.activity_baseline[camera_id]
        if hour not in cam:
            cam[hour] = collections.deque(maxlen=14)
        cam[hour].append(count)

    def check_anomaly(self, camera_id, current_count):
        """
        Returns (is_anomaly: bool, z_score: float, expected_mean: float).
        Requires at least 5 data points before flagging anything.
        """
        hour = datetime.utcnow().hour
        baseline = self.activity_baseline.get(camera_id, {}).get(hour)
        if not baseline or len(baseline) < 5:
            return False, 0.0, 0.0
        arr = list(baseline)
        mean = sum(arr) / len(arr)
        variance = sum((x - mean) ** 2 for x in arr) / len(arr)
        std = variance ** 0.5
        if std < 1.0:  # Effectively no variance — skip to avoid division noise
            return False, 0.0, mean
        z = (current_count - mean) / std
        is_anomaly = z > self.anomaly_z_threshold
        return is_anomaly, round(z, 2), round(mean, 1)

    def send_anomaly_alert(self, camera, current_count, z_score, expected):
        """Send a Telegram anomaly alert with 10-minute cooldown per camera."""
        if self.telegram_service is None:
            return
        camera_id = camera.id
        now = datetime.utcnow()
        last = self._last_anomaly_alert.get(camera_id)
        if last and (now - last).total_seconds() < 600:
            return  # 10-minute cooldown
        self._last_anomaly_alert[camera_id] = now
        hour = now.hour
        time_label = f"{hour:02d}:00–{hour:02d}:59 UTC"
        msg = (
            f"📊 <b>Anomaly Detected</b>\n\n"
            f"📷 <b>Camera:</b> {camera.name}\n"
            f"📍 <b>Location:</b> {camera.location or 'Unknown'}\n"
            f"⚠️ <b>Current activity:</b> {current_count} detections\n"
            f"📉 <b>Normal for {time_label}:</b> ~{expected}\n"
            f"📈 <b>Deviation:</b> {z_score}× above normal\n\n"
            f"<i>Unusual activity level detected — this time of day is normally much quieter.</i>\n"
            f"⏰ {now.strftime('%Y-%m-%d %H:%M:%S')} UTC"
        )
        try:
            self.telegram_service.send_message(msg)
            logger.info(f"📊 Anomaly alert sent for camera {camera.name} (z={z_score})")
        except Exception as e:
            logger.error(f"Failed to send anomaly alert: {e}")

    # =========================================================================
    # FACE BLURRING
    # =========================================================================
    def blur_faces_in_frame(self, frame, detections):
        """
        Blur the face region (upper 28% of the bounding box) of every detected person.
        Uses a single GaussianBlur pass per person — negligible CPU on Pi 5.
        Returns a new frame (does not modify in place).
        """
        if frame is None or not detections:
            return frame
        out = frame.copy()
        h_frame, w_frame = out.shape[:2]
        for det in detections:
            if det.get('class') != 'person':
                continue
            bbox = det.get('bbox', {})
            if isinstance(bbox, dict):
                # Support both {x1,y1,x2,y2} and {x,y,width,height} formats
                if 'x1' in bbox:
                    x1 = int(bbox['x1'])
                    y1 = int(bbox['y1'])
                    x2 = int(bbox['x2'])
                    y2 = int(bbox['y2'])
                elif 'x' in bbox:
                    x1 = int(bbox['x'])
                    y1 = int(bbox['y'])
                    x2 = x1 + int(bbox['width'])
                    y2 = y1 + int(bbox['height'])
                else:
                    continue
            else:
                continue
            person_h = y2 - y1
            # Face region = upper 35% of person bbox (covers head/neck regardless of distance)
            face_y2 = min(y1 + int(person_h * 0.35), y2, h_frame)
            face_x1 = max(x1, 0)
            face_x2 = min(x2, w_frame)
            if face_x2 <= face_x1 or face_y2 <= y1:
                continue
            roi = out[y1:face_y2, face_x1:face_x2]
            if roi.size == 0:
                continue
            k = self.face_blur_kernel
            # Apply strong pixelation: downscale then upscale for obvious privacy blur
            small = cv2.resize(roi, (max(1, roi.shape[1] // 10), max(1, roi.shape[0] // 10)), interpolation=cv2.INTER_LINEAR)
            blurred = cv2.resize(small, (roi.shape[1], roi.shape[0]), interpolation=cv2.INTER_NEAREST)
            out[y1:face_y2, face_x1:face_x2] = blurred
        return out

    # =========================================================================
    # IMPROVED FALL DETECTION  (aspect-ratio + velocity based)
    # =========================================================================
    def _detect_falling_enhanced(self, camera_id, detections):
        """
        Improved fall detection using both velocity AND bounding-box aspect ratio.
        A standing person is tall (height > width).  A fallen person is wide (width > height).
        Detects the transition from portrait to landscape orientation as a fall event.
        Zero extra model — pure geometry on existing YOLO boxes.
        """
        positions = self.person_positions.get(camera_id, {})
        for det in detections:
            if det.get('class') != 'person':
                continue
            bbox = det.get('bbox', {})
            if not isinstance(bbox, dict):
                continue
            x1, y1 = int(bbox.get('x1', 0)), int(bbox.get('y1', 0))
            x2, y2 = int(bbox.get('x2', 0)), int(bbox.get('y2', 0))
            w = x2 - x1
            h = y2 - y1
            if h <= 0:
                continue
            aspect = w / h  # <1 = standing, >1.4 = likely fallen/crouching
            track_id = det.get('track_id', id(det))
            pos_hist = positions.get(camera_id, {}).get(track_id, []) if isinstance(positions.get(camera_id), dict) else []
            # Check velocity-based fall (rapid downward + now horizontal)
            if len(pos_hist) >= 5:
                recent = pos_hist[-5:]
                time_diff = (recent[-1]['time'] - recent[0]['time']).total_seconds()
                if time_diff > 0:
                    vy = (recent[-1]['y'] - recent[0]['y']) / time_diff
                    if vy > 120 and aspect > 1.2:
                        return {
                            'type': 'fall',
                            'severity': 'high',
                            'track_id': track_id,
                            'description': f'Person may have fallen! (aspect={aspect:.2f}, vy={vy:.0f}px/s)',
                            'bbox': bbox
                        }
            # Check purely orientation-based fall (very wide bbox)
            if aspect > 1.6:
                return {
                    'type': 'fall',
                    'severity': 'high',
                    'track_id': track_id,
                    'description': f'Person appears to be lying down (aspect={aspect:.2f})',
                    'bbox': bbox
                }
        return None

    # =========================================================================
    # SMART ALERT SUMMARY  (context-aware Telegram messages)
    # =========================================================================
    def build_smart_summary(self, camera, detections, zone_info=None, elapsed_seconds=None):
        """
        Build a context-aware alert summary instead of generic "X detected".
        Examples:
          '3 people entered the Staff Room zone at 02:15 — unusual for this time of night'
          'Person lingering near the Safe Area for 8 minutes'
          '4 vehicles detected at Main Gate — 2× above normal'
        Purely template-based, zero CPU cost.
        """
        now = datetime.utcnow()
        hour = now.hour
        time_str = now.strftime('%H:%M')

        # Time-of-day label
        if 0 <= hour < 6:
            time_label = 'late night'
        elif 6 <= hour < 12:
            time_label = 'morning'
        elif 12 <= hour < 18:
            time_label = 'afternoon'
        else:
            time_label = 'evening'

        # Count by class
        class_counts = {}
        for det in detections:
            c = det.get('class', 'object')
            class_counts[c] = class_counts.get(c, 0) + 1

        person_count = class_counts.get('person', 0)
        vehicle_count = sum(class_counts.get(v, 0) for v in ['car', 'truck', 'bus', 'motorcycle'])
        _animal_classes = ['dog', 'cat', 'bird', 'horse', 'sheep', 'cow', 'zebra', 'giraffe']
        animal_count = sum(class_counts.get(a, 0) for a in _animal_classes)
        _animal_types = [a for a in _animal_classes if class_counts.get(a, 0) > 0]
        if len(_animal_types) == 1:
            _aname = _animal_types[0]
            animal_label = f'{_aname}s' if animal_count > 1 else _aname
        else:
            animal_label = f'animal{"s" if animal_count > 1 else ""}'

        # Build zone context
        zone_names = []
        if zone_info:
            zone_names = [z.get('name', '') for z in zone_info if z.get('name')]

        zone_str = f" in <b>{', '.join(zone_names)}</b>" if zone_names else ''
        duration_str = f' for {elapsed_seconds // 60}m {elapsed_seconds % 60}s' if elapsed_seconds and elapsed_seconds > 30 else ''

        # Anomaly hint
        is_anomaly, z_score, expected = self.check_anomaly(camera.id, len(detections))
        anomaly_hint = f' — ⚠️ {z_score}× above normal for {time_label}' if is_anomaly else ''

        # Build the main line
        if person_count > 0 and vehicle_count > 0 and animal_count > 0:
            subject = f'{person_count} {"person" if person_count == 1 else "people"}, {vehicle_count} vehicle{"s" if vehicle_count > 1 else ""} and {animal_count} {animal_label}'
        elif person_count > 0 and vehicle_count > 0:
            subject = f'{person_count} {"person" if person_count == 1 else "people"} and {vehicle_count} vehicle{"s" if vehicle_count > 1 else ""}'
        elif person_count > 0 and animal_count > 0:
            subject = f'{person_count} {"person" if person_count == 1 else "people"} and {animal_count} {animal_label}'
        elif person_count > 0:
            subject = f'{person_count} {"person" if person_count == 1 else "people"}'
        elif vehicle_count > 0 and animal_count > 0:
            subject = f'{vehicle_count} vehicle{"s" if vehicle_count > 1 else ""} and {animal_count} {animal_label}'
        elif vehicle_count > 0:
            subject = f'{vehicle_count} vehicle{"s" if vehicle_count > 1 else ""}'
        elif animal_count > 0:
            subject = f'{animal_count} {animal_label}'
        else:
            other = ', '.join(f'{v} {k}' for k, v in class_counts.items())
            subject = other or 'activity'

        summary = f'{subject.capitalize()} detected{zone_str}{duration_str}{anomaly_hint}.'
        return summary

    # =========================================================================
    # PER-CAMERA CONFIDENCE AUTO-TUNING
    # =========================================================================
    def get_camera_threshold(self, camera_id):
        """
        Return the current adjusted confidence threshold for a camera.
        Starts at _conf_base (0.35). If many false positives are recorded in the
        last hour the threshold auto-raises (up to _conf_max=0.65).
        After a quiet hour it gradually drops back toward _conf_base.
        Zero CPU — a simple float lookup.
        """
        now = time.time()
        # Reset window if expired
        window_start = self.camera_fp_window_start.get(camera_id, 0)
        if now - window_start > self._conf_window_seconds:
            fp = self.camera_fp_counts.get(camera_id, 0)
            current = self.camera_conf_thresholds.get(camera_id, self._conf_base)
            if fp > 10:
                # Many FP this hour — tighten threshold by 0.05
                new_thresh = min(current + 0.05, self._conf_max)
            elif fp == 0 and current > self._conf_base:
                # Zero FP this hour — relax threshold slightly
                new_thresh = max(current - 0.02, self._conf_base)
            else:
                new_thresh = current
            self.camera_conf_thresholds[camera_id] = new_thresh
            self.camera_fp_counts[camera_id] = 0
            self.camera_fp_window_start[camera_id] = now
            if new_thresh != current:
                logger.info(f"🎯 Camera {camera_id} confidence threshold auto-tuned: {current:.2f} → {new_thresh:.2f} (FP last hour: {fp})")
        return self.camera_conf_thresholds.get(camera_id, self._conf_base)

    def record_false_positive(self, camera_id):
        """
        Call this when a detection is dismissed as a false positive
        (e.g. from a Telegram inline button press or API endpoint).
        """
        self.camera_fp_counts[camera_id] = self.camera_fp_counts.get(camera_id, 0) + 1
        if camera_id not in self.camera_fp_window_start:
            self.camera_fp_window_start[camera_id] = time.time()
        threshold = self.camera_conf_thresholds.get(camera_id, self._conf_base)
        logger.info(f"📉 False positive recorded for camera {camera_id} "
                    f"(total this hour: {self.camera_fp_counts[camera_id]}, "
                    f"threshold: {threshold:.2f})")

    # =========================================================================
    # TAMPER DETECTION
    # =========================================================================

    def _check_tamper(self, camera_id, frame, camera):
        """
        Compare current frame against reference to detect camera tamper events:
        - Camera moved/rotated   (global scene shift)
        - Camera covered/blocked (very low variance)
        - Camera spray-painted   (flat-colour frame)
        Not triggered when a person is actively in frame (they could be adjusting it legitimately).
        """
        if not getattr(camera, 'enable_tamper_detection', False):
            return
        # Skip PTZ cameras — they are intended to move
        if getattr(camera, 'has_ptz', False):
            return

        now = time.time()

        # Sensitivity: (diff_threshold, consecutive_frames_needed)
        sensitivity = getattr(camera, 'tamper_sensitivity', 'medium')
        # Increased consec_thresh to 4/3/3 — reduces false triggers from transient glitches
        thresholds = {'low': (0.42, 5), 'medium': (0.30, 4), 'high': (0.20, 3)}
        diff_thresh, consec_thresh = thresholds.get(sensitivity, thresholds['medium'])

        # Warm-up: on first call set reference and wait 30s before alerting
        if camera_id not in self.tamper_ref_set_times:
            gray_init = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
            self.tamper_reference_frames[camera_id] = gray_init
            hsv_init = cv2.cvtColor(frame, cv2.COLOR_BGR2HSV)
            self.tamper_ref_sat[camera_id] = float(cv2.mean(hsv_init[:, :, 1])[0])
            self.tamper_ref_set_times[camera_id] = now
            return
        if now - self.tamper_ref_set_times[camera_id] < 30:
            return

        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        ref = self.tamper_reference_frames.get(camera_id)

        if ref is None or ref.shape != gray.shape:
            self.tamper_reference_frames[camera_id] = gray
            self.tamper_ref_set_times[camera_id] = now
            return

        # Compute frame stats for tamper analysis
        cur_mean = float(cv2.mean(gray)[0])
        cur_std  = float(cv2.meanStdDev(gray)[1][0][0])
        ref_mean = float(cv2.mean(ref)[0])

        # ── IR cut-filter / day-night switch detection ───────────────────────
        # When camera switches color↔B&W the saturation channel collapses or
        # jumps. This is the most reliable signal — brightness change alone is
        # not enough because objects reflect IR differently.
        hsv = cv2.cvtColor(frame, cv2.COLOR_BGR2HSV)
        cur_sat = float(cv2.mean(hsv[:, :, 1])[0])
        ref_sat = self.tamper_ref_sat.get(camera_id, cur_sat)
        sat_change = abs(cur_sat - ref_sat)

        # IR switch: saturation collapses (color→B/W) or jumps (B/W→color)
        # Threshold: >25 on 0-255 scale reliably separates IR switch from scene noise
        ir_switch_by_sat = sat_change > 25

        # Covered/blocked detection: very low std dev OR very dark frame
        covered = cur_std < 25 or cur_mean < 25
        if covered:
            diff_ratio = 1.0  # treat as full tamper — skip IR check below
        else:
            diff_img        = cv2.absdiff(gray, ref)
            diff_ratio      = float(diff_img.mean()) / 255.0
            diff_uniformity = float(cv2.meanStdDev(diff_img)[1][0][0])

            # Brightness-based IR switch: large mean shift + relatively uniform diff
            ir_switch_by_brightness = abs(cur_mean - ref_mean) > 35 and diff_uniformity < 45 and diff_ratio < 0.50

            if ir_switch_by_sat or ir_switch_by_brightness:
                logger.debug(
                    f"[{camera.name}] IR/day-night switch detected — "
                    f"sat_change={sat_change:.1f} Δmean={abs(cur_mean-ref_mean):.0f} "
                    f"diff_unif={diff_uniformity:.1f} — refreshing tamper reference silently"
                )
                self.tamper_reference_frames[camera_id] = gray
                self.tamper_ref_sat[camera_id] = cur_sat
                self.tamper_ref_set_times[camera_id] = now
                self.tamper_consecutive_counts[camera_id] = 0
                return

        logger.debug(
            f"[{camera.name}] tamper stats: mean={cur_mean:.0f} ref_mean={ref_mean:.0f} "
            f"std={cur_std:.1f} covered={covered} diff={diff_ratio:.3f}"
        )

        # If a person is detected in the current frame, they may be legitimately adjusting the camera
        has_person = any(d.get('class') == 'person' for d in self.camera_detections.get(camera_id, []))

        if diff_ratio > diff_thresh and not has_person:
            count = self.tamper_consecutive_counts.get(camera_id, 0) + 1
            self.tamper_consecutive_counts[camera_id] = count
            logger.info(f"[{camera.name}] Tamper candidate: diff={diff_ratio:.3f}, consecutive={count}/{consec_thresh}, covered={covered}")

            if count >= consec_thresh:
                last_alert = self.tamper_alert_times.get(camera_id, 0)
                if now - last_alert > 300:  # 5-minute alert cooldown
                    self.tamper_alert_times[camera_id] = now
                    self.tamper_consecutive_counts[camera_id] = 0
                    self._fire_tamper_alert(camera_id, camera, frame)
        else:
            # Scene is normal — reset counter
            self.tamper_consecutive_counts[camera_id] = 0
            # Slowly refresh reference every 10 min when scene is stable (handles gradual lighting changes)
            if now - self.tamper_ref_set_times[camera_id] > 600 and diff_ratio < 0.05:
                self.tamper_reference_frames[camera_id] = gray
                self.tamper_ref_sat[camera_id] = cur_sat
                self.tamper_ref_set_times[camera_id] = now
                logger.debug(f"[{camera.name}] Tamper reference auto-refreshed (10 min)")

    def _fire_tamper_alert(self, camera_id, camera, frame):
        """Send tamper Telegram alert with 'Update reference' and 'Acknowledge' buttons"""
        logger.warning(f"⚠️ Camera tamper detected: {camera.name} (ID {camera_id})")

        if self.bot_commands_handler and hasattr(self.bot_commands_handler, 'send_tamper_alert'):
            try:
                message_ids = self.bot_commands_handler.send_tamper_alert(camera_id, camera.name, frame)
                if message_ids:
                    self.tamper_message_ids[camera_id] = message_ids
            except Exception as _e:
                logger.error(f"Failed to send tamper alert via bot: {_e}")
        elif self.telegram_service:
            # Fallback: plain alert without buttons
            try:
                caption = (
                    f"⚠️ <b>Camera Tamper Detected</b>\n\n"
                    f"📷 <b>Camera:</b> {camera.name}\n"
                    f"🕐 <b>Time:</b> {datetime.now().strftime('%H:%M:%S')}\n\n"
                    f"<i>The camera may have been moved or covered.</i>"
                )
                self.telegram_service.send_alert_with_image(caption, frame, camera.name)
            except Exception as _e:
                logger.error(f"Failed to send tamper fallback alert: {_e}")

    def tamper_update_reference(self, camera_id):
        """
        User clicked 'This is fine — update reference'.
        Save current cached frame as the new tamper reference.
        """
        cached = self.camera_frames.get(camera_id)
        if cached is not None:
            gray = cv2.cvtColor(cached, cv2.COLOR_BGR2GRAY)
            hsv  = cv2.cvtColor(cached, cv2.COLOR_BGR2HSV)
            self.tamper_reference_frames[camera_id] = gray
            self.tamper_ref_sat[camera_id] = float(cv2.mean(hsv[:, :, 1])[0])
            self.tamper_ref_set_times[camera_id] = time.time()
            self.tamper_consecutive_counts[camera_id] = 0
            logger.info(f"Tamper reference updated for camera {camera_id} via Telegram")
            return True
        return False

    def tamper_acknowledge(self, camera_id):
        """
        User clicked 'Acknowledge — keep watching'.
        Resets counter, extends cooldown to 30 min, and refreshes the reference frame
        so the same scene does not re-trigger immediately after acknowledgement.
        """
        self.tamper_consecutive_counts[camera_id] = 0
        self.tamper_alert_times[camera_id] = time.time() + 1500  # +25 min on top of 5 min = 30 min total
        # Update reference to current frame — prevents re-triggering on the same unchanged scene
        cached = self.camera_frames.get(camera_id)
        if cached is not None:
            try:
                gray = cv2.cvtColor(cached, cv2.COLOR_BGR2GRAY)
                self.tamper_reference_frames[camera_id] = gray
                self.tamper_ref_set_times[camera_id] = time.time()
            except Exception:
                pass
        logger.info(f"Tamper acknowledged for camera {camera_id} — reference refreshed, 30-min cooldown set")

    def monitor_camera(self, camera_id):
        """Monitor a single camera for detections"""
        logger.info(f"Starting monitoring for camera ID: {camera_id}")
        
        cap = None  # Initialize outside try block for proper cleanup
        
        while self.running and camera_id in self.threads:
            try:
                with self.app.app_context():
                    # Get camera config - fresh query each connection attempt
                    camera = Camera.query.get(camera_id)
                    if not camera or not camera.is_active:
                        logger.warning(f"Camera {camera_id} not active, stopping monitoring")
                        break
                    
                    # Store camera info for status updates (avoid stale object issues)
                    camera_name = camera.name
                    camera_location = camera.location
                    rtsp_url = camera.rtsp_url

                    if not rtsp_url:
                        logger.error(f"Camera {camera_name} has no RTSP URL configured - waiting 30s")
                        time.sleep(30)
                        continue
                    
                    # If a working URL was previously discovered, try it first and skip the full scan
                    saved_working_url = getattr(camera, 'working_rtsp_url', None)
                    if saved_working_url and saved_working_url != rtsp_url:
                        urls_to_scan = [saved_working_url, rtsp_url]
                        logger.info(f"Using saved working URL for camera {camera_name}: {saved_working_url}")
                    else:
                        # Generate alternate URL formats for Provision/Hikvision/Dahua compatibility
                        alternate_urls = self.generate_alternate_rtsp_urls(rtsp_url)
                        urls_to_scan = [rtsp_url] + alternate_urls

                    # Try connecting with different URL formats
                    cap = None
                    working_url = None

                    # Set TCP transport environment option FIRST (for bandwidth-limited cameras like Provision)
                    import os
                    os.environ['OPENCV_FFMPEG_CAPTURE_OPTIONS'] = 'rtsp_transport;tcp|analyzeduration;10000000|fflags;+nobuffer+discardcorrupt|err_detect;ignore_err|stimeout;10000000'

                    for url_to_try in urls_to_scan:
                        logger.info(f"Trying RTSP URL: {url_to_try}")
                        
                        # Try with FFMPEG TCP mode (better for bandwidth-limited streams)
                        cap = cv2.VideoCapture(url_to_try, cv2.CAP_FFMPEG)
                        cap.set(cv2.CAP_PROP_BUFFERSIZE, 3)
                        cap.set(cv2.CAP_PROP_OPEN_TIMEOUT_MSEC, 10000)
                        cap.set(cv2.CAP_PROP_READ_TIMEOUT_MSEC, 5000)
                        
                        if cap.isOpened():
                            # Try up to 5 reads — HEVC streams often produce corrupt first frames
                            ret, test_frame = False, None
                            for _ in range(5):
                                ret, test_frame = cap.read()
                                if ret and test_frame is not None:
                                    break
                            if ret and test_frame is not None:
                                working_url = url_to_try
                                logger.info(f"Successfully connected with URL: {url_to_try}")
                                break
                            else:
                                cap.release()
                        
                        # Try with explicit TCP transport in URL
                        if '?' in url_to_try:
                            tcp_url = url_to_try + '&rtsp_transport=tcp'
                        else:
                            tcp_url = url_to_try + '?rtsp_transport=tcp'
                        
                        cap = cv2.VideoCapture(tcp_url, cv2.CAP_FFMPEG)
                        cap.set(cv2.CAP_PROP_BUFFERSIZE, 3)
                        cap.set(cv2.CAP_PROP_OPEN_TIMEOUT_MSEC, 10000)
                        
                        if cap.isOpened():
                            ret, test_frame = cap.read()
                            if ret and test_frame is not None:
                                working_url = tcp_url
                                logger.info(f"Successfully connected with TCP URL: {tcp_url}")
                                break
                            else:
                                cap.release()
                    
                    # Final attempt - try profile1/profile2 with lower buffer (for Provision)
                    if not working_url:
                        logger.info(f"Trying FFMPEG environment options for camera {camera_id}")
                        import os
                        os.environ['OPENCV_FFMPEG_CAPTURE_OPTIONS'] = 'rtsp_transport;tcp|analyzeduration;10000000|fflags;+nobuffer+discardcorrupt|err_detect;ignore_err|stimeout;10000000'
                        cap = cv2.VideoCapture(rtsp_url, cv2.CAP_FFMPEG)
                        if cap.isOpened():
                            ret, test_frame = False, None
                            for _ in range(5):
                                ret, test_frame = cap.read()
                                if ret and test_frame is not None:
                                    break
                            if ret and test_frame is not None:
                                working_url = rtsp_url
                    
                    if not working_url or not cap or not cap.isOpened():
                        # Camera connection failed - exponential backoff
                        attempts = self.camera_retry_attempts.get(camera_id, 0)
                        wait_time = min(5 * (2 ** attempts), 300)  # 5s→10s→20s→…→5min max
                        self.camera_retry_attempts[camera_id] = attempts + 1
                        self.update_camera_status(camera_id, False, camera_name, camera_location)
                        logger.error(f"Failed to open RTSP stream for camera {camera_id} - retry in {wait_time}s (attempt {attempts + 1})")
                        if cap:
                            cap.release()
                        time.sleep(wait_time)
                        continue
                    
                    # Camera connected successfully - reset backoff counter
                    self.camera_retry_attempts[camera_id] = 0
                    self.update_camera_status(camera_id, True, camera_name, camera_location)
                    logger.info(f"Successfully connected to camera {camera_name}")
                    
                    # Save working URL to database for use by snapshot/live view
                    try:
                        with self.app.app_context():
                            cam = Camera.query.get(camera_id)
                            if cam and working_url != cam.working_rtsp_url:
                                cam.working_rtsp_url = working_url
                                db.session.commit()
                                logger.info(f"Saved working RTSP URL for camera {camera_name}: {working_url}")
                    except Exception as e:
                        logger.error(f"Failed to save working URL: {e}")
                    
                    # Process frames
                    frame_count = 0
                    consecutive_failures = 0
                    max_consecutive_failures = 10  # Allow more frame drops before disconnecting
                    config = SystemConfig.query.first()  # initial fetch before frame loop
                    
                    while self.running and camera_id in self.threads:
                        ret, frame = cap.read()
                        
                        if not ret:
                            consecutive_failures += 1
                            if consecutive_failures >= max_consecutive_failures:
                                # Camera disconnected after multiple failures
                                self.update_camera_status(camera_id, False, camera_name, camera_location)
                                logger.warning(f"Failed to read frame from camera {camera_id} after {consecutive_failures} attempts")
                                break
                            time.sleep(0.1)  # Brief pause before retry
                            continue
                        
                        # Reset failure counter on successful read
                        consecutive_failures = 0

                        # Update heartbeat so the watchdog knows this thread is
                        # actually processing frames (not just alive-but-frozen).
                        self.camera_heartbeats[camera_id] = time.time()
                        
                        # Cache latest frame for fast snapshot access (zone drawing)
                        self.camera_frames[camera_id] = frame.copy()
                        # Stamp frame time on every captured frame so live stream
                        # staleness check doesn't trigger between detection cycles
                        self.camera_frame_times[camera_id] = time.time()

                        # ── PER-FRAME LABEL OVERLAY ─────────────────────────────────────
                        # Redraw cached labels on every new raw frame so the live stream
                        # stays fluid between YOLO refreshes (cheap cv2 ops only, no AI).
                        try:
                            _pcache_now = getattr(self, '_persistent_labels', {}).get(camera_id)
                            if _pcache_now is not None:
                                _ov_frame = frame.copy()
                                _ov_ts = time.time()
                                _ov_conf = self.get_camera_threshold(camera_id)
                                for _ok, _oo in list(_pcache_now.items()):
                                    if _ov_ts - _oo['ts'] > 150:
                                        continue
                                    _ox1, _oy1, _ox2, _oy2 = _oo['bbox']
                                    _above = _oo['conf'] >= _ov_conf
                                    _col = (0, 165, 255) if _above else (160, 160, 160)
                                    _th = 2 if _above else 1
                                    cv2.rectangle(_ov_frame, (_ox1, _oy1), (_ox2, _oy2), _col, _th)
                                    cv2.putText(_ov_frame, f"{_oo['class']} {_oo['conf']:.2f}",
                                                (_ox1, max(_oy1 - 5, 12)),
                                                cv2.FONT_HERSHEY_SIMPLEX, 0.45, _col, _th)
                                self.camera_annotated_frames[camera_id] = _ov_frame
                                self.camera_annotated_frame_times[camera_id] = _ov_ts
                        except Exception:
                            pass
                        # ────────────────────────────────────────────────────────────────
                        
                        # Camera is working - update status periodically (not every frame)
                        if frame_count % 100 == 0:
                            self.update_camera_status(camera_id, True, camera_name, camera_location)
                        
                        # Process every Nth frame to reduce CPU usage
                        frame_count += 1

                        # Tamper detection — runs every 10 frames (~fast response, negligible CPU cost)
                        if frame_count % 10 == 0 and getattr(camera, 'enable_tamper_detection', False):
                            try:
                                self._check_tamper(camera_id, frame, camera)
                            except Exception as _te:
                                logger.warning(f"Tamper check error camera {camera_id}: {_te}")

                        # Write OccupancyLog every ~20 s using camera_raw_counts (0.45 threshold).
                        # Placed BEFORE motion/YOLO skips so analytics stay fresh even when nobody
                        # is moving.  Uses raw counts so people visible at 0.45-0.70 confidence
                        # still appear in the analytics chart (they'd otherwise be 0 because
                        # camera_detections only holds detections that passed the 0.70 alert filter).
                        if frame_count % 600 == 0 and _check_license('people_counting'):
                            try:
                                raw_count = self.camera_raw_counts.get(camera_id, 0)
                                prev_count = self._occupancy_prev_count.get(camera_id, raw_count)
                                entries = max(0, raw_count - prev_count)
                                exits   = max(0, prev_count - raw_count)
                                self._occupancy_prev_count[camera_id] = raw_count

                                occ_log = OccupancyLog(
                                    camera_id=camera_id, count=raw_count, count_type='people',
                                    entries=entries, exits=exits, timestamp=datetime.utcnow()
                                )
                                db.session.add(occ_log)
                                db.session.commit()
                            except Exception as _occ_err:
                                logger.debug(f"Occupancy log error: {_occ_err}")
                                try:
                                    db.session.rollback()
                                except Exception:
                                    pass

                        if frame_count % 10 != 0:  # Process ~3 fps to save CPU on RPi
                            time.sleep(0.05)  # Longer sleep reduces CPU thrashing on skipped frames
                            continue

                        # ── MOTION PRE-FILTER ───────────────────────────────────────────
                        # Skip YOLO entirely when nothing is moving in the frame.
                        # This saves significant CPU and prevents static objects (parked
                        # cars, chairs, stored items) from ever reaching the AI model.
                        # detect_motion() also updates the previous-frame baseline each call.
                        require_motion = getattr(camera, 'require_motion', True)
                        if require_motion:
                            has_motion = self.detect_motion(
                                frame, camera_id,
                                threshold=30,   # slightly higher than default to ignore minor noise/IR grain
                                min_area=1000   # ignore tiny insects/compressions artefacts (<1000px²)
                            )
                            if not has_motion:
                                last_yolo = self._last_yolo_time.get(camera_id, 0)
                                time_since_yolo = time.time() - last_yolo
                                # Every 120 s, run one YOLO pass even in a static scene so that
                                # camera_raw_counts (people_now) stays accurate for people who
                                # are standing or sitting still.
                                # Use 15s refresh if someone is watching live, else 120s
                                _viewers = getattr(self, 'camera_stream_viewers', {})
                                _last_view = _viewers.get(camera_id, 0)
                                _live_view_active = (time.time() - _last_view) < 30
                                _refresh_interval = 15 if _live_view_active else 120
                                if time_since_yolo < _refresh_interval:
                                    if time_since_yolo > 15:
                                        self.camera_detections[camera_id] = []
                                    continue  # Static scene – skip YOLO inference
                                logger.debug(
                                    f"[{camera.name}] Periodic YOLO refresh "
                                    f"after {time_since_yolo:.0f}s without motion"
                                )
                        else:
                            # Still refresh the baseline even when motion-gate is disabled
                            self.detect_motion(frame, camera_id)
                        # ─────────────────────────────────────────────────────────────────

                        # Run detection with tracking enabled (for pizza box deduplication)
                        # Use per-camera auto-tuned confidence threshold (default 0.45, adapts to FP rate)
                        # imgsz=416: ~2.4x less compute than default 640, much better accuracy than 320.
                        # 416 is a standard YOLO-friendly size (divisible by 32) — detects small/distant
                        # objects that imgsz=320 misses, while still well within Pi 5 CPU budget.
                        self._last_yolo_time[camera_id] = time.time()
                        cam_conf = self.get_camera_threshold(camera_id)
                        cam_model = self._camera_models.get(camera_id, self.model)
                        try:
                            with self._infer_sem:
                                # Run YOLO at low conf (0.25) so ALL objects appear in the
                                # live view labels. Alert processing filters to cam_conf later.
                                results = cam_model.track(frame, persist=True,
                                                          verbose=False,
                                                          conf=0.25, imgsz=640,
                                                          iou=0.45)
                        except Exception as model_err:
                            logger.error(f"Model inference error: {model_err}")
                            continue  # Skip this frame, don't break the loop
                        
                        # Re-fetch camera and config periodically to pick up settings changes
                        # without hammering the database every single frame.
                        if frame_count % 30 == 0:
                            camera = Camera.query.get(camera_id)
                            config = SystemConfig.query.first()

                        # ── PERIODIC MEMORY CLEANUP ─────────────────────────────────────
                        # Every ~10 min (3600 frames at 6fps) trim unbounded dicts that
                        # accumulate over a long uptime and can exhaust Pi RAM/swap.
                        if frame_count % 3600 == 0:
                            try:
                                cutoff = datetime.utcnow() - timedelta(minutes=10)
                                cutoff_ts = time.time() - 600

                                # person_positions: drop tracks older than 10 min
                                cam_pos = self.person_positions.get(camera_id, {})
                                stale = [tid for tid, hist in cam_pos.items()
                                         if hist and hist[-1]['time'] < cutoff]
                                for tid in stale:
                                    del cam_pos[tid]

                                # track_zone_history: drop whole camera entry and rebuild
                                # (cheap — it only holds last N zone-ids per track)
                                if camera_id in self.track_zone_history:
                                    active_tids = set(self.people_tracker.get(camera_id, {}).keys())
                                    self.track_zone_history[camera_id] = {
                                        t: v for t, v in
                                        self.track_zone_history[camera_id].items()
                                        if t in active_tids
                                    }

                                # daily_stats_cache: drop entries older than 2 days
                                today_str = datetime.utcnow().strftime('%Y-%m-%d')
                                stale_keys = [k for k in list(self.daily_stats_cache.keys())
                                              if today_str not in k]
                                for k in stale_keys:
                                    del self.daily_stats_cache[k]

                                # zone_alert_times: already pruned every 1000 frames;
                                # belt-and-suspenders prune of very old entries here too
                                old_alert_cutoff = datetime.utcnow() - timedelta(hours=2)
                                old_keys = [k for k, v in list(self.zone_alert_times.items())
                                            if v < old_alert_cutoff]
                                for k in old_keys:
                                    del self.zone_alert_times[k]

                                logger.debug(f"[{camera_id}] Periodic memory cleanup done")
                            except Exception as _mc_err:
                                logger.debug(f"Memory cleanup error: {_mc_err}")
                        # ────────────────────────────────────────────────────────────────

                        if not camera or not config:
                            logger.warning(f"Camera or config not found, skipping frame")
                            continue
                        
                        # ── LIVE PEOPLE COUNT (dashboard) ───────────────────────────────
                        # Count persons directly from raw YOLO output — BEFORE
                        # process_detections applies its strict 0.70 alert filter.
                        # process_detections is correct for triggering alerts (avoids
                        # false notifications) but too strict for a live presence counter.
                        # Anyone detected by YOLO at cam_conf (0.45+) is genuinely in frame.
                        _live_count = 0
                        for _r in results:
                            if _r.boxes is not None:
                                for _b in _r.boxes:
                                    if _r.names[int(_b.cls[0])] == 'person':
                                        _live_count += 1
                        self.camera_raw_counts[camera_id] = _live_count

                        # ── LIVE STREAM ANNOTATION ──────────────────────────────────────
                        # Draw YOLO tracking boxes on a copy of the frame and store in
                        # camera_annotated_frames for the live stream endpoint.
                        # camera_frames continues to hold raw frames for snapshots/alerts.
                        try:
                            _ann_frame = frame.copy()
                            _now_ts = time.time()
                            if camera_id not in self._persistent_labels:
                                self._persistent_labels[camera_id] = {}
                            _pcache = self._persistent_labels[camera_id]

                            # Update persistent cache from current YOLO results
                            for _r in results:
                                if _r.boxes is None:
                                    continue
                                for _b in _r.boxes:
                                    _cls_id = int(_b.cls[0])
                                    _cls_name = _r.names[_cls_id]
                                    _conf = float(_b.conf[0])
                                    _x1, _y1, _x2, _y2 = [int(v) for v in _b.xyxy[0].tolist()]
                                    if _cls_name != 'person':
                                        # Grid key: 50px cells so minor jitter reuses same entry
                                        _gkey = f"{_cls_name}_{int(_x1/50)}_{int(_y1/50)}"
                                        _pcache[_gkey] = {
                                            'bbox': (_x1, _y1, _x2, _y2),
                                            'conf': _conf,
                                            'class': _cls_name,
                                            'ts': _now_ts,
                                        }

                            # Draw persistent static-object labels (expire after 150s — covers full refresh interval)
                            _stale = []
                            for _gkey, _obj in _pcache.items():
                                if _now_ts - _obj['ts'] > 150:
                                    _stale.append(_gkey)
                                    continue
                                _ox1, _oy1, _ox2, _oy2 = _obj['bbox']
                                _above = _obj['conf'] >= cam_conf
                                _col = (0, 165, 255) if _above else (160, 160, 160)
                                _th = 2 if _above else 1
                                cv2.rectangle(_ann_frame, (_ox1, _oy1), (_ox2, _oy2), _col, _th)
                                cv2.putText(_ann_frame, f"{_obj['class']} {_obj['conf']:.2f}",
                                            (_ox1, max(_oy1 - 5, 12)),
                                            cv2.FONT_HERSHEY_SIMPLEX, 0.45, _col, _th)
                            for _gkey in _stale:
                                del _pcache[_gkey]

                            # Draw current-frame person detections on top
                            for _r in results:
                                if _r.boxes is None:
                                    continue
                                for _b in _r.boxes:
                                    _cls_id = int(_b.cls[0])
                                    _cls_name = _r.names[_cls_id]
                                    if _cls_name != 'person':
                                        continue
                                    _conf = float(_b.conf[0])
                                    _x1, _y1, _x2, _y2 = [int(v) for v in _b.xyxy[0].tolist()]
                                    _above = _conf >= cam_conf
                                    _col = (0, 220, 0) if _above else (160, 160, 160)
                                    _th = 2 if _above else 1
                                    cv2.rectangle(_ann_frame, (_x1, _y1), (_x2, _y2), _col, _th)
                                    _lbl = f"person {_conf:.2f}"
                                    if hasattr(_b, 'id') and _b.id is not None:
                                        _lbl = f"#{int(_b.id[0])} {_lbl}"
                                    cv2.putText(_ann_frame, _lbl, (_x1, max(_y1 - 5, 12)),
                                                cv2.FONT_HERSHEY_SIMPLEX, 0.5, _col, _th)

                            self.camera_annotated_frames[camera_id] = _ann_frame
                            self.camera_annotated_frame_times[camera_id] = time.time()
                        except Exception as _ann_err:
                            logger.debug(f"Live annotation error cam {camera_id}: {_ann_err}")
                        # ────────────────────────────────────────────────────────────────

                        raw_detections = self.process_detections(frame, results, camera, config)

                        # ── CONSECUTIVE-FRAME CONFIRMATION ──────────────────────────────
                        # A detection must appear in N consecutive processed frames before
                        # it is considered real (anti-flash / single-frame noise filter).
                        min_frames = getattr(camera, 'min_consecutive_frames', 2)
                        min_frames = max(min_frames, 2)  # at least 2 frames always

                        if camera_id not in self.pending_detection_counts:
                            self.pending_detection_counts[camera_id] = {}
                        pending = self.pending_detection_counts[camera_id]

                        # Build set of track keys seen this frame
                        seen_keys = set()
                        confirmed_detections = []
                        for det in raw_detections:
                            track_id = det.get('track_id')
                            if track_id is not None:
                                tkey = f"{det['class']}_{track_id}"
                            else:
                                cx = int(det['center'][0] / 60)
                                cy = int(det['center'][1] / 60)
                                tkey = f"{det['class']}_{cx}_{cy}"
                            seen_keys.add(tkey)
                            pending[tkey] = pending.get(tkey, 0) + 1
                            if pending[tkey] >= min_frames:
                                confirmed_detections.append(det)

                        # Reset counters for anything NOT seen this frame
                        for old_key in list(pending.keys()):
                            if old_key not in seen_keys:
                                del pending[old_key]

                        detections = confirmed_detections
                        # ─────────────────────────────────────────────────────────────────

                        # ── ANOMALY DETECTION ────────────────────────────────────────────
                        # Update rolling hourly baseline and check for unusual activity
                        try:
                            det_count = len(detections)
                            self.update_activity_baseline(camera_id, det_count)
                            if det_count > 0:
                                is_anom, z_score, expected = self.check_anomaly(camera_id, det_count)
                                if is_anom and config.is_armed and getattr(camera, 'enable_anomaly_detection', True):
                                    self.send_anomaly_alert(camera, det_count, z_score, expected)
                        except Exception as _anom_err:
                            logger.debug(f"Anomaly detection error: {_anom_err}")
                        # ─────────────────────────────────────────────────────────────────

                        # Always cache latest detections for alert photo annotation
                        self.camera_detections[camera_id] = detections

                        # ALWAYS process zone detections for entry/exit tracking (even when disarmed)
                        if detections and config.enable_zone_detection:
                            try:
                                self.process_zone_detections(camera_id, detections)
                            except Exception as zone_err:
                                logger.error(f"Zone detection error: {zone_err}")
                        
                        # WEAPON/THREAT DETECTION - Always process regardless of armed status
                        if detections and hasattr(camera, 'enable_weapon_detection') and camera.enable_weapon_detection and _check_license('weapon_detection'):
                            try:
                                threats = self.detect_weapon_threat(frame, detections, camera)
                                if threats:
                                    logger.warning(f"🚨 {len(threats)} threat(s) detected on {camera.name}")
                                    for threat in threats:
                                        # Send threat alerts immediately (bypass normal cooldown)
                                        self.send_threat_alert(camera, threat, frame, self.telegram_service)
                            except Exception as threat_err:
                                logger.error(f"Threat detection error: {threat_err}")

                        # ENHANCED FALL DETECTION — runs on every frame, uses geometry only (no extra model)
                        if detections and getattr(camera, 'detect_falling', True):
                            try:
                                # Update person position history first
                                if camera_id not in self.person_positions:
                                    self.person_positions[camera_id] = {}
                                now_dt = datetime.utcnow()
                                for det in detections:
                                    if det.get('class') != 'person':
                                        continue
                                    tid = det.get('track_id', id(det))
                                    center = self._get_box_center(det)
                                    if tid not in self.person_positions[camera_id]:
                                        self.person_positions[camera_id][tid] = []
                                    hist = self.person_positions[camera_id][tid]
                                    hist.append({'x': center[0], 'y': center[1], 'time': now_dt, 'bbox': det.get('bbox')})
                                    if len(hist) > 30:
                                        self.person_positions[camera_id][tid] = hist[-30:]
                                fall_event = self._detect_falling_enhanced(camera_id, detections)
                                if fall_event and self.telegram_service:
                                    self.send_behavior_alert(camera, fall_event, frame, self.telegram_service)
                            except Exception as _fall_err:
                                logger.debug(f"Fall detection error: {_fall_err}")
                        
                        # Handle detections
                        if detections:
                            # If disarmed, skip regular detection alerts
                            if not config.is_armed or not camera.is_armed:
                                logger.debug(f"🔒 System/Camera disarmed - skipping alerts")
                                continue
                            
                            # Check snooze status first (doesn't need detection info)
                            if hasattr(camera, 'is_snoozed') and camera.is_snoozed():
                                logger.info(f"🔇 Camera {camera.name} is snoozed - skipping all alerts")
                                continue
                            
                            # Zone-only mode: filter detections to only those in zones
                            filtered_detections = detections
                            if hasattr(camera, 'zone_only_detection') and camera.zone_only_detection:
                                filtered_detections = [d for d in detections if d.get('zones') and len(d.get('zones', [])) > 0]
                                if not filtered_detections:
                                    logger.info(f"📍 Zone-only mode: No detections in zones - skipping alert")
                                    continue
                                logger.info(f"📍 Zone-only mode: {len(filtered_detections)}/{len(detections)} detections are in zones")
                            
                            # Check if we have detections to alert on
                            if filtered_detections:
                                # Capture high-quality snapshot from main stream if available
                                if camera.main_stream_url:
                                    hq_frame = self.capture_main_stream_snapshot(camera, detections)
                                    if hq_frame is not None:
                                        annotated_frame = hq_frame
                                        logger.info(f"📷 Using main stream HQ snapshot for alert")
                                    else:
                                        # Fallback to detection frame
                                        annotated_frame = self.draw_detections(frame.copy(), detections)
                                else:
                                    # No main stream, use detection frame
                                    annotated_frame = self.draw_detections(frame.copy(), detections)
                                
                                # Group filtered detections by class for counting (especially for stock items)
                                detection_groups = {}
                                for det in filtered_detections:
                                    class_name = det['class']
                                    if class_name not in detection_groups:
                                        detection_groups[class_name] = []
                                    detection_groups[class_name].append(det)

                                # Apply face blurring if enabled on this camera (privacy compliance)
                                if getattr(camera, 'enable_face_blur', False):
                                    try:
                                        annotated_frame = self.blur_faces_in_frame(annotated_frame, filtered_detections)
                                    except Exception as _blur_err:
                                        logger.debug(f"Face blur error: {_blur_err}")
                                
                                # Pre-compute combined person+animal state so animal Telegrams
                                # are suppressed when a person is also in the same frame.
                                _animal_classes_in_frame = [
                                    cn for cn in detection_groups
                                    if cn in self.class_categories['animal']
                                ]
                                _person_in_frame = 'person' in detection_groups

                                # Collect approved non-stock groups here; ONE combined
                                # Telegram is sent after all class groups are processed.
                                _approved_alert_groups = {}  # class_name -> (group_detections, best_det, best_event)

                                # Save to database - one event per detection group
                                for class_name, group_detections in detection_groups.items():
                                    # Per-class cooldown: person and dog each have independent timers
                                    if not self.should_send_alert(camera, detected_class=class_name):
                                        logger.info(f"⏰ Alert cooldown active for '{class_name}' on {camera.name} - skipping")
                                        continue

                                    # Record per-class in-memory timestamp so future iterations
                                    # for THIS class respect cooldown independently of other classes
                                    if camera.id not in self.last_detection_alerts:
                                        self.last_detection_alerts[camera.id] = {}
                                    self.last_detection_alerts[camera.id][class_name] = datetime.utcnow()

                                    # Check if this is a stock control item
                                    is_stock_item = False
                                    stock_item_name = None
                                    if camera.enable_stock_control:
                                        for stock_item in camera.get_stock_items():
                                            if class_name in stock_item.get('yolo_classes', []):
                                                is_stock_item = True
                                                stock_item_name = stock_item.get('name')
                                                break
                                    
                                    # For stock items, create single event with count (deduplicated)
                                    if is_stock_item:
                                        # Deduplicate using tracking IDs
                                        current_time = datetime.utcnow()
                                        
                                        # Initialize tracking for this camera and item if not exists
                                        if camera_id not in self.tracked_items:
                                            self.tracked_items[camera_id] = {}
                                        if stock_item_name not in self.tracked_items[camera_id]:
                                            self.tracked_items[camera_id][stock_item_name] = {}
                                        
                                        # Clean up old tracked items (not seen in last 5 minutes)
                                        items_to_remove = []
                                        for tracked_id, last_seen in self.tracked_items[camera_id][stock_item_name].items():
                                            if (current_time - last_seen).total_seconds() > self.tracking_timeout:
                                                items_to_remove.append(tracked_id)
                                        
                                        # Update database if items were removed
                                        if items_to_remove:
                                            for tracked_id in items_to_remove:
                                                del self.tracked_items[camera_id][stock_item_name][tracked_id]
                                            
                                            # Update stock count after cleanup
                                            from models import StockItem
                                            remaining_count = len(self.tracked_items[camera_id][stock_item_name])
                                            stock_item_record = StockItem.query.filter_by(
                                                camera_id=camera_id,
                                                name=stock_item_name
                                            ).first()
                                            if stock_item_record:
                                                stock_item_record.current_count = remaining_count
                                                stock_item_record.updated_at = current_time
                                        
                                        # Count only NEW items (not previously tracked)
                                        new_items = []
                                        verified_new_items = []  # Items that passed OCR verification
                                        
                                        for det in group_detections:
                                            track_id = det.get('track_id')
                                            
                                            # For pizza boxes or similar items, verify text with OCR
                                            needs_text_verification = 'pizza' in stock_item_name.lower()
                                            text_verified = True  # Default to true for non-pizza items
                                            
                                            if needs_text_verification:
                                                # Verify that the box actually says "pizza"
                                                text_verified = self.verify_pizza_box_text(frame, det['bbox'])
                                            
                                            if not text_verified:
                                                logger.debug(f"Box detected but no pizza text found, skipping")
                                                continue  # Skip this detection if text verification fails
                                            
                                            if track_id is not None:
                                                # Check if this item is already tracked
                                                if track_id not in self.tracked_items[camera_id][stock_item_name]:
                                                    new_items.append(det)
                                                    verified_new_items.append(det)
                                                    # Mark as tracked
                                                    self.tracked_items[camera_id][stock_item_name][track_id] = current_time
                                                else:
                                                    # Update last seen time for existing item
                                                    self.tracked_items[camera_id][stock_item_name][track_id] = current_time
                                            else:
                                                # No tracking ID, count it anyway (fallback)
                                                new_items.append(det)
                                                verified_new_items.append(det)
                                        
                                        # Only alert if there are NEW items detected
                                        if not verified_new_items:
                                            continue  # Skip - all items already counted or failed verification
                                        
                                        item_count = len(verified_new_items)  # Count only new verified items
                                        total_items = len(self.tracked_items[camera_id][stock_item_name])  # Total tracked items
                                        avg_confidence = sum(d['confidence'] for d in verified_new_items) / item_count
                                        
                                        # Update stock count in database
                                        from models import StockItem
                                        stock_item_record = StockItem.query.filter_by(
                                            camera_id=camera_id,
                                            name=stock_item_name
                                        ).first()
                                        if stock_item_record:
                                            stock_item_record.current_count = total_items
                                            stock_item_record.updated_at = current_time
                                        
                                        event = DetectionEvent(
                                            camera_id=camera_id,
                                            detected_class='stock_item',
                                            confidence=avg_confidence,
                                            item_count=item_count,
                                            item_name=stock_item_name
                                        )
                                        # Store all bboxes
                                        event.set_bbox(group_detections[0]['bbox'])
                                        db.session.add(event)
                                        db.session.flush()
                                        
                                        # Save image and send Telegram
                                        _stock_alert_media = getattr(camera, 'alert_media', 'image') or 'image'
                                        if True:
                                            image_path, thumb_path = self.save_detection_image(
                                                annotated_frame, camera_id, event.id
                                            )
                                            
                                            if image_path:
                                                event.image_path = image_path
                                                event.thumbnail_path = thumb_path
                                                
                                                # Send Telegram alert with new count and total
                                                success = telegram_service.send_stock_alert(
                                                    camera.name,
                                                    stock_item_name,
                                                    item_count,  # New items
                                                    total_items,  # Total current items
                                                    avg_confidence,
                                                    image_path,
                                                    camera.location
                                                )
                                                
                                                if success:
                                                    event.telegram_sent = True
                                                    event.telegram_sent_at = datetime.utcnow()
                                    else:
                                        # Collect all non-stock class groups that pass cooldown;
                                        # a single combined Telegram is sent after this loop.
                                        best_det = max(group_detections, key=lambda d: d['confidence'])

                                        # Save a DB event record for every individual detection
                                        best_event = None
                                        for det in group_detections:
                                            event = DetectionEvent(
                                                camera_id=camera_id,
                                                detected_class=det['class'],
                                                confidence=det['confidence']
                                            )
                                            event.set_bbox(det['bbox'])
                                            db.session.add(event)
                                            db.session.flush()
                                            if det is best_det:
                                                best_event = event

                                        _approved_alert_groups[class_name] = (group_detections, best_det, best_event)

                                # After all class groups processed, send ONE combined Telegram alert
                                if _approved_alert_groups:
                                    _priority = (
                                        ['person']
                                        + list(self.class_categories.get('vehicle', ['car', 'truck', 'bus', 'motorcycle', 'bicycle']))
                                        + list(self.class_categories.get('animal', []))
                                    )
                                    _primary_class = next(
                                        (c for c in _priority if c in _approved_alert_groups),
                                        next(iter(_approved_alert_groups))
                                    )
                                    _primary_grp, _primary_best_det, _primary_best_event = _approved_alert_groups[_primary_class]
                                    if _primary_best_event is not None:
                                        image_path, thumb_path = self.save_detection_image(
                                            annotated_frame, camera_id, _primary_best_event.id
                                        )
                                        if image_path:
                                            _primary_best_event.image_path = image_path
                                            _primary_best_event.thumbnail_path = thumb_path

                                            zone_info = []
                                            if _primary_best_det.get('zones'):
                                                for zone_id in _primary_best_det['zones']:
                                                    zone = DetectionZone.query.get(zone_id)
                                                    if zone:
                                                        zone_info.append({
                                                            'id': zone.id,
                                                            'name': zone.name,
                                                            'type': zone.zone_type
                                                        })

                                            try:
                                                smart_summary = self.build_smart_summary(
                                                    camera, filtered_detections, zone_info
                                                )
                                            except Exception:
                                                smart_summary = None

                                            all_class_counts = {
                                                cn: len(grp)
                                                for cn, (grp, _, _) in _approved_alert_groups.items()
                                            }
                                            _people_count = all_class_counts.get('person', 0)
                                            site_name = getattr(config, 'site_name', None)
                                            success = telegram_service.send_combined_detection_alert(
                                                camera.name,
                                                all_class_counts,
                                                _primary_best_det['confidence'],
                                                image_path,
                                                camera.location,
                                                zone_info,
                                                site_name,
                                                _people_count if _people_count > 0 else None,
                                                smart_summary,
                                                camera_id
                                            )
                                            if success:
                                                for _cn, (_grp, _bd, _be) in _approved_alert_groups.items():
                                                    if _be is not None:
                                                        _be.telegram_sent = True
                                                        _be.telegram_sent_at = datetime.utcnow()

                                try:
                                    db.session.commit()
                                except Exception as db_err:
                                    logger.error(f"Database commit error: {db_err}")
                                    db.session.rollback()
                                    continue  # Continue processing frames, don't break
                                
                                # Update last alert time - refresh camera object first
                                try:
                                    camera = Camera.query.get(camera_id)
                                    if camera:
                                        camera.last_alert_time = datetime.utcnow()
                                        db.session.commit()
                                except Exception as alert_err:
                                    logger.error(f"Alert time update error: {alert_err}")
                                    db.session.rollback()
                                
                                logger.info(f"Detection alert sent for camera {camera_name}: {len(detections)} object(s)")
                        
                        # No extra sleep needed — frame skip + 30ms sleep already controls rate
                    
                    # Release camera when inner loop exits normally
                    if cap:
                        cap.release()
                        cap = None
                    
            except Exception as e:
                logger.error(f"Error monitoring camera {camera_id}: {e}")
                import traceback
                logger.error(traceback.format_exc())
                # Ensure camera is released on error
                if cap:
                    try:
                        cap.release()
                    except:
                        pass
                    cap = None
                time.sleep(10)  # Wait before retry
        
        # Final cleanup
        if cap:
            try:
                cap.release()
            except:
                pass
        
        logger.info(f"Stopped monitoring camera ID: {camera_id}")
    
    def start_monitoring(self, camera_id):
        """Start monitoring a camera"""
        if camera_id in self.threads:
            logger.warning(f"Camera {camera_id} is already being monitored")
            return False

        if not self.model:
            logger.error("Model not loaded. Call load_model() first.")
            return False

        # Each camera gets its own YOLO instance so persist=True tracker IDs
        # never bleed between cameras.
        if camera_id not in self._camera_models:
            try:
                model_path = self.models_dir / 'yolo11s.pt'
                self._camera_models[camera_id] = YOLO(str(model_path))
                logger.info(f"Loaded dedicated model for camera {camera_id}")
            except Exception as e:
                logger.warning(f"Could not load dedicated model for camera {camera_id}: {e} — using shared model")
                self._camera_models[camera_id] = self.model

        # Start monitoring thread
        thread = threading.Thread(target=self.monitor_camera, args=(camera_id,), daemon=True)
        self.threads[camera_id] = thread
        thread.start()

        logger.info(f"Started monitoring camera {camera_id}")
        return True
    
    def stop_monitoring(self, camera_id):
        """Stop monitoring a camera"""
        if camera_id in self.threads:
            del self.threads[camera_id]
            self._camera_models.pop(camera_id, None)
            logger.info(f"Stopped monitoring camera {camera_id}")
            return True
        return False
    
    def start_all_cameras(self):
        """Start monitoring all active cameras"""
        with self.app.app_context():
            cameras = Camera.query.filter_by(is_active=True).all()
            
            for camera in cameras:
                self.start_monitoring(camera.id)
        
        logger.info(f"Started monitoring {len(cameras)} active cameras")
    
    def stop_all_cameras(self):
        """Stop monitoring all cameras"""
        self.running = False
        self.threads.clear()
        self._camera_models.clear()
        logger.info("Stopped all camera monitoring")
    
    def start(self):
        """Start the detection engine"""
        # yolo11s is Ultralytics' newest model — 47.0 mAP vs yolov8s 44.9 mAP,
        # 9.4M params vs 11.2M, and faster inference. Strict upgrade, same CPU/RAM.
        if not self.load_model('yolo11s.pt'):
            logger.error("Failed to start detection engine: model load failed")
            return False

        self.running = True
        self.start_all_cameras()

        logger.info("Detection engine started")
        return True
    
    def stop(self):
        """Stop the detection engine"""
        self.stop_all_cameras()
        logger.info("Detection engine stopped")


# Global detection engine instance
detection_engine = None


def init_detection_engine(app, telegram_service=None):
    """Initialize the global detection engine"""
    global detection_engine
    detection_engine = DetectionEngine(app, telegram_service)
    return detection_engine
