"""
Network Scanner - Find IP cameras and NVRs/DVRs on the local network
Detects device type (NVR/DVR vs standalone IP camera) and manufacturer brand.
"""
import socket
import re
import logging
from concurrent.futures import ThreadPoolExecutor, as_completed
import requests
from requests.auth import HTTPDigestAuth, HTTPBasicAuth
import xml.etree.ElementTree as ET

logger = logging.getLogger(__name__)


# ─── Brand fingerprint signatures ────────────────────────────────────────────
# Maps a search keyword (checked against HTTP headers + body) to brand info
BRAND_SIGNATURES = [
    # keyword         brand display name     device class   NVR?
    ('hikvision',     'Hikvision',           'nvr',         True),
    ('ISAPI',         'Hikvision',           'nvr',         True),
    ('dahua',         'Dahua',               'nvr',         True),
    ('dh-',          'Dahua',               'nvr',         True),
    ('provision',     'Provision ISR',       'nvr',         True),
    ('annke',         'Annke',               'nvr',         True),
    ('uniview',       'Uniview',             'nvr',         True),
    ('hanwha',        'Hanwha',              'nvr',         True),
    ('reolink',       'Reolink',             'ip_camera',   False),
    ('amcrest',       'Amcrest',             'ip_camera',   False),
    ('axis',          'Axis',                'ip_camera',   False),
    ('foscam',        'Foscam',              'ip_camera',   False),
    ('vivotek',       'Vivotek',             'ip_camera',   False),
    ('geovision',     'GeoVision',           'nvr',         True),
    ('cp plus',       'CP Plus',             'nvr',         True),
    ('cpplus',        'CP Plus',             'nvr',         True),
    ('dvr',           'Generic DVR',         'dvr',         True),
    ('nvr',           'Generic NVR',         'nvr',         True),
    # Web-server signatures common to Chinese DVR/NVR firmware (Provision ISR, XM, etc.)
    ('goahead',       'Generic NVR',         'nvr',         True),
    ('app-webs',      'Generic NVR',         'nvr',         True),
    ('mini_httpd',    'Generic NVR',         'nvr',         True),
    # Dahua/Provision web UI titles
    ('web service',   'Provision ISR',       'nvr',         True),
    ('dh-',           'Provision ISR',       'nvr',         True),
    # Generic catch-all
    ('ipc web',       'Generic NVR',         'nvr',         True),
    ('dvr login',     'Generic DVR',         'dvr',         True),
    ('nvr login',     'Generic NVR',         'nvr',         True),
]

# Brand-specific RTSP URL templates: (channel_num) → url
# Used to probe working streams per channel
BRAND_RTSP_PATTERNS = {
    'Hikvision': [
        'rtsp://{user}:{pass}@{ip}:554/Streaming/Channels/{ch}01',
        'rtsp://{user}:{pass}@{ip}:554/Streaming/Channels/{ch}02',   # sub-stream
        'rtsp://{user}:{pass}@{ip}:554/ISAPI/Streaming/Channels/{ch}01',
    ],
    'Dahua': [
        'rtsp://{user}:{pass}@{ip}:554/cam/realmonitor?channel={ch}&subtype=0',
        'rtsp://{user}:{pass}@{ip}:554/cam/realmonitor?channel={ch}&subtype=1',
    ],
    'Provision ISR': [
        'rtsp://{user}:{pass}@{ip}:554/cam/realmonitor?channel={ch}&subtype=0',
        'rtsp://{user}:{pass}@{ip}:554/cam/realmonitor?channel={ch}&subtype=1',
        'rtsp://{user}:{pass}@{ip}:554/live/ch{ch:02d}_0',
        'rtsp://{user}:{pass}@{ip}:554/Streaming/Channels/{ch}01',
    ],
    'Reolink': [
        'rtsp://{user}:{pass}@{ip}:554/h264Preview_01_main',
        'rtsp://{user}:{pass}@{ip}:554/h264Preview_01_sub',
    ],
    'Axis': [
        'rtsp://{user}:{pass}@{ip}/axis-media/media.amp',
        'rtsp://{user}:{pass}@{ip}/axis-media/media.amp?videocodec=h264',
    ],
    '_generic': [
        'rtsp://{user}:{pass}@{ip}:554/Streaming/Channels/{ch}01',
        'rtsp://{user}:{pass}@{ip}:554/cam/realmonitor?channel={ch}&subtype=0',
        'rtsp://{user}:{pass}@{ip}:554/ch{ch:02d}/0',
        'rtsp://{user}:{pass}@{ip}:554/live/ch{ch:02d}_0',
        'rtsp://{user}:{pass}@{ip}:554/stream{ch}',
        'rtsp://{user}:{pass}@{ip}:554/h264/ch{ch}/main/av_stream',
    ],
}


class NetworkScanner:
    """Scan network for IP cameras, NVRs, and DVRs"""

    # Common camera/NVR HTTP management ports
    COMMON_PORTS = [80, 8000, 8080, 37777, 34567]

    # ONVIF ports
    ONVIF_PORTS = [80, 8080, 8081, 8899]

    # Common default credentials (tried in order)
    COMMON_CREDENTIALS = [
        ('admin', 'admin'),
        ('admin', '12345'),
        ('admin', ''),
        ('admin', 'admin123'),
        ('admin', '123456'),
        ('root', 'root'),
        ('root', ''),
        ('admin', 'password'),
        ('', ''),
    ]

    def __init__(self):
        self.local_ip = self.get_local_ip()
        self.network_prefix = '.'.join(self.local_ip.split('.')[:-1])
    
    def get_local_ip(self):
        """Get the local IP address"""
        try:
            s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            s.connect(("8.8.8.8", 80))
            ip = s.getsockname()[0]
            s.close()
            return ip
        except:
            return "192.168.1.1"

    def check_port(self, ip, port, timeout=1):
        """Check if a port is open"""
        try:
            sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            sock.settimeout(timeout)
            result = sock.connect_ex((ip, port))
            sock.close()
            return result == 0
        except:
            return False

    def _fingerprint_brand(self, response_text, response_headers):
        """Identify device brand/type from HTTP response content and headers."""
        combined = (response_text + str(response_headers)).lower()
        for keyword, brand, device_class, is_nvr_flag in BRAND_SIGNATURES:
            if keyword.lower() in combined:
                return brand, device_class, is_nvr_flag
        return 'Unknown', 'ip_camera', False

    def _make_rtsp_urls(self, brand, ip, username, password, channel):
        """Generate RTSP URL candidates for a given brand and channel number."""
        patterns = BRAND_RTSP_PATTERNS.get(brand, BRAND_RTSP_PATTERNS['_generic'])
        urls = []
        for tpl in patterns:
            try:
                url = tpl.format(**{'user': username, 'pass': password,
                                    'ip': ip, 'ch': channel})
                urls.append(url)
            except Exception:
                pass
        # Always append generic patterns as fallback
        if brand != '_generic':
            for tpl in BRAND_RTSP_PATTERNS['_generic']:
                try:
                    url = tpl.format(**{'user': username, 'pass': password,
                                        'ip': ip, 'ch': channel})
                    if url not in urls:
                        urls.append(url)
                except Exception:
                    pass
        return urls

    # Extra paths probed (in addition to '/') for better brand identification.
    # Many Provision / Chinese DVR/NVR firmwares serve a branded login page here.
    PROBE_PATHS = [
        '/',
        '/Login.htm',
        '/login.htm',
        '/index.asp',
        '/doc/page/login.asp',    # Hikvision ISAPI path hint
        '/cgi-bin/magicBox.cgi?action=getProductDefinition',  # Dahua
    ]

    def probe_http(self, ip, port):
        """Try to get device information via HTTP, probing extra paths for brand detection."""
        try:
            base = f"http://{ip}:{port}"

            # --- Unauthenticated probe across several paths ---
            for path in self.PROBE_PATHS:
                try:
                    response = requests.get(base + path, timeout=2, verify=False,
                                            allow_redirects=True)
                    if response.status_code in (200, 401, 403):
                        brand, device_class, is_nvr = self._fingerprint_brand(
                            response.text, response.headers)
                        if brand != 'Unknown' or path == '/':
                            # Return on first hit with a real brand, or fall through to creds
                            if brand != 'Unknown':
                                return {
                                    'type': device_class,
                                    'url': base,
                                    'brand': brand,
                                    'name': f'{brand} {"NVR/DVR" if is_nvr else "Camera"} at {ip}',
                                    'auth_required': False,
                                    'is_nvr': is_nvr,
                                    'username': '',
                                    'password': '',
                                }
                except Exception:
                    pass

            # --- Credential probe on root path ---
            for username, password in self.COMMON_CREDENTIALS:
                for auth_cls in (HTTPBasicAuth, HTTPDigestAuth):
                    try:
                        response = requests.get(
                            base + '/',
                            auth=auth_cls(username, password),
                            timeout=2,
                            verify=False
                        )
                        if response.status_code == 200:
                            brand, device_class, is_nvr = self._fingerprint_brand(
                                response.text, response.headers)
                            return {
                                'type': device_class,
                                'url': base,
                                'brand': brand,
                                'name': f'{brand} {"NVR/DVR" if is_nvr else "Camera"} at {ip}',
                                'auth_required': True,
                                'is_nvr': is_nvr,
                                'username': username,
                                'password': password,
                            }
                    except Exception:
                        continue
        except Exception:
            pass
        return None
    def probe_rtsp(self, ip):
        """Check for RTSP service (port 554) and return a candidate stream info."""
        if not self.check_port(ip, 554, timeout=1):
            return None
        # Return a placeholder — actual URL pattern is resolved after brand detection
        return {
            'type': 'rtsp',
            'url': f'rtsp://admin:admin@{ip}:554/',
            'brand': 'Unknown',
            'name': f'RTSP Camera at {ip}',
            'is_nvr': False,
            'username': 'admin',
            'password': 'admin',
        }
    
    def detect_nvr_channels(self, ip, port=80, username='admin', password='admin', brand='Unknown'):
        """Detect NVR/DVR channels, using brand-specific APIs first, then generic fallback."""
        channels = []

        # ── Hikvision ISAPI ──────────────────────────────────────────────────
        if brand in ('Hikvision', 'Unknown'):
            try:
                url = f"http://{ip}:{port}/ISAPI/Streaming/channels"
                r = requests.get(url, auth=HTTPDigestAuth(username, password),
                                 timeout=3, verify=False)
                if r.status_code == 200:
                    try:
                        root = ET.fromstring(r.content)
                        for ch in root.findall('.//StreamingChannel'):
                            cid = ch.find('id')
                            cname = ch.find('channelName')
                            if cid is not None:
                                ch_num = int(cid.text) // 100 or 1
                                rtsp_urls = self._make_rtsp_urls('Hikvision', ip, username, password, ch_num)
                                channels.append({
                                    'id': cid.text,
                                    'name': cname.text if cname is not None else f'Channel {ch_num}',
                                    'rtsp_url': rtsp_urls[0],
                                    'alternate_urls': rtsp_urls[1:],
                                    'brand': 'Hikvision',
                                    'device_class': 'nvr',
                                })
                        if channels:
                            return channels
                    except Exception:
                        pass
            except Exception:
                pass

        # ── Dahua HTTP API ───────────────────────────────────────────────────
        if brand in ('Dahua', 'Unknown'):
            try:
                url = f"http://{ip}:{port}/cgi-bin/magicBox.cgi?action=getProductDefinition"
                r = requests.get(url, auth=HTTPDigestAuth(username, password),
                                 timeout=3, verify=False)
                if r.status_code == 200:
                    match = re.search(r'MaxExtraStream=(\d+)', r.text)
                    if match:
                        num_channels = int(match.group(1))
                        for i in range(1, num_channels + 1):
                            rtsp_urls = self._make_rtsp_urls('Dahua', ip, username, password, i)
                            channels.append({
                                'id': str(i),
                                'name': f'Channel {i}',
                                'rtsp_url': rtsp_urls[0],
                                'alternate_urls': rtsp_urls[1:],
                                'brand': 'Dahua',
                                'device_class': 'nvr',
                            })
                        if channels:
                            return channels
            except Exception:
                pass

        # ── Provision ISR / Generic DVR ──────────────────────────────────────
        # Probe ports 37777 (Dahua/Provision) and 34567 (XM/Novatek chipset DVRs)
        if brand in ('Provision ISR', 'Generic DVR', 'Generic NVR', 'Unknown'):
            for max_ch in (4, 8, 16):
                detected = self._probe_generic_channels(ip, username, password, max_ch, brand)
                if detected:
                    return detected

        # No verified channels found — return empty so caller can downgrade to standalone camera
        return channels

    def _probe_generic_channels(self, ip, username, password, max_channels, brand):
        """Probe which channels actually have live RTSP streams (up to max_channels)."""
        import cv2
        channels = []
        for i in range(1, max_channels + 1):
            rtsp_urls = self._make_rtsp_urls(brand, ip, username, password, i)
            working_url = None
            for url in rtsp_urls[:3]:   # Only probe first 3 patterns to keep it fast
                try:
                    cap = cv2.VideoCapture(url, cv2.CAP_FFMPEG)
                    cap.set(cv2.CAP_PROP_OPEN_TIMEOUT_MSEC, 3000)
                    if cap.isOpened():
                        cap.release()
                        working_url = url
                        break
                    cap.release()
                except Exception:
                    pass
            if working_url:
                channels.append({
                    'id': str(i),
                    'name': f'Channel {i}',
                    'rtsp_url': working_url,
                    'alternate_urls': [u for u in rtsp_urls if u != working_url],
                    'brand': brand,
                    'device_class': 'nvr',
                })
        return channels
    def scan_ip(self, ip):
        """Scan a single IP for cameras/NVRs"""
        devices = []

        # Check RTSP first (quick port probe)
        rtsp_device = self.probe_rtsp(ip)

        # Port-based brand hint:
        # 37777 = Dahua SDK (used by Dahua, Provision ISR, Amcrest OEM devices)
        # 34567 = XM/Novatek chipset (common in generic Chinese DVR/NVR)
        port_brand_hint = None
        if self.check_port(ip, 37777, timeout=1):
            port_brand_hint = 'Provision ISR'
        elif self.check_port(ip, 34567, timeout=1):
            port_brand_hint = 'Generic DVR'

        # Check HTTP management ports for brand + auth detection
        for port in self.COMMON_PORTS:
            if self.check_port(ip, port, timeout=1):
                http_device = self.probe_http(ip, port)
                if http_device:
                    # Apply port-based brand hint when HTTP fingerprinting returned Unknown
                    if http_device.get('brand') == 'Unknown' and port_brand_hint:
                        http_device['brand'] = port_brand_hint
                        http_device['is_nvr'] = True
                        http_device['type'] = 'nvr'
                    brand = http_device.get('brand', 'Unknown')
                    username = http_device.get('username', 'admin')
                    password = http_device.get('password', 'admin')

                    if http_device.get('is_nvr', False):
                        channels = self.detect_nvr_channels(
                            ip, port, username, password, brand=brand)
                        if channels:
                            http_device['channels'] = channels
                            http_device['channel_count'] = len(channels)
                            http_device['type'] = 'nvr'
                            http_device['name'] = (
                                f"{brand} NVR/DVR at {ip} "
                                f"({len(channels)} channel{'s' if len(channels) != 1 else ''})"
                            )
                        else:
                            # No live channels verified — treat as standalone IP camera
                            http_device['type'] = 'ip_camera'
                            http_device['is_nvr'] = False
                            rtsp_urls = self._make_rtsp_urls(brand, ip, username, password, 1)
                            http_device['rtsp_url'] = rtsp_urls[0]
                            http_device['alternate_urls'] = rtsp_urls[1:]
                            http_device['name'] = f"{brand} IP Camera at {ip}"
                    else:
                        # Standalone IP camera — build its RTSP URL from brand patterns
                        rtsp_urls = self._make_rtsp_urls(brand, ip, username, password, 1)
                        http_device['rtsp_url'] = rtsp_urls[0]
                        http_device['alternate_urls'] = rtsp_urls[1:]
                        http_device['name'] = f"{brand} IP Camera at {ip}"

                    devices.append(http_device)
                    break  # Found device on this port

        # If HTTP found nothing but port hint suggests NVR → build a minimal NVR entry
        if not devices and port_brand_hint:
            brand = port_brand_hint
            rtsp_urls = self._make_rtsp_urls(brand, ip, 'admin', 'admin', 1)
            devices.append({
                'type': 'nvr',
                'brand': brand,
                'name': f'{brand} NVR/DVR at {ip} (0 channels)',
                'is_nvr': True,
                'auth_required': False,
                'username': 'admin',
                'password': 'admin',
                'channels': [],
                'channel_count': 0,
                'rtsp_url': rtsp_urls[0],
            })
        # If HTTP found nothing but RTSP port is open, add as unknown camera
        elif not devices and rtsp_device:
            devices.append(rtsp_device)

        return devices if devices else None
    
    def scan_network(self, ip_range=None, max_workers=50):
        """Scan entire network for cameras and NVRs"""
        if ip_range is None:
            # Scan local subnet
            ip_range = [f"{self.network_prefix}.{i}" for i in range(1, 255)]
        
        logger.info(f"Scanning network {self.network_prefix}.0/24 for cameras and NVRs...")
        found_devices = []
        
        with ThreadPoolExecutor(max_workers=max_workers) as executor:
            future_to_ip = {executor.submit(self.scan_ip, ip): ip for ip in ip_range}
            
            for future in as_completed(future_to_ip):
                ip = future_to_ip[future]
                try:
                    devices = future.result()
                    if devices:
                        for device in devices:
                            device['ip'] = ip
                            found_devices.append(device)
                            logger.info(f"Found device: {device['name']} at {ip}")
                except Exception as e:
                    logger.debug(f"Error scanning {ip}: {e}")
        
        logger.info(f"Scan complete. Found {len(found_devices)} device(s)")
        return found_devices


def scan_network_for_cameras():
    """Convenience function to scan network"""
    scanner = NetworkScanner()
    return scanner.scan_network()


def get_nvr_channels(ip, port=80, username='admin', password='admin', brand='Unknown'):
    """Get channels from an NVR/DVR"""
    scanner = NetworkScanner()
    return scanner.detect_nvr_channels(ip, port, username, password, brand=brand)


if __name__ == '__main__':
    # Test scanner
    logging.basicConfig(level=logging.INFO)
    devices = scan_network_for_cameras()
    
    print("\n" + "="*50)
    print("FOUND DEVICES:")
    print("="*50)
    
    for device in devices:
        print(f"\n{device['name']}")
        print(f"  IP: {device['ip']}")
        print(f"  Type: {device['type']}")
        print(f"  URL: {device['url']}")
        
        if device.get('is_nvr'):
            print(f"  Channels: {len(device.get('channels', []))}")
            for channel in device.get('channels', [])[:3]:
                print(f"    - {channel['name']}: {channel['rtsp_url']}")
