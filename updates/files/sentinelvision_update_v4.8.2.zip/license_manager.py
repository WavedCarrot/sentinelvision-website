"""
SentinelVision License Manager
Offline license key validation with expiry for premium features.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
KEY FORMAT — FEATURE KEYS:   SVP-{FC}{DC}-{8HEX}-{4HEX}
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
  FC  = Feature Code  (single letter)
          Z → Zone Detection  (includes tripwire / line crossing)
          P → People Counting
          V → Vehicle Detection
          O → Object Detection
          W → Weapon Detection
          S → Stock Control
          A → ALL features (bundle)

  NOTE: L (Line Crossing) is no longer a separate feature.
        Existing L keys are treated as Zone Detection for backward compatibility.

  DC  = Duration Code (single character)
          1 → 1 month  (31 days)
          3 → 3 months (92 days)
          Y → 12 months (365 days)

  8HEX = 8 random uppercase hex characters
  4HEX = 4-char HMAC checksum (signs FC+DC+8HEX)

Examples:
  SVP-Z1-A3F9C201-4D2E  →  Zone Detection, 1 month
  SVP-S3-B7E2D401-9C1F  →  Stock Control, 3 months
  SVP-AY-C1F4A802-3B7E  →  ALL features, 12 months

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
KEY FORMAT — CHANNEL TIER KEYS:   SVC-{CC}{DC}-{8HEX}-{4HEX}
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
  CC  = Camera Channel Code
          4 → 4 cameras   (Starter tier)
          8 → 8 cameras   (Standard tier)
          6 → 16 cameras  (Pro tier — '6' used for hex-safe single char)

  DC  = Duration Code — same as above (1, 3, Y)

Examples:
  SVC-41-A3F9C201-4D2E  →  4 cameras, 1 month
  SVC-8Y-C1F4A802-3B7E  →  8 cameras, 12 months
  SVC-6Y-B7E2D401-9C1F  →  16 cameras, 12 months
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
"""

import hmac as _hmac
import hashlib
import secrets
import logging
import json as _json
import os as _os
from datetime import datetime, timedelta

logger = logging.getLogger(__name__)

# ─── Signing secret ────────────────────────────────────────────────────────────────── #
# Do NOT change this after issuing any keys — it will invalidate them all.
_LICENSE_SECRET = "SVP2026-c9f3a1b2-sentinel-license-secret"

# ─── Server-side validation (key revocation) ──────────────────────────────────────── #
_VALIDATE_URL    = "https://tribunal-carbon-atlantic.ngrok-free.dev/api/validate-key"
_SERVER_CACHE    = _os.path.join(_os.path.expanduser("~"), ".sv_lc.json")
_CACHE_TTL_HOURS = 24

# ─── Feature definitions ───────────────────────────────────────────────────────────── #
FEATURES = {
    "zone_detection": {
        "name": "Zone Detection",
        "description": "Draw detection zones on cameras. Get instant alerts when people enter or exit restricted areas.",
        "icon": "fas fa-draw-polygon",
        "is_experimental": False,
        "code": "Z",
    },
    "stock_control": {
        "name": "Stock Control",
        "description": "AI-powered shelf monitoring — track stock levels and receive low-stock alerts automatically.",
        "icon": "fas fa-boxes",
        "is_experimental": True,
        "code": "S",
    },
    "people_counting": {
        "name": "People Counting",
        "description": "Automatically count people moving through entrances, exits or defined zones.",
        "icon": "fas fa-users",
        "is_experimental": False,
        "code": "P",
    },
    "weapon_detection": {
        "name": "Weapon Detection",
        "description": "AI detection of potential weapons in live camera feeds for high-security environments.",
        "icon": "fas fa-shield-alt",
        "is_experimental": True,
        "code": "W",
    },
    "vehicle_detection": {
        "name": "Vehicle Detection",
        "description": "Detect and alert on vehicles (cars, trucks, buses, motorcycles, bicycles) in camera feeds.",
        "icon": "fas fa-car",
        "is_experimental": False,
        "code": "V",
    },
    "object_detection": {
        "name": "Object Detection",
        "description": "Detect and alert on everyday objects (bags, bottles, furniture, electronics and more) in camera feeds.",
        "icon": "fas fa-cube",
        "is_experimental": False,
        "code": "O",
    },
}

# Reverse map: single-letter code → feature_id
_CODE_TO_FEATURE = {v["code"]: k for k, v in FEATURES.items()}
ALL_FEATURE_IDS = list(FEATURES.keys())

# ─── Duration definitions ──────────────────────────────────────────────────── #
DURATIONS = {
    "1": {"label": "1 Month",   "months": 1,  "days": 31},
    "3": {"label": "3 Months",  "months": 3,  "days": 92},
    "Y": {"label": "12 Months", "months": 12, "days": 365},
    "P": {"label": "Permanent", "months": None, "days": None},  # No expiry — bound forever
}

# ─── Camera channel tier definitions ──────────────────────────────────────── #
# CC code → actual camera count (0 = unlimited)
CHANNEL_TIERS = {
    "4": {"label": "4 Channels (Starter)",   "cameras": 4},
    "8": {"label": "8 Channels (Standard)",  "cameras": 8},
    "6": {"label": "16 Channels (Pro)",      "cameras": 16},  # '6' avoids ambiguity in key
    "U": {"label": "Unlimited Channels",     "cameras": 0},   # 0 = no limit
}
_CC_TO_CAMERAS = {cc: v["cameras"] for cc, v in CHANNEL_TIERS.items()}


# ─── Device serial ─────────────────────────────────────────────────────────── #
def get_device_serial() -> str:
    """
    Return the hardware serial for this device.

    Priority:
      1. SV_DEVICE_SERIAL environment variable (dev/testing override)
      2. /proc/cpuinfo Serial line (Raspberry Pi)
      3. /etc/machine-id (other Linux)
      4. Windows registry MachineGuid
      5. 'UNKNOWN' as last resort
    """
    import os
    override = os.environ.get("SV_DEVICE_SERIAL", "").strip().upper()
    if override:
        return override
    try:
        with open("/proc/cpuinfo", "r") as f:
            for line in f:
                if line.lower().startswith("serial"):
                    serial = line.split(":")[-1].strip().upper()
                    if serial and serial != "0000000000000000":
                        return serial
    except OSError:
        pass
    try:
        with open("/etc/machine-id", "r") as f:
            mid = f.read().strip().upper()
            if mid:
                return mid[:16]  # first 16 chars is plenty
    except OSError:
        pass
    try:
        import winreg
        key = winreg.OpenKey(
            winreg.HKEY_LOCAL_MACHINE,
            r"SOFTWARE\Microsoft\Cryptography"
        )
        guid = winreg.QueryValueEx(key, "MachineGuid")[0]
        winreg.CloseKey(key)
        # Strip hyphens and take first 16 chars to keep it compact
        return guid.replace("-", "").upper()[:16]
    except Exception:
        pass
    return "UNKNOWN"


# ─── Internal HMAC helper ──────────────────────────────────────────────────── #
def _sign(fc: str, dc: str, base8: str, serial: str) -> str:
    """Return 4-char uppercase HMAC checksum — serial is baked in."""
    msg = f"{fc.upper()}{dc.upper()}:{base8.upper()}:{serial.upper()}"
    digest = _hmac.new(_LICENSE_SECRET.encode(), msg.encode(), hashlib.sha256).hexdigest()
    return digest[:4].upper()


def _sign_channel(cc: str, dc: str, base8: str, serial: str) -> str:
    """Return 4-char uppercase HMAC checksum for channel tier keys."""
    msg = f"SVC:{cc.upper()}{dc.upper()}:{base8.upper()}:{serial.upper()}"
    digest = _hmac.new(_LICENSE_SECRET.encode(), msg.encode(), hashlib.sha256).hexdigest()
    return digest[:4].upper()


# ─── Channel key generation ───────────────────────────────────────────────── #
def generate_channel_key(camera_count: int, duration_code: str, device_serial: str) -> str:
    """
    Generate a signed channel tier key for a specific camera count.

    Args:
        camera_count:  4, 8, or 16
        duration_code: '1' (1 month), '3' (3 months), or 'Y' (12 months)
        device_serial: the customer's device serial

    Returns:
        Key string, e.g. 'SVC-4Y-A3F9C201-4D2E'
    """
    duration_code = duration_code.upper()
    if duration_code not in DURATIONS:
        raise ValueError(f"Invalid duration_code {duration_code!r}. Use '1', '3', 'Y', or 'P'.")
    if not device_serial or not device_serial.strip():
        raise ValueError("device_serial is required.")

    # Map camera_count → cc code (0 = unlimited)
    cc_map = {4: "4", 8: "8", 16: "6", 0: "U"}
    if camera_count not in cc_map:
        raise ValueError(f"Invalid camera_count {camera_count!r}. Use 4, 8, 16, or 0 (unlimited).")
    cc = cc_map[camera_count]

    base8 = secrets.token_hex(4).upper()
    check = _sign_channel(cc, duration_code, base8, device_serial.strip().upper())
    return f"SVC-{cc}{duration_code}-{base8}-{check}"


# ─── Channel key parsing & verification ───────────────────────────────────── #
def parse_channel_key(key: str) -> dict | None:
    """
    Parse and verify a channel tier key.  Returns None if invalid/tampered.

    Returns dict on success:
        {
            "cc": "4",
            "dc": "1",
            "cameras": 4,
            "duration_months": 1,
            "duration_days": 31,
            "duration_label": "1 Month",
            "tier_label": "4 Channels (Starter)",
        }
    """
    try:
        parts = key.strip().upper().split("-")
        if len(parts) != 4 or parts[0] != "SVC":
            return None

        cc_dc, base8, check = parts[1], parts[2], parts[3]

        if len(cc_dc) != 2 or len(base8) != 8 or len(check) != 4:
            return None

        cc, dc = cc_dc[0], cc_dc[1]

        if cc not in CHANNEL_TIERS:
            return None
        if dc not in DURATIONS:
            return None

        serial = get_device_serial()
        expected = _sign_channel(cc, dc, base8, serial)
        if not _hmac.compare_digest(check, expected):
            return None

        dur = DURATIONS[dc]
        tier = CHANNEL_TIERS[cc]
        return {
            "cc":              cc,
            "dc":              dc,
            "cameras":         tier["cameras"],
            "tier_label":      tier["label"],
            "duration_months": dur["months"],
            "duration_days":   dur["days"],   # None = permanent
            "duration_label":  dur["label"],
            "permanent":       dur["days"] is None,
        }
    except Exception:
        return None
def generate_license_key(feature_id_or_all: str, duration_code: str, device_serial: str) -> str:
    """
    Generate a signed license key bound to a specific device serial.

    Args:
        feature_id_or_all: a key from FEATURES (e.g. 'zone_detection') OR 'all'
        duration_code: '1' (1 month), '3' (3 months), or 'Y' (12 months)
        device_serial: the customer's Pi serial (from /proc/cpuinfo or get_device_serial())

    Returns:
        Key string, e.g. 'SVP-Z1-A3F9C201-4D2E'  (same format, serial baked into checksum)
    """
    duration_code = duration_code.upper()
    if duration_code not in DURATIONS:
        raise ValueError(f"Invalid duration_code {duration_code!r}. Use '1', '3', 'Y', or 'P'.")

    if not device_serial or not device_serial.strip():
        raise ValueError("device_serial is required — get it from the customer's Pi.")

    if feature_id_or_all == "all":
        fc = "A"
    elif feature_id_or_all in FEATURES:
        fc = FEATURES[feature_id_or_all]["code"]
    else:
        raise ValueError(f"Unknown feature {feature_id_or_all!r}.")

    base8 = secrets.token_hex(4).upper()
    check  = _sign(fc, duration_code, base8, device_serial.strip().upper())
    return f"SVP-{fc}{duration_code}-{base8}-{check}"


# ─── Key parsing & verification ────────────────────────────────────────────── #
def parse_license_key(key: str) -> dict | None:
    """
    Parse and verify a key string. Returns None if invalid/tampered.

    Returns dict on success:
        {
            "fc": "Z",
            "dc": "1",
            "feature_ids": ["zone_detection"],
            "covers_all": False,
            "duration_months": 1,
            "duration_days": 31,
            "duration_label": "1 Month",
        }
    """
    try:
        parts = key.strip().upper().split("-")
        if len(parts) != 4 or parts[0] != "SVP":
            return None

        fc_dc, base8, check = parts[1], parts[2], parts[3]

        if len(fc_dc) != 2 or len(base8) != 8 or len(check) != 4:
            return None

        fc, dc = fc_dc[0], fc_dc[1]

        if dc not in DURATIONS:
            return None

        # Verify HMAC — must match this device's serial
        serial = get_device_serial()
        expected = _sign(fc, dc, base8, serial)
        if not _hmac.compare_digest(check, expected):
            return None

        # Resolve feature(s)
        if fc == "A":
            feature_ids = list(ALL_FEATURE_IDS)
            covers_all  = True
        elif fc in _CODE_TO_FEATURE:
            feature_ids = [_CODE_TO_FEATURE[fc]]
            covers_all  = False
        else:
            return None

        dur = DURATIONS[dc]
        return {
            "fc":              fc,
            "dc":              dc,
            "feature_ids":     feature_ids,
            "covers_all":      covers_all,
            "duration_months": dur["months"],
            "duration_days":   dur["days"],
            "duration_label":  dur["label"],
        }
    except Exception:
        return None


def verify_license_key(key: str) -> bool:
    """Quick check: True if the key signature is valid (ignores expiry)."""
    return parse_license_key(key) is not None


# ─── DB-level helpers ──────────────────────────────────────────────────────── #
def expire_old_licenses():
    """Mark past-expiry active keys as inactive."""
    try:
        from models import LicenseKey, db
        now = datetime.utcnow()
        expired = LicenseKey.query.filter(
            LicenseKey.is_active == True,
            LicenseKey.expires_at != None,
            LicenseKey.expires_at < now
        ).all()
        for k in expired:
            k.is_active = False
            logger.info(f"License expired: {k.key} ({k.feature_id})")
        if expired:
            db.session.commit()
    except Exception as e:
        logger.error(f"expire_old_licenses error: {e}")


def _server_validate(key: str, device_serial: str):
    """
    Check if a license key is still valid on the licensing server.
    Returns True (valid), False (explicitly revoked), or None (offline — use local check).
    Results are cached for 24 h so offline deployments continue to work.
    """
    cache_key = f"{key}:{device_serial}"

    # ── Read cache ──
    try:
        if _os.path.exists(_SERVER_CACHE):
            with open(_SERVER_CACHE, "r", encoding="utf-8") as _f:
                _cache = _json.load(_f)
            entry = _cache.get(cache_key)
            if entry:
                checked = datetime.fromisoformat(entry["checked_at"])
                if datetime.utcnow() - checked < timedelta(hours=_CACHE_TTL_HOURS):
                    return entry["valid"]
    except Exception:
        pass

    # ── Call server ──
    try:
        import urllib.request as _ur
        payload = _json.dumps({"key": key, "device_serial": device_serial}).encode()
        req = _ur.Request(
            _VALIDATE_URL,
            data    = payload,
            headers = {"Content-Type": "application/json"},
            method  = "POST",
        )
        with _ur.urlopen(req, timeout=5) as _resp:
            result = _json.loads(_resp.read())

        valid   = bool(result.get("valid",   False))
        revoked = bool(result.get("revoked", False))
        server_ok = valid and not revoked

        # ── Update cache ──
        try:
            _cache = {}
            if _os.path.exists(_SERVER_CACHE):
                try:
                    with open(_SERVER_CACHE, "r", encoding="utf-8") as _f:
                        _cache = _json.load(_f)
                except Exception:
                    pass
            _cache[cache_key] = {
                "valid":      server_ok,
                "checked_at": datetime.utcnow().isoformat(),
            }
            with open(_SERVER_CACHE, "w", encoding="utf-8") as _f:
                _json.dump(_cache, _f)
        except Exception:
            pass

        return server_ok

    except Exception:
        return None  # offline — caller uses local HMAC check as fallback


# line_crossing merged into zone_detection — treat them as the same feature
_FEATURE_ALIASES = {
    "line_crossing": "zone_detection",
}

def is_feature_unlocked(feature_id: str) -> bool:
    """
    Return True if the feature has an active, non-expired license in the DB.
    Accepts both specific-feature keys and all-features bundle keys.
    line_crossing is aliased to zone_detection.
    """
    # Resolve alias
    feature_id = _FEATURE_ALIASES.get(feature_id, feature_id)
    try:
        from models import LicenseKey
        expire_old_licenses()
        now = datetime.utcnow()
        keys = LicenseKey.query.filter(
            LicenseKey.is_active == True,
        ).all()
        serial = get_device_serial()
        for k in keys:
            # Skip expired (belt-and-suspenders)
            if k.expires_at and k.expires_at <= now:
                continue
            # Also accept old 'L' (line_crossing) keys as zone_detection
            resolved_fid = _FEATURE_ALIASES.get(k.feature_id, k.feature_id)
            if k.covers_all or resolved_fid == feature_id:
                # Server revocation check — if server explicitly says revoked, skip key
                sv = _server_validate(k.key, serial)
                if sv is False:
                    logger.warning("License key revoked by server: %s...", k.key[:12])
                    continue
                return True
        return False
    except Exception as e:
        logger.error(f"License check failed for {feature_id!r}: {e}")
        return False


def get_feature_status() -> dict:
    """
    Return a dict mapping feature_id → status info (used by license.html).
    """
    try:
        from models import LicenseKey
        expire_old_licenses()
        now = datetime.utcnow()
        active_keys = LicenseKey.query.filter(
            LicenseKey.is_active == True,
        ).all()
    except Exception:
        active_keys = []

    # Build per-feature lookup including "all" bundle keys
    unlocked = {}  # feature_id → LicenseKey row
    now = datetime.utcnow()
    for row in active_keys:
        if row.expires_at and row.expires_at <= now:
            continue
        if row.covers_all:
            for fid in ALL_FEATURE_IDS:
                if fid not in unlocked:
                    unlocked[fid] = row
        elif row.feature_id in FEATURES and row.feature_id not in unlocked:
            unlocked[row.feature_id] = row

    result = {}
    for fid, fdata in FEATURES.items():
        row = unlocked.get(fid)
        days_rem = None
        if row and row.expires_at:
            days_rem = max(0, (row.expires_at - now).days)

        is_expired = bool(row and row.expires_at and row.expires_at <= now)

        result[fid] = {
            **{k: v for k, v in fdata.items()},
            "is_unlocked":    row is not None and not is_expired,
            "is_expired":     is_expired,
            "license_key":    row.key if row else None,
            "expires_at":     row.expires_at.strftime("%d %b %Y") if (row and row.expires_at) else None,
            "duration_label": row.duration_label if row else None,
            "days_remaining": days_rem,
            "covers_all":     (row.covers_all if row else False),
        }
    return result


def get_expiry_warnings() -> list:
    """
    Return a sorted list of dicts for licenses that are expired or expiring within 30 days.
    Each dict:  { feature, feature_id, days_remaining, expired, expires_at }
    Used by the global banner in base.html and by Telegram notifications.
    """
    try:
        from models import LicenseKey
        now = datetime.utcnow()
        active_keys = LicenseKey.query.filter(LicenseKey.is_active == True).all()

        # Also pick up keys that WERE active but have now expired (expire_old_licenses may not have run yet)
        recently_expired = LicenseKey.query.filter(
            LicenseKey.is_active == False,
            LicenseKey.expires_at != None,
            LicenseKey.expires_at >= (now - timedelta(days=1)),  # expired in last 24h
            LicenseKey.expires_at < now,
        ).all()

        seen_features = set()
        warnings = []

        for k in list(active_keys) + list(recently_expired):
            if not k.expires_at:
                continue
            days_rem = (k.expires_at - now).days
            if days_rem > 30:
                continue  # not near expiry

            # Determine display name
            if k.covers_all:
                feature_display = "All Features"
                fid = "all"
            else:
                fid = k.feature_id
                feature_display = FEATURES.get(fid, {}).get("name", fid)

            if fid in seen_features:
                continue
            seen_features.add(fid)

            warnings.append({
                "feature":        feature_display,
                "feature_id":     fid,
                "days_remaining": max(0, days_rem),
                "expired":        k.expires_at <= now,
                "expires_at":     k.expires_at.strftime("%d %b %Y"),
            })

        return sorted(warnings, key=lambda x: x["days_remaining"])
    except Exception as e:
        logger.error(f"get_expiry_warnings error: {e}")
        return []


# ─── Cloud heartbeat ───────────────────────────────────────────────────────── #
# Derive from the same base already used for validation — no separate URL to expose
_HEARTBEAT_URL      = _VALIDATE_URL.rsplit("/", 1)[0].rsplit("/", 1)[0] + "/api/device/heartbeat"
_HEARTBEAT_INTERVAL = 300   # seconds (5 minutes)
_heartbeat_thread   = None

def _heartbeat_loop(app_version: str, flask_app=None):
    import urllib.request as _ur
    import time as _time

    while True:
        try:
            serial = get_device_serial()
            active_key = ""
            try:
                from models import LicenseKey
                if flask_app is not None:
                    with flask_app.app_context():
                        row = LicenseKey.query.filter(LicenseKey.is_active == True).first()
                        if row:
                            active_key = row.key
                else:
                    row = LicenseKey.query.filter(LicenseKey.is_active == True).first()
                    if row:
                        active_key = row.key
            except Exception:
                pass

            payload = _json.dumps({
                "device_serial": serial,
                "license_key":   active_key,
                "app_version":   app_version,
            }).encode()
            req = _ur.Request(
                _HEARTBEAT_URL,
                data    = payload,
                headers = {"Content-Type": "application/json"},
                method  = "POST",
            )
            with _ur.urlopen(req, timeout=8) as _resp:
                result = _json.loads(_resp.read())

            # — Auto-update if server says a new version is available —
            if result.get("update_available") and result.get("download_url"):
                _trigger_auto_update(result["download_url"], result.get("version", ""))

            logger.debug(f"Heartbeat sent: {serial[:8]}")
        except Exception as e:
            logger.debug(f"Heartbeat failed (offline?): {e}")
        _time.sleep(_HEARTBEAT_INTERVAL)


def _trigger_auto_update(download_url: str, new_version: str):
    """Download and apply an OTA update in a background thread."""
    import threading
    import urllib.request as _ur
    import tempfile

    current = ""
    try:
        import json as _j
        with open(_os.path.join(_os.path.dirname(_os.path.abspath(__file__)), "version.json")) as _f:
            current = _j.load(_f).get("version", "")
    except Exception:
        pass

    if current and new_version and current == new_version:
        return  # already on this version

    def _do_update():
        try:
            logger.info(f"OTA update available: v{new_version} — downloading...")
            with _ur.urlopen(download_url, timeout=120) as resp:
                data = resp.read()
            tmp = tempfile.NamedTemporaryFile(delete=False, suffix=".zip")
            tmp.write(data)
            tmp.close()
            from update_manager import UpdateManager
            ok, info = UpdateManager.apply_update(tmp.tmp_name if hasattr(tmp, 'tmp_name') else tmp.name)
            if ok:
                logger.info(f"OTA update to v{new_version} applied — restarting...")
                import sys, os as _os2
                _os2.execv(sys.executable, [sys.executable] + sys.argv)
            else:
                logger.warning(f"OTA update apply failed: {info}")
        except Exception as e:
            logger.error(f"OTA update failed: {e}")

    threading.Thread(target=_do_update, daemon=True, name="sv-ota-update").start()


def start_heartbeat(app_version: str = "", flask_app=None):
    """Start background thread that pings the license server every 5 minutes."""
    import threading
    global _heartbeat_thread
    if _heartbeat_thread and _heartbeat_thread.is_alive():
        return
    _heartbeat_thread = threading.Thread(
        target=_heartbeat_loop, args=(app_version, flask_app), daemon=True, name="sv-heartbeat"
    )
    _heartbeat_thread.start()
    logger.info("Cloud heartbeat started")
