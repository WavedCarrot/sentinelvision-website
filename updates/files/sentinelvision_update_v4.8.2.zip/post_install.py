#!/usr/bin/env python3
"""Post-install script for SentinelVision v4.7.10+"""
import subprocess
import sys
import os
import sqlite3
import glob

print("=" * 50)
print("SentinelVision Post-Install v4.8.2")
print("=" * 50)


# ── 1. Database migrations ────────────────────────────────
print("\n[1/4] Applying database migrations...")
try:
    # Find the database file
    db_paths = glob.glob('instance/*.db')
    db_path = db_paths[0] if db_paths else None

    if db_path:
        conn = sqlite3.connect(db_path)
        c = conn.cursor()

        # ── ADD MISSING COLUMNS (safe — fails silently if already present) ──

        # system_config: viewer account
        for ddl in [
            "ALTER TABLE system_config ADD COLUMN viewer_password_hash TEXT",
            "ALTER TABLE system_config ADD COLUMN viewer_account_enabled BOOLEAN DEFAULT 0",
            "ALTER TABLE system_config ADD COLUMN admin_username VARCHAR(100) DEFAULT 'admin'",
            "ALTER TABLE system_config ADD COLUMN viewer_username VARCHAR(100) DEFAULT 'viewer'",
            # multi-site
            "ALTER TABLE system_config ADD COLUMN site_name VARCHAR(200) DEFAULT 'Main Site'",
            "ALTER TABLE system_config ADD COLUMN site_id VARCHAR(50)",
            # multi-user telegram
            "ALTER TABLE system_config ADD COLUMN telegram_users TEXT",
            # retention & alerts
            "ALTER TABLE system_config ADD COLUMN auto_delete_days INTEGER DEFAULT 30",
            "ALTER TABLE system_config ADD COLUMN camera_offline_alert_minutes INTEGER DEFAULT 5",
            # feature password
            "ALTER TABLE system_config ADD COLUMN feature_password VARCHAR(100) DEFAULT 'sentinel2026'",
            "ALTER TABLE system_config ADD COLUMN feature_password_enabled BOOLEAN DEFAULT 1",
            # auto schedule
            "ALTER TABLE system_config ADD COLUMN enable_auto_schedule BOOLEAN DEFAULT 0",
            "ALTER TABLE system_config ADD COLUMN arm_time VARCHAR(10) DEFAULT '22:00'",
            "ALTER TABLE system_config ADD COLUMN disarm_time VARCHAR(10) DEFAULT '07:00'",
            "ALTER TABLE system_config ADD COLUMN schedule_days VARCHAR(20) DEFAULT '1,2,3,4,5'",
            "ALTER TABLE system_config ADD COLUMN timezone VARCHAR(50) DEFAULT 'UTC'",
            # camera channel limit (4/8/16 tier licensing)
            "ALTER TABLE system_config ADD COLUMN camera_channel_limit INTEGER DEFAULT 4",
            # password setup & first-run
            "ALTER TABLE system_config ADD COLUMN admin_password_hash VARCHAR(256)",
            "ALTER TABLE system_config ADD COLUMN admin_password_set BOOLEAN DEFAULT 0",
            "ALTER TABLE system_config ADD COLUMN first_login BOOLEAN DEFAULT 1",
            # detection global defaults
            "ALTER TABLE system_config ADD COLUMN detection_confidence REAL DEFAULT 0.35",
            "ALTER TABLE system_config ADD COLUMN min_detection_size INTEGER DEFAULT 80",
            "ALTER TABLE system_config ADD COLUMN max_detection_size INTEGER DEFAULT 5000",
            "ALTER TABLE system_config ADD COLUMN enable_zone_detection BOOLEAN DEFAULT 1",
            "ALTER TABLE system_config ADD COLUMN enable_people_counting BOOLEAN DEFAULT 1",
            "ALTER TABLE system_config ADD COLUMN enable_tracking BOOLEAN DEFAULT 1",
            # network
            "ALTER TABLE system_config ADD COLUMN system_name VARCHAR(200) DEFAULT 'SentinelVision Security Platform'",
            "ALTER TABLE system_config ADD COLUMN network_ip VARCHAR(50)",
            "ALTER TABLE system_config ADD COLUMN network_mode VARCHAR(20) DEFAULT 'dhcp'",
            "ALTER TABLE system_config ADD COLUMN network_port INTEGER DEFAULT 5000",
            # camera channel licensing tier lock (v4.8.2)
            "ALTER TABLE system_config ADD COLUMN camera_channel_locked BOOLEAN DEFAULT 0",
        ]:
            try:
                c.execute(ddl)
            except Exception:
                pass  # Column already exists

        # license_keys table — create if missing (old devices pre-v4.7)
        c.execute("""
            CREATE TABLE IF NOT EXISTS license_keys (
                id INTEGER PRIMARY KEY,
                key VARCHAR(32) UNIQUE NOT NULL,
                feature_id VARCHAR(50) NOT NULL,
                covers_all BOOLEAN DEFAULT 0,
                duration_months INTEGER DEFAULT 1,
                duration_label VARCHAR(20) DEFAULT '1 Month',
                activated_at DATETIME,
                expires_at DATETIME,
                is_active BOOLEAN DEFAULT 1
            )
        """)
        for ddl in [
            "ALTER TABLE license_keys ADD COLUMN covers_all BOOLEAN DEFAULT 0",
            "ALTER TABLE license_keys ADD COLUMN duration_months INTEGER DEFAULT 1",
            "ALTER TABLE license_keys ADD COLUMN duration_label VARCHAR(20) DEFAULT '1 Month'",
            "ALTER TABLE license_keys ADD COLUMN activated_at DATETIME",
            "ALTER TABLE license_keys ADD COLUMN expires_at DATETIME",
            "ALTER TABLE license_keys ADD COLUMN is_active BOOLEAN DEFAULT 1",
        ]:
            try:
                c.execute(ddl)
            except Exception:
                pass

        # cameras: new detection + alert fields
        for ddl in [
            # stream settings
            "ALTER TABLE cameras ADD COLUMN stream_width INTEGER DEFAULT 1920",
            "ALTER TABLE cameras ADD COLUMN stream_height INTEGER DEFAULT 1080",
            "ALTER TABLE cameras ADD COLUMN substream_width INTEGER DEFAULT 704",
            "ALTER TABLE cameras ADD COLUMN substream_height INTEGER DEFAULT 576",
            "ALTER TABLE cameras ADD COLUMN weapon_alert_sound BOOLEAN DEFAULT 1",
            "ALTER TABLE cameras ADD COLUMN enable_weapon_detection BOOLEAN DEFAULT 0",
            "ALTER TABLE cameras ADD COLUMN working_rtsp_url VARCHAR(500)",
            "ALTER TABLE cameras ADD COLUMN main_stream_url VARCHAR(500)",
            "ALTER TABLE cameras ADD COLUMN is_dvr_channel BOOLEAN DEFAULT 0",
            "ALTER TABLE cameras ADD COLUMN exclusion_zones TEXT",
            "ALTER TABLE cameras ADD COLUMN enable_face_blur BOOLEAN DEFAULT 0",
            # per-camera sensitivity
            "ALTER TABLE cameras ADD COLUMN person_sensitivity REAL DEFAULT 0.75",
            "ALTER TABLE cameras ADD COLUMN vehicle_sensitivity REAL DEFAULT 0.65",
            "ALTER TABLE cameras ADD COLUMN animal_sensitivity REAL DEFAULT 0.65",
            "ALTER TABLE cameras ADD COLUMN animal_classes TEXT",
            "ALTER TABLE cameras ADD COLUMN night_ir_threshold REAL DEFAULT 12.0",
            "ALTER TABLE cameras ADD COLUMN detection_cooldown_seconds INTEGER DEFAULT 60",
            "ALTER TABLE cameras ADD COLUMN animal_min_size INTEGER DEFAULT 1500",
            # zone-only & snooze
            "ALTER TABLE cameras ADD COLUMN zone_only_detection BOOLEAN DEFAULT 0",
            "ALTER TABLE cameras ADD COLUMN snooze_until DATETIME",
            # PTZ
            "ALTER TABLE cameras ADD COLUMN has_ptz BOOLEAN DEFAULT 0",
            "ALTER TABLE cameras ADD COLUMN ptz_onvif_url VARCHAR(500)",
            "ALTER TABLE cameras ADD COLUMN ptz_username VARCHAR(100)",
            "ALTER TABLE cameras ADD COLUMN ptz_password VARCHAR(100)",
            "ALTER TABLE cameras ADD COLUMN ptz_presets TEXT",
            # behaviour analysis
            "ALTER TABLE cameras ADD COLUMN enable_behavior_analysis BOOLEAN DEFAULT 0",
            "ALTER TABLE cameras ADD COLUMN detect_running BOOLEAN DEFAULT 1",
            "ALTER TABLE cameras ADD COLUMN detect_fighting BOOLEAN DEFAULT 1",
            "ALTER TABLE cameras ADD COLUMN detect_falling BOOLEAN DEFAULT 1",
            "ALTER TABLE cameras ADD COLUMN behavior_sensitivity VARCHAR(20) DEFAULT 'medium'",
            # anti-false-positive
            "ALTER TABLE cameras ADD COLUMN require_motion BOOLEAN DEFAULT 1",
            "ALTER TABLE cameras ADD COLUMN min_consecutive_frames INTEGER DEFAULT 2",
            # alert & display
            "ALTER TABLE cameras ADD COLUMN enable_anomaly_detection BOOLEAN DEFAULT 1",
            "ALTER TABLE cameras ADD COLUMN alert_media VARCHAR(20) DEFAULT 'both'",
            "ALTER TABLE cameras ADD COLUMN sort_order INTEGER DEFAULT 0",
            # tamper detection
            "ALTER TABLE cameras ADD COLUMN enable_tamper_detection BOOLEAN DEFAULT 0",
            "ALTER TABLE cameras ADD COLUMN tamper_sensitivity VARCHAR(20) DEFAULT 'medium'",
            # stock control
            "ALTER TABLE cameras ADD COLUMN enable_stock_control BOOLEAN DEFAULT 0",
            "ALTER TABLE cameras ADD COLUMN stock_items TEXT",
            "ALTER TABLE cameras ADD COLUMN stock_low_threshold INTEGER DEFAULT 50",
            "ALTER TABLE cameras ADD COLUMN stock_critical_threshold INTEGER DEFAULT 20",
            # time-based sensitivity
            "ALTER TABLE cameras ADD COLUMN day_sensitivity REAL DEFAULT 0.80",
            "ALTER TABLE cameras ADD COLUMN night_sensitivity REAL DEFAULT 0.80",
            # advanced detection features
            "ALTER TABLE cameras ADD COLUMN enable_license_plate_detection BOOLEAN DEFAULT 0",
            "ALTER TABLE cameras ADD COLUMN enable_motion_detection BOOLEAN DEFAULT 1",
            "ALTER TABLE cameras ADD COLUMN enable_night_mode BOOLEAN DEFAULT 1",
            "ALTER TABLE cameras ADD COLUMN detection_sensitivity VARCHAR(20) DEFAULT 'medium'",
            "ALTER TABLE cameras ADD COLUMN custom_classes TEXT",
            "ALTER TABLE cameras ADD COLUMN alert_cooldown INTEGER DEFAULT 60",
            # recording
            "ALTER TABLE cameras ADD COLUMN enable_recording BOOLEAN DEFAULT 0",
            "ALTER TABLE cameras ADD COLUMN recording_path VARCHAR(500)",
            # armed state & object detection (original columns, safety fallback)
            "ALTER TABLE cameras ADD COLUMN is_armed BOOLEAN DEFAULT 1",
            "ALTER TABLE cameras ADD COLUMN enable_object_detection BOOLEAN DEFAULT 0",
            # per-type detection toggles
            "ALTER TABLE cameras ADD COLUMN enable_person_detection BOOLEAN DEFAULT 1",
            "ALTER TABLE cameras ADD COLUMN enable_vehicle_detection BOOLEAN DEFAULT 0",
            "ALTER TABLE cameras ADD COLUMN enable_animal_detection BOOLEAN DEFAULT 0",
            # location & alert tracking
            "ALTER TABLE cameras ADD COLUMN location VARCHAR(200)",
            "ALTER TABLE cameras ADD COLUMN last_alert_time DATETIME",
        ]:
            try:
                c.execute(ddl)
            except Exception:
                pass  # Column already exists

        # ── DATA FIXES ────────────────────────────────────────────────────────

        # detection_events: new fields added post-v3
        for ddl in [
            "ALTER TABLE detection_events ADD COLUMN thumbnail_path VARCHAR(500)",
            "ALTER TABLE detection_events ADD COLUMN clip_path VARCHAR(500)",
            "ALTER TABLE detection_events ADD COLUMN item_count INTEGER DEFAULT 0",
            "ALTER TABLE detection_events ADD COLUMN item_name VARCHAR(100)",
            "ALTER TABLE detection_events ADD COLUMN acknowledged BOOLEAN DEFAULT 0",
            "ALTER TABLE detection_events ADD COLUMN acknowledged_at DATETIME",
            "ALTER TABLE detection_events ADD COLUMN additional_data TEXT",
            "ALTER TABLE detection_events ADD COLUMN bbox TEXT",
            "ALTER TABLE detection_events ADD COLUMN telegram_sent_at DATETIME",
        ]:
            try:
                c.execute(ddl)
            except Exception:
                pass  # Column already exists

        # detection_zones: new fields
        for ddl in [
            "ALTER TABLE detection_zones ADD COLUMN line_points TEXT",
            "ALTER TABLE detection_zones ADD COLUMN line_direction VARCHAR(20) DEFAULT 'both'",
            "ALTER TABLE detection_zones ADD COLUMN schedule_enabled BOOLEAN DEFAULT 0",
            "ALTER TABLE detection_zones ADD COLUMN active_start_time VARCHAR(10) DEFAULT '00:00'",
            "ALTER TABLE detection_zones ADD COLUMN active_end_time VARCHAR(10) DEFAULT '23:59'",
            "ALTER TABLE detection_zones ADD COLUMN active_days VARCHAR(20) DEFAULT '0,1,2,3,4,5,6'",
            "ALTER TABLE detection_zones ADD COLUMN preset_type VARCHAR(50)",
            "ALTER TABLE detection_zones ADD COLUMN enable_path_tracking BOOLEAN DEFAULT 0",
            "ALTER TABLE detection_zones ADD COLUMN path_history_seconds INTEGER DEFAULT 30",
            "ALTER TABLE detection_zones ADD COLUMN min_confidence FLOAT DEFAULT 0.35",
            "ALTER TABLE detection_zones ADD COLUMN alert_cooldown_minutes INTEGER DEFAULT 5",
            # detection type toggles per zone
            "ALTER TABLE detection_zones ADD COLUMN detect_person BOOLEAN DEFAULT 1",
            "ALTER TABLE detection_zones ADD COLUMN detect_vehicle BOOLEAN DEFAULT 0",
            "ALTER TABLE detection_zones ADD COLUMN detect_animal BOOLEAN DEFAULT 0",
            # zone behaviour
            "ALTER TABLE detection_zones ADD COLUMN zone_type VARCHAR(50) DEFAULT 'alert'",
            "ALTER TABLE detection_zones ADD COLUMN alert_on_entry BOOLEAN DEFAULT 1",
            "ALTER TABLE detection_zones ADD COLUMN alert_on_exit BOOLEAN DEFAULT 1",
            "ALTER TABLE detection_zones ADD COLUMN loiter_threshold_seconds INTEGER DEFAULT 300",
            "ALTER TABLE detection_zones ADD COLUMN current_occupancy INTEGER DEFAULT 0",
            "ALTER TABLE detection_zones ADD COLUMN crowd_alert_threshold INTEGER DEFAULT 80",
            "ALTER TABLE detection_zones ADD COLUMN polygon_points TEXT",
        ]:
            try:
                c.execute(ddl)
            except Exception:
                pass  # Column already exists or table doesn't exist yet

        # Clear stuck alert cooldowns so alerts fire immediately after install
        c.execute("UPDATE cameras SET last_alert_time=NULL")

        # Restore person_sensitivity to 0.75 default for cameras that were
        # lowered to 0.55 by a previous migration (reverted: 0.55 caused false alerts)
        try:
            c.execute("UPDATE cameras SET person_sensitivity=0.75 WHERE person_sensitivity <= 0.56")
        except Exception:
            pass

        # Enable loitering zone alerts if they have none configured
        try:
            c.execute("""UPDATE detection_zones SET alert_on_exit=1
                         WHERE zone_type='loitering'
                           AND alert_on_entry=0 AND alert_on_exit=0""")
        except Exception:
            pass  # Table may not exist on older installs

        conn.commit()
        conn.close()
        print("  ✓ Schema migrations applied (new columns added where missing)")
        print("  ✓ Alert cooldown reset")
        print("  ✓ Person sensitivity restored to 0.75 default")
    else:
        print("  ⚠ No database found - will be created on first run")

except Exception as e:
    print(f"  ⚠ DB migration warning: {e}")


# ── 2. Ensure yolov8s model is present ───────────────────
print("\n[2/4] Checking AI model...")
model_dir = "models"
model_path = os.path.join(model_dir, "yolo11s.pt")

if os.path.exists(model_path):
    size_mb = os.path.getsize(model_path) / (1024 * 1024)
    print(f"  ✓ yolo11s.pt already present ({size_mb:.1f} MB)")
else:
    print("  ↓ Downloading yolo11s.pt (19 MB - requires internet)...")
    try:
        os.makedirs(model_dir, exist_ok=True)
        from ultralytics import YOLO
        model = YOLO("yolo11s.pt")  # auto-downloads
        import shutil
        cached = os.path.join(os.path.expanduser("~"), ".cache", "ultralytics", "yolo11s.pt")
        if os.path.exists(cached):
            shutil.copy2(cached, model_path)
        else:
            model.save(model_path)
        print(f"  ✓ yolo11s.pt downloaded successfully")
    except Exception as e:
        print(f"  ⚠ Could not download model: {e}")
        print("    The model will auto-download when the service starts (needs internet)")


# ── 3. Install/update dependencies ───────────────────────
print("\n[3/4] Checking dependencies...")
pip_ok = True
try:
    result = subprocess.run(
        [sys.executable, '-m', 'pip', 'install', '-r', 'requirements.txt'],
        capture_output=True, text=True
    )
    if result.returncode != 0:
        pip_ok = False
        print(f"  ✗ pip install FAILED (exit {result.returncode})")
        print(result.stderr[-2000:] if result.stderr else "(no stderr)")
    else:
        # Show any "Successfully installed …" lines from pip output
        for line in result.stdout.splitlines():
            if 'Successfully installed' in line or 'already satisfied' in line.lower():
                print(f"  pip: {line.strip()}")
        print("  ✓ Dependencies installed/verified")
except Exception as e:
    pip_ok = False
    print(f"  ✗ pip install error: {e}")

# ── 4. Verify critical imports and report versions ───────
print("\n[4/4] Verifying critical packages...")

critical = [
    ('flask',        'flask',        '__version__'),
    ('cv2',          'opencv-python','__version__'),
    ('ultralytics',  'ultralytics',  '__version__'),
    ('torch',        'torch',        '__version__'),
]
all_ok = True
for mod, pkg_name, ver_attr in critical:
    try:
        m = __import__(mod)
        ver = getattr(m, ver_attr, 'unknown')
        print(f"  ✓ {pkg_name} {ver}")
    except ImportError:
        all_ok = False
        print(f"  ✗ {pkg_name} NOT importable — try: pip install {pkg_name}")

if not all_ok:
    print("\n  ⚠ Some packages failed to import. If the service fails to start")
    print("    run: pip install -r requirements.txt")

print("\n" + "=" * 50)
if pip_ok and all_ok:
    print("✅ Post-install complete!")
else:
    print("⚠  Post-install finished with warnings — check output above.")
print("   Restart service: sudo systemctl restart sentinelvision")
print("=" * 50)
