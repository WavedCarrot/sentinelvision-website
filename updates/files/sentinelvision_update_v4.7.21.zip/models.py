"""
Simplified database models for SentinelVision Raspberry Pi Edition
Single-user setup with Telegram notifications
"""
from flask_sqlalchemy import SQLAlchemy
from datetime import datetime, timedelta
import json

db = SQLAlchemy()


class SystemConfig(db.Model):
    """Store system-wide configuration"""
    __tablename__ = 'system_config'
    
    id = db.Column(db.Integer, primary_key=True)
    system_name = db.Column(db.String(200), default='SentinelVision Security Platform')
    site_name = db.Column(db.String(200), default='Main Site')  # Site/unit name for multi-site management
    site_id = db.Column(db.String(50))  # Unique site identifier
    telegram_chat_id = db.Column(db.Text)  # Multiple chat IDs (comma-separated) - legacy
    telegram_users = db.Column(db.Text)  # JSON: {"chat_id": {"role": "admin/viewer", "name": "..."}}
    
    # Admin Authentication
    admin_password_hash = db.Column(db.String(256))  # Hashed admin password
    admin_password_set = db.Column(db.Boolean, default=False)  # Whether password has been set
    first_login = db.Column(db.Boolean, default=True)  # First time login flag

    # Viewer Account (read-only access to Events page)
    viewer_password_hash = db.Column(db.String(256))  # Hashed viewer password
    viewer_account_enabled = db.Column(db.Boolean, default=False)  # Whether viewer login is enabled

    # Account usernames (displayed on login and navbar)
    admin_username = db.Column(db.String(100), default='admin')
    viewer_username = db.Column(db.String(100), default='viewer')
    
    # Feature Password (for zones and stock control - cannot be changed)
    feature_password = db.Column(db.String(100), default='sentinel2026')  # Default feature password
    feature_password_enabled = db.Column(db.Boolean, default=True)  # Whether feature password is required
    
    # Network settings
    network_ip = db.Column(db.String(50))  # Current/desired IP address
    network_port = db.Column(db.Integer, default=5000)
    network_mode = db.Column(db.String(20), default='dhcp')  # dhcp or static
    
    # Detection settings
    detection_confidence = db.Column(db.Float, default=0.35)  # Lowered to 35% for better person detection
    min_detection_size = db.Column(db.Integer, default=80)  # Minimum pixel size (increased from 50)
    max_detection_size = db.Column(db.Integer, default=5000)  # Maximum pixel size
    enable_tracking = db.Column(db.Boolean, default=True)  # Object tracking
    enable_zone_detection = db.Column(db.Boolean, default=True)  # Detection zones - ENABLED by default
    enable_people_counting = db.Column(db.Boolean, default=True)  # People counting feature
    
    is_armed = db.Column(db.Boolean, default=True)  # System armed/disarmed state
    
    # Auto scheduling
    enable_auto_schedule = db.Column(db.Boolean, default=False)  # Enable automatic arm/disarm
    arm_time = db.Column(db.String(10), default='22:00')  # Auto arm time (HH:MM)
    disarm_time = db.Column(db.String(10), default='07:00')  # Auto disarm time (HH:MM)
    schedule_days = db.Column(db.String(20), default='1,2,3,4,5')  # Days of week (0=Monday, 6=Sunday)
    timezone = db.Column(db.String(50), default='UTC')  # Timezone for scheduling
    
    # Data retention
    auto_delete_days = db.Column(db.Integer, default=30)  # Delete events/clips older than N days
    
    # Camera channel limit (set at install time based on purchased tier: 4, 8, or 16)
    camera_channel_limit = db.Column(db.Integer, default=4)  # Max cameras allowed: 4 / 8 / 16

    # Camera offline alarm
    camera_offline_alert_minutes = db.Column(db.Integer, default=5)  # Alert after X minutes offline
    
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    def get_telegram_users(self):
        """Get dictionary of all telegram users with roles"""
        users = {}
        
        # First, try to load from telegram_users JSON field
        if self.telegram_users:
            try:
                users = json.loads(self.telegram_users)
            except:
                users = {}
        
        # Also check legacy telegram_chat_id field for users not in JSON
        if self.telegram_chat_id:
            for cid in str(self.telegram_chat_id).split(','):
                cid = cid.strip()
                if cid and cid not in users:
                    # Add as admin by default for legacy users
                    users[cid] = {'role': 'admin', 'name': 'Legacy User', 'added_at': ''}
        
        return users
    
    def get_chat_ids(self, role=None):
        """Get list of chat IDs, optionally filtered by role"""
        users = self.get_telegram_users()
        if role:
            return [cid for cid, data in users.items() if data.get('role') == role]
        return list(users.keys())
    
    def get_admin_chat_ids(self):
        """Get list of admin chat IDs"""
        return self.get_chat_ids(role='admin')
    
    def add_telegram_user(self, chat_id, role='admin', name=''):
        """Add a telegram user with role - default to admin"""
        users = self.get_telegram_users()
        users[str(chat_id)] = {
            'role': role,
            'name': name,
            'added_at': datetime.utcnow().isoformat()
        }
        self.telegram_users = json.dumps(users)
        # Update legacy field for backward compatibility
        self.telegram_chat_id = ','.join(users.keys())
    
    def remove_telegram_user(self, chat_id):
        """Remove a telegram user"""
        users = self.get_telegram_users()
        if str(chat_id) in users:
            del users[str(chat_id)]
            self.telegram_users = json.dumps(users)
            self.telegram_chat_id = ','.join(users.keys())
    
    def is_admin(self, chat_id):
        """Check if a chat ID is an admin"""
        users = self.get_telegram_users()
        return users.get(str(chat_id), {}).get('role') == 'admin'
    
    def get_schedule_days_list(self):
        """Get list of schedule days as integers"""
        if not self.schedule_days:
            return [1, 2, 3, 4, 5]  # Default weekdays
        try:
            return [int(d) for d in self.schedule_days.split(',') if d.strip()]
        except:
            return [1, 2, 3, 4, 5]
    
    def set_schedule_days(self, days_list):
        """Set schedule days from list of integers"""
        self.schedule_days = ','.join(str(d) for d in days_list)
    
    def get_schedule_info(self):
        """Get formatted schedule information"""
        if not self.enable_auto_schedule:
            return "Auto-schedule disabled"
        
        day_names = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun']
        days = [day_names[d] for d in self.get_schedule_days_list()]
        
        return f"Arm: {self.arm_time}, Disarm: {self.disarm_time} on {', '.join(days)}"
    
    def add_chat_id(self, chat_id):
        """Legacy method - adds as viewer"""
        self.add_telegram_user(chat_id, role='viewer')
    
    def remove_chat_id(self, chat_id):
        """Legacy method"""
        self.remove_telegram_user(chat_id)
    
    def set_admin_password(self, password):
        """Set admin password with PBKDF2+salt hashing"""
        from werkzeug.security import generate_password_hash
        self.admin_password_hash = generate_password_hash(password)
        self.admin_password_set = True
        self.first_login = False
    
    def verify_admin_password(self, password):
        """Verify admin password — supports both new PBKDF2 and legacy SHA-256 hashes"""
        if not self.admin_password_hash:
            return False
        from werkzeug.security import check_password_hash
        # Legacy: plain SHA-256 hex (64 chars, no method prefix)
        if len(self.admin_password_hash) == 64 and ':' not in self.admin_password_hash:
            import hashlib
            match = self.admin_password_hash == hashlib.sha256(password.encode()).hexdigest()
            if match:
                # Upgrade hash to PBKDF2 on successful login
                self.set_admin_password(password)
            return match
        return check_password_hash(self.admin_password_hash, password)
    
    def verify_feature_password(self, password):
        """Verify feature password for zones/stock control"""
        return password == self.feature_password

    def set_viewer_password(self, password):
        """Set viewer password with PBKDF2+salt hashing"""
        from werkzeug.security import generate_password_hash
        self.viewer_password_hash = generate_password_hash(password)
        self.viewer_account_enabled = True

    def verify_viewer_password(self, password):
        """Verify viewer password"""
        if not self.viewer_password_hash or not self.viewer_account_enabled:
            return False
        from werkzeug.security import check_password_hash
        return check_password_hash(self.viewer_password_hash, password)

    def clear_viewer_password(self):
        """Disable viewer account"""
        self.viewer_password_hash = None
        self.viewer_account_enabled = False
    
    def to_dict(self):
        return {
            'id': self.id,
            'system_name': self.system_name,
            'site_name': getattr(self, 'site_name', 'Main Site'),
            'site_id': getattr(self, 'site_id', None),
            'telegram_chat_id': self.telegram_chat_id,
            'telegram_chat_ids': self.get_chat_ids(),
            'telegram_users': self.get_telegram_users(),
            'network_ip': self.network_ip,
            'network_port': self.network_port,
            'network_mode': self.network_mode,
            'detection_confidence': self.detection_confidence,
            'min_detection_size': self.min_detection_size,
            'max_detection_size': self.max_detection_size,
            'enable_tracking': self.enable_tracking,
            'enable_zone_detection': self.enable_zone_detection,
            'enable_people_counting': getattr(self, 'enable_people_counting', True),
            'is_armed': self.is_armed,
            'enable_auto_schedule': self.enable_auto_schedule,
            'arm_time': self.arm_time,
            'disarm_time': self.disarm_time,
            'schedule_days': self.get_schedule_days_list(),
            'schedule_info': self.get_schedule_info(),
            'timezone': self.timezone,
            'auto_delete_days': getattr(self, 'auto_delete_days', 30),
            'camera_offline_alert_minutes': getattr(self, 'camera_offline_alert_minutes', 5),
            'admin_password_set': getattr(self, 'admin_password_set', False),
            'first_login': getattr(self, 'first_login', True),
            'feature_password_enabled': getattr(self, 'feature_password_enabled', True),
            'admin_username': getattr(self, 'admin_username', None) or 'admin',
            'viewer_username': getattr(self, 'viewer_username', None) or 'viewer',
            'updated_at': self.updated_at.isoformat() if self.updated_at else None
        }


class Camera(db.Model):
    """Camera configuration"""
    __tablename__ = 'cameras'
    
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    rtsp_url = db.Column(db.String(500), nullable=False)  # Main detection stream (can be substream)
    main_stream_url = db.Column(db.String(500))  # High quality stream for snapshots
    working_rtsp_url = db.Column(db.String(500))  # Auto-discovered working RTSP URL
    location = db.Column(db.String(200))
    is_active = db.Column(db.Boolean, default=True)
    
    # Stream settings
    stream_width = db.Column(db.Integer, default=1920)  # Main stream resolution
    stream_height = db.Column(db.Integer, default=1080)
    substream_width = db.Column(db.Integer, default=704)  # Substream resolution for detection
    substream_height = db.Column(db.Integer, default=576)
    is_dvr_channel = db.Column(db.Boolean, default=False)  # True if camera is on DVR/NVR
    
    # Exclusion zones - areas to ignore (JSON array of polygons)
    exclusion_zones = db.Column(db.Text)  # JSON: [[{x,y}, {x,y}, ...], ...]
    
    # Detection settings
    enable_person_detection = db.Column(db.Boolean, default=True)
    enable_vehicle_detection = db.Column(db.Boolean, default=False)
    enable_animal_detection = db.Column(db.Boolean, default=False)
    enable_stock_control = db.Column(db.Boolean, default=False)  # Stock control for multiple items
    enable_object_detection = db.Column(db.Boolean, default=False)
    
    # Weapon/Threat detection - HIGH PRIORITY ALERTS
    enable_weapon_detection = db.Column(db.Boolean, default=False)  # Detect firearms/weapons
    weapon_alert_sound = db.Column(db.Boolean, default=True)  # Play alert sound on threat

    # Privacy / compliance
    enable_face_blur = db.Column(db.Boolean, default=False)  # Blur faces in saved snapshots (POPIA/GDPR)
    
    # PTZ (Pan-Tilt-Zoom) control
    has_ptz = db.Column(db.Boolean, default=False)  # Camera supports PTZ
    ptz_onvif_url = db.Column(db.String(500))  # ONVIF service URL for PTZ
    ptz_username = db.Column(db.String(100))  # PTZ authentication
    ptz_password = db.Column(db.String(100))  # PTZ password
    ptz_presets = db.Column(db.Text)  # JSON: [{name, preset_id}, ...]
    
    # Behavior analysis
    enable_behavior_analysis = db.Column(db.Boolean, default=False)
    detect_running = db.Column(db.Boolean, default=True)
    detect_fighting = db.Column(db.Boolean, default=True)
    detect_falling = db.Column(db.Boolean, default=True)
    behavior_sensitivity = db.Column(db.String(20), default='medium')
    
    # Anti-false positive settings
    require_motion = db.Column(db.Boolean, default=True)  # Require motion before detection
    min_consecutive_frames = db.Column(db.Integer, default=2)  # Require detection in N frames
    
    # Zone-only detection - only alert when person is IN a detection zone
    zone_only_detection = db.Column(db.Boolean, default=False)  # Only alert for in-zone detections
    
    # Time-based sensitivity (different thresholds for day/night)
    day_sensitivity = db.Column(db.Float, default=0.80)  # Daytime confidence threshold (6am-6pm)
    night_sensitivity = db.Column(db.Float, default=0.80)  # Nighttime confidence threshold (IR/low-light)
    animal_sensitivity = db.Column(db.Float, default=0.65)  # Animal detection confidence threshold
    vehicle_sensitivity = db.Column(db.Float, default=0.65)  # Vehicle detection confidence threshold (raise to reduce static object false positives)
    person_sensitivity = db.Column(db.Float, default=0.75)  # Person detection confidence threshold
    animal_classes = db.Column(db.Text)  # JSON list of animal classes to detect, e.g. ["dog","cat"]; null = all
    night_ir_threshold = db.Column(db.Float, default=12.0)  # Channel-diff threshold for night/IR detection (lower = more sensitive to IR)
    detection_cooldown_seconds = db.Column(db.Integer, default=60)  # Per-camera detection alert cooldown (seconds)
    animal_min_size = db.Column(db.Integer, default=1500)  # Minimum animal bounding box area in px²
    
    # Alert snooze
    snooze_until = db.Column(db.DateTime)  # Snooze alerts until this time
    
    # Stock control settings
    stock_items = db.Column(db.Text)  # JSON: [{name, min_threshold, current_count, yolo_classes}]
    stock_low_threshold = db.Column(db.Integer, default=50)  # Default low stock alert
    stock_critical_threshold = db.Column(db.Integer, default=20)  # Critical stock alert
    
    # Advanced detection features
    enable_anomaly_detection = db.Column(db.Boolean, default=True)  # Alert on unusual activity spikes
    enable_license_plate_detection = db.Column(db.Boolean, default=False)
    enable_motion_detection = db.Column(db.Boolean, default=True)
    enable_night_mode = db.Column(db.Boolean, default=True)  # Enhanced low-light detection
    detection_sensitivity = db.Column(db.String(20), default='medium')  # low, medium, high
    
    # Custom detection classes (JSON array)
    custom_classes = db.Column(db.Text)  # JSON array of class names
    
    # Alert settings
    alert_cooldown = db.Column(db.Integer, default=60)  # Seconds between alerts for same camera
    last_alert_time = db.Column(db.DateTime)
    is_armed = db.Column(db.Boolean, default=True)  # Camera-specific armed state
    alert_media = db.Column(db.String(20), default='both')  # 'image', 'clip', or 'both'
    sort_order = db.Column(db.Integer, default=0)  # Display order for camera cards (drag-to-reorder)
    
    # Recording
    enable_recording = db.Column(db.Boolean, default=False)
    recording_path = db.Column(db.String(500))

    # Tamper detection — alert when camera is moved or covered
    enable_tamper_detection = db.Column(db.Boolean, default=False)
    tamper_sensitivity = db.Column(db.String(20), default='medium')  # low, medium, high
    
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # Relationships
    events = db.relationship('DetectionEvent', backref='camera', lazy=True, cascade='all, delete-orphan')
    
    def get_custom_classes(self):
        """Parse custom classes from JSON"""
        if self.custom_classes:
            try:
                return json.loads(self.custom_classes)
            except:
                return []
        return []

    def get_animal_classes(self):
        """Return list of animal classes to detect; empty list means detect all animals"""
        if self.animal_classes:
            try:
                return json.loads(self.animal_classes)
            except:
                return []
        return []

    def set_animal_classes(self, classes_list):
        """Set animal classes as JSON; pass empty list to detect all animals"""
        self.animal_classes = json.dumps(classes_list) if classes_list else None
    
    def set_custom_classes(self, classes_list):
        """Set custom classes as JSON"""
        self.custom_classes = json.dumps(classes_list)
    
    def get_stock_items(self):
        """Get stock items from database relationship"""
        from models import StockItem  # Import here to avoid circular import
        stock_items = StockItem.query.filter_by(camera_id=self.id).all()
        return [item.to_dict() for item in stock_items]
    
    def set_stock_items(self, items_list):
        """Set stock items as JSON"""
        self.stock_items = json.dumps(items_list)
    
    def get_exclusion_zones(self):
        """Get exclusion zones as list of polygons"""
        if not self.exclusion_zones:
            return []
        try:
            return json.loads(self.exclusion_zones)
        except:
            return []
    
    def set_exclusion_zones(self, zones_list):
        """Set exclusion zones as JSON"""
        self.exclusion_zones = json.dumps(zones_list)
    
    def get_snapshot_url(self):
        """Get URL for high-quality snapshots (main stream or fallback to rtsp_url)"""
        return self.main_stream_url if self.main_stream_url else self.rtsp_url
    
    def is_snoozed(self):
        """Check if camera alerts are currently snoozed"""
        if not self.snooze_until:
            return False
        return datetime.utcnow() < self.snooze_until
    
    def snooze_alerts(self, minutes=30):
        """Snooze alerts for specified minutes"""
        self.snooze_until = datetime.utcnow() + timedelta(minutes=minutes)
    
    def unsnooze_alerts(self):
        """Cancel snooze"""
        self.snooze_until = None
    
    def get_current_sensitivity(self):
        """Get sensitivity based on time of day (6am-6pm = day, otherwise night)"""
        from datetime import datetime
        hour = datetime.now().hour
        is_daytime = 6 <= hour < 18
        
        if is_daytime:
            return self.day_sensitivity if self.day_sensitivity else 0.80
        else:
            return self.night_sensitivity if self.night_sensitivity else 0.80
    
    def to_dict(self):
        return {
            'id': self.id,
            'name': self.name,
            'rtsp_url': self.rtsp_url,
            'main_stream_url': self.main_stream_url,
            'location': self.location,
            'is_active': self.is_active,
            'is_dvr_channel': self.is_dvr_channel,
            'stream_width': self.stream_width,
            'stream_height': self.stream_height,
            'substream_width': self.substream_width,
            'substream_height': self.substream_height,
            'exclusion_zones': self.get_exclusion_zones(),
            'enable_person_detection': self.enable_person_detection,
            'enable_vehicle_detection': self.enable_vehicle_detection,
            'enable_animal_detection': self.enable_animal_detection,
            'enable_stock_control': self.enable_stock_control,
            'enable_object_detection': self.enable_object_detection,
            'enable_weapon_detection': getattr(self, 'enable_weapon_detection', False),
            'weapon_alert_sound': getattr(self, 'weapon_alert_sound', True),
            'enable_face_blur': getattr(self, 'enable_face_blur', False),
            'enable_anomaly_detection': getattr(self, 'enable_anomaly_detection', True),
            'detect_falling': getattr(self, 'detect_falling', True),
            'require_motion': self.require_motion,
            'min_consecutive_frames': self.min_consecutive_frames,
            'zone_only_detection': self.zone_only_detection,
            'day_sensitivity': self.day_sensitivity,
            'night_sensitivity': self.night_sensitivity,
            'animal_sensitivity': self.animal_sensitivity if self.animal_sensitivity is not None else 0.65,
            'vehicle_sensitivity': self.vehicle_sensitivity if self.vehicle_sensitivity is not None else 0.65,
            'person_sensitivity': self.person_sensitivity if self.person_sensitivity is not None else 0.75,
            'animal_classes': self.get_animal_classes(),
            'night_ir_threshold': self.night_ir_threshold if self.night_ir_threshold is not None else 12.0,
            'detection_cooldown_seconds': self.detection_cooldown_seconds if self.detection_cooldown_seconds is not None else 60,
            'animal_min_size': self.animal_min_size if self.animal_min_size is not None else 1500,
            'snooze_until': self.snooze_until.isoformat() if self.snooze_until else None,
            'is_snoozed': self.is_snoozed(),
            'current_sensitivity': self.get_current_sensitivity(),
            'custom_classes': self.get_custom_classes(),
            'stock_items': self.get_stock_items(),
            'stock_low_threshold': self.stock_low_threshold,
            'stock_critical_threshold': self.stock_critical_threshold,
            'alert_cooldown': self.alert_cooldown,
            'is_armed': self.is_armed,
            'alert_media': getattr(self, 'alert_media', 'both'),
            'enable_recording': self.enable_recording,
            'enable_tamper_detection': getattr(self, 'enable_tamper_detection', False),
            'tamper_sensitivity': getattr(self, 'tamper_sensitivity', 'medium'),
            'created_at': self.created_at.isoformat() if self.created_at else None
        }


class DetectionEvent(db.Model):
    """Detection events from cameras"""
    __tablename__ = 'detection_events'
    
    id = db.Column(db.Integer, primary_key=True)
    camera_id = db.Column(db.Integer, db.ForeignKey('cameras.id'), nullable=False, index=True)
    
    # Detection details
    detected_class = db.Column(db.String(100))  # person, car, dog, etc.
    confidence = db.Column(db.Float)
    item_count = db.Column(db.Integer, default=0)  # Number of items detected (for stock control)
    item_name = db.Column(db.String(100))  # Name of stock item detected
    
    # Image
    image_path = db.Column(db.String(500))
    thumbnail_path = db.Column(db.String(500))
    
    # Video clip (pre+post alert recording with bounding boxes)
    clip_path = db.Column(db.String(500))
    
    # Bounding box (JSON)
    bbox = db.Column(db.Text)  # JSON: {x, y, width, height}
    
    # Notification
    telegram_sent = db.Column(db.Boolean, default=False)
    telegram_sent_at = db.Column(db.DateTime)
    
    # Acknowledgement
    acknowledged = db.Column(db.Boolean, default=False)
    acknowledged_at = db.Column(db.DateTime)
    
    # Metadata
    additional_data = db.Column(db.Text)  # JSON for extra info
    
    created_at = db.Column(db.DateTime, default=datetime.utcnow, index=True)
    
    def get_bbox(self):
        """Parse bbox from JSON"""
        if self.bbox:
            try:
                return json.loads(self.bbox)
            except:
                return None
        return None
    
    def set_bbox(self, bbox_dict):
        """Set bbox as JSON"""
        self.bbox = json.dumps(bbox_dict)
    
    def get_additional_data(self):
        """Parse additional data from JSON"""
        if self.additional_data:
            try:
                return json.loads(self.additional_data)
            except:
                return {}
        return {}
    
    def set_additional_data(self, data_dict):
        """Set additional data as JSON"""
        self.additional_data = json.dumps(data_dict)
    
    def to_dict(self):
        return {
            'id': self.id,
            'camera_id': self.camera_id,
            'camera_name': self.camera.name if self.camera else None,
            'detected_class': self.detected_class,
            'confidence': self.confidence,
            'image_path': self.image_path,
            'thumbnail_path': self.thumbnail_path,
            'clip_path': getattr(self, 'clip_path', None),
            'bbox': self.get_bbox(),
            'telegram_sent': self.telegram_sent,
            'telegram_sent_at': self.telegram_sent_at.isoformat() if self.telegram_sent_at else None,
            'acknowledged': getattr(self, 'acknowledged', False),
            'acknowledged_at': self.acknowledged_at.isoformat() if getattr(self, 'acknowledged_at', None) else None,
            'created_at': self.created_at.isoformat() if self.created_at else None
        }


class StockItem(db.Model):
    """Stock inventory tracking"""
    __tablename__ = 'stock_items'
    
    id = db.Column(db.Integer, primary_key=True)
    camera_id = db.Column(db.Integer, db.ForeignKey('cameras.id'), nullable=False)
    
    name = db.Column(db.String(100), nullable=False)  # Pizza Box, Cup, Napkin, etc.
    yolo_classes = db.Column(db.Text)  # JSON array of YOLO class names to detect
    current_count = db.Column(db.Integer, default=0)
    
    # Thresholds
    min_threshold = db.Column(db.Integer, default=50)  # Low stock warning
    critical_threshold = db.Column(db.Integer, default=20)  # Critical stock alert
    reorder_point = db.Column(db.Integer, default=100)  # Auto-calculated reorder point
    
    # Analytics
    average_daily_usage = db.Column(db.Float, default=0.0)
    days_until_empty = db.Column(db.Integer, default=0)  # Predictive
    last_restocked_at = db.Column(db.DateTime)
    last_low_stock_alert = db.Column(db.DateTime)  # Prevent spam
    
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # Relationships
    camera = db.relationship('Camera', backref='stock_item_list')
    
    def get_yolo_classes(self):
        """Parse YOLO classes from JSON"""
        if self.yolo_classes:
            try:
                return json.loads(self.yolo_classes)
            except:
                return []
        return []
    
    def set_yolo_classes(self, classes_list):
        """Set YOLO classes as JSON"""
        self.yolo_classes = json.dumps(classes_list)
    
    def get_status(self):
        """Get stock status: critical, low, normal, good"""
        if self.current_count <= self.critical_threshold:
            return 'critical'
        elif self.current_count <= self.min_threshold:
            return 'low'
        elif self.current_count <= self.reorder_point:
            return 'normal'
        return 'good'
    
    def to_dict(self):
        return {
            'id': self.id,
            'camera_id': self.camera_id,
            'name': self.name,
            'yolo_classes': self.get_yolo_classes(),
            'current_count': self.current_count,
            'min_threshold': self.min_threshold,
            'critical_threshold': self.critical_threshold,
            'reorder_point': self.reorder_point,
            'average_daily_usage': self.average_daily_usage,
            'days_until_empty': self.days_until_empty,
            'status': self.get_status(),
            'last_restocked_at': self.last_restocked_at.isoformat() if self.last_restocked_at else None,
            'created_at': self.created_at.isoformat() if self.created_at else None
        }


class StockDelivery(db.Model):
    """Track stock deliveries/restocking"""
    __tablename__ = 'stock_deliveries'
    
    id = db.Column(db.Integer, primary_key=True)
    stock_item_id = db.Column(db.Integer, db.ForeignKey('stock_items.id'), nullable=False)
    
    quantity = db.Column(db.Integer, nullable=False)
    supplier = db.Column(db.String(200))
    notes = db.Column(db.Text)
    
    delivered_at = db.Column(db.DateTime, default=datetime.utcnow)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    # Relationships
    stock_item = db.relationship('StockItem', backref='deliveries')
    
    def to_dict(self):
        return {
            'id': self.id,
            'stock_item_id': self.stock_item_id,
            'stock_item_name': self.stock_item.name if self.stock_item else None,
            'quantity': self.quantity,
            'supplier': self.supplier,
            'notes': self.notes,
            'delivered_at': self.delivered_at.isoformat() if self.delivered_at else None,
            'created_at': self.created_at.isoformat() if self.created_at else None
        }


class StockWaste(db.Model):
    """Track damaged/wasted inventory"""
    __tablename__ = 'stock_waste'
    
    id = db.Column(db.Integer, primary_key=True)
    stock_item_id = db.Column(db.Integer, db.ForeignKey('stock_items.id'), nullable=False)
    
    quantity = db.Column(db.Integer, nullable=False)
    reason = db.Column(db.String(200))  # Damaged, Expired, Lost, etc.
    notes = db.Column(db.Text)
    
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    # Relationships
    stock_item = db.relationship('StockItem', backref='waste_logs')
    
    def to_dict(self):
        return {
            'id': self.id,
            'stock_item_id': self.stock_item_id,
            'stock_item_name': self.stock_item.name if self.stock_item else None,
            'quantity': self.quantity,
            'reason': self.reason,
            'notes': self.notes,
            'created_at': self.created_at.isoformat() if self.created_at else None
        }


class StockUsageHistory(db.Model):
    """Daily stock usage tracking for analytics"""
    __tablename__ = 'stock_usage_history'
    
    id = db.Column(db.Integer, primary_key=True)
    stock_item_id = db.Column(db.Integer, db.ForeignKey('stock_items.id'), nullable=False)
    
    date = db.Column(db.Date, nullable=False, index=True)
    items_used = db.Column(db.Integer, default=0)
    items_added = db.Column(db.Integer, default=0)  # From deliveries
    items_wasted = db.Column(db.Integer, default=0)
    
    # Time-based analytics
    peak_hour = db.Column(db.Integer)  # 0-23, busiest hour
    peak_hour_count = db.Column(db.Integer)  # Items used during peak hour
    
    starting_count = db.Column(db.Integer)
    ending_count = db.Column(db.Integer)
    
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    # Relationships
    stock_item = db.relationship('StockItem', backref='usage_history')
    
    def to_dict(self):
        return {
            'id': self.id,
            'stock_item_id': self.stock_item_id,
            'stock_item_name': self.stock_item.name if self.stock_item else None,
            'date': self.date.isoformat() if self.date else None,
            'items_used': self.items_used,
            'items_added': self.items_added,
            'items_wasted': self.items_wasted,
            'peak_hour': self.peak_hour,
            'peak_hour_count': self.peak_hour_count,
            'starting_count': self.starting_count,
            'ending_count': self.ending_count,
            'created_at': self.created_at.isoformat() if self.created_at else None
        }


class SystemStats(db.Model):
    """System statistics and health monitoring"""
    __tablename__ = 'system_stats'
    
    id = db.Column(db.Integer, primary_key=True)
    
    # System health
    cpu_usage = db.Column(db.Float)
    memory_usage = db.Column(db.Float)
    disk_usage = db.Column(db.Float)
    temperature = db.Column(db.Float)  # Raspberry Pi temperature
    
    # Detection stats
    total_detections_today = db.Column(db.Integer, default=0)
    active_cameras = db.Column(db.Integer, default=0)
    
    # Uptime
    uptime_seconds = db.Column(db.Integer)
    
    created_at = db.Column(db.DateTime, default=datetime.utcnow, index=True)
    
    def to_dict(self):
        return {
            'id': self.id,
            'cpu_usage': self.cpu_usage,
            'memory_usage': self.memory_usage,
            'disk_usage': self.disk_usage,
            'temperature': self.temperature,
            'total_detections_today': self.total_detections_today,
            'active_cameras': self.active_cameras,
            'uptime_seconds': self.uptime_seconds,
            'created_at': self.created_at.isoformat() if self.created_at else None
        }


class DetectionZone(db.Model):
    """Detection zones for cameras - polygon areas for alerts"""
    __tablename__ = 'detection_zones'
    
    id = db.Column(db.Integer, primary_key=True)
    camera_id = db.Column(db.Integer, db.ForeignKey('cameras.id'), nullable=False)
    
    name = db.Column(db.String(100), nullable=False)  # e.g., "Restricted Area", "Exit Zone"
    zone_type = db.Column(db.String(50), default='alert')  # alert, counting, exclusion, loitering, crowd, tripwire
    polygon_points = db.Column(db.Text)  # JSON: [[x1,y1], [x2,y2], ...]
    
    # Line crossing / Tripwire settings
    line_points = db.Column(db.Text)  # JSON: [[x1,y1], [x2,y2]] for virtual tripwire
    line_direction = db.Column(db.String(20), default='both')  # 'left_to_right', 'right_to_left', 'up', 'down', 'both'
    
    # Zone settings
    is_active = db.Column(db.Boolean, default=True)
    alert_on_entry = db.Column(db.Boolean, default=True)
    alert_on_exit = db.Column(db.Boolean, default=True)  # Both enabled by default
    loiter_threshold_seconds = db.Column(db.Integer, default=300)  # 5 minutes
    
    # Crowd counting settings
    max_capacity = db.Column(db.Integer, default=0)  # 0 = disabled, >0 = max people allowed
    crowd_alert_threshold = db.Column(db.Integer, default=80)  # Alert when at X% capacity
    current_occupancy = db.Column(db.Integer, default=0)  # Current count in zone
    
    # Zone scheduling settings
    schedule_enabled = db.Column(db.Boolean, default=False)  # Enable time-based activation
    active_start_time = db.Column(db.String(10), default='00:00')  # HH:MM format
    active_end_time = db.Column(db.String(10), default='23:59')  # HH:MM format
    active_days = db.Column(db.String(20), default='0,1,2,3,4,5,6')  # Days of week (0=Monday)
    
    # Preset settings
    preset_type = db.Column(db.String(50))  # 'entrance', 'exit', 'restricted', 'parking', 'counter', 'custom'
    
    # Path tracking
    enable_path_tracking = db.Column(db.Boolean, default=False)  # Enable movement trail visualization
    path_history_seconds = db.Column(db.Integer, default=30)  # How long to keep path history
    
    # Detection filters
    detect_person = db.Column(db.Boolean, default=True)
    detect_vehicle = db.Column(db.Boolean, default=False)
    detect_animal = db.Column(db.Boolean, default=False)

    # Per-zone confidence threshold (override global setting per zone)
    # e.g. set higher for open areas, lower for doorways
    min_confidence = db.Column(db.Float, default=0.35)  # Min YOLO confidence to trigger zone

    # Per-zone alert cooldown in minutes (overrides global 5-minute default)
    alert_cooldown_minutes = db.Column(db.Integer, default=5)  # Minutes between repeat zone alerts
    
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # Relationships
    camera = db.relationship('Camera', backref='detection_zones')
    
    def get_polygon_points(self):
        """Parse polygon points from JSON with error handling"""
        if self.polygon_points:
            try:
                points = json.loads(self.polygon_points)
                # Validate that it's a list of coordinate pairs
                if isinstance(points, list) and all(
                    isinstance(point, (list, tuple)) and len(point) >= 2 
                    for point in points
                ):
                    return points
                else:
                    print(f"Warning: Invalid polygon points format for zone {self.id}")
                    return []
            except (json.JSONDecodeError, TypeError) as e:
                print(f"Error parsing polygon points for zone {self.id}: {e}")
                return []
        return []
    
    def set_polygon_points(self, points):
        """Set polygon points as JSON with validation"""
        try:
            # Validate input
            if not isinstance(points, list):
                raise ValueError("Points must be a list")
            
            # Validate each point
            validated_points = []
            for i, point in enumerate(points):
                if not isinstance(point, (list, tuple)) or len(point) < 2:
                    raise ValueError(f"Point {i} must be a list/tuple with at least 2 coordinates")
                
                # Convert to numbers and validate
                try:
                    x, y = float(point[0]), float(point[1])
                    validated_points.append([x, y])
                except (ValueError, TypeError):
                    raise ValueError(f"Point {i} contains invalid coordinates: {point}")
            
            if len(validated_points) < 3:
                raise ValueError("A polygon must have at least 3 points")
            
            self.polygon_points = json.dumps(validated_points)
        except Exception as e:
            print(f"Error setting polygon points for zone {getattr(self, 'id', 'new')}: {e}")
            raise
    
    def to_dict(self):
        try:
            return {
                'id': self.id,
                'camera_id': self.camera_id,
                'name': self.name,
                'zone_type': self.zone_type,
                'polygon_points': self.get_polygon_points(),
                'is_active': self.is_active,
                'alert_on_entry': self.alert_on_entry,
                'alert_on_exit': self.alert_on_exit,
                'loiter_threshold_seconds': self.loiter_threshold_seconds,
                'detect_person': self.detect_person,
                'detect_vehicle': self.detect_vehicle,
                'detect_animal': self.detect_animal,
                'created_at': self.created_at.isoformat() if self.created_at else None,
                # Line crossing / tripwire
                'line_points': json.loads(self.line_points) if self.line_points else None,
                'line_direction': getattr(self, 'line_direction', 'both'),
                # Crowd settings
                'max_capacity': getattr(self, 'max_capacity', 0),
                'crowd_alert_threshold': getattr(self, 'crowd_alert_threshold', 80),
                'current_occupancy': getattr(self, 'current_occupancy', 0),
                # Scheduling
                'schedule_enabled': getattr(self, 'schedule_enabled', False),
                'active_start_time': getattr(self, 'active_start_time', '00:00'),
                'active_end_time': getattr(self, 'active_end_time', '23:59'),
                'active_days': getattr(self, 'active_days', '0,1,2,3,4,5,6'),
                # Presets & path tracking
                'preset_type': getattr(self, 'preset_type', None),
                'enable_path_tracking': getattr(self, 'enable_path_tracking', False),
                'path_history_seconds': getattr(self, 'path_history_seconds', 30),
                # Alert cooldown & confidence
                'alert_cooldown_minutes': getattr(self, 'alert_cooldown_minutes', 5),
                'min_confidence': getattr(self, 'min_confidence', 0.35),
                # Legacy compatibility
                'entry_direction': 'any',
                'exit_direction': 'any',
                'is_rectangular': True,
                'dimensions': self.get_zone_dimensions() if len(self.get_polygon_points()) == 4 else None
            }
        except Exception as e:
            # Fallback for any attribute errors
            return {
                'id': getattr(self, 'id', None),
                'camera_id': getattr(self, 'camera_id', None),
                'name': getattr(self, 'name', ''),
                'zone_type': getattr(self, 'zone_type', 'alert'),
                'polygon_points': [],
                'is_active': getattr(self, 'is_active', True),
                'alert_on_entry': getattr(self, 'alert_on_entry', True),
                'alert_on_exit': getattr(self, 'alert_on_exit', False),
                'loiter_threshold_seconds': getattr(self, 'loiter_threshold_seconds', 300),
                'detect_person': getattr(self, 'detect_person', True),
                'detect_vehicle': getattr(self, 'detect_vehicle', False),
                'detect_animal': getattr(self, 'detect_animal', False),
                'created_at': None,
                'entry_direction': 'any',
                'exit_direction': 'any',
                'is_rectangular': True,
                'dimensions': None
            }
    
    def is_currently_active(self):
        """Check if zone is active based on schedule and is_active flag"""
        if not self.is_active:
            return False
        
        if not getattr(self, 'schedule_enabled', False):
            return True  # No schedule, always active when is_active=True
        
        from datetime import datetime
        now = datetime.now()
        
        # Check day of week (0=Monday in Python)
        active_days = getattr(self, 'active_days', '0,1,2,3,4,5,6')
        try:
            day_list = [int(d) for d in active_days.split(',')]
        except:
            day_list = [0, 1, 2, 3, 4, 5, 6]
        
        if now.weekday() not in day_list:
            return False
        
        # Check time range
        start_time = getattr(self, 'active_start_time', '00:00')
        end_time = getattr(self, 'active_end_time', '23:59')
        
        try:
            start_h, start_m = map(int, start_time.split(':'))
            end_h, end_m = map(int, end_time.split(':'))
            
            current_minutes = now.hour * 60 + now.minute
            start_minutes = start_h * 60 + start_m
            end_minutes = end_h * 60 + end_m
            
            # Handle overnight schedules (e.g., 22:00 - 06:00)
            if end_minutes < start_minutes:
                return current_minutes >= start_minutes or current_minutes <= end_minutes
            else:
                return start_minutes <= current_minutes <= end_minutes
        except:
            return True  # On error, assume active
    
    def get_line_points(self):
        """Get tripwire line points"""
        if self.line_points:
            try:
                return json.loads(self.line_points)
            except:
                return None
        return None
    
    def set_line_points(self, points):
        """Set tripwire line points - expects [[x1,y1], [x2,y2]]"""
        if points and len(points) == 2:
            self.line_points = json.dumps(points)
        else:
            self.line_points = None


class ZoneTransition(db.Model):
    """Track individual entry/exit transitions through zones for accurate analytics"""
    __tablename__ = 'zone_transitions'
    
    id = db.Column(db.Integer, primary_key=True)
    camera_id = db.Column(db.Integer, db.ForeignKey('cameras.id'), nullable=False, index=True)
    zone_id = db.Column(db.Integer, db.ForeignKey('detection_zones.id'), nullable=False, index=True)
    
    # Transition details
    track_id = db.Column(db.String(50))  # Person tracking ID
    transition_type = db.Column(db.String(20), nullable=False)  # 'entry' or 'exit'
    direction = db.Column(db.String(30))  # Movement direction: up, down, left, right, etc.
    
    # Position data for heatmap
    position_x = db.Column(db.Float)  # X coordinate where transition occurred
    position_y = db.Column(db.Float)  # Y coordinate where transition occurred
    
    # Timing
    timestamp = db.Column(db.DateTime, default=datetime.utcnow, index=True)
    
    # Dwell time (only for exits - how long person was in zone)
    dwell_time_seconds = db.Column(db.Integer, default=0)
    
    # Detection confidence
    confidence = db.Column(db.Float, default=1.0)
    
    # Relationships
    camera = db.relationship('Camera', backref='zone_transitions')
    zone = db.relationship('DetectionZone', backref='zone_transitions')
    
    def to_dict(self):
        return {
            'id': self.id,
            'camera_id': self.camera_id,
            'zone_id': self.zone_id,
            'zone_name': self.zone.name if self.zone else None,
            'track_id': self.track_id,
            'transition_type': self.transition_type,
            'direction': self.direction,
            'position': {'x': self.position_x, 'y': self.position_y},
            'dwell_time_seconds': self.dwell_time_seconds,
            'confidence': self.confidence,
            'timestamp': self.timestamp.isoformat() if self.timestamp else None
        }


class ZoneHeatmapData(db.Model):
    """Aggregated heatmap data for zones - tracks where people spend time"""
    __tablename__ = 'zone_heatmap_data'
    __table_args__ = (db.Index('ix_heatmap_camera_date_hour', 'camera_id', 'date', 'hour_of_day'),)
    
    id = db.Column(db.Integer, primary_key=True)
    camera_id = db.Column(db.Integer, db.ForeignKey('cameras.id'), nullable=False)
    zone_id = db.Column(db.Integer, db.ForeignKey('detection_zones.id'))
    
    # Grid cell position (zone is divided into grid for heatmap)
    grid_x = db.Column(db.Integer, nullable=False)  # Grid cell X index
    grid_y = db.Column(db.Integer, nullable=False)  # Grid cell Y index
    
    # Activity count (how many times this cell was occupied)
    activity_count = db.Column(db.Integer, default=0)
    
    # Time aggregation
    hour_of_day = db.Column(db.Integer)  # 0-23 for hourly patterns
    day_of_week = db.Column(db.Integer)  # 0-6 for weekly patterns
    date = db.Column(db.Date, index=True)
    
    # Relationships
    camera = db.relationship('Camera', backref='heatmap_data')
    zone = db.relationship('DetectionZone', backref='heatmap_data')
    
    def to_dict(self):
        return {
            'id': self.id,
            'camera_id': self.camera_id,
            'zone_id': self.zone_id,
            'grid_x': self.grid_x,
            'grid_y': self.grid_y,
            'activity_count': self.activity_count,
            'hour_of_day': self.hour_of_day,
            'day_of_week': self.day_of_week,
            'date': self.date.isoformat() if self.date else None
        }


class ZoneDailyStats(db.Model):
    """Daily aggregated statistics per zone for efficient analytics queries"""
    __tablename__ = 'zone_daily_stats'
    __table_args__ = (db.UniqueConstraint('zone_id', 'date', name='uq_zone_daily_stats_zone_date'),)
    
    id = db.Column(db.Integer, primary_key=True)
    camera_id = db.Column(db.Integer, db.ForeignKey('cameras.id'), nullable=False)
    zone_id = db.Column(db.Integer, db.ForeignKey('detection_zones.id'), nullable=False)
    date = db.Column(db.Date, nullable=False, index=True)
    
    # Entry/Exit totals
    total_entries = db.Column(db.Integer, default=0)
    total_exits = db.Column(db.Integer, default=0)
    unique_visitors = db.Column(db.Integer, default=0)  # Unique track IDs
    
    # Peak occupancy
    peak_occupancy = db.Column(db.Integer, default=0)
    peak_occupancy_time = db.Column(db.DateTime)
    
    # Dwell time statistics
    avg_dwell_time_seconds = db.Column(db.Float, default=0)
    max_dwell_time_seconds = db.Column(db.Integer, default=0)
    min_dwell_time_seconds = db.Column(db.Integer, default=0)
    
    # Hourly breakdown (JSON: {"0": count, "1": count, ...})
    hourly_entries = db.Column(db.Text)  # JSON
    hourly_exits = db.Column(db.Text)  # JSON
    
    # Direction analysis (JSON: {"up": count, "down": count, ...})
    entry_directions = db.Column(db.Text)  # JSON
    exit_directions = db.Column(db.Text)  # JSON
    
    # Loitering events count
    loitering_count = db.Column(db.Integer, default=0)
    
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # Relationships
    camera = db.relationship('Camera', backref='zone_daily_stats')
    zone = db.relationship('DetectionZone', backref='daily_stats')
    
    def get_hourly_entries(self):
        if self.hourly_entries:
            try:
                return json.loads(self.hourly_entries)
            except:
                return {}
        return {}
    
    def get_hourly_exits(self):
        if self.hourly_exits:
            try:
                return json.loads(self.hourly_exits)
            except:
                return {}
        return {}
    
    def get_entry_directions(self):
        if self.entry_directions:
            try:
                return json.loads(self.entry_directions)
            except:
                return {}
        return {}
    
    def get_exit_directions(self):
        if self.exit_directions:
            try:
                return json.loads(self.exit_directions)
            except:
                return {}
        return {}
    
    def to_dict(self):
        return {
            'id': self.id,
            'camera_id': self.camera_id,
            'zone_id': self.zone_id,
            'zone_name': self.zone.name if self.zone else None,
            'date': self.date.isoformat() if self.date else None,
            'total_entries': self.total_entries,
            'total_exits': self.total_exits,
            'unique_visitors': self.unique_visitors,
            'peak_occupancy': self.peak_occupancy,
            'peak_occupancy_time': self.peak_occupancy_time.strftime('%H:%M') if self.peak_occupancy_time else None,
            'avg_dwell_time_seconds': round(self.avg_dwell_time_seconds, 1),
            'max_dwell_time_seconds': self.max_dwell_time_seconds,
            'hourly_entries': self.get_hourly_entries(),
            'hourly_exits': self.get_hourly_exits(),
            'entry_directions': self.get_entry_directions(),
            'exit_directions': self.get_exit_directions(),
            'loitering_count': self.loitering_count
        }


class OccupancyLog(db.Model):
    """Track people/vehicle count over time"""
    __tablename__ = 'occupancy_logs'
    
    id = db.Column(db.Integer, primary_key=True)
    camera_id = db.Column(db.Integer, db.ForeignKey('cameras.id'))
    zone_id = db.Column(db.Integer, db.ForeignKey('detection_zones.id'))  # Optional zone-specific count
    
    count_type = db.Column(db.String(20), default='people')  # people, vehicles
    count = db.Column(db.Integer, default=0)
    
    # Entry/exit tracking
    entries = db.Column(db.Integer, default=0)  # People who entered
    exits = db.Column(db.Integer, default=0)  # People who left
    
    timestamp = db.Column(db.DateTime, default=datetime.utcnow, index=True)
    
    # Relationships
    camera = db.relationship('Camera', backref='occupancy_logs')
    zone = db.relationship('DetectionZone', backref='occupancy_logs')
    
    def to_dict(self):
        return {
            'id': self.id,
            'camera_id': self.camera_id,
            'zone_id': self.zone_id,
            'count_type': self.count_type,
            'count': self.count,
            'entries': self.entries,
            'exits': self.exits,
            'timestamp': self.timestamp.isoformat() if self.timestamp else None
        }


class LoiteringEvent(db.Model):
    """Track loitering events (person in area too long)"""
    __tablename__ = 'loitering_events'
    
    id = db.Column(db.Integer, primary_key=True)
    camera_id = db.Column(db.Integer, db.ForeignKey('cameras.id'), nullable=False)
    zone_id = db.Column(db.Integer, db.ForeignKey('detection_zones.id'))
    
    track_id = db.Column(db.Integer)  # YOLO tracking ID
    detected_class = db.Column(db.String(50))  # person, vehicle, etc.
    
    # Timing
    first_seen = db.Column(db.DateTime, default=datetime.utcnow)
    last_seen = db.Column(db.DateTime, default=datetime.utcnow)
    duration_seconds = db.Column(db.Integer)
    
    # Alert status
    alert_sent = db.Column(db.Boolean, default=False)
    telegram_sent = db.Column(db.Boolean, default=False)
    
    # Image
    image_path = db.Column(db.String(500))
    
    # Relationships
    camera = db.relationship('Camera', backref='loitering_events')
    zone = db.relationship('DetectionZone', backref='loitering_events')
    
    def to_dict(self):
        return {
            'id': self.id,
            'camera_id': self.camera_id,
            'zone_id': self.zone_id,
            'track_id': self.track_id,
            'detected_class': self.detected_class,
            'first_seen': self.first_seen.isoformat() if self.first_seen else None,
            'last_seen': self.last_seen.isoformat() if self.last_seen else None,
            'duration_seconds': self.duration_seconds,
            'alert_sent': self.alert_sent,
            'telegram_sent': self.telegram_sent,
            'image_path': self.image_path
        }


class User(db.Model):
    """User accounts with role-based access control"""
    __tablename__ = 'users'
    
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(50), unique=True, nullable=False)
    password_hash = db.Column(db.String(256), nullable=False)
    email = db.Column(db.String(120))
    
    # Role-based access: admin, operator, viewer
    role = db.Column(db.String(20), default='viewer')
    
    # Permissions (granular control)
    can_view_live = db.Column(db.Boolean, default=True)
    can_view_events = db.Column(db.Boolean, default=True)
    can_arm_disarm = db.Column(db.Boolean, default=False)
    can_manage_cameras = db.Column(db.Boolean, default=False)
    can_manage_zones = db.Column(db.Boolean, default=False)
    can_manage_users = db.Column(db.Boolean, default=False)
    can_view_settings = db.Column(db.Boolean, default=False)
    can_use_ptz = db.Column(db.Boolean, default=False)
    
    # Account status
    is_active = db.Column(db.Boolean, default=True)
    last_login = db.Column(db.DateTime)
    login_count = db.Column(db.Integer, default=0)
    
    # Telegram link
    telegram_chat_id = db.Column(db.String(50))
    
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    def set_password(self, password):
        """Hash and set password using PBKDF2+salt"""
        from werkzeug.security import generate_password_hash
        self.password_hash = generate_password_hash(password)
    
    def verify_password(self, password):
        """Verify password — supports both new PBKDF2 and legacy SHA-256 hashes"""
        if not self.password_hash:
            return False
        from werkzeug.security import check_password_hash
        # Legacy: plain SHA-256 hex (64 chars, no method prefix)
        if len(self.password_hash) == 64 and ':' not in self.password_hash:
            import hashlib
            match = self.password_hash == hashlib.sha256(password.encode()).hexdigest()
            if match:
                # Upgrade hash to PBKDF2 on successful login
                self.set_password(password)
            return match
        return check_password_hash(self.password_hash, password)
    
    def set_role(self, role):
        """Set role and apply default permissions"""
        self.role = role
        if role == 'admin':
            self.can_view_live = True
            self.can_view_events = True
            self.can_arm_disarm = True
            self.can_manage_cameras = True
            self.can_manage_zones = True
            self.can_manage_users = True
            self.can_view_settings = True
            self.can_use_ptz = True
        elif role == 'operator':
            self.can_view_live = True
            self.can_view_events = True
            self.can_arm_disarm = True
            self.can_manage_cameras = False
            self.can_manage_zones = True
            self.can_manage_users = False
            self.can_view_settings = False
            self.can_use_ptz = True
        else:  # viewer
            self.can_view_live = True
            self.can_view_events = True
            self.can_arm_disarm = False
            self.can_manage_cameras = False
            self.can_manage_zones = False
            self.can_manage_users = False
            self.can_view_settings = False
            self.can_use_ptz = False
    
    def to_dict(self):
        return {
            'id': self.id,
            'username': self.username,
            'email': self.email,
            'role': self.role,
            'can_view_live': self.can_view_live,
            'can_view_events': self.can_view_events,
            'can_arm_disarm': self.can_arm_disarm,
            'can_manage_cameras': self.can_manage_cameras,
            'can_manage_zones': self.can_manage_zones,
            'can_manage_users': self.can_manage_users,
            'can_view_settings': self.can_view_settings,
            'can_use_ptz': self.can_use_ptz,
            'is_active': self.is_active,
            'last_login': self.last_login.isoformat() if self.last_login else None,
            'telegram_chat_id': self.telegram_chat_id,
            'created_at': self.created_at.isoformat() if self.created_at else None
        }


class CameraHealth(db.Model):
    """Track camera health and online status"""
    __tablename__ = 'camera_health'
    
    id = db.Column(db.Integer, primary_key=True)
    camera_id = db.Column(db.Integer, db.ForeignKey('cameras.id'), nullable=False)
    
    is_online = db.Column(db.Boolean, default=True)
    last_frame_time = db.Column(db.DateTime)
    last_check_time = db.Column(db.DateTime, default=datetime.utcnow)
    
    # Statistics
    uptime_percent = db.Column(db.Float, default=100.0)
    total_checks = db.Column(db.Integer, default=0)
    failed_checks = db.Column(db.Integer, default=0)
    consecutive_failures = db.Column(db.Integer, default=0)
    
    # Alert tracking
    offline_alert_sent = db.Column(db.Boolean, default=False)
    offline_since = db.Column(db.DateTime)
    
    # Performance metrics
    avg_fps = db.Column(db.Float, default=0.0)
    avg_latency_ms = db.Column(db.Float, default=0.0)
    
    # Relationships
    camera = db.relationship('Camera', backref='health_record')
    
    def to_dict(self):
        return {
            'id': self.id,
            'camera_id': self.camera_id,
            'is_online': self.is_online,
            'last_frame_time': self.last_frame_time.isoformat() if self.last_frame_time else None,
            'last_check_time': self.last_check_time.isoformat() if self.last_check_time else None,
            'uptime_percent': round(self.uptime_percent, 1),
            'consecutive_failures': self.consecutive_failures,
            'offline_since': self.offline_since.isoformat() if self.offline_since else None,
            'avg_fps': round(self.avg_fps, 1),
            'avg_latency_ms': round(self.avg_latency_ms, 1)
        }


class BehaviorEvent(db.Model):
    """Track behavior analysis events (running, fighting, loitering, crowd)"""
    __tablename__ = 'behavior_events'
    
    id = db.Column(db.Integer, primary_key=True)
    camera_id = db.Column(db.Integer, db.ForeignKey('cameras.id'), nullable=False)
    zone_id = db.Column(db.Integer, db.ForeignKey('detection_zones.id'))
    
    # Behavior type: running, fighting, loitering, crowd, fall
    behavior_type = db.Column(db.String(50), nullable=False)
    severity = db.Column(db.String(20), default='medium')  # low, medium, high, critical
    
    # Details
    description = db.Column(db.Text)
    person_count = db.Column(db.Integer, default=1)
    confidence = db.Column(db.Float, default=0.5)
    
    # For crowd counting
    max_capacity = db.Column(db.Integer)
    current_count = db.Column(db.Integer)
    is_over_capacity = db.Column(db.Boolean, default=False)
    
    # Duration for ongoing behaviors
    started_at = db.Column(db.DateTime, default=datetime.utcnow)
    ended_at = db.Column(db.DateTime)
    duration_seconds = db.Column(db.Integer)
    
    # Alert status
    alert_sent = db.Column(db.Boolean, default=False)
    image_path = db.Column(db.String(500))
    
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    # Relationships
    camera = db.relationship('Camera', backref='behavior_events')
    zone = db.relationship('DetectionZone', backref='behavior_events')
    
    def to_dict(self):
        return {
            'id': self.id,
            'camera_id': self.camera_id,
            'zone_id': self.zone_id,
            'behavior_type': self.behavior_type,
            'severity': self.severity,
            'description': self.description,
            'person_count': self.person_count,
            'confidence': self.confidence,
            'max_capacity': self.max_capacity,
            'current_count': self.current_count,
            'is_over_capacity': self.is_over_capacity,
            'started_at': self.started_at.isoformat() if self.started_at else None,
            'ended_at': self.ended_at.isoformat() if self.ended_at else None,
            'duration_seconds': self.duration_seconds,
            'alert_sent': self.alert_sent,
            'image_path': self.image_path,
            'created_at': self.created_at.isoformat() if self.created_at else None
        }


class AuditLog(db.Model):
    """Track user actions for security audit"""
    __tablename__ = 'audit_logs'
    
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'))
    username = db.Column(db.String(50))  # Store username for when user is deleted
    
    action = db.Column(db.String(100), nullable=False)  # login, arm, disarm, add_camera, etc.
    target_type = db.Column(db.String(50))  # camera, zone, user, system
    target_id = db.Column(db.Integer)
    details = db.Column(db.Text)  # JSON with additional details
    
    ip_address = db.Column(db.String(45))
    user_agent = db.Column(db.String(500))
    
    created_at = db.Column(db.DateTime, default=datetime.utcnow, index=True)
    
    def to_dict(self):
        return {
            'id': self.id,
            'user_id': self.user_id,
            'username': self.username,
            'action': self.action,
            'target_type': self.target_type,
            'target_id': self.target_id,
            'details': json.loads(self.details) if self.details else None,
            'ip_address': self.ip_address,
            'created_at': self.created_at.isoformat() if self.created_at else None
        }


class LicenseKey(db.Model):
    """Stores activated license keys for premium features."""
    __tablename__ = 'license_keys'

    id = db.Column(db.Integer, primary_key=True)
    key = db.Column(db.String(32), unique=True, nullable=False)   # SVP-Z1-XXXXXXXX-XXXX
    feature_id = db.Column(db.String(50), nullable=False)         # zone_detection / 'all'
    covers_all = db.Column(db.Boolean, default=False)             # True = all-features bundle
    duration_months = db.Column(db.Integer, default=1)            # 1, 3, or 12
    duration_label = db.Column(db.String(20), default='1 Month')  # human label
    activated_at = db.Column(db.DateTime, default=datetime.utcnow)
    expires_at = db.Column(db.DateTime, nullable=True)            # NULL = never expires (legacy)
    is_active = db.Column(db.Boolean, default=True)

    def to_dict(self):
        return {
            'id': self.id,
            'key': self.key,
            'feature_id': self.feature_id,
            'covers_all': self.covers_all,
            'duration_months': self.duration_months,
            'duration_label': self.duration_label,
            'activated_at': self.activated_at.isoformat() if self.activated_at else None,
            'expires_at': self.expires_at.isoformat() if self.expires_at else None,
            'is_active': self.is_active,
        }
