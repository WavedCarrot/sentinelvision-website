"""
Telegram notification service for SentinelVision Security Platform
Sends detection alerts with images to Telegram using shared SentinelVision bot
"""
import os
import requests
import logging
from datetime import datetime
from pathlib import Path

logger = logging.getLogger(__name__)

# Shared SentinelVision Bot Token (users only need to add their Chat ID)
SENTINELVISION_BOT_TOKEN = os.environ.get('TELEGRAM_BOT_TOKEN', '8092135145:AAH1uKh9MQV8THbSiO8UuKgAl7hTkd-9DHc')
SENTINELVISION_BOT_LINK = "https://t.me/SentinelVisionBot"


class TelegramService:
    def __init__(self, chat_id=None):
        self.bot_token = SENTINELVISION_BOT_TOKEN
        self.chat_id = chat_id
        self.api_url = f"https://api.telegram.org/bot{self.bot_token}"
    
    def set_credentials(self, chat_id):
        """Update Telegram chat ID (bot token is fixed)"""
        self.chat_id = chat_id
    
    def test_connection(self):
        """Test if the chat ID is valid"""
        if not self.chat_id:
            return False, "Chat ID not configured"
        
        try:
            # Test by getting bot info
            response = requests.get(f"{self.api_url}/getMe", timeout=10)
            if response.status_code == 200:
                bot_info = response.json()
                if bot_info.get('ok'):
                    # Register bot commands in menu
                    self.register_bot_commands()
                    return True, f"Connected to SentinelVision Bot"
                else:
                    return False, "Bot connection failed"
            else:
                return False, f"HTTP error: {response.status_code}"
        except Exception as e:
            logger.error(f"Telegram connection test failed: {e}")
            return False, str(e)
    
    def register_bot_commands(self):
        """Register bot commands in Telegram menu"""
        try:
            commands = [
                {"command": "start", "description": "Show help message"},
                {"command": "help", "description": "Show command help"},
                {"command": "status", "description": "System status and health"},
                {"command": "cameras", "description": "List all cameras"},
                {"command": "stats", "description": "Detection statistics"},
                {"command": "arm", "description": "Arm all cameras"},
                {"command": "disarm", "description": "Disarm all cameras"},
                {"command": "schedule", "description": "Show current schedule"},
                {"command": "setarm", "description": "Set auto-arm time (HH:MM)"},
                {"command": "setdisarm", "description": "Set auto-disarm time (HH:MM)"},
                {"command": "setdays", "description": "Set schedule days (1,2,3,4,5)"},
                {"command": "enableschedule", "description": "Enable/disable auto-schedule"},
                {"command": "testschedule", "description": "Test schedule (arm/disarm)"}
            ]
            
            url = f"{self.api_url}/setMyCommands"
            payload = {"commands": commands}
            
            response = requests.post(url, json=payload, timeout=10)
            if response.status_code == 200:
                result = response.json()
                if result.get('ok'):
                    logger.info("Bot commands registered successfully in Telegram menu")
                    return True
                else:
                    logger.warning(f"Failed to register commands: {result}")
            else:
                logger.warning(f"Failed to register commands: HTTP {response.status_code}")
            return False
        except Exception as e:
            logger.error(f"Error registering bot commands: {e}")
            return False
    
    def send_message(self, text, parse_mode='HTML'):
        """Send a text message to all configured Telegram chat IDs"""
        if not self.chat_id:
            logger.warning("Telegram chat ID not configured")
            return False
        
        # Support multiple chat IDs (comma-separated)
        chat_ids = [cid.strip() for cid in str(self.chat_id).split(',') if cid.strip()]
        
        if not chat_ids:
            logger.warning("No valid chat IDs found")
            return False
        
        success_count = 0
        try:
            url = f"{self.api_url}/sendMessage"
            for chat_id in chat_ids:
                payload = {
                    'chat_id': chat_id,
                    'text': text,
                    'parse_mode': parse_mode
                }
                response = requests.post(url, json=payload, timeout=10)
                if response.status_code == 200:
                    success_count += 1
                else:
                    logger.warning(f"Failed to send message to {chat_id}: {response.status_code}")
            
            return success_count > 0
        except Exception as e:
            logger.error(f"Failed to send Telegram message: {e}")
            return False
    
    def send_photo(self, photo_path, caption='', parse_mode='HTML'):
        """Send a photo with caption to all configured Telegram chat IDs"""
        if not self.bot_token or not self.chat_id:
            logger.warning("Telegram credentials not configured")
            return False
        
        # Support multiple chat IDs (comma-separated)
        chat_ids = [cid.strip() for cid in str(self.chat_id).split(',') if cid.strip()]
        
        if not chat_ids:
            logger.warning("No valid chat IDs found")
            return False
        
        try:
            url = f"{self.api_url}/sendPhoto"
            
            # Convert relative path to absolute if needed
            photo_file = Path(photo_path)
            if not photo_file.is_absolute():
                # Assume it's relative to uploads folder
                uploads_dir = Path(__file__).parent / 'uploads'
                photo_file = uploads_dir / photo_path
            
            # Check if file exists
            if not photo_file.exists():
                logger.error(f"Photo file not found: {photo_file}")
                # Try without conversion
                photo_file = Path(photo_path)
                if not photo_file.exists():
                    logger.error(f"Photo file not found (tried both paths): {photo_path}")
                    return False
            
            success_count = 0
            with open(photo_file, 'rb') as photo:
                for chat_id in chat_ids:
                    photo.seek(0)  # Reset file pointer for each send
                    files = {'photo': photo}
                    data = {
                        'chat_id': chat_id,
                        'caption': caption,
                        'parse_mode': parse_mode
                    }
                    response = requests.post(url, files=files, data=data, timeout=30)
                    if response.status_code == 200:
                        success_count += 1
                        logger.info(f"Photo sent successfully to chat {chat_id}")
                    else:
                        logger.warning(f"Failed to send photo to {chat_id}: {response.status_code} - {response.text}")
                
            return success_count > 0
        except Exception as e:
            logger.error(f"Failed to send Telegram photo: {e}")
            return False

    def send_photo_with_keyboard(self, photo_path, caption='', parse_mode='HTML', inline_keyboard=None):
        """Send a photo with caption AND an inline keyboard (e.g. False Alert button)"""
        if not self.bot_token or not self.chat_id:
            return self.send_photo(photo_path, caption, parse_mode)

        chat_ids = [cid.strip() for cid in str(self.chat_id).split(',') if cid.strip()]
        if not chat_ids:
            return False

        try:
            url = f"{self.api_url}/sendPhoto"
            photo_file = Path(photo_path)
            if not photo_file.is_absolute():
                photo_file = Path(__file__).parent / 'uploads' / photo_path
            if not photo_file.exists():
                photo_file = Path(photo_path)
            if not photo_file.exists():
                logger.error(f"Photo file not found: {photo_path}")
                return False

            success_count = 0
            with open(photo_file, 'rb') as photo:
                for chat_id in chat_ids:
                    photo.seek(0)
                    import json as _json
                    data = {
                        'chat_id': chat_id,
                        'caption': caption,
                        'parse_mode': parse_mode,
                    }
                    if inline_keyboard:
                        data['reply_markup'] = _json.dumps({'inline_keyboard': inline_keyboard})
                    response = requests.post(url, files={'photo': photo}, data=data, timeout=30)
                    if response.status_code == 200:
                        success_count += 1
                    else:
                        logger.warning(f"Failed to send photo+keyboard to {chat_id}: {response.status_code}")
            return success_count > 0
        except Exception as e:
            logger.error(f"Failed to send photo with keyboard: {e}")
            return False

    def send_alert_with_image(self, message, frame, camera_name=''):
        """Send a zone/crossing alert with a numpy image frame via Telegram sendPhoto"""
        if not self.bot_token or not self.chat_id:
            logger.warning("Telegram credentials not configured")
            return self.send_message(message)

        # Support multiple chat IDs (comma-separated)
        chat_ids = [cid.strip() for cid in str(self.chat_id).split(',') if cid.strip()]
        if not chat_ids:
            return self.send_message(message)

        try:
            import cv2
            import io

            # Encode numpy frame as JPEG bytes
            _, jpeg_bytes = cv2.imencode('.jpg', frame, [cv2.IMWRITE_JPEG_QUALITY, 85])
            photo_bytes = jpeg_bytes.tobytes()

            url = f"{self.api_url}/sendPhoto"
            success_count = 0

            for chat_id in chat_ids:
                try:
                    files = {'photo': ('alert.jpg', io.BytesIO(photo_bytes), 'image/jpeg')}
                    data = {
                        'chat_id': chat_id,
                        'caption': message,
                        'parse_mode': 'HTML'
                    }
                    response = requests.post(url, files=files, data=data, timeout=30)
                    if response.status_code == 200:
                        success_count += 1
                        logger.info(f"Alert photo sent to chat {chat_id}")
                    else:
                        logger.warning(f"Failed to send alert photo to {chat_id}: {response.status_code}")
                        self.send_message(message)
                except Exception as chat_err:
                    logger.error(f"Error sending alert photo to chat {chat_id}: {chat_err}")
                    self.send_message(message)

            return success_count > 0

        except Exception as e:
            logger.error(f"Failed to send alert with image: {e}")
            return self.send_message(message)

    def send_detection_alert(self, camera_name, detected_class, confidence, image_path, location=None, zone_info=None, detection_count=1, site_name=None, people_count=None, smart_summary=None, camera_id=None):
        """Send a formatted detection alert with image, including people count and site info"""
        # Format the message
        timestamp = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        
        # Better class descriptions
        class_descriptions = {
            'person': '👤 Person',
            'car': '🚗 Vehicle (Car)',
            'truck': '🚛 Vehicle (Truck)',
            'bus': '🚌 Vehicle (Bus)',
            'motorcycle': '🏍️ Vehicle (Motorcycle)',
            'bicycle': '🚴 Bicycle',
            'dog': '🐕 Animal (Dog)',
            'cat': '🐱 Animal (Cat)',
            'bird': '🐦 Animal (Bird)',
            'book': '📚 Book',
            'bottle': '🍼 Bottle',
            'cup': '☕ Cup',
            'bowl': '🥣 Bowl',
            'banana': '🍌 Banana',
            'apple': '🍎 Apple',
            'pizza': '🍕 Pizza'
        }
        
        detected_desc = class_descriptions.get(detected_class, f'🔍 {detected_class.title()}')
        
        caption = f"🚨 <b>Detection Alert</b>\n\n"

        # Smart AI summary (context-aware sentence at the top)
        if smart_summary:
            caption += f"💡 <i>{smart_summary}</i>\n\n"
        
        # Add site name if available (for multi-site management)
        if site_name:
            caption += f"🏢 <b>Site:</b> {site_name}\n"
        
        caption += f"📷 <b>Camera:</b> {camera_name}\n"
        if location:
            caption += f"📍 <b>Location:</b> {location}\n"
        
        # Add zone information if available
        if zone_info:
            zone_names = [zone.get('name', f'Zone {zone.get("id", "unknown")}') for zone in zone_info]
            caption += f"🎯 <b>Zone:</b> {', '.join(zone_names)}\n"
        
        caption += f"👁 <b>Detected:</b> {detected_desc}\n"
        
        # Show people count if available and more than 1
        if people_count and people_count > 1:
            caption += f"👥 <b>People Count:</b> {people_count} {'people' if people_count > 1 else 'person'}\n"
        
        # Show count if multiple objects
        if detection_count > 1:
            caption += f"📊 <b>Count:</b> {detection_count} objects\n"
        
        # Show confidence as a human-readable label, not a raw percentage
        if confidence >= 0.85:
            conf_label = "Very High"
        elif confidence >= 0.70:
            conf_label = "High"
        elif confidence >= 0.55:
            conf_label = "Medium"
        else:
            conf_label = "Low"
        caption += f"📈 <b>Confidence:</b> {conf_label}\n\n"
        
        # Add helpful descriptions based on detection type
        if detected_class == 'person':
            if people_count and people_count > 1:
                caption += f"👥 <i>{people_count} people detected in monitored area</i>"
            else:
                caption += f"👥 <i>Person detected in monitored area</i>"
        elif detected_class in ['car', 'truck', 'bus', 'motorcycle']:
            caption += f"🚗 <i>Vehicle detected in monitoring zone</i>"
        elif detected_class in ['dog', 'cat', 'bird']:
            caption += f"🐾 <i>Animal detected on camera</i>"
        else:
            caption += f"🔍 <i>Object recognition active</i>"
        
        # Send photo with False Alert inline button (trains confidence auto-tuner)
        if camera_id is not None:
            try:
                from app import app as _flask_app
                with _flask_app.app_context():
                    from models import SystemConfig
                    _cfg = SystemConfig.query.first()
                    _site_id = str(getattr(_cfg, 'site_id', 'default') or 'default')
            except Exception:
                _site_id = 'default'
            inline_keyboard = [[
                {'text': '✅ Real alert', 'callback_data': f'alert_ok:{_site_id}'},
                {'text': '❌ False alert', 'callback_data': f'fp_cam_{camera_id}:{_site_id}'}
            ]]
            return self.send_photo_with_keyboard(image_path, caption, inline_keyboard=inline_keyboard)
        return self.send_photo(image_path, caption)
        """Send a stock item detection alert for stock control"""
        timestamp = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        
        caption = f"📦 <b>Stock Control Alert - {item_name}</b>\n\n"
        caption += f"➕ <b>New Items Detected:</b> {new_items}\n"
        caption += f"📊 <b>Current Inventory:</b> {total_items} item" + ("s" if total_items != 1 else "") + "\n"
        caption += f"📷 <b>Camera:</b> {camera_name}\n"
        if location:
            caption += f"📍 <b>Location:</b> {location}\n"
        caption += f"🎯 <b>Avg Confidence:</b> {confidence:.1%}\n"
        caption += f"⏰ <b>Time:</b> {timestamp}\n\n"
        
        # Add status note
        caption += f"💡 <i>System tracks individual items to prevent double counting</i>"
        
        # Send the photo with caption
        return self.send_photo(image_path, caption)
    
    def send_combined_detection_alert(self, camera_name, class_counts, confidence,
                                      image_path, location=None, zone_info=None,
                                      site_name=None, people_count=None,
                                      smart_summary=None, camera_id=None):
        """Send ONE combined detection alert when multiple classes are detected in the same frame."""
        class_descriptions = {
            'person': ('👤', 'Person', 'People'),
            'car': ('🚗', 'Vehicle (Car)', 'Vehicles (Car)'),
            'truck': ('🚛', 'Vehicle (Truck)', 'Vehicles (Truck)'),
            'bus': ('🚌', 'Vehicle (Bus)', 'Vehicles (Bus)'),
            'motorcycle': ('🏍️', 'Vehicle (Motorcycle)', 'Vehicles (Motorcycle)'),
            'bicycle': ('🚴', 'Bicycle', 'Bicycles'),
            'dog': ('🐕', 'Dog', 'Dogs'),
            'cat': ('🐱', 'Cat', 'Cats'),
            'bird': ('🐦', 'Bird', 'Birds'),
        }

        caption = "🚨 <b>Detection Alert</b>\n\n"

        if smart_summary:
            caption += f"💡 <i>{smart_summary}</i>\n\n"

        if site_name:
            caption += f"🏢 <b>Site:</b> {site_name}\n"

        caption += f"📷 <b>Camera:</b> {camera_name}\n"
        if location:
            caption += f"📍 <b>Location:</b> {location}\n"

        if zone_info:
            zone_names = [z.get('name', f'Zone {z.get("id", "?")}') for z in zone_info]
            caption += f"🎯 <b>Zone:</b> {', '.join(zone_names)}\n"

        caption += "👁 <b>Detected:</b>\n"
        # Merge people_count into class_counts so person always appears when detected
        if people_count and people_count > 0 and 'person' not in class_counts:
            class_counts = dict(class_counts)
            class_counts['person'] = people_count
        priority_order = ['person', 'car', 'truck', 'bus', 'motorcycle', 'bicycle',
                          'dog', 'cat', 'bird']
        # Print priority classes first, then any others
        ordered_classes = [c for c in priority_order if c in class_counts] + \
                          [c for c in class_counts if c not in priority_order]
        for cls in ordered_classes:
            count = class_counts[cls]
            if cls in class_descriptions:
                emoji, singular, plural = class_descriptions[cls]
                label = plural if count > 1 else singular
            else:
                emoji, label = '🔍', cls.title() + ('s' if count > 1 else '')
            caption += f"  {emoji} {count} {label}\n"

        if people_count and people_count > 1:
            caption += f"👥 <b>People Count:</b> {people_count}\n"

        if confidence >= 0.85:
            conf_label = "Very High"
        elif confidence >= 0.70:
            conf_label = "High"
        elif confidence >= 0.55:
            conf_label = "Medium"
        else:
            conf_label = "Low"
        caption += f"📈 <b>Confidence:</b> {conf_label}\n"

        if camera_id is not None:
            try:
                from app import app as _flask_app
                with _flask_app.app_context():
                    from models import SystemConfig
                    _cfg = SystemConfig.query.first()
                    _site_id = str(getattr(_cfg, 'site_id', 'default') or 'default')
            except Exception:
                _site_id = 'default'
            inline_keyboard = [[
                {'text': '✅ Real alert', 'callback_data': f'alert_ok:{_site_id}'},
                {'text': '❌ False alert', 'callback_data': f'fp_cam_{camera_id}:{_site_id}'}
            ]]
            return self.send_photo_with_keyboard(image_path, caption, inline_keyboard=inline_keyboard)
        return self.send_photo(image_path, caption)

    def send_low_stock_alert(self, camera_name, item_name, current_count, threshold_type='low', location=None):
        """Send low stock alert"""
        timestamp = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        
        icons = {
            'critical': '🚨',
            'low': '⚠️',
            'reorder': '📋'
        }
        
        titles = {
            'critical': 'CRITICAL STOCK LEVEL',
            'low': 'LOW STOCK WARNING',
            'reorder': 'Reorder Recommended'
        }
        
        icon = icons.get(threshold_type, '⚠️')
        title = titles.get(threshold_type, 'Stock Alert')
        
        text = f"{icon} <b>{title}</b>\n\n"
        text += f"📦 <b>Item:</b> {item_name}\n"
        text += f"📊 <b>Current Count:</b> {current_count}\n"
        text += f"📷 <b>Camera:</b> {camera_name}\n"
        if location:
            text += f"📍 <b>Location:</b> {location}\n"
        text += f"⏰ <b>Time:</b> {timestamp}\n\n"
        
        if threshold_type == 'critical':
            text += f"⚠️ <b>Action Required:</b> Restock immediately!"
        elif threshold_type == 'low':
            text += f"📋 <b>Action Required:</b> Plan to restock soon"
        else:
            text += f"💡 <b>Tip:</b> Consider placing a reorder"
        
        return self.send_message(text)
    
    def send_daily_stock_report(self, report_data):
        """Send daily stock control report"""
        timestamp = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        
        text = f"📊 <b>Daily Stock Report</b>\n\n"
        text += f"📅 <b>Date:</b> {report_data.get('date', 'Today')}\n\n"
        
        text += f"<b>Summary:</b>\n"
        text += f"• Items Used: {report_data.get('total_items_used', 0)}\n"
        text += f"• Items Added: {report_data.get('total_items_added', 0)}\n"
        text += f"• Items Wasted: {report_data.get('total_items_wasted', 0)}\n\n"
        
        if 'items' in report_data and report_data['items']:
            text += f"<b>By Item:</b>\n"
            for item in report_data['items'][:5]:  # Show top 5
                item_name = item.get('stock_item_name', 'Unknown')
                used = item.get('items_used', 0)
                text += f"• {item_name}: {used} used"
                if item.get('peak_hour') is not None:
                    text += f" (Peak: {item['peak_hour']}:00)"
                text += f"\n"
        
        text += f"\n⏰ <b>Report Time:</b> {timestamp}"
        
        return self.send_message(text)
    
    def send_weekly_stock_report(self, report_data):
        """Send weekly stock control report"""
        text = f"📊 <b>Weekly Stock Report</b>\n\n"
        text += f"📅 <b>Period:</b> {report_data.get('period', 'Last 7 days')}\n\n"
        
        if 'items' in report_data and report_data['items']:
            for item in report_data['items']:
                text += f"<b>{item.get('name', 'Unknown')}:</b>\n"
                text += f"• Used: {item.get('total_used', 0)}\n"
                text += f"• Added: {item.get('total_added', 0)}\n"
                text += f"• Wasted: {item.get('total_wasted', 0)}\n"
                text += f"• Current: {item.get('current_count', 0)} ({item.get('status', 'unknown')})\n\n"
        
        return self.send_message(text)
    
    def send_camera_offline_alert(self, camera_name, location=None, last_seen=None):
        """Send camera offline notification"""
        timestamp = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        
        text = f"📴 <b>CAMERA OFFLINE</b>\n\n"
        text += f"📷 <b>Camera:</b> {camera_name}\n"
        if location:
            text += f"📍 <b>Location:</b> {location}\n"
        if last_seen:
            text += f"⏰ <b>Last Seen:</b> {last_seen}\n"
        text += f"🚫 <b>Status:</b> Connection Lost\n"
        text += f"⏰ <b>Detected:</b> {timestamp}\n\n"
        text += f"🔧 <b>Action Required:</b> Check camera connection and power\n"
        text += f"📱 <i>System will retry connection automatically</i>"
        
        return self.send_message(text)
    
    def send_camera_online_alert(self, camera_name, location=None, offline_duration=None):
        """Send camera back online notification"""
        timestamp = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        
        text = f"✅ <b>CAMERA BACK ONLINE</b>\n\n"
        text += f"📷 <b>Camera:</b> {camera_name}\n"
        if location:
            text += f"📍 <b>Location:</b> {location}\n"
        text += f"🟢 <b>Status:</b> Connected\n"
        text += f"⏰ <b>Reconnected:</b> {timestamp}\n"
        if offline_duration:
            text += f"⏱️ <b>Downtime:</b> {offline_duration}\n"
        text += f"\n🎯 <i>Detection monitoring resumed</i>"
        
        return self.send_message(text)

    def send_video_clip(self, clip_path, camera_name='', detected_class='', confidence=0.0, location=None):
        """Send a video clip to all configured Telegram chat IDs.
        
        Tries sendVideo (inline playback for .mp4) first, falls back to sendDocument.
        clip_path should be an absolute path to the video file.
        """
        if not self.bot_token or not self.chat_id:
            logger.warning("Telegram credentials not configured")
            return False

        chat_ids = [cid.strip() for cid in str(self.chat_id).split(',') if cid.strip()]
        if not chat_ids:
            return False

        clip_file = Path(clip_path)
        if not clip_file.exists():
            logger.error(f"Clip file not found for Telegram send: {clip_path}")
            return False

        timestamp = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        caption = f"🎬 <b>Alert Clip</b>\n"
        caption += f"📷 <b>Camera:</b> {camera_name}\n"
        if location:
            caption += f"📍 <b>Location:</b> {location}\n"
        caption += f"🎯 <b>Detected:</b> {detected_class.title()} ({confidence:.0%})\n"
        caption += f"⏰ <b>Time:</b> {timestamp}\n"
        caption += f"<i>15s pre-alert + 15s post-alert with bounding boxes</i>"

        success_count = 0
        ext = clip_file.suffix.lower()
        use_video = ext in ('.mp4', '.mov', '.3gp')
        api_method = 'sendVideo' if use_video else 'sendDocument'
        field_name  = 'video'   if use_video else 'document'

        try:
            url = f"{self.api_url}/{api_method}"
            with open(clip_file, 'rb') as f:
                for chat_id in chat_ids:
                    f.seek(0)
                    files = {field_name: (clip_file.name, f, 'video/mp4' if use_video else 'application/octet-stream')}
                    data = {'chat_id': chat_id, 'caption': caption, 'parse_mode': 'HTML'}
                    if use_video:
                        data['supports_streaming'] = 'true'
                    try:
                        resp = requests.post(url, files=files, data=data, timeout=120)
                        if resp.status_code == 200 and resp.json().get('ok'):
                            success_count += 1
                            logger.info(f"Clip sent to Telegram chat {chat_id}")
                        else:
                            # Fallback: try sendDocument if sendVideo failed
                            if use_video:
                                f.seek(0)
                                fb_url = f"{self.api_url}/sendDocument"
                                fb_files = {'document': (clip_file.name, f, 'application/octet-stream')}
                                fb_resp = requests.post(fb_url, files=fb_files, data={'chat_id': chat_id, 'caption': caption, 'parse_mode': 'HTML'}, timeout=120)
                                if fb_resp.status_code == 200 and fb_resp.json().get('ok'):
                                    success_count += 1
                                    logger.info(f"Clip sent as document to Telegram chat {chat_id}")
                                else:
                                    logger.warning(f"Failed to send clip to {chat_id}: {fb_resp.text}")
                            else:
                                logger.warning(f"Failed to send clip to {chat_id}: {resp.text}")
                    except Exception as inner_e:
                        logger.error(f"Error sending clip to {chat_id}: {inner_e}")
            return success_count > 0
        except Exception as e:
            logger.error(f"Failed to send Telegram clip: {e}")
            return False
    
    def send_system_alert(self, alert_type, message):
        """Send system alerts (errors, warnings, etc.)"""
        icons = {
            'error': '❌',
            'warning': '⚠️',
            'info': 'ℹ️',
            'success': '✅'
        }
        
        icon = icons.get(alert_type, 'ℹ️')
        timestamp = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        
        text = f"{icon} <b>System Alert</b>\n\n"
        text += f"{message}\n\n"
        text += f"⏰ {timestamp}"
        
        return self.send_message(text)
    
    def send_zone_alert(self, camera_name, zone_name, zone_type, detected_objects, location=None):
        """Send zone-specific detection alert"""
        timestamp = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        
        zone_icons = {
            'alert': '🚨',
            'counting': '📊', 
            'exclusion': '🚫',
            'loitering': '⏱️'
        }
        
        icon = zone_icons.get(zone_type, '🎯')
        
        text = f"{icon} <b>Zone Alert - {zone_name}</b>\n\n"
        text += f"📷 <b>Camera:</b> {camera_name}\n"
        if location:
            text += f"📍 <b>Location:</b> {location}\n"
        text += f"🎯 <b>Zone Type:</b> {zone_type.title()}\n"
        
        if detected_objects:
            text += f"👁 <b>Detected:</b>\n"
            for obj_type, count in detected_objects.items():
                if count > 0:
                    text += f"  • {obj_type.title()}: {count}\n"
        
        text += f"⏰ <b>Time:</b> {timestamp}\n\n"
        
        if zone_type == 'loitering':
            text += f"⏱️ <i>Person detected loitering in restricted zone</i>"
        elif zone_type == 'exclusion':
            text += f"🚫 <i>Unauthorized entry detected in exclusion zone</i>"
        elif zone_type == 'counting':
            text += f"📊 <i>Object count updated for monitoring zone</i>"
        else:
            text += f"🎯 <i>Zone boundary violation detected</i>"
        
        return self.send_message(text)
    
    def handle_telegram_command(self, command, from_user_id=None):
        """Handle telegram bot commands from users"""
        command = command.lower().strip()
        
        if command == '/start' or command == '/help':
            return self.send_command_help()
        elif command == '/status':
            return self.send_system_status()
        elif command == '/cameras':
            return self.send_camera_list()
        elif command == '/sites':
            return self.send_site_list()
        elif command == '/stats':
            return self.send_detection_stats()
        elif command.startswith('/arm'):
            return self.handle_arm_command(command)
        elif command.startswith('/disarm'):
            return self.handle_disarm_command(command)
        elif command.startswith('/snapshot'):
            return self.handle_snapshot_command(command)
        elif command == '/schedule':
            return self.send_schedule_info()
        elif command.startswith('/setarm'):
            return self.handle_set_arm_time(command)
        elif command.startswith('/setdisarm'):
            return self.handle_set_disarm_time(command)
        elif command.startswith('/setdays'):
            return self.handle_set_schedule_days(command)
        elif command.startswith('/enableschedule'):
            return self.handle_enable_schedule(command)
        elif command.startswith('/testschedule'):
            return self.handle_test_schedule(command)
        else:
            return self.send_unknown_command(command)
    
    def send_site_list(self):
        """Send list of configured sites"""
        try:
            from models import SystemConfig
            
            config = SystemConfig.query.first()
            site_name = getattr(config, 'site_name', 'Main Site') if config else 'Main Site'
            site_id = getattr(config, 'site_id', '1') if config else '1'
            
            text = f"🏢 <b>Configured Sites</b>\n\n"
            text += f"• <b>{site_name}</b> (ID: {site_id})\n"
            armed_status = "🟢 Armed" if config and config.is_armed else "🔴 Disarmed"
            text += f"  Status: {armed_status}\n\n"
            text += f"💡 <i>Use /arm [site_id] or /disarm [site_id] to control specific sites</i>"
            
            return self.send_message(text)
        except Exception as e:
            return self.send_message(f"\u274c Error getting site list: {str(e)}")
    
    def handle_snapshot_command(self, command):
        """Handle snapshot command - get live snapshot from camera"""
        try:
            from models import Camera
            import cv2
            import os
            from pathlib import Path
            
            parts = command.split()
            
            # If no camera specified, show available cameras
            if len(parts) == 1:
                cameras = Camera.query.filter_by(is_active=True).all()
                text = f"📷 <b>Available Cameras for Snapshot</b>\n\n"
                for cam in cameras:
                    text += f"• /snapshot {cam.id} - {cam.name}\n"
                return self.send_message(text)
            
            camera_id = int(parts[1])
            camera = Camera.query.get(camera_id)
            
            if not camera:
                return self.send_message(f"\u274c Camera {camera_id} not found")
            
            frame = None

            # 1. Try detection engine frame cache first (no extra RTSP connection needed;
            #    single-stream cameras like Provision ISR can't handle a second connection)
            try:
                from app import detection_engine
                import numpy as np
                if detection_engine and hasattr(detection_engine, 'camera_frames'):
                    cached = detection_engine.camera_frames.get(camera_id)
                    if cached is not None:
                        # Validate frame is not blank
                        gray = cv2.cvtColor(cached, cv2.COLOR_BGR2GRAY) if len(cached.shape) == 3 else cached
                        if np.var(gray) > 30:
                            frame = cached.copy()
                            logger.info(f"📷 Snapshot from detection cache for {camera.name}")
            except Exception as ce:
                logger.debug(f"Cache snapshot error: {ce}")

            # 2. Fall back to RTSP only if cache empty
            if frame is None:
                working_url = getattr(camera, 'working_rtsp_url', None) or camera.rtsp_url
                snapshot_url = working_url
                logger.info(f"📷 Capturing snapshot via RTSP: {snapshot_url[:50]}...")
                os.environ['OPENCV_FFMPEG_CAPTURE_OPTIONS'] = 'rtsp_transport;tcp|stimeout;5000000|fflags;nobuffer'
                cap = cv2.VideoCapture(snapshot_url, cv2.CAP_FFMPEG)
                cap.set(cv2.CAP_PROP_OPEN_TIMEOUT_MSEC, 5000)
                cap.set(cv2.CAP_PROP_READ_TIMEOUT_MSEC, 5000)
                cap.set(cv2.CAP_PROP_BUFFERSIZE, 1)
                ret, frame = cap.read()
                cap.release()

            if frame is None:
                return self.send_message(f"\u274c Could not capture snapshot from {camera.name}")
            
            # Save snapshot
            uploads_dir = Path(__file__).parent / 'uploads' / 'snapshots'
            uploads_dir.mkdir(parents=True, exist_ok=True)
            
            filename = f"snapshot_{camera_id}_{datetime.now().strftime('%Y%m%d_%H%M%S')}.jpg"
            filepath = uploads_dir / filename
            cv2.imwrite(str(filepath), frame)
            
            # Send snapshot
            caption = f"📷 <b>Snapshot from {camera.name}</b>\n"
            if camera.location:
                caption += f"📍 Location: {camera.location}\n"
            caption += f"⏰ {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}"
            
            return self.send_photo(str(filepath), caption)
            
        except Exception as e:
            return self.send_message(f"\u274c Error capturing snapshot: {str(e)}")
    
    def send_command_help(self):
        """Send list of available commands"""
        text = f"🤖 <b>SentinelVision Pro Bot Commands</b>\n\n"
        text += f"📋 <b>System Commands:</b>\n"
        text += f"• /start - Show this help message\n"
        text += f"• /help - Show command help\n"
        text += f"• /status - System status and health\n"
        text += f"• /cameras - List all cameras and status\n"
        text += f"• /sites - List configured sites\n"
        text += f"• /stats - Detection statistics\n"
        text += f"• /snapshot [camera_id] - Get live snapshot\n\n"
        text += f"🛡️ <b>Control Commands:</b>\n"
        text += f"• /arm - Arm all cameras (or /arm [site_id])\n"
        text += f"• /disarm - Disarm all cameras (or /disarm [site_id])\n\n"
        text += f"⏰ <b>Schedule Commands:</b>\n"
        text += f"• /schedule - Show current schedule\n"
        text += f"• /setarm HH:MM - Set auto-arm time\n"
        text += f"• /setdisarm HH:MM - Set auto-disarm time\n"
        text += f"• /setdays 1,2,3,4,5 - Set schedule days\n"
        text += f"• /enableschedule on/off - Enable/disable\n"
        text += f"• /testschedule arm/disarm - Test schedule\n\n"
        text += f"🔧 <b>Examples:</b>\n"
        text += f"• /setarm 22:00 - Auto-arm at 10 PM\n"
        text += f"• /setdisarm 07:00 - Auto-disarm at 7 AM\n"
        text += f"• /snapshot 1 - Get snapshot from camera 1\n"
        text += f"• /enableschedule on - Enable auto-schedule\n\n"
        text += f"📱 <i>You will receive automatic alerts when objects are detected</i>"
        
        return self.send_message(text)
    
    def send_system_status(self):
        """Send current system status"""
        try:
            from models import SystemConfig, Camera, DetectionEvent
            from datetime import datetime, timedelta
            
            # Get system config
            config = SystemConfig.query.first()
            
            # Get camera info
            total_cameras = Camera.query.count()
            active_cameras = Camera.query.filter_by(is_active=True).count()
            armed_cameras = Camera.query.filter_by(is_active=True, is_armed=True).count()
            
            # Get recent detections (last 24 hours)
            yesterday = datetime.utcnow() - timedelta(hours=24)
            recent_detections = DetectionEvent.query.filter(
                DetectionEvent.created_at >= yesterday
            ).count()
            
            text = f"📊 <b>System Status</b>\n\n"
            text += f"🔧 <b>System:</b> {'🟢 Armed' if config and config.is_armed else '🔴 Disarmed'}\n"
            text += f"📷 <b>Cameras:</b> {active_cameras}/{total_cameras} Active\n"
            text += f"🛡️ <b>Armed Cameras:</b> {armed_cameras}\n"
            text += f"🎯 <b>Detections (24h):</b> {recent_detections}\n"
            text += f"⏰ <b>Checked:</b> {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n\n"
            text += f"✅ <i>All systems operational</i>"
            
            return self.send_message(text)
        except Exception as e:
            return self.send_message(f"❌ Error getting system status: {str(e)}")
    
    def send_camera_list(self):
        """Send list of cameras and their status"""
        try:
            from models import Camera
            
            cameras = Camera.query.all()
            
            text = f"📷 <b>Camera List</b>\n\n"
            
            if not cameras:
                text += f"❌ No cameras configured\n\n"
            else:
                for camera in cameras:
                    status_icon = "🟢" if camera.is_active else "🔴"
                    arm_icon = "🛡️" if camera.is_armed else "🔓"
                    
                    text += f"{status_icon} <b>{camera.name}</b> {arm_icon}\n"
                    if camera.location:
                        text += f"  📍 {camera.location}\n"
                    text += f"  Status: {'Active' if camera.is_active else 'Inactive'}\n"
                    text += f"  Armed: {'Yes' if camera.is_armed else 'No'}\n\n"
            
            text += f"⏰ {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}"
            
            return self.send_message(text)
        except Exception as e:
            return self.send_message(f"❌ Error getting camera list: {str(e)}")
    
    def send_detection_stats(self):
        """Send detection statistics"""
        try:
            from models import DetectionEvent
            from datetime import datetime, timedelta
            from sqlalchemy import func
            from models import db  # Import db here to avoid circular import
            
            # Get stats for last 24 hours
            yesterday = datetime.utcnow() - timedelta(hours=24)
            
            total_today = DetectionEvent.query.filter(
                DetectionEvent.created_at >= yesterday
            ).count()
            
            # Get detections by class
            class_stats = db.session.query(
                DetectionEvent.detected_class,
                func.count(DetectionEvent.id).label('count')
            ).filter(
                DetectionEvent.created_at >= yesterday
            ).group_by(DetectionEvent.detected_class).all()
            
            text = f"📊 <b>Detection Statistics (24h)</b>\n\n"
            text += f"🎯 <b>Total Detections:</b> {total_today}\n\n"
            
            if class_stats:
                text += f"<b>By Object Type:</b>\n"
                for class_name, count in class_stats:
                    if class_name:
                        text += f"  • {class_name.title()}: {count}\n"
            
            text += f"\n⏰ {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}"
            
            return self.send_message(text)
        except Exception as e:
            return self.send_message(f"❌ Error getting statistics: {str(e)}")
    
    def handle_arm_command(self, command):
        """Handle arm/disarm commands"""
        try:
            from models import SystemConfig, Camera
            from models import db  # Import db here
            
            # For now, arm all cameras
            config = SystemConfig.query.first()
            if config:
                config.is_armed = True
            
            Camera.query.update({Camera.is_armed: True})
            db.session.commit()
            
            return self.send_message("🛡️ <b>System Armed</b>\n\nAll cameras are now monitoring and will send alerts for detections.")
        except Exception as e:
            return self.send_message(f"❌ Error arming system: {str(e)}")
    
    def handle_disarm_command(self, command):
        """Handle disarm commands"""
        try:
            from models import SystemConfig, Camera
            from models import db  # Import db here
            
            # For now, disarm all cameras
            config = SystemConfig.query.first()
            if config:
                config.is_armed = False
            
            Camera.query.update({Camera.is_armed: False})
            db.session.commit()
            
            return self.send_message("🔓 <b>System Disarmed</b>\n\nAll cameras are now disarmed and will not send detection alerts.")
        except Exception as e:
            return self.send_message(f"❌ Error disarming system: {str(e)}")
    
    def send_unknown_command(self, command):
        """Send help for unknown command"""
        text = f"❓ <b>Unknown Command:</b> {command}\n\n"
        text += f"Send /help to see available commands."
        
        return self.send_message(text)    
    def send_schedule_info(self):
        """Send current auto-schedule information"""
        try:
            from models import SystemConfig
            
            config = SystemConfig.query.first()
            if not config:
                return self.send_message("❌ No system configuration found")
            
            text = f"⏰ <b>Auto-Schedule Configuration</b>\\n\\n"
            text += f"📊 <b>Status:</b> {'✅ Enabled' if config.enable_auto_schedule else '❌ Disabled'}\\n"
            
            if config.enable_auto_schedule:
                text += f"🛡️ <b>Auto-Arm:</b> {config.arm_time}\\n"
                text += f"🔓 <b>Auto-Disarm:</b> {config.disarm_time}\\n"
                
                # Show schedule days
                day_names = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday']
                active_days = [day_names[d] for d in config.get_schedule_days_list()]
                text += f"📅 <b>Active Days:</b> {', '.join(active_days)}\\n"
                text += f"🌍 <b>Timezone:</b> {config.timezone or 'UTC'}\\n\\n"
                
                # Get next scheduled times
                try:
                    from scheduler_service import get_scheduler_service
                    scheduler = get_scheduler_service()
                    if scheduler:
                        next_times = scheduler.get_next_schedule_times()
                        if next_times['arm']:
                            text += f"⏭️ <b>Next Arm:</b> {next_times['arm'].strftime('%Y-%m-%d %H:%M')}\\n"
                        if next_times['disarm']:
                            text += f"⏭️ <b>Next Disarm:</b> {next_times['disarm'].strftime('%Y-%m-%d %H:%M')}\\n"
                except Exception:
                    text += f"⚠️ <i>Scheduler status unavailable</i>\\n"
            else:
                text += f"\\n💡 Use /enableschedule on to activate automatic scheduling"
            
            text += f"\\n⏰ {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}"
            
            return self.send_message(text)
        except Exception as e:
            return self.send_message(f"❌ Error getting schedule info: {str(e)}")
    
    def handle_set_arm_time(self, command):
        """Handle /setarm HH:MM command"""
        try:
            parts = command.split()
            if len(parts) != 2:
                return self.send_message("❌ Usage: /setarm HH:MM\\nExample: /setarm 22:00")
            
            time_str = parts[1]
            
            # Validate time format
            try:
                hour, minute = map(int, time_str.split(':'))
                if not (0 <= hour <= 23) or not (0 <= minute <= 59):
                    raise ValueError("Invalid time range")
            except ValueError:
                return self.send_message("❌ Invalid time format. Use HH:MM (24-hour format)\\nExample: 22:00")
            
            from models import SystemConfig
            from models import db
            
            config = SystemConfig.query.first()
            if not config:
                return self.send_message("❌ No system configuration found")
            
            config.arm_time = time_str
            config.updated_at = datetime.utcnow()
            db.session.commit()
            
            # Update scheduler
            try:
                from scheduler_service import get_scheduler_service
                scheduler = get_scheduler_service()
                if scheduler:
                    scheduler.update_schedule()
            except Exception as e:
                logger.error(f"Error updating scheduler: {e}")
            
            text = f"✅ <b>Auto-Arm Time Updated</b>\\n\\n"
            text += f"🛡️ <b>New Arm Time:</b> {time_str}\\n"
            text += f"📊 <b>Schedule Status:</b> {'Enabled' if config.enable_auto_schedule else 'Disabled'}\\n\\n"
            
            if not config.enable_auto_schedule:
                text += f"💡 Use /enableschedule on to activate the schedule"
            else:
                text += f"⚡ Schedule automatically updated"
            
            return self.send_message(text)
        except Exception as e:
            return self.send_message(f"❌ Error setting arm time: {str(e)}")
    
    def handle_set_disarm_time(self, command):
        """Handle /setdisarm HH:MM command"""
        try:
            parts = command.split()
            if len(parts) != 2:
                return self.send_message("❌ Usage: /setdisarm HH:MM\\nExample: /setdisarm 07:00")
            
            time_str = parts[1]
            
            # Validate time format
            try:
                hour, minute = map(int, time_str.split(':'))
                if not (0 <= hour <= 23) or not (0 <= minute <= 59):
                    raise ValueError("Invalid time range")
            except ValueError:
                return self.send_message("❌ Invalid time format. Use HH:MM (24-hour format)\\nExample: 07:00")
            
            from models import SystemConfig
            from models import db
            
            config = SystemConfig.query.first()
            if not config:
                return self.send_message("❌ No system configuration found")
            
            config.disarm_time = time_str
            config.updated_at = datetime.utcnow()
            db.session.commit()
            
            # Update scheduler
            try:
                from scheduler_service import get_scheduler_service
                scheduler = get_scheduler_service()
                if scheduler:
                    scheduler.update_schedule()
            except Exception as e:
                logger.error(f"Error updating scheduler: {e}")
            
            text = f"✅ <b>Auto-Disarm Time Updated</b>\\n\\n"
            text += f"🔓 <b>New Disarm Time:</b> {time_str}\\n"
            text += f"📊 <b>Schedule Status:</b> {'Enabled' if config.enable_auto_schedule else 'Disabled'}\\n\\n"
            
            if not config.enable_auto_schedule:
                text += f"💡 Use /enableschedule on to activate the schedule"
            else:
                text += f"⚡ Schedule automatically updated"
            
            return self.send_message(text)
        except Exception as e:
            return self.send_message(f"❌ Error setting disarm time: {str(e)}")
    
    def handle_set_schedule_days(self, command):
        """Handle /setdays 1,2,3,4,5 command"""
        try:
            parts = command.split(maxsplit=1)
            if len(parts) != 2:
                return self.send_message("❌ Usage: /setdays 1,2,3,4,5\\nDays: 1=Mon, 2=Tue, 3=Wed, 4=Thu, 5=Fri, 6=Sat, 7=Sun")
            
            days_str = parts[1]
            
            # Parse and validate days
            try:
                days = [int(d.strip()) - 1 for d in days_str.split(',') if d.strip()]  # Convert to 0-based
                if not all(0 <= d <= 6 for d in days) or not days:
                    raise ValueError("Invalid day numbers")
            except ValueError:
                return self.send_message("❌ Invalid day format. Use numbers 1-7 separated by commas\\nExample: 1,2,3,4,5 (weekdays)")
            
            from models import SystemConfig
            from models import db
            
            config = SystemConfig.query.first()
            if not config:
                return self.send_message("❌ No system configuration found")
            
            config.set_schedule_days(days)
            config.updated_at = datetime.utcnow()
            db.session.commit()
            
            # Update scheduler
            try:
                from scheduler_service import get_scheduler_service
                scheduler = get_scheduler_service()
                if scheduler:
                    scheduler.update_schedule()
            except Exception as e:
                logger.error(f"Error updating scheduler: {e}")
            
            # Format day names for display
            day_names = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday']
            active_days = [day_names[d] for d in days]
            
            text = f"✅ <b>Schedule Days Updated</b>\\n\\n"
            text += f"📅 <b>Active Days:</b> {', '.join(active_days)}\\n"
            text += f"📊 <b>Schedule Status:</b> {'Enabled' if config.enable_auto_schedule else 'Disabled'}\\n\\n"
            
            if not config.enable_auto_schedule:
                text += f"💡 Use /enableschedule on to activate the schedule"
            else:
                text += f"⚡ Schedule automatically updated"
            
            return self.send_message(text)
        except Exception as e:
            return self.send_message(f"❌ Error setting schedule days: {str(e)}")
    
    def handle_enable_schedule(self, command):
        """Handle /enableschedule on/off command"""
        try:
            parts = command.split()
            if len(parts) != 2 or parts[1] not in ['on', 'off']:
                return self.send_message("❌ Usage: /enableschedule on or /enableschedule off")
            
            enable = parts[1] == 'on'
            
            from models import SystemConfig
            from models import db
            
            config = SystemConfig.query.first()
            if not config:
                return self.send_message("❌ No system configuration found")
            
            config.enable_auto_schedule = enable
            config.updated_at = datetime.utcnow()
            db.session.commit()
            
            # Update scheduler
            try:
                from scheduler_service import get_scheduler_service
                scheduler = get_scheduler_service()
                if scheduler:
                    scheduler.update_schedule()
            except Exception as e:
                logger.error(f"Error updating scheduler: {e}")
            
            if enable:
                text = f"✅ <b>Auto-Schedule Enabled</b>\\n\\n"
                text += f"🛡️ <b>Arm Time:</b> {config.arm_time}\\n"
                text += f"🔓 <b>Disarm Time:</b> {config.disarm_time}\\n"
                
                day_names = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday']
                active_days = [day_names[d] for d in config.get_schedule_days_list()]
                text += f"📅 <b>Active Days:</b> {', '.join(active_days)}\\n\\n"
                text += f"⚡ <i>System will now automatically arm and disarm according to schedule</i>"
            else:
                text = f"❌ <b>Auto-Schedule Disabled</b>\\n\\n"
                text += f"💤 <i>Automatic arming/disarming has been turned off</i>\\n"
                text += f"🎛️ <i>Use manual /arm and /disarm commands instead</i>"
            
            return self.send_message(text)
        except Exception as e:
            return self.send_message(f"❌ Error toggling schedule: {str(e)}")
    
    def handle_test_schedule(self, command):
        """Handle /testschedule arm/disarm command"""
        try:
            parts = command.split()
            if len(parts) != 2 or parts[1] not in ['arm', 'disarm']:
                return self.send_message("❌ Usage: /testschedule arm or /testschedule disarm")
            
            test_type = parts[1]
            
            from scheduler_service import get_scheduler_service
            scheduler = get_scheduler_service()
            
            if not scheduler:
                return self.send_message("❌ Scheduler service not available")
            
            success = scheduler.test_schedule(test_type)
            
            if success:
                action = "armed" if test_type == 'arm' else "disarmed"
                text = f"✅ <b>Schedule Test Successful</b>\\n\\n"
                text += f"🧪 <b>Test Action:</b> {test_type.title()}\\n"
                text += f"📊 <b>Result:</b> System {action}\\n\\n"
                text += f"⚡ <i>This was a manual test of the scheduled {test_type} function</i>"
            else:
                text = f"❌ <b>Schedule Test Failed</b>\\n\\n"
                text += f"🧪 <b>Test Action:</b> {test_type.title()}\\n"
                text += f"📊 <b>Result:</b> Error occurred\\n\\n"
                text += f"🔧 <i>Check logs for more details</i>"
            
            return self.send_message(text)
        except Exception as e:
            return self.send_message(f"❌ Error testing schedule: {str(e)}")
    
    def setup_bot_commands(self):
        """Setup bot commands without requiring chat_id"""
        try:
            commands = [
                {"command": "start", "description": "Show help message"},
                {"command": "help", "description": "Show command help"},
                {"command": "status", "description": "System status and health"},
                {"command": "cameras", "description": "List all cameras"},
                {"command": "stats", "description": "Detection statistics"},
                {"command": "arm", "description": "Arm all cameras"},
                {"command": "disarm", "description": "Disarm all cameras"},
                {"command": "schedule", "description": "Show current schedule"},
                {"command": "setarm", "description": "Set auto-arm time (HH:MM)"},
                {"command": "setdisarm", "description": "Set auto-disarm time (HH:MM)"},
                {"command": "setdays", "description": "Set schedule days (1,2,3,4,5)"},
                {"command": "enableschedule", "description": "Enable/disable auto-schedule"},
                {"command": "testschedule", "description": "Test schedule (arm/disarm)"}
            ]
            
            url = f"{self.api_url}/setMyCommands"
            payload = {"commands": commands}
            
            response = requests.post(url, json=payload, timeout=10)
            if response.status_code == 200:
                result = response.json()
                if result.get('ok'):
                    logger.info("✅ Telegram bot commands registered successfully in menu")
                    return True
                else:
                    logger.warning(f"Failed to register commands: {result}")
            else:
                logger.warning(f"Failed to register commands: HTTP {response.status_code}")
            return False
        except Exception as e:
            logger.error(f"Error setting up bot commands: {e}")
            return False
    
    def send_daily_summary(self, stats):
        """Send daily detection summary"""
        text = f"📊 <b>Daily Summary</b>\\n\\n"
        text += f"🎯 <b>Total Detections:</b> {stats.get('total_detections', 0)}\\n"
        text += f"📷 <b>Active Cameras:</b> {stats.get('active_cameras', 0)}\\n"
        
        if 'detections_by_class' in stats:
            text += f"\\n<b>Detections by Class:</b>\\n"
            for class_name, count in stats['detections_by_class'].items():
                text += f"  • {class_name.title()}: {count}\\n"
        
        text += f"\n⏰ {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}"
        
        return self.send_message(text)
    
    def get_chat_id_instructions(self):
        """Return instructions for getting chat ID"""
        return """
To get your Telegram Chat ID:

1. Open Telegram and search for @userinfobot
2. Start a chat with the bot
3. Send any message to the bot
4. The bot will reply with your Chat ID
5. Copy the Chat ID number and paste it in the setup page

Alternatively:
1. Search for @RawDataBot
2. Send any message
3. Look for "chat": {"id": YOUR_CHAT_ID}
"""


# Global telegram service instance
telegram_service = TelegramService()
