#!/bin/bash
# SentinelVision Raspberry Pi Edition - Installation Script
# For Raspberry Pi OS (Debian-based)
# Run this script from the sentinelvision folder
set -euo pipefail

# ── Colours ─────────────────────────────────────────────
RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'
CYAN='\033[0;36m'; BOLD='\033[1m'; RESET='\033[0m'

info()    { echo -e "${CYAN}[INFO]${RESET}  $*"; }
success() { echo -e "${GREEN}[OK]${RESET}    $*"; }
warn()    { echo -e "${YELLOW}[WARN]${RESET}  $*"; }
fail()    { echo -e "${RED}[ERROR]${RESET} $*"; exit 1; }

echo ""
echo -e "${BOLD}==========================================${RESET}"
echo -e "${BOLD} SentinelVision Pro — Raspberry Pi Setup ${RESET}"
echo -e "${BOLD}==========================================${RESET}"
echo ""

# ── Get script directory ─────────────────────────────────
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
info "Installing from: $SCRIPT_DIR"
echo ""

# ── Pre-flight checks ────────────────────────────────────
echo -e "${BOLD}PRE-FLIGHT CHECKS${RESET}"

# Raspberry Pi check
if [ -f /proc/device-tree/model ]; then
    PI_MODEL=$(cat /proc/device-tree/model 2>/dev/null | tr -d '\0')
    success "Detected: $PI_MODEL"
else
    warn "This does not appear to be a Raspberry Pi."
    read -rp "  Continue anyway? (y/n) " _CONT
    [[ "$_CONT" =~ ^[Yy]$ ]] || exit 1
fi

# RAM check — warn if below 1.5 GB (Pi Zero/1 will struggle)
TOTAL_RAM_KB=$(grep MemTotal /proc/meminfo | awk '{print $2}')
TOTAL_RAM_MB=$((TOTAL_RAM_KB / 1024))
if [ "$TOTAL_RAM_MB" -lt 1400 ]; then
    warn "Only ${TOTAL_RAM_MB} MB RAM detected. SentinelVision runs best on Pi 3B+ or Pi 4 (2 GB+)."
    warn "Expect slower AI detection on this hardware."
    read -rp "  Continue anyway? (y/n) " _CONT
    [[ "$_CONT" =~ ^[Yy]$ ]] || exit 1
else
    success "RAM: ${TOTAL_RAM_MB} MB — OK"
fi

# Disk space check — need at least 4 GB free
FREE_KB=$(df "$SCRIPT_DIR" | awk 'NR==2{print $4}')
FREE_GB=$((FREE_KB / 1024 / 1024))
if [ "$FREE_GB" -lt 4 ]; then
    fail "Less than 4 GB free disk space (${FREE_GB} GB available). Please free up space and retry."
fi
success "Free disk: ${FREE_GB} GB — OK"

# Internet connectivity check
if ! ping -c 1 -W 3 8.8.8.8 &>/dev/null; then
    fail "No internet connection detected. Please connect to the internet and retry."
fi
success "Internet — OK"
echo ""

# ── Admin password setup ─────────────────────────────────
echo -e "${BOLD}ADMIN SETUP${RESET}"
echo "  You will use these credentials to log into SentinelVision."
echo ""
while true; do
    read -rsp "  Set admin password (min 8 chars): " ADMIN_PASS; echo
    [ ${#ADMIN_PASS} -ge 8 ] && break
    warn "Password must be at least 8 characters."
done
read -rsp "  Confirm password: " ADMIN_PASS2; echo
if [ "$ADMIN_PASS" != "$ADMIN_PASS2" ]; then
    fail "Passwords do not match. Please re-run the installer."
fi
success "Admin password set."

# Write password to a temp file the app will read on first boot
echo "$ADMIN_PASS" > "$SCRIPT_DIR/.install_admin_pass"
chmod 600 "$SCRIPT_DIR/.install_admin_pass"
echo ""

# ── Update system ────────────────────────────────────────
echo -e "${BOLD}Step 1: Updating system packages...${RESET}"
sudo apt-get update -qq
sudo apt-get upgrade -y -qq
success "System packages updated."

# ── System dependencies ──────────────────────────────────
echo ""
echo -e "${BOLD}Step 2: Installing system dependencies...${RESET}"
sudo apt-get install -y \
    python3 \
    python3-pip \
    python3-venv \
    libopencv-dev \
    python3-opencv \
    libatlas-base-dev \
    libhdf5-dev \
    libhdf5-serial-dev \
    libharfbuzz0b \
    libwebp7 \
    libjasper1 \
    libilmbase25 \
    libopenexr25 \
    libgstreamer1.0-0 \
    libavcodec-dev \
    libavformat-dev \
    libswscale-dev \
    ffmpeg \
    git
success "System dependencies installed."

# ── Application directory ────────────────────────────────
echo ""
echo -e "${BOLD}Step 3: Setting up application directory...${RESET}"
APP_DIR="/opt/sentinelvision"
sudo mkdir -p $APP_DIR
sudo chown $USER:$USER $APP_DIR

# Copy files from the script directory
echo "Copying application files..."
cp -r "$SCRIPT_DIR"/* $APP_DIR/
cp -r "$SCRIPT_DIR"/.[!.]* $APP_DIR/ 2>/dev/null || true
success "Files copied to $APP_DIR"

cd $APP_DIR

# Create required directories
mkdir -p uploads instance models
success "Directories created."

# ── Python virtual environment ───────────────────────────
echo ""
echo -e "${BOLD}Step 4: Creating Python virtual environment...${RESET}"
python3 -m venv venv
source venv/bin/activate
success "Virtual environment ready."

# Upgrade pip
pip install --upgrade pip -q

# ── Python dependencies ──────────────────────────────────
echo ""
echo -e "${BOLD}Step 5: Installing Python dependencies...${RESET}"
echo "  This may take 15–30 minutes on Raspberry Pi. Please be patient."
pip install -r requirements.txt || fail "Python dependency install failed. Check your internet connection and retry."
success "Python dependencies installed."

# ── Download AI model ─────────────────────────────────────
if [ ! -f "models/yolo11s.pt" ]; then
    echo ""
    echo -e "${BOLD}Downloading AI detection model (yolo11s)...${RESET}"
    python -c "from ultralytics import YOLO; m=YOLO('yolo11s.pt'); m.save('models/yolo11s.pt')" \
        || warn "Model download failed — it will be downloaded on first run."
    success "AI model ready."
fi

# ── systemd service ──────────────────────────────────────
echo ""
echo -e "${BOLD}Step 6: Creating systemd service...${RESET}"
sudo tee /etc/systemd/system/sentinelvision.service > /dev/null <<EOF
[Unit]
Description=SentinelVision Raspberry Pi Edition
After=network.target network-online.target
Wants=network-online.target

[Service]
Type=simple
User=$USER
WorkingDirectory=$APP_DIR
Environment="PATH=$APP_DIR/venv/bin:/usr/bin:/bin"
ExecStart=$APP_DIR/venv/bin/python run.py
Restart=always
RestartSec=10
StartLimitAction=none
ProtectSystem=strict
ReadWritePaths=$APP_DIR /tmp
NoNewPrivileges=true

[Install]
WantedBy=multi-user.target
EOF

# Enable service
sudo systemctl daemon-reload
sudo systemctl enable sentinelvision.service
success "systemd service created and enabled."

# ── Passwordless sudo ────────────────────────────────────
echo ""
echo -e "${BOLD}Step 7: Configuring passwordless sudo for reboot...${RESET}"
# Include both /bin and /usr/bin paths — older Pi OS has them as real files,
# newer Pi OS (Bookworm) has /bin -> /usr/bin symlink. Sudo matches canonical
# paths so we list both to guarantee the passwordless restart works on all versions.
SUDOERS_LINE="$USER ALL=(ALL) NOPASSWD: /sbin/reboot, /usr/sbin/reboot, /sbin/shutdown, /usr/sbin/shutdown, /bin/systemctl restart sentinelvision, /usr/bin/systemctl restart sentinelvision"
echo "$SUDOERS_LINE" | sudo tee /etc/sudoers.d/sentinelvision > /dev/null
sudo chmod 440 /etc/sudoers.d/sentinelvision
success "Sudoers entry added."

# ── Permissions ───────────────────────────────────────────
echo ""
echo -e "${BOLD}Step 8: Setting permissions...${RESET}"
chmod +x run.py
chmod +x start.sh

# Lock down the install directory so only the app user can read/write it
# (prevents other OS users — or a web vulnerability — reading config/API keys)
sudo chown -R $USER:$USER $APP_DIR
chmod 700 $APP_DIR
find $APP_DIR -type f -name "*.py"   -exec chmod 600 {} \;
find $APP_DIR -type f -name "*.json" -exec chmod 600 {} \;
find $APP_DIR -name "run.py"  -exec chmod 700 {} \;
find $APP_DIR -name "*.sh"    -exec chmod 700 {} \;
# Keep uploads/ and instance/ writable by the app
chmod 700 $APP_DIR/uploads  2>/dev/null || true
chmod 700 $APP_DIR/instance 2>/dev/null || true
success "Folder locked — readable only by $USER"

# ── Start service ────────────────────────────────────────
echo ""
echo -e "${BOLD}Step 9: Starting SentinelVision...${RESET}"
sudo systemctl start sentinelvision.service
sleep 4
if sudo systemctl is-active --quiet sentinelvision.service; then
    success "SentinelVision is running!"
else
    warn "Service did not start cleanly. Check logs: sudo journalctl -u sentinelvision -n 40"
fi

PI_IP=$(hostname -I | awk '{print $1}')
echo ""
echo -e "${BOLD}==========================================${RESET}"
echo -e "${GREEN}${BOLD}  INSTALLATION COMPLETE!${RESET}"
echo -e "${BOLD}==========================================${RESET}"
echo ""
echo -e "  ${BOLD}Open your browser on any device on this network:${RESET}"
echo -e "  ${CYAN}http://${PI_IP}:5000${RESET}"
echo ""
echo -e "  ${BOLD}Login with:${RESET}"
echo -e "    Username: ${CYAN}admin${RESET}"
echo -e "    Password: (the one you just set)"
echo ""
echo -e "  ${BOLD}Useful commands:${RESET}"
echo -e "    Status : sudo systemctl status sentinelvision"
echo -e "    Logs   : sudo journalctl -u sentinelvision -f"
echo -e "    Restart: sudo systemctl restart sentinelvision"
echo ""
echo -e "  ${BOLD}Next steps:${RESET}"
echo -e "    1. Open the web interface at the URL above"
echo -e "    2. Go to Cameras → Scan Network to auto-discover your cameras/NVR"
echo -e "    3. Configure Telegram alerts in Settings"
echo -e "    4. Activate your license key at /license"
echo ""
echo -e "${BOLD}==========================================${RESET}"
echo ""

read -p "Start SentinelVision now? (y/n) " -n 1 -r
echo
if [[ $REPLY =~ ^[Yy]$ ]]; then
    sudo systemctl start sentinelvision
    sleep 3
    echo ""
    echo "SentinelVision started!"
    sudo systemctl status sentinelvision --no-pager
fi
